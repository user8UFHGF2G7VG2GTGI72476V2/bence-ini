# Features

Dino tab:
- Auto Saddle, with matching saddle selection and range.
- Auto Imprint: pet and food care. Food must be carried; walking care still requires walking.
- Auto Name, name text, range and overwrite-named option.
- Auto Claim.
- Auto Neuter, with range.
- Auto Level: eight per-stat targets and confirmed applied-point counts saved per dino across restarts.
- Auto Clone, with range.
- Auto Fill Cloning Chamber with carried element shards.
- Auto Pickup Fertilized Eggs.
- Auto Transfer Eggs into nearby owned incubators.
- Auto Hatch Eggs using a hatch action verified against the incubator's radial labels.
- Auto Enable Mating.

Misc:
- Auto Forge: deposit gasoline, distribute metal/scrap, collect ingots, send them to a matching dedicated storage and switch forges on.
- Quick Pickup, with optional action key.
- Take All on opening a remote inventory, or on an optional action key.

HUD:
- Ping, server FPS, connected players, enemy/friendly turret counts, inventory slots and server name.
- Info text scale and rainbow colors.
- Crosshair opacity.
- Tek Rifle indicator: actual aim target health, range, optional any-weapon mode, position/scale and an estimated shot count learned from health drops after firing.
- Spyglass now includes other tribes' dinos/structures, players and death bags; owner, held item, tamed stat points, color IDs, offline/decompose timers where replicated, target lock, scale and background toggle.

Appearance and configs:
- Sharpen and Reset Filter.
- Typed config names, create/save/load/delete profiles.
- Interface scale, animated menu background and Eject / Close.
- Menu hides on world changes/disconnects. Queued game calls recheck object identity and destruction flags before running.
- Crash text log for Bence and unhandled ARK exceptions seen while the debugger is attached.

## How to use

All new automation is off by default. Enable the desired Dino controls, or enable Auto Forge in Misc and select its individual actions. Materials, saddles, imprint food, eggs and shards come from your character inventory. Ordinary server reach, ownership, access, fuel and capacity rules still apply; a search range is not extended server access.

Auto Level targets count points applied by this automation, not the dino's total existing stat points. These counts are shared between profiles and saved in autolevel.dat. A server response may still refuse a request. Clone requests need a suitable adult tame and a fueled chamber. Hatch uses only actions the incubator identifies as hatching; no demolition/pickup action is guessed. Paid's optional learned net-exec hatch commands and claim-name popup suppression were not carried over.

Config names accept letters, numbers, spaces, underscores and hyphens. Configs are under %LOCALAPPDATA%/Packages/StudioWildcard.4558480580BB9_1w2mm55455e38/AC/Bence INI/profiles. Loading an older named profile defaults absent new automation to off. Save stores a profile by the typed name; Save at the bottom stores the current startup config.

Resource Pull provides inventory controls for recipe quantities and material transfers. In-game verification is pending.


