#include "tabs/config/Config.cpp"
#include <filesystem>
#include <iostream>
#include <set>
#include <stdexcept>
using namespace wintek;
void Check(bool v,const char* message){if(!v)throw std::runtime_error(message);}
int wmain(int argc,wchar_t** argv){try{
 Check(argc==2,"Pass an isolated test data directory");std::filesystem::path base=std::filesystem::absolute(argv[1]);
 _wputenv_s(L"LOCALAPPDATA",base.c_str());std::filesystem::create_directories(base/L"Packages/StudioWildcard.4558480580BB9_1w2mm55455e38/AC");LoadConfig();
 std::set<std::string> keys;for(auto& f:Fields())Check(keys.insert(f.key).second,"Duplicate config key");
 g_settings=Settings{};g_settings.dino.saddle.on=g_settings.dino.imprint.on=g_settings.dino.claim.on=g_settings.dino.level.on=g_settings.misc.autoForge.on=true;
 g_settings.misc.forgeMetal=g_settings.misc.forgeGas=true;g_settings.misc.forgeRange=27;g_settings.hud.tekIndicator.on=true;g_settings.hud.infoServerName=true;g_settings.hud.crossOpacity=41;g_settings.other.filterSharpen=1.25f;g_settings.interfaceScale=125;
 for(int i=0;i<8;++i)g_settings.dino.levelPoints[i]=i*3;
 strcpy_s(g_settings.dino.nameText,"Baby \"test\" \\ line\n\xe2\x99\xa5");ui::SetTheme("Sakura");
 std::string expected=g_settings.dino.nameText;Check(SaveConfigProfile("Port Test",true),"Create profile");Check(!SaveConfigProfile("Port Test",true),"Duplicate create must not overwrite");
 g_settings=Settings{};Check(LoadConfigProfile("Port Test"),"Load profile");Check(expected==g_settings.dino.nameText,"Escaped UTF8 name roundtrip");Check(g_settings.misc.autoForge.on&&g_settings.misc.forgeMetal&&g_settings.misc.forgeRange==27,"Forge settings roundtrip");Check(g_settings.dino.saddle.on&&g_settings.dino.level.on&&g_settings.dino.levelPoints[7]==21,"Dino settings roundtrip");Check(g_settings.hud.tekIndicator.on&&g_settings.hud.infoServerName&&g_settings.hud.crossOpacity==41,"HUD roundtrip");Check(g_settings.interfaceScale==125&&g_settings.other.filterSharpen==1.25f,"Appearance roundtrip");Check(std::string(ui::CurrentThemeName())=="Sakura","Theme roundtrip");
 g_settings.misc.forgeRange=19;Check(SaveConfigProfile("Port Test"),"Overwrite profile");g_settings.misc.forgeRange=1;Check(LoadConfigProfile("Port Test")&&g_settings.misc.forgeRange==19,"Overwrite content");
 Check(ConfigProfiles().size()==1,"List profiles");
 {FILE* f=_wfopen(ProfilePath("Old Profile").c_str(),L"wb");std::fputs("{\"crossSize\": 17}",f);std::fclose(f);}
 Check(LoadConfigProfile("Old Profile")&&g_settings.hud.crossSize==17&&!g_settings.misc.autoForge.on&&!g_settings.dino.level.on,"Old profiles must default new automation to off");
 for(auto name:{"../escape","..","C:\\bad","CON","COM1"," name","name ","bad/name"})Check(!SaveConfigProfile(name),"Unsafe profile name");
 std::string text;Check(JsonReadText("\"\\ud83d\\ude00\"",text,4)&&text=="\xf0\x9f\x98\x80","Unicode surrogate pair");Check(!JsonReadText("\"\\ud83d\"",text,64),"Unpaired surrogate");Check(!JsonReadText("\"\\u0000\"",text,64),"Embedded NUL");Check(!JsonReadText("\"12345\"",text,4),"Length limit");Check(!JsonReadText("\"unterminated",text,64),"Malformed string");
 Check(DeleteConfigProfile("Port Test")&&!DeleteConfigProfile("Port Test"),"Delete config");Check(DeleteConfigProfile("Old Profile"),"Delete old profile");
 std::cout<<"PASS: "<<keys.size()<<" unique config fields; named config lifecycle, legacy defaults, escaped UTF8, invalid names and Unicode bounds\n";return 0;
 }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
