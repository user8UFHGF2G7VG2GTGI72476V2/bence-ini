#include "../src/hud/Camera.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main() {
  wintek::CameraView view;
  view.valid=true;view.fov=90;
  view.location[0]=300;view.location[2]=100;view.yaw=180;
  const float local[3]={0,0,100};
  float x,y;
  assert(wintek::ProjectToScreen(view,local,1920,1080,x,y));
  assert(std::fabs(x-960)<0.01f&&std::fabs(y-540)<0.01f);
  const float above[3]={0,0,120};
  assert(wintek::ProjectToScreen(view,above,1920,1080,x,y)&&y<540);
  view.yaw=0;
  assert(!wintek::ProjectToScreen(view,local,1920,1080,x,y));
  view.yaw=180;view.valid=false;
  assert(!wintek::ProjectToScreen(view,local,1920,1080,x,y));
  std::puts("Actual camera projection: front-facing local marker checks passed");
}
