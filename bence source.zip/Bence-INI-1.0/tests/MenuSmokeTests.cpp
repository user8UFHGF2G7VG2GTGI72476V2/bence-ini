#include "ui/Menu.cpp"
#include "tabs/config/Config.cpp"
#include <filesystem>
#include <iostream>
#include <stdexcept>
namespace wintek{
void ResizeAppWindow(int,int){}const char* DebuggerError(){return nullptr;}const char* ConsoleError(){return nullptr;}
const char* AutoForgeStatus(){return "Waiting for a reachable owned forge.";}const char* DinoAutomationStatus(){return "Watching nearby dinos and breeding stations.";}
const char* AutoMatingStatus(){return "off";}const char* AutoChemBenchStatus(){return "off";}const char* PlayerListStatusText(){return "off";}
const char* StructureSnapStatus(){return "off";}const char* TrajectoryStatus(){return "off";}const char* OutlineStatus(){return "off";}
void ApplyStretchResolution(OtherSettings&){}void ResetStretch(OtherSettings&){}
namespace ui{extern const char* const kMenuFontNames[]={"Pixel"};extern const int kMenuFontCount=1;
void DrawLogo(ImDrawList*,const ImVec2&,float){} }
}
int main(){using namespace wintek;using namespace wintek::ui;try{
 auto check=[](bool v,const char* s){if(!v)throw std::runtime_error(s);};
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;
 auto assets=std::filesystem::path(__FILE__).parent_path().parent_path()/"assets/fonts";
 ImFont* body=io.Fonts->AddFontFromFileTTF((assets/"PixelifySans.ttf").string().c_str(),16);
 g_titleFont=io.Fonts->AddFontFromFileTTF((assets/"Silkscreen-Regular.ttf").string().c_str(),14);check(body&&g_titleFont,"Bundled menu fonts load");
 io.FontDefault=body;unsigned char* pixels;int w,h;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);io.Fonts->SetTexID((ImTextureID)1);ApplyTheme();
 int cases=0;for(bool expanded:{false,true})for(int scale:{75,100,150})for(int tab=0;tab<8;++tab){
  g_settings=Settings{};if(expanded)for(auto& field:Fields())if(field.type==Type::Bool)*static_cast<bool*>(field.value)=true;
  g_settings.interfaceScale=scale;g_menu.selected=g_menu.shown=static_cast<Tab>(tab);g_menu.alpha=1;g_menu.height=g_theme.size.y=600;
  for(int frame=0;frame<3;++frame){io.DisplaySize=ImVec2(900,900);io.DeltaTime=1.f/60;ImGui::NewFrame();NewFrame();DrawMenu();ImGui::Render();
   check(g_theme.dragExcludeMin>220,"Tab bar overlaps menu branding");auto* data=ImGui::GetDrawData();check(data&&data->TotalVtxCount>0,"Menu renders draw commands");
   for(int l=0;l<data->CmdListsCount;++l)for(auto& v:data->CmdLists[l]->VtxBuffer)check(std::isfinite(v.pos.x)&&std::isfinite(v.pos.y),"Finite menu geometry");
  }++cases;
 }
 ImGui::DestroyContext();std::cout<<"PASS: "<<cases<<" menu layouts across all eight tabs, collapsed/expanded controls and 75/100/150% settings\n";return 0;
 }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
