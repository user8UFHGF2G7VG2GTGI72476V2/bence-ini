// Synthetic UE objects in this test process. No game is opened or modified.
#include "engine/Engine.cpp"
#include "engine/QueuedObject.h"
#include "misc/Automation.cpp"
#include <deque>
#include <filesystem>
#include <iostream>
#include <stdexcept>
namespace {
struct Call {wintek::Address object,function;std::array<unsigned char,256> parameters;};
std::vector<Call> calls;std::uint64_t issued=0,completed=0;
std::deque<std::array<unsigned char,8192>> storage;
std::vector<wintek::Address> nameEntries(16384),nameChunks(128),objectEntries(65536*2);
std::array<wintek::Address,1> objectChunkPointers{};
std::array<unsigned char,64> objectGlobal{};wintek::Address tableRoot=0;int nextIndex=1,nextName=1;
std::unordered_map<std::string,int> names;
void Check(bool v,const char* message){if(!v)throw std::runtime_error(message);}
wintek::Address Block(){storage.emplace_back();storage.back().fill(0);return reinterpret_cast<wintek::Address>(storage.back().data());}
int Name(const std::string& s){auto it=names.find(s);if(it!=names.end())return it->second;int i=nextName++;auto p=Block();std::memcpy(reinterpret_cast<void*>(p+0x10),s.c_str(),s.size()+1);nameEntries[i]=p;return names[s]=i;}
wintek::Address Obj(const char* name,wintek::Address cls=0){using namespace wintek;Address p=Block();int index=nextIndex++;Write(p+offsets::object::kIndex,index);Write(p+offsets::object::kClass,cls);Write(p+offsets::object::kName,Name(name));objectEntries[index*2]=p;reinterpret_cast<int*>(objectEntries.data()+index*2)[2]=10000+index;return p;}
wintek::Address Type(const char* name,wintek::Address base=0){auto p=Obj(name);wintek::Write(p+wintek::offsets::reflection::kSuperStruct,base);return p;}
wintek::Address MakeField(wintek::Address owner,const char* name,const char* kind,int at,int bytes,unsigned char mask=0){using namespace wintek;auto p=Obj(name,Type(kind));Write(p+offsets::reflection::kPropertyOffset,at);Write(p+0x34,bytes);Write(p+offsets::reflection::kBoolFieldMask,mask);Address previous=Read<Address>(owner+offsets::reflection::kChildren);Write(p+offsets::reflection::kNext,previous);Write(owner+offsets::reflection::kChildren,p);return p;}
wintek::Address Function(wintek::Address owner,const char* name){using namespace wintek;auto p=Obj(name,Type("Function"));Address previous=Read<Address>(owner+offsets::reflection::kChildren);Write(p+offsets::reflection::kNext,previous);Write(owner+offsets::reflection::kChildren,p);return p;}
void Finish(){completed=issued;}
}
namespace wintek {
void RequestDebugger(DebuggerClient,bool){} bool DebuggerAttached(){return true;} const char* DebuggerError(){return nullptr;}
std::uint64_t CompletedCalls(){return completed;}
std::uint64_t QueueProcessEvent(Address o,Address f,Address p){Call c{o,f,{}};g_memory.ReadRaw(p,c.parameters.data(),256);calls.push_back(c);return ++issued;}
void TickDebugger(){Finish();}
bool ResourcePullBusy(){return false;}bool AutoChemBenchBusy(){return false;}
GameWindow FindGameWindow(DWORD){return {};}
namespace ui{bool ActionPressed(int){return false;}}
}
int wmain(int argc,wchar_t** argv){using namespace wintek;try{
 Check(argc==2,"Pass an isolated test data directory");auto base=std::filesystem::absolute(argv[1]);_wputenv_s(L"LOCALAPPDATA",base.c_str());std::filesystem::create_directories(base/L"Packages/StudioWildcard.4558480580BB9_1w2mm55455e38/AC/Bence INI");
 g_process.handle=OpenProcess(PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_VM_OPERATION|PROCESS_QUERY_INFORMATION,FALSE,GetCurrentProcessId());Check(g_process.handle!=nullptr,"Open test process");g_process.pid=GetCurrentProcessId();g_memory.Attach(g_process.handle);
 nameChunks[0]=reinterpret_cast<Address>(nameEntries.data());tableRoot=reinterpret_cast<Address>(nameChunks.data());g_globals.names=reinterpret_cast<Address>(&tableRoot);
 g_globals.objects=reinterpret_cast<Address>(objectGlobal.data());objectChunkPointers[0]=reinterpret_cast<Address>(objectEntries.data());Write(g_globals.objects,reinterpret_cast<Address>(objectChunkPointers.data()));Write(g_globals.objects+offsets::kObjectCount,65536);g_objectChunks={reinterpret_cast<Address>(objectEntries.data())};g_objectCount=65536;
 auto rootClass=Type("SceneComponent");MakeField(rootClass,"RelativeLocation","StructProperty",0x40,12);
 auto structureClass=Type("PrimalStructure"),dinoClass=Type("PrimalDinoCharacter"),pcClass=Type("ShooterPlayerController");
 for(auto cls:{structureClass,dinoClass}){MakeField(cls,"TargetingTeam","IntProperty",0x40,4);MakeField(cls,"RootComponent","ObjectProperty",0x48,8);}
 MakeField(dinoClass,"bIsDead","BoolProperty",0x50,1,1);MakeField(dinoClass,"DinoID1","UInt32Property",0x60,4);MakeField(dinoClass,"DinoID2","UInt32Property",0x64,4);MakeField(dinoClass,"MyCharacterStatusComponent","ObjectProperty",0x68,8);
 auto actor=[&](Address cls,int team,float x){auto p=Obj("Actor",cls),r=Obj("Root",rootClass);Write(p+0x40,team);Write(p+0x48,r);Write(r+0x40,x);return p;};
 GameContext game;game.pawn=actor(dinoClass,50001,0);game.controller=Obj("Controller",pcClass);
 Address industrial=actor(structureClass,50001,100),industrial2=actor(structureClass,50001,200),normal=actor(structureClass,50001,300),enemy=actor(structureClass,50002,200),farForge=actor(structureClass,50001,20000);
 auto queued=QueuedObject::Capture(industrial);Check(queued.Alive(),"Queued receiver starts valid");auto entry=QueuedObject::Slot(queued.index);Write(entry+8,queued.serial+1);Check(!queued.Alive(),"Queued request rejects recycled object serial");Write(entry+8,queued.serial);Write<unsigned>(industrial+offsets::object::kFlags,0x8000);Check(!queued.Alive(),"Queued request rejects destroying actors");Write<unsigned>(industrial+offsets::object::kFlags,0);
 Check(Mine(industrial,game),"Owned structures must work without a character death flag");Check(!Mine(enemy,game),"Enemy structure rejected");
 Address dead=actor(dinoClass,50001,0);Write<unsigned char>(dead+0x50,1);Check(!Mine(dead,game),"Dead dino rejected");Check(Mine(game.pawn,game),"Living owned dino accepted");
 actors={ {ObjectRef::Of(industrial),Forge|Industrial}, {ObjectRef::Of(industrial2),Forge|Industrial},{ObjectRef::Of(normal),Forge},{ObjectRef::Of(enemy),Forge|Industrial},{ObjectRef::Of(farForge),Forge|Industrial} };
 auto gasClass=Type("PrimalItemResource_Gasoline_C"),metalClass=Type("PrimalItemResource_Metal_C");MiscSettings settings;settings.forgeGas=settings.forgeMetal=true;settings.forgeRange=15;
 std::vector<Item> materials={{ {},gasClass,1,29 },{{},metalClass,2,23}};PlanForge(game,settings,materials,5000);
 Check(allocations[{industrial,0}]==15&&allocations[{industrial2,0}]==14&&!allocations.count({normal,0}),"Gas distributed only between industrial forges");
 Check(allocations[{industrial,1}]+allocations[{industrial2,1}]+allocations[{normal,1}]==23,"Metal conservation across forges");Check(!allocations.count({enemy,1})&&!allocations.count({farForge,1}),"Enemy and distant forges excluded");
 Name("Clone");Check(FindCloneName()==names["Clone"],"Clone FName resolves through both name table indirections");
 auto statusClass=Type("PrimalCharacterStatusComponent");MakeField(statusClass,"ExtraCharacterLevel","UInt16Property",0x40,2);auto status=Obj("Status",statusClass);Write(game.pawn+0x60,123u);Write(game.pawn+0x64,456u);Write(game.pawn+0x68,status);
 auto can=Function(statusClass,"CanLevelUp");MakeField(can,"Stat","ByteProperty",0,1);MakeField(can,"bCheckExperience","BoolProperty",1,1,1);MakeField(can,"ReturnValue","BoolProperty",2,1,1);
 auto level=Function(pcClass,"ServerRequestLevelUp");MakeField(level,"forStatusComp","ObjectProperty",0,8);MakeField(level,"ValueType","ByteProperty",8,1);
 DinoSettings ds;ds.levelPoints[0]=1;ds.levelPoints[1]=2;levelsLoaded=true;
 Check(StartLevel(game,game.pawn,ds,10000),"CanLevelUp query starts");Check(calls.back().parameters[0]==0,"Health queried first");Finish();Write<unsigned char>(remote+2,0);auto sentCalls=calls.size();CheckLevels(game,10200);Check(calls.size()==sentCalls,"Capped stat sends no level RPC");
 Check(StartLevel(game,game.pawn,ds,12000)&&calls.back().parameters[0]==1,"Capped stat does not starve stamina");Finish();Write<unsigned char>(remote+2,1);Check(CheckLevels(game,12200)&&calls.back().function==level,"Accepted level query sends request");Finish();
 auto id=DinoId(game.pawn);Check(levels[id].applied[1]==0&&PendingLevels(),"No optimistic level counting");ConfirmLevels(12300);Check(levels[id].applied[1]==0,"Rejected or delayed level not counted");Write<unsigned short>(status+0x40,1);
 TickAutomation(game,Settings{},true);Check(levels[id].applied[1]==1&&!PendingLevels(),"Replicated success counted while disabled/restoring");ConfirmLevels(12400);Check(levels[id].applied[1]==1,"Confirmation counted once");
 levels[id].pending=0;levels[id].before=1;levels[id].at=13000;levels[id].status=ObjectRef::Of(status);ConfirmLevels(15000);Check(levels[id].applied[0]==0&&levels[id].pending<0,"Timed out requests never increase applied points");
 auto transfer=Function(pcClass,"ServerTransferToRemoteInventory");MakeField(transfer,"InventoryComp","ObjectProperty",0,8);MakeField(transfer,"ItemID","StructProperty",8,8);MakeField(transfer,"bAlsoTryToEquip","BoolProperty",16,1,1);MakeField(transfer,"RequestedQuantity","IntProperty",20,4);
 auto item=Obj("Saddle",Type("Saddle")),inv=Obj("Inventory",Type("PrimalInventoryComponent"));visit={};visit.inventory=ObjectRef::Of(inv);visit.purpose=VisitPurpose::Saddle;
 Item saddle{ObjectRef::Of(item),ClassOf(item),1234,1};Check(Transfer(game,saddle,1,false,{}, {},16000),"Saddle transfer RPC fields resolve");Check(calls.back().parameters[16]==1&&*reinterpret_cast<int*>(calls.back().parameters.data()+20)==1,"Saddle transfer enables equip and exact quantity");Finish();visit={};
 auto beforeCalls=calls.size();Check(!Transfer(game,saddle,0,false,{}, {},17000)&&calls.size()==beforeCalls,"Zero quantity never transfers");
 // Real RemoteViewingInventories is a TArray of UObject pointers, not weak handles.
 MakeField(pcClass,"RemoteViewingInventories","ArrayProperty",0x100,16);
 auto takeFn=Function(pcClass,"ServerTransferAllFromRemoteInventory");MakeField(takeFn,"InventoryComp","ObjectProperty",0,8);
 auto remoteList=Block();Write(remoteList,inv);TArray viewing{remoteList,1,1};Write(game.controller+0x100,viewing);
 MiscSettings takeSettings;takeSettings.takeAll.on=true;openedUI=takenUI=0;
 Check(!TakeAll(game,123,takeSettings,20000),"Take All waits for inventory to settle");
 Check(TakeAll(game,123,takeSettings,20700)&&calls.back().function==takeFn,"Take All accepts a raw inventory pointer");Finish();
 Check(!TakeAll(game,123,takeSettings,21000),"Take All only sends once per opening");
 openedUI=takenUI=0;Write(game.pawn+0x120,inv);MakeField(dinoClass,"MyInventoryComponent","ObjectProperty",0x120,8);
 TakeAll(game,124,takeSettings,22000);Check(!TakeAll(game,124,takeSettings,22700),"Take All rejects player inventory");
 levelsDirty=true;SaveLevels();Check(!levelsDirty,"Level ledger saved atomically");levels.clear();levelsLoaded=false;LoadLevels();Check(levels[id].applied[1]==1&&levels[id].applied[0]==0,"Confirmed level counts survive restart");
 ResetAutomation();g_memory.Detach();std::cout<<"PASS: synthetic ownership, forge distribution/access range, name lookup, capped stats, confirmed level persistence, saddle RPC parameters and zero-quantity guard\n";return 0;
 }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}



