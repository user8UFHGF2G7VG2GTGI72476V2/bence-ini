#include "../src/misc/SnapMath.h"
#include <cassert>
#include <limits>
#include <cstdio>

bool near(float a,float b) { return std::fabs(a-b)<0.002f; }
int main() {
  const float origin[3]={1000,-2000,0};
  float p[3]={1149,-2149,37},r[3]={3,44,-2};
  assert(wintek::AlignSnapGrid(p,r,origin,0,100,90));
  assert(near(p[0],1100)&&near(p[1],-2100)&&near(p[2],37));
  assert(near(r[0],3)&&near(r[1],0)&&near(r[2],-2));
  p[0]=1149;p[1]=-1851;r[1]=132;
  assert(wintek::AlignSnapGrid(p,r,origin,90,100,90));
  assert(near(p[0],1100)&&near(p[1],-1900)&&near(r[1],90));
  const float diagonal[3]={7,9,0};
  p[0]=7+std::sqrt(0.5f)*144;p[1]=9+std::sqrt(0.5f)*144;r[1]=765;
  assert(wintek::AlignSnapGrid(p,r,diagonal,45,100,90));
  assert(near(p[0],7+std::sqrt(0.5f)*100)&&near(p[1],9+std::sqrt(0.5f)*100)&&near(r[1],45));
  float oldP[3]={p[0],p[1],p[2]},oldR=r[1];
  assert(wintek::AlignSnapGrid(p,r,diagonal,45,100,90));
  assert(near(p[0],oldP[0])&&near(p[1],oldP[1])&&near(r[1],oldR));
  p[0]=std::numeric_limits<float>::quiet_NaN();
  assert(!wintek::AlignSnapGrid(p,r,origin,0,100,90));
  p[0]=1000;p[1]=-2000;r[1]=179;
  assert(wintek::AlignSnapGrid(p,r,origin,-179,100,90));
  assert(near(r[1],-179));
  const wintek::SnapFootprint footprint={-50,50,-30,30};
  const float vaultAnchor[3]={1000,2000,0};
  p[0]=1149;p[1]=2010;p[2]=37;r[0]=0;r[1]=18;r[2]=0;
  assert(wintek::DockVault(p,r,vaultAnchor,0,footprint,footprint,2));
  assert(near(p[0],1102)&&near(p[1],2000)&&near(p[2],37)&&near(r[1],0));
  assert(wintek::DockVault(p,r,vaultAnchor,0,footprint,footprint,2));
  assert(near(p[0],1102)&&near(p[1],2000));
  p[0]=1000;p[1]=2149;
  assert(wintek::DockVault(p,r,vaultAnchor,90,footprint,footprint,2));
  assert(near(p[0],1000)&&near(p[1],2102)&&near(r[1],90));
  const wintek::SnapFootprint offCenter={0,100,-20,40};
  p[0]=1149;p[1]=2000;
  assert(wintek::DockVault(p,r,vaultAnchor,0,offCenter,offCenter,2));
  assert(near(p[0],1102)&&near(p[1],2000));
  p[0]=1000;p[1]=1900;
  assert(wintek::DockVault(p,r,vaultAnchor,0,footprint,footprint,2));
  assert(near(p[0],1000)&&near(p[1],1938));
  assert(!wintek::DockVault(p,r,vaultAnchor,0,footprint,footprint,-1));
  wintek::SnapFootprint reconstructed;
  const float c=std::cos(3.14159265359f/6),sn=std::sin(3.14159265359f/6);
  float center[3]={1000+c*50-sn*10,2000+sn*50+c*10,80};
  float extent[3]={c*50+sn*30,sn*50+c*30,80};
  assert(wintek::FootprintFromWorldBounds(vaultAnchor,30,center,extent,reconstructed));
  assert(near(reconstructed.minX,0)&&near(reconstructed.maxX,100)&&near(reconstructed.minY,-20)&&near(reconstructed.maxY,40));
  assert(!wintek::FootprintFromWorldBounds(vaultAnchor,45,center,extent,reconstructed));
  extent[0]=0;assert(!wintek::FootprintFromWorldBounds(vaultAnchor,0,center,extent,reconstructed));
  const float minimum[3]={-50,-30,0},maximum[3]={50,30,100},unitScale[3]={1,1,1};
  assert(wintek::FootprintFromLocalBox(minimum,maximum,nullptr,0,unitScale,reconstructed));
  assert(near(reconstructed.minX,-50)&&near(reconstructed.maxY,30));
  wintek::SnapLocalTransform transforms[2];
  transforms[0].position[0]=10;transforms[0].position[1]=20;transforms[0].rotation[1]=90;
  const float scaledRoot[3]={2,3,1};
  assert(wintek::FootprintFromLocalBox(minimum,maximum,transforms,1,scaledRoot,reconstructed));
  assert(near(reconstructed.minX,-40)&&near(reconstructed.maxX,80)&&near(reconstructed.minY,-90)&&near(reconstructed.maxY,210));
  transforms[0]={};transforms[0].position[0]=100;
  transforms[1].position[0]=10;transforms[1].position[1]=20;transforms[1].rotation[1]=90;
  assert(wintek::FootprintFromLocalBox(minimum,maximum,transforms,2,unitScale,reconstructed));
  assert(near(reconstructed.minX,-20)&&near(reconstructed.maxX,40)&&near(reconstructed.minY,70)&&near(reconstructed.maxY,170));
  assert(!wintek::FootprintFromLocalBox(minimum,minimum,nullptr,0,unitScale,reconstructed));
  assert(!wintek::FootprintFromLocalBox(minimum,maximum,nullptr,1,unitScale,reconstructed));
  transforms[0].scale[0]=std::numeric_limits<float>::quiet_NaN();
  assert(!wintek::FootprintFromLocalBox(minimum,maximum,transforms,1,unitScale,reconstructed));
  std::puts("Grid, vault docking and mesh-bound transform checks passed");
}
