# Vault snap bounds recovery — v28.15

This revision targets the screenshot showing “Game returned unusable vault bounds; no custom snap applied.” Earlier code permanently cached a failed measurement and prevented any further vault snapping for that class until restart.

The bounds reader now tries: collision-only actor bounds; all-component actor bounds; then StaticMeshComponent.GetLocalBounds. The local-mesh path follows attachment transforms and component/root scale into actor-local space, so it does not depend on inverting world bounds at a 45-degree heading. All function names, parameter fields and component transforms are looked up through reflection. Invalid results are rejected. If every method fails, measurement retries after five seconds rather than becoming permanently disabled.

Use Structure Snap > Vaults with a matching owned vault within 10 metres. The cyan marker remains the calculated target. Preview OK/failed counters report the engine transform function's return value; request counts report edits to placement parameters, not server acceptance. Foundations and native snap-point structures remain excluded from custom snapping.

Validation: Release build passed. Direct tests of production helpers passed for grid/docking geometry, rotated anchors, off-center pivots, spacing gaps, transform chains, component/root scaling, idempotence and invalid input rejection. The prior permanent-failure cache and message are removed. ARK is not running in this environment, so the bounds fallback functions, retained preview movement and final server-accepted placement remain unverified in-game.

The mesh path assumes an upright vault with positive scale and a static mesh attached beneath the actor root. It selects the root mesh, a named main mesh, or the first reflected static mesh component. Unusual multi-mesh, modded, animated or differently scaled matching-class vaults may require more handling. Matching vault classes and normal server placement rules still apply. Corrupted Dino ESP and Turret Snap are preserved.
