@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>&1 || (echo CMake is not installed or not on PATH. Install it from https://cmake.org/download/ & goto fail)
cmake -S . -B build -G "Visual Studio 18 2026" -A x64
if errorlevel 1 (
  if exist build rmdir /s /q build
  cmake -S . -B build -G "Visual Studio 17 2022" -A x64
)
if errorlevel 1 (echo. & echo Could not set up the build. Make sure Visual Studio 2022+ with "Desktop development with C++" is installed. & goto fail)
cmake --build build --config Release
if errorlevel 1 goto fail
copy /y "build\Release\Bence INI.exe" "Bence INI.exe" >nul
echo.
echo Done! Bence INI.exe is in this folder.
pause
exit /b 0
:fail
echo.
echo BUILD FAILED - screenshot this window and send it.
pause
exit /b 1
