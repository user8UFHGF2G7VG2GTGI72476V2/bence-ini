# Black Structure — v28.22

INI > Black Structure enables a local black-material override for loaded metal structure meshes. It has a saved toggle and optional hotkey. Discovery scans every five seconds. Actor class ancestry must identify a PrimalStructure with a metal-named class, or the standard StorageBox_Huge vault class. This does not claim support for every modded or differently named metal object, nor unloaded structures.

Unlike Black Sky, this keeps meshes visible. The shader search prefers a loaded opaque surface material with an unlit, directly parameterized emissive color, creates a private dynamic instance and sets that color to black. A strictly named loaded opaque black material can also be used. The code does not change shared parent material parameters or disable depth testing. If no compatible loaded shader is found, no structure materials are changed; Config > Diagnostics reports the missing resource and discovery retries.

Original slot materials are captured before overrides and restored when the option is disabled. Normal close attempts to drain restore calls for up to three seconds. Restoration requires original materials and meshes to remain alive, and engine calls to complete. Destroyed/unloaded objects are skipped. Abrupt termination, game-side replacement of a mesh/material or garbage collection of an original dynamic material can prevent restoration. Reapplying an override after the game independently changes a slot is not implemented in this revision.

Validation: Release build passed. Shader availability, class matching and appearance/restoration have not been verified in ARK here. The Config diagnostic counts completed material-setting calls, not visually confirmed black pixels.

The Write players.json switch is removed from the HUD tab. Player List always writes players.json when it obtains an updated list; old configuration values cannot disable that behavior. Existing server/admin access requirements for retrieving player data remain unchanged.
