#include "client/Renderer.h"

namespace wintek {

namespace {

template <typename T>
void SafeRelease(T*& p) {
  if (p) p->Release();
  p = nullptr;
}

}  // namespace

bool Renderer::Create(HWND window) {
  window_ = window;
  DXGI_SWAP_CHAIN_DESC desc{};
  desc.BufferCount = 2;
  desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  desc.BufferDesc.RefreshRate = { 60, 1 };
  desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
  desc.OutputWindow = window;
  desc.SampleDesc.Count = 1;
  desc.Windowed = TRUE;
  desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
  const D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
  if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, levels, 2, D3D11_SDK_VERSION, &desc,
                                           &swapChain_, &device_, nullptr, &context_)))
    return false;
  CreateTarget();
  return true;
}

void Renderer::Destroy() {
  ReleaseTarget();
  SafeRelease(swapChain_);
  SafeRelease(context_);
  SafeRelease(device_);
}

void Renderer::Resize(int width, int height) {
  if (!device_ || !swapChain_) return;
  ReleaseTarget();
  swapChain_->ResizeBuffers(0, width, height, DXGI_FORMAT_UNKNOWN, 0);
  CreateTarget();
}

void Renderer::BeginFrame() {
  const float clear[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
  context_->OMSetRenderTargets(1, &target_, nullptr);
  context_->ClearRenderTargetView(target_, clear);
}

void Renderer::EndFrame() {
  const HRESULT result = swapChain_->Present(1, 0);  // vsync
  if (result == DXGI_ERROR_DEVICE_REMOVED || result == DXGI_ERROR_DEVICE_RESET) {
    Destroy();
    Create(window_);
  }
}

void Renderer::CreateTarget() {
  ID3D11Texture2D* backBuffer = nullptr;
  if (FAILED(swapChain_->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) return;
  device_->CreateRenderTargetView(backBuffer, nullptr, &target_);
  backBuffer->Release();
}

void Renderer::ReleaseTarget() { SafeRelease(target_); }

}  // namespace wintek
