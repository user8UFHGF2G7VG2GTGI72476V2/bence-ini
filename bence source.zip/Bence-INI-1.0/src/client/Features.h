#pragma once

namespace wintek {

// Applies the current settings to the game. Call every frame; it does the work about 30 times a second
// and handles the game being started, restarted or closed.
void TickFeatures();

// Undoes everything WinTek changed in the game. Called when WinTek closes.
void RestoreFeatures();

}  // namespace wintek
