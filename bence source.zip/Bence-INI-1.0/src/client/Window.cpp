#include "client/Window.h"
#include "core/Settings.h"
#include "client/Features.h"
#include "client/Renderer.h"
#include "engine/Debugger.h"
#include "ui/Theme.h"
#include "ui/Widgets.h"
#include "imgui.h"
#include <dwmapi.h>
#include <algorithm>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace wintek {

namespace {

constexpr const wchar_t* kClassName = L"BenceINIWindow";
HWND g_window = nullptr;

// The top bar moves the window, except where the tab pills are; everything else is normal client area.
LRESULT HitTest(HWND window, LPARAM lParam) {
  POINT p{ static_cast<short>(LOWORD(lParam)), static_cast<short>(HIWORD(lParam)) };
  ScreenToClient(window, &p);
  const float scale=std::clamp(g_settings.interfaceScale,75,150)/100.f;p.x=static_cast<LONG>(p.x/scale);p.y=static_cast<LONG>(p.y/scale);
  const ui::Theme& t = ui::g_theme;
  const bool inHeader = p.y >= 0 && p.y < static_cast<int>(t.headerHeight);
  const bool onTabs = p.x >= static_cast<int>(t.dragExcludeMin) && p.x < static_cast<int>(t.dragExcludeMax);
  return inHeader && !onTabs ? HTCAPTION : HTCLIENT;
}

// Right click works like left click everywhere in the menu: toggles, buttons, sliders, tabs. The one exception is
// while a hotkey box is waiting for a key, so right mouse can still be bound as a hotkey.
void RightClickAsLeft(UINT& message, WPARAM& wParam) {
  static bool translating = false;  // the right button went down as a left click, so it comes up as one too
  switch (message) {
    case WM_RBUTTONDOWN:
    case WM_RBUTTONDBLCLK:
      if (ui::IsBindingKey()) return;
      translating = true;
      message = message == WM_RBUTTONDOWN ? WM_LBUTTONDOWN : WM_LBUTTONDBLCLK;
      break;
    case WM_RBUTTONUP:
      if (!translating) return;
      translating = false;
      message = WM_LBUTTONUP;
      break;
    default:
      return;
  }
  if (wParam & MK_RBUTTON) wParam = (wParam & ~MK_RBUTTON) | MK_LBUTTON;
}

LRESULT WINAPI WindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
  RightClickAsLeft(message, wParam);
  if (ImGui_ImplWin32_WndProcHandler(window, message, wParam, lParam)) return 1;
  switch (message) {
    case WM_SIZE:
      if (wParam != SIZE_MINIMIZED) g_renderer.Resize(LOWORD(lParam), HIWORD(lParam));
      return 0;
    case WM_NCHITTEST:
      return HitTest(window, lParam);
    case WM_CLOSE:
      AnimateWindow(window, 150, AW_BLEND | AW_HIDE);
      DestroyWindow(window);
      return 0;
    case WM_ENDSESSION:
      // Shutting down or signing out ends the process without a WM_QUIT, so undo everything here.
      if (wParam) {
        RestoreFeatures();
        StopDebugger();
      }
      return 0;
    case WM_DESTROY:
      PostQuitMessage(0);
      return 0;
  }
  return DefWindowProcW(window, message, wParam, lParam);
}

}  // namespace

HWND CreateAppWindow() {
  WNDCLASSEXW wc{ sizeof(wc) };
  wc.lpfnWndProc = WindowProc;
  wc.hInstance = GetModuleHandleW(nullptr);
  wc.lpszClassName = kClassName;
  wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
  wc.hIcon = LoadIconW(wc.hInstance, L"APP_ICON");
  wc.hIconSm = wc.hIcon;
  RegisterClassExW(&wc);

  const int width = static_cast<int>(ui::g_theme.size.x), height = static_cast<int>(ui::g_theme.size.y);
  const int x = (std::max)(0, (GetSystemMetrics(SM_CXSCREEN) - width) / 2);
  const int y = (std::max)(0, (GetSystemMetrics(SM_CYSCREEN) - height) / 2);
  g_window = CreateWindowExW(WS_EX_APPWINDOW | WS_EX_LAYERED, kClassName, L"Bence INI", WS_POPUP | WS_MINIMIZEBOX, x, y, width, height,
                             nullptr, nullptr, wc.hInstance, nullptr);
  if (!g_window) return nullptr;
  // Fully opaque, but layered + an extended frame lets the rounded corners show the desktop through.
  SetLayeredWindowAttributes(g_window, 0, 255, LWA_ALPHA);
  const MARGINS margins{ -1, -1, -1, -1 };
  DwmExtendFrameIntoClientArea(g_window, &margins);
  return g_window;
}

bool IsAppWindowVisible() { return g_window && IsWindowVisible(g_window); }

void ToggleAppWindow() {
  if (!g_window) return;
  if (IsWindowVisible(g_window)) {
    AnimateWindow(g_window, 120, AW_BLEND | AW_HIDE);
    return;
  }
  if (IsIconic(g_window)) ShowWindow(g_window, SW_RESTORE);
  AnimateWindow(g_window, 120, AW_BLEND);
  ShowWindow(g_window, SW_SHOW);
  // Windows only lets a background app take focus right after a key event like this one, so ask now.
  SetWindowPos(g_window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
  SetWindowPos(g_window, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
  SetForegroundWindow(g_window);
}

void ResizeAppWindow(int width, int height) {
  const float scale=std::clamp(g_settings.interfaceScale,75,150)/100.f;
  SetWindowPos(g_window, nullptr, 0, 0, static_cast<int>(width*scale), static_cast<int>(height*scale), SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

}  // namespace wintek
