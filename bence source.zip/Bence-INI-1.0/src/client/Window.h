#pragma once
#include <windows.h>

namespace wintek {

// The borderless app window, centred on screen. The strip along the top of the card drags it.
HWND CreateAppWindow();
void ResizeAppWindow(int width, int height);
// Hides the menu if it's showing, shows it (in front) if it's hidden.
void ToggleAppWindow();
bool IsAppWindowVisible();

}  // namespace wintek
