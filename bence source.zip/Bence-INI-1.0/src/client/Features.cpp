#include "client/Features.h"
#include "client/Window.h"
#include "core/Diagnostics.h"
#include "core/Process.h"
#include "core/Settings.h"
#include "engine/Console.h"
#include "engine/Engine.h"
#include "engine/ShowFlagProbe.h"
#include "tabs/visual/Visual.h"
#include "hud/GameInfo.h"
#include "hud/AimTarget.h"
#include "hud/Spyglass.h"
#include "hud/PlayerList.h"
#include "hud/Camera.h"
#include "hud/Targeting.h"
#include "misc/TurretFiller.h"
#include "misc/BetterInput.h"
#include "misc/AutoMating.h"
#include "misc/Automation.h"
#include "misc/AutoChemBench.h"
#include "misc/ResourcePull.h"
#include "tabs/ini/BlackSky.h"
#include "tabs/ini/BlackStructures.h"
#include "tabs/ini/LowMemory.h"
#include "engine/PostProcessVolumes.h"
#include "tabs/ini/Fullbright.h"
#include "tabs/ini/NoHands.h"
#include "tabs/ini/NoHud.h"
#include "tabs/ini/NoWater.h"
#include "tabs/ini/NoXyz.h"
#include "tabs/ini/StalkerIni.h"
#include "tabs/ini/ViewMode.h"
#include "tabs/other/ColorFilter.h"
#include "tabs/other/Fov.h"
#include "tabs/other/StretchedRes.h"
#include <windows.h>
#include <algorithm>

namespace wintek {

namespace {

constexpr DWORD kTickMs = 30;

struct {
  DWORD pid = 0;      // the game process the engine was set up for
  bool ready = false;  // its signatures matched
} g_session;

// `restoring` is set when called with default settings to undo everything; background scans aren't started then.
void Apply(const Settings& s, bool restoring) {
  RefreshObjectTable();
  const GameContext game = ReadContext();
  static Address shownWorld=0;
  if(shownWorld&&shownWorld!=game.world){if(IsAppWindowVisible())ToggleAppWindow();shownWorld=0;}
  if(game.world&&game.pawn)shownWorld=game.world;
  TickShowFlagProbe(game.viewport);  // before anything writes the view flags
  TickViewMode(s, game.viewport);
  TickDisplayGamma(s, game.engine);
  TickNoHud(s.ini, game.hud);
  TickFov(s.other, game.camera, game.pawn);
  TickNoHands(s.ini, game.pawn);

  const bool volumesNeeded = s.other.vibrance || s.other.colorFilter || s.ini.noWater.on || s.ini.stalker.on || s.hud.playerOutlines.on || s.hud.turretOutlines.on;
  TrackVolumes(game.world, volumesNeeded && !restoring);
  TickNoWater(s.ini, game.world, restoring);  // before No XYZ: a world change here cancels running scans
  TickNoXyz(s.ini, restoring);
  TickColorGrading(s.other);
  IniSettings outlineIni=s.ini;
  if(s.hud.playerOutlines.on || s.hud.turretOutlines.on) {
    outlineIni.stalker.on=true;
    outlineIni.stalkerDistance=(std::max)(outlineIni.stalkerDistance,static_cast<float>(s.hud.outlineRange));
  }
  TickStalkerIni(outlineIni, game, restoring);
  TickStretchedRes(s.other);
  TickBlackSky(s.ini, s.visual, game.world, restoring);
  TickBlackStructures(game, s.ini.blackStructures.on && !restoring);
  TickLowMemory(s.ini, restoring);
  TickVisual(s.visual, restoring);
  TickConsole(game);
  TickGameInfo(game, !restoring && s.hud.info.on && s.hud.infoFps);
  TickAimTarget(game,s.hud,restoring);
  TickSpyglass(game, !restoring && s.hud.spyglass.on, static_cast<float>(s.hud.spyRange));
  TickCorruptedEsp(game, !restoring && s.hud.corruptedEsp.on, static_cast<float>(s.hud.corruptedEspRange));
  TickResourcePull(game, s.misc, restoring);
  TickAutomation(game, s, restoring);
  MiscSettings chem = s.misc;
  if (AutomationInventoryBusy()||ResourcePullBusy()) chem.autoChemBench.on=false;
  TickAutoChemBench(game, chem, restoring);
  TickAutoMating(game, s.misc, restoring);
  TickStructureSnap(game, s.misc, restoring);
  TickPenisEsp(game, !restoring && s.hud.penisEsp.on);
  TickCamera(game);
  TickTargeting(game,s.hud,restoring);
  TickPlayerList(game, !restoring && s.hud.playerList.on, s.hud.playerRefresh);
  TickTurretFiller(game, s.misc, restoring);
  TickBetterInput(game, s.misc, restoring || ResourcePullBusy());
}

void ResetAll() {
  ResetEngine();
  ResetVolumes();
  ResetViewMode();
  ResetDisplayGamma();
  ResetNoHud();
  ResetFov();
  ResetNoHands();
  ResetNoXyz();
  ResetNoWater();
  ResetStalkerIni();
  ResetBlackSky();
  ResetBlackStructures();
  ResetLowMemory();
  ResetVisual();
  ResetShowFlagProbe();
  ResetConsole();
  ResetGameInfo();
  ResetAimTarget();
  ResetSpyglass();
  ResetPlayerList();
  ResetCamera();
  ResetTargeting();
  ResetTurretFiller();
  ResetBetterInput();
  ResetAutoMating();
  ResetAutomation();
  ResetAutoChemBench();
  ResetResourcePull();
}

}  // namespace

void TickFeatures() {
  if (!g_process.IsAttached()) {
    if (g_session.pid) {
      ResetAll();
      g_session = {};
      g_diag = {};
    }
    return;
  }
  if (g_session.pid != g_process.pid) {
    ResetAll();
    g_session.pid = g_process.pid;
    g_session.ready = InitEngine();
    g_diag.engineReady = g_session.ready;
  }
  if (!g_session.ready) return;

  static DWORD lastTick = 0;
  const DWORD now = GetTickCount();
  if (now - lastTick < kTickMs) return;
  lastTick = now;
  Apply(g_settings, false);
}

void RestoreFeatures() {
  if (g_session.ready && g_process.IsAttached()) {
    Apply(Settings{}, true);
    FlushConsole(2500);  // Low Memory's render scale is set back through the game, which takes a few frames
    FlushBlackStructures(3000);
    FlushTargeting(3000);
    FlushAimTarget(1500);
    FlushResourcePull(2500);
    FlushAutomation(3000);
  }
}

}  // namespace wintek
