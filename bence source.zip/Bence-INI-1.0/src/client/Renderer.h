#pragma once
#include <windows.h>
#include <d3d11.h>

namespace wintek {

// The D3D11 device and swap chain ImGui draws into.
class Renderer {
public:
  bool Create(HWND window);
  void Destroy();
  void Resize(int width, int height);
  void BeginFrame();
  void EndFrame();

  ID3D11Device* device() const { return device_; }
  ID3D11DeviceContext* context() const { return context_; }

private:
  void CreateTarget();
  void ReleaseTarget();

  HWND window_ = nullptr;
  ID3D11Device* device_ = nullptr;
  ID3D11DeviceContext* context_ = nullptr;
  IDXGISwapChain* swapChain_ = nullptr;
  ID3D11RenderTargetView* target_ = nullptr;
};

inline Renderer g_renderer;

}  // namespace wintek
