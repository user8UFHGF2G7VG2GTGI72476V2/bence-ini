#include "ui/Menu.h"
#include <algorithm>
#include "client/Window.h"
#include "tabs/config/ConfigTab.h"
#include "tabs/hud/HudTab.h"
#include "tabs/misc/MiscTab.h"
#include "tabs/dino/DinoTab.h"
#include "tabs/structure/StructureSnapTab.h"
#include "tabs/visual/VisualTab.h"
#include "tabs/ini/IniTab.h"
#include "tabs/other/OtherTab.h"
#include "core/Settings.h"
#include "tabs/config/Themes.h"
#include "ui/Hotkeys.h"
#include "ui/MenuColors.h"
#include "ui/Layout.h"
#include "ui/Logo.h"
#include "ui/Pixel.h"
#include "ui/Theme.h"
#include "ui/Widgets.h"
#include "imgui_internal.h"
#include <cmath>

namespace wintek::ui {

namespace {

enum class Tab { Ini, Visual, Hud, Other, Dino, Misc, StructureSnap, Config };

struct TabInfo {
  const char* sidebarLabel;
  const char* cardTitle;
};
constexpr TabInfo kTabs[] = { { "INI", "INI settings" }, { "Visual", "Visual settings" }, { "HUD", "HUD overlays" }, { "Other", "Other" }, { "Dino", "Dino Automation" }, { "Misc", "Misc" }, { "Structure Snap", "Structure Snap" }, { "Config", "Config" } };

// Top bar, gap, card title strip + insets, and the bottom padding.
constexpr float kCardChrome = 64.0f + 14.0f + 40.0f + 14.0f * 1.5f + 14.0f;
constexpr float kMinHeight = 300.0f;
constexpr const char* kMenuName = "Bence";
constexpr const char* kMenuNameAccent = " INI";
constexpr float kLogoSize = 40.0f;
constexpr float kTabHeight = 30.0f;
constexpr float kTabGap = 4.0f;
constexpr float kMaxHeight = 1000.0f;
constexpr float kResizeSpeed = 10.0f;
constexpr float kFadeSpeed = 6.0f;
constexpr float kSlideDistance = 10.0f;

struct {
  Tab selected = Tab::Ini;
  Tab shown = Tab::Ini;  // lags `selected` while the old tab fades out
  float alpha = 1.0f;
  float height = 0.0f;
} g_menu;

float ContentHeight(Tab tab) {
  switch (tab) {
    case Tab::Ini: return IniTabHeight();
    case Tab::Visual: return VisualTabHeight();
    case Tab::Hud: return HudTabHeight();
    case Tab::Other: return OtherTabHeight();
    case Tab::Misc: return MiscTabHeight();
    case Tab::Dino: return DinoTabHeight();
    case Tab::StructureSnap: return StructureSnapTabHeight();
    case Tab::Config: return ConfigTabHeight();
  }
  return 0.0f;
}

float FrameDelta() {
  const float dt = ImGui::GetIO().DeltaTime;
  return dt <= 0.0f ? 0.016f : (dt > 0.05f ? 0.05f : dt);
}

// Eases the window's height toward what the selected tab needs.
void ResizeToFit(float dt) {
  // Every row already counts the item spacing after it, so the last one's is taken off.
  const float limit=(std::min)(kMaxHeight,(GetSystemMetrics(SM_CYSCREEN)-80.f)/(std::clamp(g_settings.interfaceScale,75,150)/100.f));
  const float target = ImClamp(ContentHeight(g_menu.selected) - kItemSpacing + kCardChrome, kMinHeight, (std::max)(kMinHeight,limit));
  static int lastScale=0;const bool scaleChanged=lastScale!=g_settings.interfaceScale;lastScale=g_settings.interfaceScale;
  if (g_menu.height <= 0.0f) g_menu.height = g_theme.size.y;
  g_menu.height += (target - g_menu.height) * ImMin(dt * kResizeSpeed, 1.0f);
  if (ImFabs(target - g_menu.height) < 0.5f) g_menu.height = target;
  if (scaleChanged || static_cast<int>(g_menu.height) != static_cast<int>(g_theme.size.y)) {
    g_theme.size.y = g_menu.height;
    ResizeAppWindow(static_cast<int>(g_theme.size.x), static_cast<int>(g_menu.height));
    ImGui::GetIO().DisplaySize = g_theme.size;
  }
}

// Fades the old tab out, swaps, then fades the new one in.
void AnimateTabSwitch(float dt) {
  if (g_menu.shown != g_menu.selected) {
    g_menu.alpha -= dt * kFadeSpeed;
    if (g_menu.alpha <= 0.0f) {
      g_menu.alpha = 0.0f;
      g_menu.shown = g_menu.selected;
    }
  } else if (g_menu.alpha < 1.0f) {
    g_menu.alpha = ImMin(g_menu.alpha + dt * kFadeSpeed, 1.0f);
  }
}

ImVec4 AccentB() {
  float h, sat, v;
  ImGui::ColorConvertRGBtoHSV(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, h, sat, v);
  float r, g, b;
  ImGui::ColorConvertHSVtoRGB(std::fmod(h + 0.09f, 1.0f), sat, (std::min)(1.0f, v * 1.12f + 0.05f), r, g, b);
  return ImVec4(r, g, b, 1.0f);
}

// The rounded window: a dark gradient, two soft accent glows, the top bar and a gradient line under it.
void DrawBackground(const ImVec2& pos, const ImVec2& size) {
  ImDrawList* dl = ImGui::GetWindowDrawList();
  const ImVec2 end = pos + size;
  const float r = g_theme.rounding + 4.0f;
  const int first = dl->VtxBuffer.Size;
  dl->AddRectFilled(pos, end, IM_COL32_WHITE, r);
  ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, first, dl->VtxBuffer.Size, pos, ImVec2(pos.x, end.y), Color(g_theme.bgSoft), Color(g_theme.bg));
  // soft glows in the accent colours, kept inside the rounded window
  dl->PushClipRect(ImVec2(pos.x + 2.0f, pos.y + 2.0f), ImVec2(end.x - 2.0f, end.y - 2.0f), true);
  for (int i = 24; i >= 1; --i) {  // many faint rings so the glow fades smoothly
    ImVec4 a = g_theme.accent, b = AccentB();
    a.w = 0.007f;
    b.w = 0.006f;
    dl->AddCircleFilled(ImVec2(pos.x + size.x * 0.12f, pos.y - 20.0f), 40.0f + i * 10.0f, Color(a), 64);
    dl->AddCircleFilled(ImVec2(end.x - 40.0f, end.y + 30.0f), 30.0f + i * 9.0f, Color(b), 64);
  }
  if(g_settings.menuBackgroundEffect){const float time=static_cast<float>(ImGui::GetTime());ImVec4 color=g_theme.accent;color.w=0.16f;for(int i=0;i<24;++i){float x=pos.x+std::fmod(i*137.f+time*(4+i%3),size.x-12)+6;float y=pos.y+std::fmod(i*73.f+time*(2+i%5),size.y-12)+6;dl->AddCircleFilled(ImVec2(x,y),1.5f,Color(color),8);if(i%2==0)dl->AddLine(ImVec2(x,y),ImVec2(x+20,y-18),Color(color));}}
  dl->PopClipRect();
  // top bar line: accent gradient fading out at both ends
  const float y = pos.y + g_theme.headerHeight;
  const ImVec4 clear = ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.0f);
  const float mid = pos.x + size.x * 0.5f;
  dl->AddRectFilledMultiColor(ImVec2(pos.x + 16.0f, y), ImVec2(mid, y + 1.0f), Color(clear), Color(g_theme.topLine), Color(g_theme.topLine), Color(clear));
  ImVec4 b = AccentB(), bClear = b;
  bClear.w = 0.0f;
  dl->AddRectFilledMultiColor(ImVec2(mid, y), ImVec2(end.x - 16.0f, y + 1.0f), Color(g_theme.topLine), Color(bClear), Color(bClear), Color(g_theme.topLine));
  ImVec4 edge = g_theme.border;
  edge.w = 0.9f;
  dl->AddRect(pos, end, Color(edge), r, 0, 1.0f);
}

// Logo and "Bence INI" at the left of the top bar.
void DrawBrand(const ImVec2& pos) {
  ImDrawList* dl = ImGui::GetWindowDrawList();
  const ImVec2 logoPos(pos.x + 18.0f, pos.y + std::floor((g_theme.headerHeight - kLogoSize) * 0.5f));
  ImVec4 ring = g_theme.accent;
  ring.w = 0.35f;
  dl->AddCircle(ImVec2(logoPos.x + kLogoSize * 0.5f, logoPos.y + kLogoSize * 0.5f), kLogoSize * 0.5f + 3.0f, Color(ring), 40, 1.5f);
  DrawLogo(dl, logoPos, kLogoSize);

  ImFont* font = g_titleFont ? g_titleFont : ImGui::GetFont();
  const float fontSize = (g_titleFont ? g_titleFont->FontSize : ImGui::GetFontSize()) * 1.15f;
  const ImVec2 nameSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, kMenuName);
  const float x = logoPos.x + kLogoSize + 14.0f;
  const float y = std::floor(pos.y + (g_theme.headerHeight - nameSize.y) * 0.5f) - 7.0f;
  dl->AddText(font, fontSize, ImVec2(x, y), Color(g_theme.title), kMenuName);
  dl->AddText(font, fontSize, ImVec2(x + nameSize.x, y), Color(g_theme.accent), kMenuNameAccent);
  ImVec4 dim = g_theme.textDim;
  dl->AddText(ImVec2(x, y + nameSize.y + 3.0f), Color(dim), "ARK external menu");
}

// The tab pills, right-aligned in the top bar.
void DrawTabs(const ImVec2& pos, const ImVec2& size) {
  float total = 0.0f;
  float widths[IM_ARRAYSIZE(kTabs)];
  for (int i = 0; i < IM_ARRAYSIZE(kTabs); ++i) {
    widths[i] = std::floor(ImGui::CalcTextSize(kTabs[i].sidebarLabel).x + 20.0f);
    total += widths[i] + (i ? kTabGap : 0.0f);
  }
  const float x0 = pos.x + size.x - 18.0f - total;
  const float y0 = pos.y + std::floor((g_theme.headerHeight - kTabHeight) * 0.5f);
  // the pills sit on a rounded track
  ImDrawList* dl = ImGui::GetWindowDrawList();
  ImVec4 track = g_theme.bg;
  track.w = 0.75f;
  dl->AddRectFilled(ImVec2(x0 - 4.0f, y0 - 4.0f), ImVec2(x0 + total + 4.0f, y0 + kTabHeight + 4.0f), Color(track), 999.0f);
  dl->AddRect(ImVec2(x0 - 4.0f, y0 - 4.0f), ImVec2(x0 + total + 4.0f, y0 + kTabHeight + 4.0f), Color(g_theme.border), 999.0f);
  g_theme.dragExcludeMin = x0 - 4.0f - pos.x;
  g_theme.dragExcludeMax = x0 + total + 4.0f - pos.x;
  float x = x0;
  for (int i = 0; i < IM_ARRAYSIZE(kTabs); ++i) {
    ImGui::SetCursorScreenPos(ImVec2(x, y0));
    const Tab tab = static_cast<Tab>(i);
    if (SidebarTab(kTabs[i].sidebarLabel, g_menu.selected == tab, ImVec2(widths[i], kTabHeight))) g_menu.selected = tab;
    x += widths[i] + kTabGap;
  }
}

void DrawHeader(const ImVec2& pos, const ImVec2& size) {
  DrawBrand(pos);
  DrawTabs(pos, size);
}

void DrawContent(const ImVec2& pos, const ImVec2& size) {
  const float slide = (1.0f - g_menu.alpha) * kSlideDistance;
  const ImVec2 cardPos(pos.x + g_theme.padding + slide, pos.y + g_theme.headerHeight + g_theme.padding);
  const ImVec2 cardSize(size.x - g_theme.padding * 2.0f, size.y - g_theme.headerHeight - g_theme.padding * 2.0f);
  const float innerWidth = cardSize.x - 28.0f;

  ImGui::PushStyleVar(ImGuiStyleVar_Alpha, g_menu.alpha * ImGui::GetStyle().Alpha);
  ImGui::SetCursorScreenPos(cardPos);
  ImGui::BeginGroup();
  ImGui::PushItemWidth(innerWidth);
  BeginCard(kTabs[static_cast<int>(g_menu.shown)].cardTitle, cardSize);
  switch (g_menu.shown) {
    case Tab::Ini: DrawIniTab(); break;
    case Tab::Visual: DrawVisualTab(); break;
    case Tab::Hud: DrawHudTab(); break;
    case Tab::Other: DrawOtherTab(innerWidth); break;
    case Tab::Misc: DrawMiscTab(); break;
    case Tab::Dino: DrawDinoTab(); break;
    case Tab::StructureSnap: DrawStructureSnapTab(); break;
    case Tab::Config: DrawConfigTab(innerWidth); break;
  }
  EndCard();
  ImGui::PopItemWidth();
  ImGui::EndGroup();
  ImGui::PopStyleVar();
}

}  // namespace

void DrawMenu() {
  ResolveMenuColors();  // theme, Custom Accent Color and Menu Colors

  const float dt = FrameDelta();
  ResizeToFit(dt);
  AnimateTabSwitch(dt);

  const ImVec2 size = g_theme.size;
  const ImVec2 pos((ImGui::GetIO().DisplaySize.x - size.x) * 0.5f, (ImGui::GetIO().DisplaySize.y - size.y) * 0.5f);
  ImGui::SetNextWindowPos(pos);
  ImGui::SetNextWindowSize(size);
  constexpr ImGuiWindowFlags kFlags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBackground |
                                      ImGuiWindowFlags_NoBringToFrontOnFocus;
  ImGui::Begin("Bence INI", nullptr, kFlags);
  DrawBackground(pos, size);
  DrawHeader(pos, size);
  DrawContent(pos, size);
  ImGui::End();
}

}  // namespace wintek::ui
