#pragma once
#include "imgui.h"

namespace wintek::ui {

// Colours and metrics for the whole menu. Colours change with the theme picked on the Config tab.
struct Theme {
  ImVec4 bg = ImColor(8, 20, 24, 255);
  ImVec4 bgSoft = ImColor(10, 26, 31, 255);
  ImVec4 panel = ImColor(13, 31, 37, 255);
  ImVec4 panelHeader = ImColor(16, 38, 45, 255);
  ImVec4 border = ImColor(27, 65, 74, 255);
  ImVec4 text = ImColor(230, 249, 252, 255);
  ImVec4 textDim = ImColor(136, 180, 188, 255);
  ImVec4 accent = ImVec4(0.0f, 0.85f, 0.95f, 1.0f);
  ImVec4 accentSoft = ImVec4(0.0f, 0.85f, 0.95f, 0.16f);  // follows accent, see Menu.cpp
  ImVec4 topLine = ImVec4(0.0f, 0.85f, 0.95f, 1.0f);     // the line along the top of the window (accent unless changed)
  ImVec4 title = ImColor(230, 249, 252, 255);            // card titles and the menu name (text unless changed)

  ImVec2 size = ImVec2(900.0f, 360.0f);  // window size; the height animates to fit the open tab
  float rounding = 12.0f;  // window and card corners
  float borderSize = 1.0f;
  float sidebarWidth = 0.0f;   // no sidebar: the tabs are pills in the header
  float padding = 14.0f;
  float headerHeight = 64.0f;  // the top bar with the logo and tabs, also the window's drag area
  float cardHeader = 40.0f;    // a card's title strip
  float dragExcludeMin = 0.0f, dragExcludeMax = 0.0f;  // the tab pills' x range inside the header (not a drag area)
  float toggleWidth = 38.0f;   // switch width
  float toggleHeight = 20.0f;
  float sliderHeight = 6.0f;
  float controlHeight = 30.0f;
  float fontSize = 16.0f;
  float animSpeed = 14.0f;
};

inline Theme g_theme;
inline ImFont* g_titleFont = nullptr;  // bigger font for the menu name, loaded in main.cpp

void ApplyTheme();  // ImGui style values that the custom widgets rely on
inline ImU32 Color(const ImVec4& c) { return ImGui::GetColorU32(c); }

}  // namespace wintek::ui
