#include "ui/MenuColors.h"
#include "core/Settings.h"
#include "tabs/config/Themes.h"
#include "ui/Theme.h"

namespace wintek::ui {

const char* const kMenuColorNames[kMenuColorCount] = { "Background", "Sidebar", "Panel", "Controls", "Border",
                                                       "Text", "Dim Text", "Accent", "Top Line", "Titles" };

ImVec4& MenuColor(int slot) {
  switch (slot) {
    case 0: return g_theme.bg;
    case 1: return g_theme.bgSoft;
    case 2: return g_theme.panel;
    case 3: return g_theme.panelHeader;
    case 4: return g_theme.border;
    case 5: return g_theme.text;
    case 6: return g_theme.textDim;
    case 7: return g_theme.accent;
    case 8: return g_theme.topLine;
    default: return g_theme.title;
  }
}

void ResolveMenuColors() {
  const ThemePreset& p = CurrentThemePreset();
  g_theme.bg = p.bg;
  g_theme.bgSoft = p.bgSoft;
  g_theme.panel = p.panel;
  g_theme.panelHeader = p.panelHeader;
  g_theme.border = p.border;
  g_theme.text = p.text;
  g_theme.textDim = p.textDim;
  g_theme.accent = p.accent;
  if (g_settings.customAccent) {
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB((g_settings.accentHue % 360) / 360.0f, 0.62f, 1.0f, r, g, b);
    g_theme.accent = ImVec4(r, g, b, 1.0f);
  }
  auto apply = [](int from, int to) {
    for (int i = from; i < to; ++i) {
      const int c = g_settings.colors[i];
      if (c >= 0) MenuColor(i) = ImVec4(((c >> 16) & 0xFF) / 255.0f, ((c >> 8) & 0xFF) / 255.0f, (c & 0xFF) / 255.0f, 1.0f);
    }
  };
  apply(0, 8);
  g_theme.topLine = g_theme.accent;  // Top Line follows the accent and Titles follow the text, unless changed
  g_theme.title = g_theme.text;
  apply(8, kMenuColorCount);
  g_theme.accentSoft = ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.16f);
}

}  // namespace wintek::ui
