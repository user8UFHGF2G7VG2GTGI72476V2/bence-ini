#include "ui/Widgets.h"
#include "ui/Anim.h"
#include "ui/Pixel.h"
#include "ui/Theme.h"
#include "imgui_internal.h"
#include <algorithm>
#include <cstdio>
#include <cmath>

// The menu's widgets in the "glass" style: rounded cards, sliding switches with a gradient track, round-knob
// sliders with the value above, pill hotkey boxes and rounded dropdowns.
namespace wintek::ui {

namespace {

constexpr float kRowHeight = 30.0f;
constexpr float kCardInset = 14.0f;
constexpr float kKeyBoxWidth = 74.0f;
constexpr float kKeyBoxHeight = 22.0f;
constexpr float kDropdownWidth = 170.0f;
constexpr float kPill = 999.0f;  // rounding that makes a pill

ImGuiID g_bindingId = 0;  // the hotkey box waiting for a key press, 0 if none

ImVec4 Mix(ImVec4 from, const ImVec4& to, float t) {
  from.x += (to.x - from.x) * t;
  from.y += (to.y - from.y) * t;
  from.z += (to.z - from.z) * t;
  return from;
}

ImVec4 WithAlpha(ImVec4 c, float a) {
  c.w = a;
  return c;
}

// The second colour of the accent gradient: the accent nudged along the colour wheel and a little brighter.
ImVec4 AccentB() {
  float h, s, v;
  ImGui::ColorConvertRGBtoHSV(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, h, s, v);
  h = std::fmod(h + 0.09f, 1.0f);
  v = (std::min)(1.0f, v * 1.12f + 0.05f);
  float r, g, b;
  ImGui::ColorConvertHSVtoRGB(h, s, v, r, g, b);
  return ImVec4(r, g, b, 1.0f);
}

// A rounded box filled with the accent gradient (left to right).
void GradientBox(ImDrawList* dl, const ImVec2& a, const ImVec2& b, float rounding, float alpha = 1.0f) {
  const int first = dl->VtxBuffer.Size;
  dl->AddRectFilled(a, b, IM_COL32_WHITE, rounding);
  ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, first, dl->VtxBuffer.Size, a, ImVec2(b.x, a.y), Color(WithAlpha(g_theme.accent, alpha)),
                                                Color(WithAlpha(AccentB(), alpha)));
}

float RowWidth() {
  const float width = ImGui::GetContentRegionAvail().x;
  return width < 1.0f ? 200.0f : width;
}

float CenteredTextY(float top, float height, const char* text) { return std::floor(top + (height - ImGui::CalcTextSize(text).y) * 0.5f); }

float Animate(ImGuiID id, float target, int slot = 0) {
  AnimState& a = GetAnim(id);
  if (!a.init) {
    a.value[0] = a.value[1] = a.value[2] = 0.0f;
    a.value[slot] = target;
    a.init = true;
  }
  return Approach(a.value[slot], target, g_theme.animSpeed);
}

// A soft rounded highlight behind a hovered row.
void RowHover(ImDrawList* dl, const ImVec2& p, float width, float t) {
  if (t < 0.01f) return;
  dl->AddRectFilled(ImVec2(p.x - 8.0f, p.y), ImVec2(p.x + width + 8.0f, p.y + kRowHeight), Color(WithAlpha(g_theme.panelHeader, 0.7f * t)), 8.0f);
}

// The sliding switch at the right end of a row; `t` is the animated on-ness (0..1).
void DrawSwitch(ImDrawList* dl, const ImVec2& rowPos, float width, float t, bool hovered) {
  const float w = g_theme.toggleWidth, h = g_theme.toggleHeight;
  const ImVec2 a(rowPos.x + width - w, std::floor(rowPos.y + (kRowHeight - h) * 0.5f)), b(a.x + w, a.y + h);
  dl->AddRectFilled(a, b, Color(Mix(g_theme.panelHeader, g_theme.border, hovered ? 0.6f : 0.3f)), kPill);
  if (t > 0.01f) GradientBox(dl, a, b, kPill, t);
  const float r = h * 0.5f - 3.0f;
  const ImVec2 knob(a.x + h * 0.5f + (w - h) * t, a.y + h * 0.5f);
  dl->AddCircleFilled(ImVec2(knob.x, knob.y + 1.0f), r + 0.5f, IM_COL32(0, 0, 0, 70), 20);
  dl->AddCircleFilled(knob, r, Color(Mix(g_theme.textDim, ImVec4(1, 1, 1, 1), 0.4f + 0.6f * t)), 20);
}

// While a hotkey box is listening: returns true once a key was pressed (or Escape cleared it).
bool CaptureKey(int* key) {
  if (ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
    *key = ImGuiKey_None;
    return true;
  }
  for (int k = ImGuiKey_NamedKey_BEGIN; k < ImGuiKey_COUNT; ++k) {
    if (k != ImGuiKey_Escape && ImGui::IsKeyPressed(static_cast<ImGuiKey>(k), false)) {
      *key = k;
      return true;
    }
  }
  return false;
}

// A pill-shaped hotkey box; shows the key, "..." while listening.
void DrawKeyBox(ImDrawList* dl, const ImRect& box, int key, bool listening, bool hovered) {
  if (listening) GradientBox(dl, box.Min, box.Max, kPill, 0.35f);
  else dl->AddRectFilled(box.Min, box.Max, Color(hovered ? g_theme.panelHeader : WithAlpha(g_theme.bgSoft, 0.9f)), kPill);
  dl->AddRect(box.Min, box.Max, Color(listening || hovered ? g_theme.accent : g_theme.border), kPill);
  const char* keyText = listening ? "..." : (key <= 0 ? "None" : ImGui::GetKeyName(static_cast<ImGuiKey>(key)));
  const ImVec2 keySize = ImGui::CalcTextSize(keyText);
  dl->PushClipRect(box.Min, box.Max, true);
  dl->AddText(ImVec2(std::floor(box.Min.x + (box.GetWidth() - keySize.x) * 0.5f), std::floor(box.Min.y + (box.GetHeight() - keySize.y) * 0.5f)),
              Color(listening ? g_theme.text : g_theme.textDim), keyText);
  dl->PopClipRect();
}

// The little tip above a listening hotkey box.
void DrawKeyHint(const char* hint, float right, float boxTop) {
  const ImVec2 hintSize = ImGui::CalcTextSize(hint);
  const ImVec2 hintMax(right, boxTop - 6.0f), hintMin(hintMax.x - hintSize.x - 20.0f, hintMax.y - hintSize.y - 10.0f);
  ImDrawList* top = ImGui::GetForegroundDrawList();
  top->AddRectFilled(ImVec2(hintMin.x + 2.0f, hintMin.y + 3.0f), ImVec2(hintMax.x + 2.0f, hintMax.y + 3.0f), IM_COL32(0, 0, 0, 80), 8.0f);
  top->AddRectFilled(hintMin, hintMax, Color(g_theme.panelHeader), 8.0f);
  top->AddRect(hintMin, hintMax, Color(g_theme.accent), 8.0f);
  top->AddText(ImVec2(hintMin.x + 10.0f, hintMin.y + 5.0f), Color(g_theme.text), hint);
}

// Label on the left and the value on the right of one line, then a rounded track with a gradient fill and a
// round knob.
bool Slider(const char* label, float* fraction, const char* valueText) {
  constexpr float kTrackRow = 18.0f, kKnob = 7.0f;
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const float width = RowWidth();
  const ImVec2 top = window->DC.CursorPos;
  ImGui::TextUnformatted("");  // takes the label line's height; drawn by hand below
  const ImVec2 p = window->DC.CursorPos;
  const ImVec2 size(width, kTrackRow);
  ImGui::ItemSize(size);
  const ImGuiID id = window->GetID(label);
  if (!ImGui::ItemAdd(ImRect(p, p + size), id)) return false;

  const float trackLeft = p.x + kKnob, trackRight = p.x + width - kKnob;
  bool hovered = false, held = false;
  const bool pressed = ImGui::ButtonBehavior(ImRect(p, p + size), id, &hovered, &held, ImGuiButtonFlags_None);
  if (held) {
    const float t = (ImGui::GetIO().MousePos.x - trackLeft) / (trackRight - trackLeft);
    *fraction = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
  }
  AnimState& a = GetAnim(id);
  if (!a.init) {
    a.value[0] = *fraction;
    a.init = true;
  }
  Approach(a.value[0], *fraction, g_theme.animSpeed);
  const float glow = Animate(id ^ 0x9E3779B9u, hovered || held ? 1.0f : 0.0f);

  ImDrawList* dl = window->DrawList;
  dl->AddText(top, Color(Mix(g_theme.textDim, g_theme.text, 0.55f)), label);
  const ImVec2 valueSize = ImGui::CalcTextSize(valueText);
  dl->AddText(ImVec2(std::floor(p.x + width - valueSize.x), top.y), Color(Mix(g_theme.accent, g_theme.text, 0.25f)), valueText);

  const float centerY = std::floor(p.y + size.y * 0.5f);
  const float half = g_theme.sliderHeight * 0.5f;
  const float knobX = std::floor(trackLeft + (trackRight - trackLeft) * a.value[0]);
  dl->AddRectFilled(ImVec2(p.x, centerY - half), ImVec2(p.x + width, centerY + half), Color(g_theme.panelHeader), kPill);
  if (knobX > p.x + 1.0f) GradientBox(dl, ImVec2(p.x, centerY - half), ImVec2(knobX, centerY + half), kPill);
  if (glow > 0.01f) dl->AddCircleFilled(ImVec2(knobX, centerY), kKnob + 5.0f, Color(WithAlpha(g_theme.accent, 0.22f * glow)), 24);
  dl->AddCircleFilled(ImVec2(knobX, centerY + 1.0f), kKnob + 0.5f, IM_COL32(0, 0, 0, 80), 24);
  dl->AddCircleFilled(ImVec2(knobX, centerY), kKnob, IM_COL32_WHITE, 24);
  dl->AddCircle(ImVec2(knobX, centerY), kKnob, Color(g_theme.accent), 24, 2.0f);
  return pressed || held;
}

}  // namespace

void NewFrame() { CollectAnims(); }

void HintText(const char* text) {
  ImGui::PushStyleColor(ImGuiCol_Text, Color(g_theme.textDim));
  ImGui::TextUnformatted(text);
  ImGui::PopStyleColor();
}

void Separator() {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  if (window->SkipItems) return;
  const float width = (std::max)(ImGui::GetContentRegionAvail().x, 1.0f);
  const ImVec2 p = window->DC.CursorPos;
  ImGui::ItemSize(ImVec2(width, 12.0f));
  if (!ImGui::ItemAdd(ImRect(p, p + ImVec2(width, 12.0f)), 0)) return;
  // fades out towards both ends
  const ImU32 solid = Color(g_theme.border), clear = Color(WithAlpha(g_theme.border, 0.0f));
  const float y = std::floor(p.y + 6.0f), mid = p.x + width * 0.5f;
  window->DrawList->AddRectFilledMultiColor(ImVec2(p.x, y), ImVec2(mid, y + 1.0f), clear, solid, solid, clear);
  window->DrawList->AddRectFilledMultiColor(ImVec2(mid, y), ImVec2(p.x + width, y + 1.0f), solid, clear, clear, solid);
}

// A rounded glass card: a title with a gradient dot, then the content, which scrolls smoothly if it doesn't fit.
void BeginCard(const char* title, const ImVec2& size) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const ImVec2 p = window->DC.CursorPos, max = p + size;
  ImGui::ItemSize(size);
  ImGui::ItemAdd(ImRect(p, max), 0);

  ImDrawList* dl = window->DrawList;
  const float header = g_theme.cardHeader, r = g_theme.rounding;
  dl->AddRectFilled(ImVec2(p.x, p.y + 4.0f), ImVec2(max.x, max.y + 6.0f), IM_COL32(0, 0, 0, 60), r);  // soft shadow
  dl->AddRectFilled(p, max, Color(WithAlpha(g_theme.panel, 0.92f)), r);
  // a faint sheen across the top of the card
  dl->AddRectFilledMultiColor(ImVec2(p.x + r, p.y + 1.0f), ImVec2(max.x - r, p.y + header), IM_COL32(255, 255, 255, 10), IM_COL32(255, 255, 255, 10),
                              IM_COL32(255, 255, 255, 0), IM_COL32(255, 255, 255, 0));
  dl->AddRect(p, max, Color(WithAlpha(Mix(g_theme.border, g_theme.accent, 0.15f), 1.0f)), r);
  {
    ImFont* font = g_titleFont ? g_titleFont : ImGui::GetFont();
    const float fontSize = g_titleFont ? g_titleFont->FontSize : ImGui::GetFontSize();
    const float textH = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, title).y;
    const ImVec2 dot(p.x + kCardInset + 4.0f, p.y + header * 0.5f);
    const int first = dl->VtxBuffer.Size;
    dl->AddCircleFilled(dot, 4.5f, IM_COL32_WHITE, 16);
    ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, first, dl->VtxBuffer.Size, ImVec2(dot.x - 5, dot.y), ImVec2(dot.x + 5, dot.y), Color(g_theme.accent),
                                                  Color(AccentB()));
    dl->AddCircle(dot, 8.0f, Color(WithAlpha(g_theme.accent, 0.35f)), 20, 1.5f);
    px::Text(dl, font, fontSize, ImVec2(p.x + kCardInset + 18.0f, p.y + (header - textH) * 0.5f), Color(g_theme.title), title);
    dl->AddRectFilledMultiColor(ImVec2(p.x + kCardInset, p.y + header - 1.0f), ImVec2(max.x - kCardInset, p.y + header), Color(g_theme.border),
                                Color(WithAlpha(g_theme.border, 0.0f)), Color(WithAlpha(g_theme.border, 0.0f)), Color(g_theme.border));
  }

  ImGui::SetCursorScreenPos(ImVec2(p.x + kCardInset, p.y + header + kCardInset * 0.75f));
  ImGui::PushItemWidth(size.x - kCardInset * 2.0f);
  AnimState& scroll = GetAnim(window->GetID(title));  // value[1] = target, value[2] = shown
  if (!scroll.init) {
    scroll.value[1] = scroll.value[2] = 0.0f;
    scroll.init = true;
  }
  constexpr ImGuiWindowFlags kFlags = ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                                      ImGuiWindowFlags_AlwaysUseWindowPadding;
  ImGui::BeginChild(title, ImVec2(size.x - kCardInset * 2.0f, size.y - header - kCardInset * 1.5f), false, kFlags);
  const float maxScroll = (std::max)(ImGui::GetScrollMaxY(), 0.0f);
  if (ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows) && !ImGui::IsPopupOpen("", ImGuiPopupFlags_AnyPopupId)) {
    const float wheel = ImGui::GetIO().MouseWheel;
    if (wheel < -0.001f || wheel > 0.001f) scroll.value[1] -= wheel * 44.0f;
  }
  scroll.value[1] = ImClamp(scroll.value[1], 0.0f, maxScroll);
  ImGui::SetScrollY(Approach(scroll.value[2], scroll.value[1], 12.0f));
}

void EndCard() {
  ImGui::EndChild();
  ImGui::PopItemWidth();
}

// A pill tab in the top bar; the open one is filled with the accent gradient.
bool SidebarTab(const char* label, bool selected, const ImVec2& size) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const ImVec2 p = window->DC.CursorPos;
  ImGui::ItemSize(size);
  const ImGuiID id = window->GetID(label);
  if (!ImGui::ItemAdd(ImRect(p, p + size), id)) return false;
  bool hovered = false, held = false;
  const bool pressed = ImGui::ButtonBehavior(ImRect(p, p + size), id, &hovered, &held, ImGuiButtonFlags_None);
  const float t = Animate(id, selected ? 1.0f : 0.0f);
  const float h = Animate(id ^ 0x51u, hovered ? 1.0f : 0.0f);

  ImDrawList* dl = window->DrawList;
  if (h > 0.01f && t < 0.99f) dl->AddRectFilled(p, p + size, Color(WithAlpha(g_theme.panelHeader, 0.8f * h * (1.0f - t))), kPill);
  if (t > 0.01f) {
    dl->AddRectFilled(ImVec2(p.x, p.y + 3.0f), ImVec2(p.x + size.x, p.y + size.y + 3.0f), Color(WithAlpha(g_theme.accent, 0.25f * t)), kPill);  // glow
    GradientBox(dl, p, p + size, kPill, t);
  }
  const ImVec2 textSize = ImGui::CalcTextSize(label);
  const ImVec4 idle = Mix(g_theme.textDim, g_theme.text, 0.5f * h);
  dl->AddText(ImVec2(std::floor(p.x + (size.x - textSize.x) * 0.5f), std::floor(p.y + (size.y - textSize.y) * 0.5f)),
              Color(Mix(idle, ImVec4(1, 1, 1, 1), t)), label);
  return pressed;
}

bool Toggle(const char* label, bool* on) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const float width = RowWidth();
  const ImVec2 p = window->DC.CursorPos, size(width, kRowHeight);
  ImGui::ItemSize(size);
  const ImGuiID id = window->GetID(label);
  const ImRect row(p, p + size);
  if (!ImGui::ItemAdd(row, id)) return false;
  bool hovered = false, held = false;
  const bool pressed = ImGui::ButtonBehavior(row, id, &hovered, &held, ImGuiButtonFlags_None);
  if (pressed) *on = !*on;
  ImDrawList* dl = window->DrawList;
  RowHover(dl, p, width, Animate(id ^ 0x77u, hovered ? 1.0f : 0.0f));
  dl->AddText(ImVec2(p.x, CenteredTextY(p.y, kRowHeight, label)), Color(*on ? g_theme.text : Mix(g_theme.textDim, g_theme.text, 0.45f)), label);
  DrawSwitch(dl, p, width, Animate(id, *on ? 1.0f : 0.0f), hovered);
  return pressed;
}

bool IsBindingKey() { return g_bindingId != 0; }

bool ToggleBind(const char* label, bool* on, int* key) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const float width = RowWidth();
  const ImVec2 p = window->DC.CursorPos, size(width, kRowHeight);
  ImGui::ItemSize(size);
  const ImGuiID rowId = window->GetID(label);

  // The hotkey pill sits just left of the switch and is its own item.
  char boxLabel[160];
  std::snprintf(boxLabel, sizeof(boxLabel), "%s##key", label);
  const ImVec2 boxPos(p.x + width - g_theme.toggleWidth - 10.0f - kKeyBoxWidth, std::floor(p.y + (kRowHeight - kKeyBoxHeight) * 0.5f));
  const ImRect box(boxPos, ImVec2(boxPos.x + kKeyBoxWidth, boxPos.y + kKeyBoxHeight));
  const ImGuiID boxId = window->GetID(boxLabel);
  ImGui::ItemAdd(box, boxId);
  bool boxHovered = false, boxHeld = false;
  if (ImGui::ButtonBehavior(box, boxId, &boxHovered, &boxHeld, ImGuiButtonFlags_None)) g_bindingId = g_bindingId == boxId ? 0 : boxId;
  bool listening = g_bindingId == boxId;
  if (listening && CaptureKey(key)) {
    g_bindingId = 0;
    listening = false;
  }

  const ImRect row(p, p + size);
  if (!ImGui::ItemAdd(row, rowId)) return false;
  bool rowHovered = false, rowHeld = false;
  const bool pressed = ImGui::ButtonBehavior(row, rowId, &rowHovered, &rowHeld, ImGuiButtonFlags_None);
  if (pressed && !boxHovered) *on = !*on;

  ImDrawList* dl = window->DrawList;
  RowHover(dl, p, width, Animate(rowId ^ 0x77u, rowHovered || boxHovered ? 1.0f : 0.0f));
  dl->AddText(ImVec2(p.x, CenteredTextY(p.y, kRowHeight, label)), Color(*on ? g_theme.text : Mix(g_theme.textDim, g_theme.text, 0.45f)), label);
  DrawKeyBox(dl, box, *key, listening, boxHovered);
  DrawSwitch(dl, p, width, Animate(rowId, *on ? 1.0f : 0.0f), rowHovered && !boxHovered);
  if (listening) DrawKeyHint("ESC removes the keybind", box.Max.x, box.Min.y);
  return pressed && !boxHovered;
}

bool KeyBind(const char* label, int* key, bool allowClear) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const float width = RowWidth();
  const ImVec2 p = window->DC.CursorPos, size(width, kRowHeight);
  ImGui::ItemSize(size);
  const ImVec2 boxPos(p.x + width - kKeyBoxWidth, std::floor(p.y + (kRowHeight - kKeyBoxHeight) * 0.5f));
  const ImRect box(boxPos, ImVec2(boxPos.x + kKeyBoxWidth, boxPos.y + kKeyBoxHeight));
  const ImGuiID boxId = window->GetID(label);
  if (!ImGui::ItemAdd(box, boxId)) return false;
  bool hovered = false, held = false;
  if (ImGui::ButtonBehavior(box, boxId, &hovered, &held, ImGuiButtonFlags_None)) g_bindingId = g_bindingId == boxId ? 0 : boxId;
  bool listening = g_bindingId == boxId;
  bool changed = false;
  if (listening) {
    const int before = *key;
    if (CaptureKey(key)) {
      if (!allowClear && *key <= 0) *key = before;
      changed = *key != before;
      g_bindingId = 0;
      listening = false;
    }
  }

  ImDrawList* dl = window->DrawList;
  dl->AddText(ImVec2(p.x, CenteredTextY(p.y, kRowHeight, label)), Color(g_theme.text), label);
  DrawKeyBox(dl, box, *key, listening, hovered);
  if (listening) DrawKeyHint(allowClear ? "ESC removes the keybind" : "Press a key (ESC cancels)", box.Max.x, box.Min.y);
  return changed;
}

// A label with a rounded dropdown at the right of the row: click it for the list of options.
bool Choice(const char* label, int* index, const char* const* items, int count) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  const float width = RowWidth();
  const ImVec2 p = window->DC.CursorPos, size(width, kRowHeight);
  ImGui::ItemSize(size);
  if (count <= 0) return false;
  *index = ((*index % count) + count) % count;

  const float boxWidth = (std::min)(kDropdownWidth, width * 0.5f);
  const float boxH = 24.0f;
  const ImVec2 boxMin(p.x + width - boxWidth, std::floor(p.y + (kRowHeight - boxH) * 0.5f)), boxMax(p.x + width, boxMin.y + boxH);
  const ImRect box(boxMin, boxMax);
  const ImGuiID id = window->GetID(label);
  if (!ImGui::ItemAdd(box, id)) return false;
  char popupId[160];
  std::snprintf(popupId, sizeof(popupId), "%s##list", label);
  bool hovered = false, held = false;
  if (ImGui::ButtonBehavior(box, id, &hovered, &held, ImGuiButtonFlags_None)) ImGui::OpenPopup(popupId);
  const bool open = ImGui::IsPopupOpen(popupId);
  const float spin = Animate(id, open ? 1.0f : 0.0f);

  ImDrawList* dl = window->DrawList;
  dl->AddText(ImVec2(p.x, CenteredTextY(p.y, kRowHeight, label)), Color(g_theme.text), label);
  dl->AddRectFilled(boxMin, boxMax, Color(hovered || open ? g_theme.panelHeader : WithAlpha(g_theme.bgSoft, 0.9f)), 8.0f);
  dl->AddRect(boxMin, boxMax, Color(open || hovered ? g_theme.accent : g_theme.border), 8.0f);
  // chevron that flips while the list is open
  const ImVec2 c(boxMax.x - 14.0f, boxMin.y + boxH * 0.5f);
  const float d = 4.0f * (1.0f - 2.0f * spin);
  dl->AddLine(ImVec2(c.x - 4.0f, c.y - d * 0.5f), ImVec2(c.x, c.y + d * 0.5f), Color(open || hovered ? g_theme.accent : g_theme.textDim), 1.8f);
  dl->AddLine(ImVec2(c.x, c.y + d * 0.5f), ImVec2(c.x + 4.0f, c.y - d * 0.5f), Color(open || hovered ? g_theme.accent : g_theme.textDim), 1.8f);
  const char* shown = items[*index];
  dl->PushClipRect(boxMin, ImVec2(boxMax.x - 26.0f, boxMax.y), true);
  dl->AddText(ImVec2(boxMin.x + 10.0f, CenteredTextY(boxMin.y, boxH, shown)), Color(g_theme.text), shown);
  dl->PopClipRect();

  const int before = *index;
  // Opens downward, or upward when the list wouldn't fit below the box inside the menu window.
  const float listHeight = (std::min)(count * 24.0f + 8.0f, 300.0f);
  const bool up = boxMax.y + 4.0f + listHeight > ImGui::GetIO().DisplaySize.y && boxMin.y - 4.0f - listHeight >= 0.0f;
  ImGui::SetNextWindowPos(up ? ImVec2(boxMin.x, boxMin.y - 4.0f - listHeight) : ImVec2(boxMin.x, boxMax.y + 4.0f));
  ImGui::SetNextWindowSizeConstraints(ImVec2(boxWidth, 0.0f), ImVec2(boxWidth, 300.0f));
  ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4.0f, 4.0f));
  ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 0.0f));
  ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.0f);
  ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, 10.0f);
  ImGui::PushStyleColor(ImGuiCol_PopupBg, g_theme.bgSoft);
  ImGui::PushStyleColor(ImGuiCol_Border, WithAlpha(g_theme.accent, 0.6f));
  ImGui::PushStyleColor(ImGuiCol_Text, g_theme.text);
  if (ImGui::BeginPopup(popupId, ImGuiWindowFlags_NoMove)) {
    ImGuiWindow* popup = ImGui::GetCurrentWindow();
    for (int i = 0; i < count; ++i) {
      const ImVec2 rp = popup->DC.CursorPos, rs(boxWidth - 8.0f, 24.0f);
      ImGui::PushID(i);
      const ImGuiID rowId = popup->GetID("row");
      ImGui::ItemSize(rs);
      const ImRect row(rp, rp + rs);
      if (ImGui::ItemAdd(row, rowId)) {
        bool rowHovered = false, rowHeld = false;
        if (ImGui::ButtonBehavior(row, rowId, &rowHovered, &rowHeld, ImGuiButtonFlags_None)) {
          *index = i;
          ImGui::CloseCurrentPopup();
        }
        ImDrawList* pdl = popup->DrawList;
        if (i == *index) GradientBox(pdl, row.Min, row.Max, 7.0f, 0.3f);
        else if (rowHovered) pdl->AddRectFilled(row.Min, row.Max, Color(g_theme.panelHeader), 7.0f);
        pdl->AddText(ImVec2(row.Min.x + 10.0f, CenteredTextY(row.Min.y, rs.y, items[i])), Color(i == *index || rowHovered ? g_theme.text : g_theme.textDim),
                     items[i]);
      }
      ImGui::PopID();
    }
    ImGui::EndPopup();
  }
  ImGui::PopStyleColor(3);
  ImGui::PopStyleVar(4);
  return *index != before;
}

bool SliderInt(const char* label, int* value, int min, int max, const char* format) {
  char text[64];
  std::snprintf(text, sizeof(text), format, *value);
  float fraction = max == min ? 0.0f : static_cast<float>(*value - min) / (max - min);
  if (!Slider(label, &fraction, text)) return false;
  *value = min + static_cast<int>(fraction * (max - min) + 0.5f);
  return true;
}

bool SliderFloat(const char* label, float* value, float min, float max, const char* format) {
  char text[64];
  std::snprintf(text, sizeof(text), format, *value);
  float fraction = max == min ? 0.0f : (*value - min) / (max - min);
  if (!Slider(label, &fraction, text)) return false;
  *value = min + fraction * (max - min);
  return true;
}

bool Button(const char* label, const ImVec2& size) {
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  float width = size.x > 0.0f ? size.x : ImGui::GetContentRegionAvail().x;
  if (width < 1.0f) width = 100.0f;
  const ImVec2 p = window->DC.CursorPos, buttonSize(width, size.y > 0.0f ? size.y : g_theme.controlHeight);
  ImGui::ItemSize(buttonSize);
  const ImRect bounds(p, p + buttonSize);
  const ImGuiID id = window->GetID(label);
  if (!ImGui::ItemAdd(bounds, id)) return false;
  bool hovered = false, held = false;
  const bool pressed = ImGui::ButtonBehavior(bounds, id, &hovered, &held, ImGuiButtonFlags_None);
  const float t = Animate(id, held ? 1.0f : (hovered ? 0.6f : 0.0f));

  ImDrawList* dl = window->DrawList;
  const float r = 9.0f;
  const ImVec2 push = held ? ImVec2(0.0f, 1.0f) : ImVec2(0.0f, 0.0f);
  dl->AddRectFilled(bounds.Min + push, bounds.Max + push, Color(WithAlpha(g_theme.bgSoft, 0.9f)), r);
  if (t > 0.01f) GradientBox(dl, bounds.Min + push, bounds.Max + push, r, 0.55f * t);
  dl->AddRect(bounds.Min + push, bounds.Max + push, Color(hovered ? WithAlpha(g_theme.accent, 0.9f) : g_theme.border), r);
  const ImVec2 textSize = ImGui::CalcTextSize(label);
  dl->AddText(ImVec2(std::floor(bounds.Min.x + (buttonSize.x - textSize.x) * 0.5f), std::floor(bounds.Min.y + push.y + (buttonSize.y - textSize.y) * 0.5f)),
              Color(g_theme.text), label);
  return pressed;
}

bool NumberBox(const char* id, int* value, float width) {
  ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 9.0f);
  ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
  ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10.0f, std::floor((g_theme.controlHeight - ImGui::GetFontSize()) * 0.5f)));
  ImGui::PushStyleColor(ImGuiCol_FrameBg, WithAlpha(g_theme.bgSoft, 0.9f));
  ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, g_theme.panelHeader);
  ImGui::PushStyleColor(ImGuiCol_FrameBgActive, g_theme.panelHeader);
  ImGui::PushStyleColor(ImGuiCol_Border, g_theme.border);
  ImGui::PushStyleColor(ImGuiCol_Text, g_theme.text);
  ImGui::PushStyleColor(ImGuiCol_TextSelectedBg, g_theme.accentSoft);
  ImGui::SetNextItemWidth(width);
  const bool changed = ImGui::InputScalar(id, ImGuiDataType_S32, value, nullptr, nullptr, "%d");
  ImGui::PopStyleColor(6);
  ImGui::PopStyleVar(3);
  return changed;
}

}  // namespace wintek::ui
