#pragma once

namespace wintek::ui {

// Checks the bound hotkeys with GetAsyncKeyState, so they work while the game has focus.
// Also handles the menu key (Insert by default), which hides and shows the menu. Call once per loop.
void PollHotkeys();
bool ActionPressed(int key);

}  // namespace wintek::ui
