#pragma once
#include "imgui.h"

// The menu fonts, picked on the Config tab (Menu Font). Every choice has a body font and a title font (menu name,
// tabs, card titles). The pixel fonts are compiled into the exe; the Windows ones are read from C:\Windows\Fonts and
// fall back to the default when a PC doesn't have them.
namespace wintek::ui {

extern const char* const kMenuFontNames[];
extern const int kMenuFontCount;

// Loads every choice into the font atlas. Call once, before the renderer builds the atlas.
void LoadMenuFonts(ImGuiIO& io);
// Makes `index` the font the menu draws with from the next frame. Call before ImGui::NewFrame.
void UseMenuFont(int index);

}  // namespace wintek::ui
