#include "ui/Hotkeys.h"
#include "client/Window.h"
#include "core/Settings.h"
#include "tabs/ini/Presets.h"
#include "ui/Widgets.h"
#include "imgui.h"
#include <windows.h>

ImGuiKey ImGui_ImplWin32_KeyEventToImGuiKey(WPARAM wParam, LPARAM lParam);

namespace wintek::ui {

namespace {

bool g_down[256] = {};

// ImGuiKey -> virtual-key code. Built by asking the Win32 backend how it maps each virtual key.
int VirtualKey(int key) {
  static int map[ImGuiKey_COUNT] = {};
  static bool built = false;
  if (!built) {
    built = true;
    for (int vk = 255; vk > 0; --vk) {
      const int k = static_cast<int>(ImGui_ImplWin32_KeyEventToImGuiKey(static_cast<WPARAM>(vk), 0));
      if (k > 0 && k < ImGuiKey_COUNT) map[k] = vk;
    }
    map[ImGuiKey_MouseLeft] = VK_LBUTTON;
    map[ImGuiKey_MouseRight] = VK_RBUTTON;
    map[ImGuiKey_MouseMiddle] = VK_MBUTTON;
    map[ImGuiKey_MouseX1] = VK_XBUTTON1;
    map[ImGuiKey_MouseX2] = VK_XBUTTON2;
  }
  return key > 0 && key < ImGuiKey_COUNT ? map[key] : 0;
}

bool IsDown(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

// True on the frame the key goes down.
bool Pressed(int key) {
  const int vk = VirtualKey(key);
  if (!vk) return false;
  const bool down = IsDown(vk);
  const bool pressed = down && !g_down[vk];
  g_down[vk] = down;
  return pressed;
}

void Flip(KeyedToggle& toggle) {
  if (Pressed(toggle.key)) toggle.on = !toggle.on;
}

void SelectOnPress(IniSettings& ini, KeyedToggle& preset) {
  if (!Pressed(preset.key)) return;
  preset.on = true;
  SelectPreset(ini, preset);
}

}  // namespace

void PollHotkeys() {
  if (IsBindingKey()) {
    // Track key state while a key is being bound, so the key just bound doesn't also fire its toggle.
    for (int vk = 1; vk < 256; ++vk) g_down[vk] = IsDown(vk);
    return;
  }
  if (Pressed(g_settings.menuKey)) ToggleAppWindow();
  auto& d=g_settings.dino;
  for(KeyedToggle* t:{&d.saddle,&d.imprint,&d.name,&d.claim,&d.neuter,&d.level,&d.clone,&d.fillCloning,&d.pickupEggs,&d.transferEggs,&d.hatchEggs,&g_settings.misc.autoForge,&g_settings.misc.quickPickup,&g_settings.misc.takeAll})Flip(*t);
  IniSettings& ini = g_settings.ini;
  SelectOnPress(ini, ini.normal);
  SelectOnPress(ini, ini.hard);
  SelectOnPress(ini, ini.potato);
  for (KeyedToggle* toggle : { &ini.stalker, &ini.fullbright, &ini.noXyz, &ini.noRockTrees, &ini.noLandscape, &ini.noWater,
                               &ini.noHands, &ini.noHud, &ini.noFoliage, &ini.removeParticle, &g_settings.other.stretchedRes,
                               &ini.lowMemory, &ini.blackSky, &ini.blackStructures, &g_settings.hud.watermark, &g_settings.hud.crosshair, &g_settings.hud.info, &g_settings.misc.structureSnap, &g_settings.misc.structureSnapOther, &g_settings.misc.turretFiller, &g_settings.misc.betterInput, &g_settings.misc.autoMating, &g_settings.misc.autoChemBench, &g_settings.misc.resourcePull, &g_settings.hud.armor, &g_settings.hud.spyglass, &g_settings.hud.corruptedEsp, &g_settings.hud.trajectory, &g_settings.hud.playerOutlines, &g_settings.hud.turretOutlines, &g_settings.hud.penisEsp, &g_settings.hud.tekIndicator, &g_settings.hud.hp,
                               &g_settings.hud.mountHp, &g_settings.hud.playerList, &g_settings.visual.noFog, &g_settings.visual.noClouds,
                               &g_settings.visual.noShadows, &g_settings.visual.noBloom, &g_settings.visual.noLensFlare,
                               &g_settings.visual.noMotionBlur, &g_settings.visual.viewDistance, &g_settings.visual.fpsLimit })
    Flip(*toggle);
}
bool ActionPressed(int key) { return !IsBindingKey() && Pressed(key); }

}  // namespace wintek::ui
