#pragma once
#include "imgui.h"
#include <cmath>

// Drawing helpers for the menu's flat, compact style: square boxes, 1 px outlines, no shadows.
// (The namespace keeps its old name from the pixel-art style so every caller stays the same.)
namespace wintek::ui::px {

constexpr float kStep = 1.0f;

inline ImVec2 Snap(const ImVec2& v) { return ImVec2(std::floor(v.x), std::floor(v.y)); }

inline void Fill(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col, float = kStep) { dl->AddRectFilled(Snap(a), Snap(b), col); }

// A 1 px outline just inside the box.
inline void Frame(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col, float = kStep) {
  a = Snap(a);
  b = Snap(b);
  dl->AddRect(ImVec2(a.x + 0.5f, a.y + 0.5f), ImVec2(b.x - 0.5f, b.y - 0.5f), col, 0.0f, 0, 1.0f);
}

// A faint, soft shadow under popups and the selected tab.
inline void Shadow(ImDrawList* dl, const ImVec2& a, const ImVec2& b, float = 0.0f) {
  dl->AddRectFilled(ImVec2(a.x + 1.0f, a.y + 2.0f), ImVec2(b.x + 1.0f, b.y + 2.0f), IM_COL32(0, 0, 0, 50));
}

inline void Bevel(ImDrawList*, ImVec2, ImVec2, float = kStep) {}

// A thin solid divider line.
inline void DashedLine(ImDrawList* dl, float x0, float x1, float y, ImU32 col, float = 0.0f, float = 0.0f) {
  y = std::floor(y);
  dl->AddRectFilled(ImVec2(std::floor(x0), y), ImVec2(std::floor(x1), y + 1.0f), col);
}

inline void Text(ImDrawList* dl, ImFont* font, float size, ImVec2 pos, ImU32 col, const char* text) {
  dl->AddText(font, size, Snap(pos), col, text);
}

// A small right-pointing triangle, `h` tall, left edge at `p`.
inline void Arrow(ImDrawList* dl, ImVec2 p, float h, ImU32 col, float = kStep) {
  p = Snap(p);
  dl->AddTriangleFilled(p, ImVec2(p.x + h * 0.6f, p.y + h * 0.5f), ImVec2(p.x, p.y + h), col);
}

// The same triangle pointing left; `p` is its right edge.
inline void ArrowLeft(ImDrawList* dl, ImVec2 p, float h, ImU32 col, float = kStep) {
  p = Snap(p);
  dl->AddTriangleFilled(p, ImVec2(p.x, p.y + h), ImVec2(p.x - h * 0.6f, p.y + h * 0.5f), col);
}

// A small down-pointing triangle centred on `c`, `w` wide.
inline void ArrowDown(ImDrawList* dl, ImVec2 c, float w, ImU32 col) {
  c = Snap(c);
  dl->AddTriangleFilled(ImVec2(c.x - w * 0.5f, c.y - w * 0.25f), ImVec2(c.x + w * 0.5f, c.y - w * 0.25f), ImVec2(c.x, c.y + w * 0.3f), col);
}

}  // namespace wintek::ui::px
