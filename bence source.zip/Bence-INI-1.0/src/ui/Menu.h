#pragma once

namespace wintek::ui {

// Draws the whole menu: sidebar, the open tab's card, and the window height animating to fit it.
void DrawMenu();

}  // namespace wintek::ui
