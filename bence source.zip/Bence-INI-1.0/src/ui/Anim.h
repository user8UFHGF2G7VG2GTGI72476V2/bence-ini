#pragma once
#include "imgui.h"

namespace wintek::ui {

// Per-widget animation values, keyed by ImGui ID. Entries not used for a while are dropped.
struct AnimState {
  float value[3] = {};
  bool init = false;
  int lastFrame = -1;
};

AnimState& GetAnim(ImGuiID id);
void CollectAnims();  // once per frame

// Eases `value` toward `target` at `speed` per second (frame-rate independent). Returns the new value.
float Approach(float& value, float target, float speed);

}  // namespace wintek::ui
