#include "ui/Logo.h"
#include "ui/Theme.h"
#include <windows.h>
#include <wincodec.h>
#include <cstdint>
#include <vector>

namespace wintek::ui {

namespace {

// Layout of assets/images/logo_sheet.png: 75 frames of 128 x 128, 10 per row, 40 ms each.
constexpr int kFrameCount = 75;
constexpr int kColumns = 10;
constexpr int kRows = 8;
constexpr ULONGLONG kFrameMs = 40;

ID3D11ShaderResourceView* g_logo = nullptr;

template <typename T>
void SafeRelease(T*& p) {
  if (p) p->Release();
  p = nullptr;
}

}  // namespace

bool LoadLogo(ID3D11Device* device) {
  const HRSRC resource = FindResourceW(nullptr, L"MENU_LOGO", RT_RCDATA);
  const HGLOBAL loaded = resource ? LoadResource(nullptr, resource) : nullptr;
  auto* data = static_cast<BYTE*>(loaded ? LockResource(loaded) : nullptr);
  if (!data || !device) return false;
  const DWORD dataSize = SizeofResource(nullptr, resource);

  CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  IWICImagingFactory* factory = nullptr;
  IWICStream* stream = nullptr;
  IWICBitmapDecoder* decoder = nullptr;
  IWICBitmapFrameDecode* frame = nullptr;
  IWICFormatConverter* converter = nullptr;
  bool ok = false;
  UINT width = 0, height = 0;
  std::vector<std::uint8_t> pixels;

  if (SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory))) &&
      SUCCEEDED(factory->CreateStream(&stream)) && SUCCEEDED(stream->InitializeFromMemory(data, dataSize)) &&
      SUCCEEDED(factory->CreateDecoderFromStream(stream, nullptr, WICDecodeMetadataCacheOnLoad, &decoder)) &&
      SUCCEEDED(decoder->GetFrame(0, &frame)) && SUCCEEDED(factory->CreateFormatConverter(&converter)) &&
      SUCCEEDED(converter->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0,
                                      WICBitmapPaletteTypeCustom)) &&
      SUCCEEDED(converter->GetSize(&width, &height))) {
    pixels.resize(static_cast<size_t>(width) * height * 4);
    ok = SUCCEEDED(converter->CopyPixels(nullptr, width * 4, static_cast<UINT>(pixels.size()), pixels.data()));
  }
  SafeRelease(converter);
  SafeRelease(frame);
  SafeRelease(decoder);
  SafeRelease(stream);
  SafeRelease(factory);
  if (!ok) return false;

  D3D11_TEXTURE2D_DESC desc{};
  desc.Width = width;
  desc.Height = height;
  desc.MipLevels = 1;
  desc.ArraySize = 1;
  desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  desc.SampleDesc.Count = 1;
  desc.Usage = D3D11_USAGE_IMMUTABLE;
  desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
  D3D11_SUBRESOURCE_DATA init{ pixels.data(), width * 4, 0 };
  ID3D11Texture2D* texture = nullptr;
  if (FAILED(device->CreateTexture2D(&desc, &init, &texture))) return false;
  const HRESULT hr = device->CreateShaderResourceView(texture, nullptr, &g_logo);
  texture->Release();
  return SUCCEEDED(hr);
}

void ReleaseLogo() { SafeRelease(g_logo); }

void DrawLogo(ImDrawList* dl, const ImVec2& topLeft, float size) {
  const ImVec2 bottomRight(topLeft.x + size, topLeft.y + size);
  if (!g_logo) {
    dl->AddCircleFilled(ImVec2(topLeft.x + size * 0.5f, topLeft.y + size * 0.5f), size * 0.5f, Color(g_theme.accent));
    return;
  }
  const int index = static_cast<int>((GetTickCount64() / kFrameMs) % kFrameCount);
  const float u = 1.0f / kColumns, v = 1.0f / kRows;
  const ImVec2 uv0((index % kColumns) * u, (index / kColumns) * v);
  const ImVec2 uv1(uv0.x + u, uv0.y + v);
  dl->AddImageRounded((ImTextureID)(intptr_t)g_logo, topLeft, bottomRight, uv0, uv1, IM_COL32_WHITE, size * 0.5f);
}

}  // namespace wintek::ui
