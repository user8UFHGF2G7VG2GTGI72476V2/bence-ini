#pragma once
#include <d3d11.h>
#include "imgui.h"

namespace wintek::ui {

// The animated Bence logo. It's a sprite sheet compiled into the exe (MENU_LOGO in client/Resources.rc.in).
bool LoadLogo(ID3D11Device* device);
void ReleaseLogo();
// Draws the current animation frame as a circle of the given diameter.
void DrawLogo(ImDrawList* dl, const ImVec2& topLeft, float size);

}  // namespace wintek::ui
