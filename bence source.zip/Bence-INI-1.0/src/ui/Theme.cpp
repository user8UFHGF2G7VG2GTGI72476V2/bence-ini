#include "ui/Theme.h"

namespace wintek::ui {

void ApplyTheme() {
  ImGuiStyle& style = ImGui::GetStyle();
  style.WindowPadding = ImVec2(0, 0);
  style.WindowBorderSize = 0.0f;
  style.FramePadding = ImVec2(0, 0);
  style.ItemSpacing = ImVec2(6, 6);
  style.ScrollbarSize = 5.0f;
  style.ScrollbarRounding = 0.0f;
  style.FrameRounding = 0.0f;
  style.WindowRounding = 0.0f;
  style.ChildRounding = 0.0f;
  style.GrabRounding = 0.0f;
  style.PopupRounding = 8.0f;
  style.PopupBorderSize = 1.0f;
  style.Colors[ImGuiCol_Text] = g_theme.text;
  style.Colors[ImGuiCol_WindowBg] = ImVec4(0, 0, 0, 0);
  style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0, 0, 0, 0);
  style.Colors[ImGuiCol_ScrollbarGrab] = g_theme.border;
  style.Colors[ImGuiCol_ScrollbarGrabHovered] = g_theme.textDim;
  style.Colors[ImGuiCol_ScrollbarGrabActive] = g_theme.textDim;
}

}  // namespace wintek::ui
