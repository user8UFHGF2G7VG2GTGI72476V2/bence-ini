#pragma once

namespace wintek::ui {

// Vertical space each kind of row takes inside a card, including the 6 px item spacing after it.
// The tabs add these up to report their height.
constexpr float kToggleRowStep = 36.0f;  // 30 px row
constexpr float kSliderRowStep = 46.0f;  // label/value line + 18 px track
constexpr float kItemSpacing = 6.0f;

}  // namespace wintek::ui
