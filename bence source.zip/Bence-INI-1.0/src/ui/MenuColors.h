#pragma once
#include "imgui.h"

// The ten menu colours that can be changed one by one on the Config tab (Menu Colors). Each starts as the
// theme's own colour; a changed one is kept in Settings::colors as 0xRRGGBB until it's reset.
namespace wintek::ui {

constexpr int kMenuColorCount = 10;
extern const char* const kMenuColorNames[kMenuColorCount];

// The theme colour a slot changes (in g_theme).
ImVec4& MenuColor(int slot);
// Sets every g_theme colour for this frame: the theme, then Custom Accent Color, then any changed colours.
void ResolveMenuColors();

}  // namespace wintek::ui
