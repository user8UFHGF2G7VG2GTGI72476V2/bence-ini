#pragma once
#include "imgui.h"

// The menu's custom widgets. All of them fill the available width unless given a size.
namespace wintek::ui {

void NewFrame();

// A titled panel; the content between BeginCard and EndCard scrolls smoothly if it doesn't fit.
void BeginCard(const char* title, const ImVec2& size);
void EndCard();

bool SidebarTab(const char* label, bool selected, const ImVec2& size);

// A label with an on/off switch on the right. Returns true when clicked.
bool Toggle(const char* label, bool* on);
// Toggle with a hotkey box next to the switch: click the box, then press a key (Escape clears it).
bool ToggleBind(const char* label, bool* on, int* key);
bool IsBindingKey();
// A label with just a hotkey box on the right. With allowClear false, Escape cancels instead of unbinding.
bool KeyBind(const char* label, int* key, bool allowClear = true);

// A label with a "< option >" picker on the right; click the arrows to cycle. Returns true when changed.
bool Choice(const char* label, int* index, const char* const* items, int count);

bool SliderInt(const char* label, int* value, int min, int max, const char* format = "%d");
bool SliderFloat(const char* label, float* value, float min, float max, const char* format = "%.1f");

bool Button(const char* label, const ImVec2& size = ImVec2(0, 0));
bool NumberBox(const char* id, int* value, float width);

void Separator();
void HintText(const char* text);

}  // namespace wintek::ui
