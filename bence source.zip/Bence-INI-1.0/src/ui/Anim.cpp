#include "ui/Anim.h"
#include <unordered_map>

namespace wintek::ui {

namespace {

constexpr int kForgetAfterFrames = 600;
std::unordered_map<ImGuiID, AnimState> g_anims;

}  // namespace

AnimState& GetAnim(ImGuiID id) {
  AnimState& state = g_anims[id];
  state.lastFrame = ImGui::GetFrameCount();
  return state;
}

void CollectAnims() {
  const int frame = ImGui::GetFrameCount();
  for (auto it = g_anims.begin(); it != g_anims.end();) {
    if (frame - it->second.lastFrame > kForgetAfterFrames) it = g_anims.erase(it);
    else ++it;
  }
}

float Approach(float& value, float target, float speed) {
  float dt = ImGui::GetIO().DeltaTime;
  if (dt <= 0.0f) dt = 0.016f;
  if (dt > 0.05f) dt = 0.05f;
  float t = dt * speed;
  if (t > 1.0f) t = 1.0f;
  value += (target - value) * t;
  const float remaining = target - value;
  if (remaining < 0.001f && remaining > -0.001f) value = target;
  return value;
}

}  // namespace wintek::ui
