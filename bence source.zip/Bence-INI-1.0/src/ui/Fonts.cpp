#include "ui/Fonts.h"
#include "ui/Theme.h"
#include <windows.h>
#include <string>

namespace wintek::ui {

namespace {

// Where a font comes from: an RCDATA resource in the exe, or a file in the Windows fonts folder.
struct Source {
  const wchar_t* resource;  // nullptr for a Windows font
  const wchar_t* file;
  float size;
};

struct Choice {
  const char* name;
  Source body, title;
};

// Sizes are tuned so every font has about the same letter height as Pixelify, which the layout is built around.
constexpr Choice kChoices[] = {
  { "Pixelify", { L"MENU_FONT", nullptr, 16.0f }, { L"TITLE_FONT", nullptr, 16.0f } },
  { "Silkscreen", { L"TITLE_FONT", nullptr, 14.0f }, { L"TITLE_FONT", nullptr, 16.0f } },
  { "Press Start", { L"FONT_PRESSSTART", nullptr, 8.0f }, { L"FONT_PRESSSTART", nullptr, 10.0f } },
  { "VT323", { L"FONT_VT323", nullptr, 18.0f }, { L"FONT_VT323", nullptr, 22.0f } },
  { "Jersey", { L"FONT_JERSEY", nullptr, 20.0f }, { L"FONT_JERSEY", nullptr, 22.0f } },
  { "Tiny5", { L"FONT_TINY5", nullptr, 18.0f }, { L"FONT_TINY5", nullptr, 18.0f } },
  { "Micro5", { L"FONT_MICRO5", nullptr, 22.0f }, { L"FONT_MICRO5", nullptr, 24.0f } },
  { "Segoe UI", { nullptr, L"segoeui.ttf", 16.0f }, { nullptr, L"segoeuib.ttf", 16.0f } },
  { "Verdana", { nullptr, L"verdana.ttf", 14.0f }, { nullptr, L"verdanab.ttf", 15.0f } },
  { "Consolas", { nullptr, L"consola.ttf", 13.0f }, { nullptr, L"consolab.ttf", 14.0f } },
  { "Comic Sans", { nullptr, L"comic.ttf", 14.0f }, { nullptr, L"comicbd.ttf", 16.0f } },
};
constexpr int kCount = static_cast<int>(sizeof(kChoices) / sizeof(kChoices[0]));

struct Loaded {
  ImFont* body = nullptr;
  ImFont* title = nullptr;
};
Loaded g_loaded[kCount];

ImFont* LoadResourceFont(ImGuiIO& io, const wchar_t* name, float size) {
  const HRSRC resource = FindResourceW(nullptr, name, RT_RCDATA);
  const HGLOBAL loaded = resource ? LoadResource(nullptr, resource) : nullptr;
  void* data = loaded ? LockResource(loaded) : nullptr;
  if (!data) return nullptr;
  // Pixel fonts: no oversampling and snapped to whole pixels so they stay crisp and blocky.
  ImFontConfig config;
  config.FontDataOwnedByAtlas = false;  // resource memory belongs to the exe and stays mapped while it runs
  config.OversampleH = 1;
  config.OversampleV = 1;
  config.PixelSnapH = true;
  return io.Fonts->AddFontFromMemoryTTF(data, static_cast<int>(SizeofResource(nullptr, resource)), size, &config);
}

ImFont* LoadWindowsFont(ImGuiIO& io, const wchar_t* file, float size) {
  wchar_t folder[MAX_PATH];
  const UINT n = GetWindowsDirectoryW(folder, MAX_PATH);
  if (!n || n >= MAX_PATH) return nullptr;
  const std::wstring path = std::wstring(folder) + L"\\Fonts\\" + file;
  if (GetFileAttributesW(path.c_str()) == INVALID_FILE_ATTRIBUTES) return nullptr;
  char utf8[MAX_PATH * 3];
  if (!WideCharToMultiByte(CP_UTF8, 0, path.c_str(), -1, utf8, sizeof(utf8), nullptr, nullptr)) return nullptr;
  ImFontConfig config;
  config.OversampleH = 2;  // smooth fonts: a little oversampling keeps them sharp
  config.OversampleV = 1;
  return io.Fonts->AddFontFromFileTTF(utf8, size, &config);
}

ImFont* Load(ImGuiIO& io, const Source& source) {
  return source.resource ? LoadResourceFont(io, source.resource, source.size) : LoadWindowsFont(io, source.file, source.size);
}

}  // namespace

const char* const kMenuFontNames[] = {
  kChoices[0].name, kChoices[1].name, kChoices[2].name, kChoices[3].name, kChoices[4].name, kChoices[5].name,
  kChoices[6].name, kChoices[7].name, kChoices[8].name, kChoices[9].name, kChoices[10].name,
};
const int kMenuFontCount = kCount;
static_assert(sizeof(kMenuFontNames) / sizeof(kMenuFontNames[0]) == kCount, "every font needs a name");

void LoadMenuFonts(ImGuiIO& io) {
  // The first font added is ImGui's default, so the standard one (Pixelify) goes in first.
  for (int i = 0; i < kCount; ++i) {
    g_loaded[i].body = Load(io, kChoices[i].body);
    g_loaded[i].title = Load(io, kChoices[i].title);
  }
  if (!g_loaded[0].body) g_loaded[0].body = io.Fonts->AddFontDefault();
}

void UseMenuFont(int index) {
  if (index < 0 || index >= kCount || !g_loaded[index].body) index = 0;  // missing on this PC: the standard font
  ImGui::GetIO().FontDefault = g_loaded[index].body;
  g_titleFont = g_loaded[index].title ? g_loaded[index].title : g_loaded[index].body;
}

}  // namespace wintek::ui
