#pragma once
#include <cstdint>
#include <string>

// The Armor HUD's icons: the "ARK Armor Icons" pack (hud/ArmorIconData.h), matched to equipped items by class
// name the same way the original armor overlay did it.
namespace wintek {

constexpr int kArmorIconSize = 48;

// The icon for an item's class name (e.g. "PrimalItemArmor_RiotHelmet_C") in a slot (see ArmorSlot in
// hud/GameInfo.h), or -1 if none fits. Cached per class name.
int ArmorIconFor(const std::string& className, int slot);
// The icon's 48 x 48 premultiplied BGRA pixels, decoded on first use; nullptr if it can't be decoded.
const std::uint32_t* ArmorIconPixels(int icon);
// Which slot a name belongs to, from words like "Helmet", "Gloves" or "Shield"; -1 if none.
int ArmorSlotFromName(const std::string& name);

}  // namespace wintek
