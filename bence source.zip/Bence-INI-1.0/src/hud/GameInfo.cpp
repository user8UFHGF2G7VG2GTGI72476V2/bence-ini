#include "hud/GameInfo.h"
#include "core/Settings.h"
#include "hud/ArmorIcons.h"
#include "core/Diagnostics.h"
#include <windows.h>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <deque>
#include <mutex>
#include "engine/Debugger.h"

namespace wintek {

namespace {

constexpr int kHealth = 0;  // EPrimalCharacterStatusValue::Health
constexpr int kMaxAttachDepth = 4;

HudData g_data;
const char* g_lastSource = "not found";

std::unordered_map<Address, std::int32_t> g_offsets;  // (class ^ hash(name)) -> offset
std::int32_t Offset(Address cls, const char* name) {
  const Address key = cls ^ (std::hash<std::string>{}(name) << 1);
  auto it = g_offsets.find(key);
  if (it == g_offsets.end()) it = g_offsets.emplace(key, PropertyOffset(cls, name)).first;
  return it->second;
}

Address ReadPointer(Address object, const char* name) {
  if (!object) return 0;
  const std::int32_t offset = Offset(ClassOf(object), name);
  return offset ? Read<Address>(object + offset) : 0;
}

bool Plausible(float current, float max) {
  return std::isfinite(current) && std::isfinite(max) && max > 0.0f && max < 1e8f && current >= 0.0f && current <= max * 1.5f;
}

// Health from the character's status component, or the replicated values the game keeps for other players' HUDs.
bool ReadHealth(Address character, float& current, float& max) {
  if (!character) return false;
  if (const Address status = ReadPointer(character, "MyCharacterStatusComponent")) {
    const Address cls = ClassOf(status);
    const std::int32_t cur = Offset(cls, "CurrentStatusValues"), mx = Offset(cls, "MaxStatusValues");
    if (cur && mx) {
      current = Read<float>(status + cur + kHealth * sizeof(float));
      max = Read<float>(status + mx + kHealth * sizeof(float));
      if (Plausible(current, max)) {
        g_lastSource = "status component";
        return true;
      }
    }
  }
  const Address cls = ClassOf(character);
  const std::int32_t cur = Offset(cls, "ReplicatedCurrentHealth"), mx = Offset(cls, "ReplicatedMaxHealth");
  if (!cur || !mx) return false;
  current = Read<float>(character + cur);
  max = Read<float>(character + mx);
  if (!Plausible(current, max)) return false;
  g_lastSource = "replicated health";
  return true;
}

// The dino our character is attached to (riding), found through the attachment: our root component's parent
// belongs to the dino.
Address MountOf(Address pawn) {
  const Address root = ReadPointer(pawn, "RootComponent");
  const Address parent = ReadPointer(root, "AttachParent");
  int depth = 0;
  for (Address outer = parent ? Read<Address>(parent + offsets::object::kOuter) : 0; outer && depth < kMaxAttachDepth;
       outer = Read<Address>(outer + offsets::object::kOuter), ++depth)
    if (IsA(ClassOf(outer), "PrimalDinoCharacter")) return outer;
  return 0;
}

// ARK's map coordinates: Lat = latShift + Y / latScale, Lon = lonShift + X / lonScale, with a scale per map.
struct MapScale {
  const char* name;  // matched against the start of the world's name, lower case
  float latShift, latScale, lonShift, lonScale;
};
constexpr MapScale kMaps[] = {
  { "theisland", 50.0f, 8000.0f, 50.0f, 8000.0f },
  { "scorchedearth", 50.0f, 8000.0f, 50.0f, 8000.0f },
  { "aberration", 50.0f, 8000.0f, 50.0f, 8000.0f },
  { "extinction", 50.0f, 8000.0f, 50.0f, 8000.0f },
  { "thecenter", 30.34223747f, 9584.0f, 55.10416794f, 9600.0f },
  { "ragnarok", 50.009388f, 13100.0f, 50.009388f, 13100.0f },
  { "valguero", 50.0f, 8161.0f, 50.0f, 8161.0f },
  { "genesis2", 49.655f, 14500.0f, 49.655f, 14500.0f },
  { "gen2", 49.655f, 14500.0f, 49.655f, 14500.0f },
  { "genesis", 50.0f, 10500.0f, 50.0f, 10500.0f },
  { "crystalisles", 48.75f, 7925.0f, 50.0f, 9500.0f },
  { "lostisland", 48.7f, 15300.0f, 50.0f, 15300.0f },
  { "fjordur", 50.0f, 7140.0f, 50.0f, 7140.0f },
};

void ToGps(const std::string& world, float x, float y, float& lat, float& lon) {
  const std::string lower = ToLower(world);
  const MapScale* map = &kMaps[0];  // unknown maps: The Island's scale, the most common one
  for (const MapScale& m : kMaps)
    if (lower.rfind(m.name, 0) == 0) {
      map = &m;
      break;
    }
  lat = map->latShift + y / map->latScale;
  lon = map->lonShift + x / map->lonScale;
}

bool ReadLocation(Address actor, float& x, float& y, float& z) {
  const Address root = ReadPointer(actor, "RootComponent");
  const std::int32_t offset = root ? Offset(ClassOf(root), "RelativeLocation") : 0;
  if (!offset) return false;
  float v[3];
  if (!g_memory.ReadRaw(root + offset, v, sizeof(v)) || !std::isfinite(v[0]) || !std::isfinite(v[1]) || !std::isfinite(v[2])) return false;
  x = v[0];
  y = v[1];
  z = v[2];
  return true;
}

// FPS: counted, not guessed. The debugger's per-frame breakpoint (see engine/Debugger.h) stops the game thread
// once for every view it renders, so counting those stops per second is the frame rate. The breakpoint hands us
// the address of the view's projection data; each view keeps its own, so counting per address and taking the
// busiest one ignores anything that asks for a projection more than once a frame.
constexpr int kMaxViews = 16;

struct ViewCount {
  std::uintptr_t view;
  std::uint32_t frames;
};

std::mutex g_frameMutex;
ViewCount g_frames[kMaxViews] = {};

void CountFrame(std::uintptr_t projectionData) {  // debugger thread
  std::lock_guard<std::mutex> lock(g_frameMutex);
  for (ViewCount& v : g_frames) {
    if (v.view == projectionData || v.view == 0) {
      v.view = projectionData;
      ++v.frames;
      return;
    }
  }
}

struct {
  ULONGLONG windowStart = 0;
  bool counting = false;
} g_fps;

void TickFps(bool wanted) {
  static bool callbackSet = false;
  if (!callbackSet) {
    callbackSet = true;
    SetFrameCallback(DebuggerClient::FpsCounter, CountFrame);
  }
  RequestDebugger(DebuggerClient::FpsCounter, wanted);
  const ULONGLONG now = GetTickCount64();
  if (!wanted || !DebuggerAttached()) {
    g_fps.counting = false;
    g_data.fps = 0.0f;
    g_diag.fps = !wanted ? "off" : DebuggerError() ? std::string("debugger: ") + DebuggerError() : "waiting for debugger";
    return;
  }
  if (!g_fps.counting) {  // start a fresh one-second window
    std::lock_guard<std::mutex> lock(g_frameMutex);
    for (ViewCount& v : g_frames) v = {};
    g_fps.windowStart = now;
    g_fps.counting = true;
    g_diag.fps = "counting";
    return;
  }
  const ULONGLONG elapsed = now - g_fps.windowStart;
  if (elapsed < 1000) return;
  std::uint32_t busiest = 0;
  {
    std::lock_guard<std::mutex> lock(g_frameMutex);
    for (ViewCount& v : g_frames) {
      busiest = (std::max)(busiest, v.frames);
      v = {};
    }
  }
  g_fps.windowStart = now;
  g_data.fps = busiest * 1000.0f / static_cast<float>(elapsed);
  g_diag.fps = "counted " + std::to_string(static_cast<int>(g_data.fps + 0.5f));
}

// ------------------------------------------------------------------ armor
// The local player's equipped items, through the inventory component. Field names are looked up by reflection;
// if a name isn't found, the offset from the Microsoft Store build's SDK dump is used instead.
namespace armor {
constexpr std::int32_t kInventory = 0x0D20;         // APrimalCharacter::MyInventoryComponent
constexpr std::int32_t kInventoryItems = 0x0118;    // UPrimalInventoryComponent::InventoryItems
constexpr std::int32_t kEquipped = 0x0128;          // UPrimalInventoryComponent::EquippedItems
constexpr std::int32_t kQuality = 0x0298;           // UPrimalItem::ItemQualityIndex (uint8)
constexpr std::int32_t kDurability = 0x057C;        // UPrimalItem::ItemDurability (float)
constexpr int kMaxEquipped = 32;
constexpr int kMaxInventory = 2000;
}  // namespace armor

std::unordered_map<Address, float> g_armorBest;  // item -> highest durability seen this session

std::int32_t OffsetOr(Address cls, const char* name, std::int32_t fallback) {
  const std::int32_t found = Offset(cls, name);
  return found ? found : fallback;
}

// ArmorHud.h's stacking order from the item's class name; 99 when it isn't armor it knows.
int StackOrder(const std::string& n) {
  if (n.find("Shield") != std::string::npos) return 5;
  if (n.find("Helmet") != std::string::npos || n.find("Hat") != std::string::npos) return 4;
  if (n.find("Shirt") != std::string::npos || n.find("Chest") != std::string::npos) return 3;
  if (n.find("Gloves") != std::string::npos || n.find("Gauntlets") != std::string::npos) return 2;
  if (n.find("Pants") != std::string::npos || n.find("Legs") != std::string::npos) return 1;
  if (n.find("Boots") != std::string::npos || n.find("Feet") != std::string::npos) return 0;
  return 99;
}

std::vector<Address> ReadItemArray(Address inventory, const char* name, std::int32_t fallback, int limit) {
  std::vector<Address> items;
  const auto array = Read<TArray>(inventory + OffsetOr(ClassOf(inventory), name, fallback));
  if (!array.data || array.count <= 0 || array.count > limit) return items;
  items.resize(array.count);
  if (!g_memory.ReadRaw(array.data, items.data(), items.size() * sizeof(Address))) items.clear();
  return items;
}

// The local character's armor, as ArmorHud.h reads it: equipped items whose class is armor or a shield
// (saddles skipped), durability against the highest seen, quality, and spare copies carried.
void ReadArmor(Address pawn, Address controller) {
  g_data.armor.clear();
  if (!pawn) return;
  // Riding: if the pawn isn't the character, use the controller's last controlled character.
  Address character = pawn;
  if (!IsA(ClassOf(character), "ShooterCharacter") && controller) {
    const Address field = MainReflection().FindField(ClassOf(controller), "LastControlledPlayerCharacter");
    const std::int32_t at = field ? Read<std::int32_t>(field + offsets::reflection::kPropertyOffset) : 0;
    if (at > 0) {
      // A weak pointer: object index (+ serial); the object at that index must still report it.
      const std::int32_t index = Read<std::int32_t>(controller + at);
      const Address chunks = Read<Address>(GObjects());
      const Address chunk = index > 0 && chunks ? Read<Address>(chunks + (index / offsets::kObjectsPerChunk) * sizeof(Address)) : 0;
      const Address object = chunk ? Read<Address>(chunk + (index % offsets::kObjectsPerChunk) * offsets::kObjectItemSize) : 0;
      if (object && Read<std::int32_t>(object + offsets::object::kIndex) == index) character = object;
    }
  }
  const Address inventory = Read<Address>(character + OffsetOr(ClassOf(character), "MyInventoryComponent", armor::kInventory));
  if (!inventory) return;
  const std::vector<Address> equipped = ReadItemArray(inventory, "EquippedItems", armor::kEquipped, armor::kMaxEquipped);
  std::vector<Address> carried;  // read once, only if something needs counting
  bool carriedRead = false;

  for (const Address item : equipped) {
    if (!item) continue;
    const Address cls = ClassOf(item);
    const std::string& className = NameOf(cls);
    if (className.find("Saddle") != std::string::npos) continue;
    if (className.find("PrimalItemArmor") == std::string::npos && className.find("ArmorPrimalItem") == std::string::npos &&
        className.find("Shield") == std::string::npos)
      continue;
    ArmorPiece piece;
    piece.order = StackOrder(className);
    piece.slot = ArmorSlotFromName(className);
    piece.icon = piece.slot >= 0 ? ArmorIconFor(className, piece.slot) : -1;
    piece.durability = Read<float>(item + OffsetOr(cls, "ItemDurability", armor::kDurability));
    piece.quality = Read<std::uint8_t>(item + OffsetOr(cls, "ItemQualityIndex", armor::kQuality));
    if (piece.quality > 5) piece.quality = 0;
    // ARK exposes no readable max durability; the highest value seen is it.
    if (std::isfinite(piece.durability) && piece.durability > 0.0f) {
      float& best = g_armorBest[item];
      best = (std::max)(best, piece.durability);
      piece.fraction = std::clamp(piece.durability / best, 0.0f, 1.0f);
    } else {
      piece.fraction = 0.0f;
    }
    if (!carriedRead) {
      carried = ReadItemArray(inventory, "InventoryItems", armor::kInventoryItems, armor::kMaxInventory);
      carriedRead = true;
    }
    for (const Address other : carried)
      if (other && other != item && ClassOf(other) == cls) ++piece.spares;
    g_data.armor.push_back(piece);
    if (g_data.armor.size() >= 12) break;
  }
  std::sort(g_data.armor.begin(), g_data.armor.end(), [](const ArmorPiece& a, const ArmorPiece& b) { return a.order < b.order; });
  g_diag.armorItems = static_cast<int>(g_data.armor.size());
}

void ReadExtraInfo(const GameContext& game){
  static ULONGLONG last=0;const auto now=GetTickCount64();if(now-last<1000)return;last=now;
  g_data.ping=g_data.players=g_data.inventoryUsed=g_data.inventoryMax=-1;g_data.serverFps=-1;g_data.serverName.clear();g_data.enemyTurrets=g_data.friendlyTurrets=0;
  const auto& s=g_settings.hud;if(!s.info.on||!game.pawn)return;
  Address ps=ReadPointer(game.controller,"PlayerState");int at=ps?Offset(ClassOf(ps),"Ping"):0;if(s.infoPing&&at)g_data.ping=4*Read<unsigned char>(ps+at);
  Address state=ReadPointer(game.world,"GameState");
  auto gsOffset=[&](const char* name,int fallback){int off=state?Offset(ClassOf(state),name):0;return off?off:state&&IsA(ClassOf(state),"ShooterGameState")?fallback:0;};
  if(s.infoPlayers&&(at=gsOffset("NumPlayerConnected",0x568))){int n=Read<int>(state+at);if(n>=0&&n<100000)g_data.players=n;}
  if(s.infoServerFps&&(at=gsOffset("ServerFramerate",0x578))){float n=Read<float>(state+at);if(std::isfinite(n)&&n>=0&&n<10000)g_data.serverFps=n;}
  if(s.infoServerName&&(at=gsOffset("ServerSessionName",0x948))){TArray a=Read<TArray>(state+at);if(a.data&&a.count>0&&a.count<=256){std::wstring name(a.count,L'\0');if(g_memory.ReadRaw(a.data,name.data(),name.size()*2)){while(!name.empty()&&!name.back())name.pop_back();g_data.serverName=std::move(name);}}}
  if(s.infoSlots){Address inv=ReadPointer(game.pawn,"MyInventoryComponent");if(inv){auto items=ReadItemArray(inv,"InventoryItems",armor::kInventoryItems,20000);g_data.inventoryUsed=0;static BoolProperty engram("bIsEngram");for(auto item:items)if(item&&!engram.Get(item))++g_data.inventoryUsed;at=Offset(ClassOf(inv),"MaxInventoryItems");int n=at?Read<int>(inv+at):0;g_data.inventoryMax=n>0&&n<100000?n:300;}}
  if(s.infoTurrets||s.infoFriendlyTurrets){float me[3];if(!ReadLocation(game.pawn,me[0],me[1],me[2]))return;float range=10000;at=gsOffset("LimitTurretsRange",0xa00);if(at){float r=Read<float>(state+at);if(std::isfinite(r)&&r>=100&&r<=100000)range=r;}
    int teamAt=Offset(ClassOf(game.pawn),"TargetingTeam");int team=teamAt?Read<int>(game.pawn+teamAt):0;
    // Sweep the loaded levels, rather than the entire object table on each HUD frame.
    at=Offset(ClassOf(game.world),"Levels");if(!at)at=offsets::world::kLevels;TArray levels=Read<TArray>(game.world+at);
    if(!levels.data||levels.count<0||levels.count>256)return;
    for(int l=0;l<levels.count;++l){Address level=Read<Address>(levels.data+l*8);if(!level)continue;int actorsAt=Offset(ClassOf(level),"Actors");if(!actorsAt)actorsAt=offsets::world::kLevelActors;TArray actors=Read<TArray>(level+actorsAt);if(!actors.data||actors.count<=0||actors.count>200000)continue;
      for(int i=0;i<actors.count;++i){Address a=Read<Address>(actors.data+i*8);if(!a||!IsA(ClassOf(a),"PrimalStructureTurret"))continue;float p[3];if(!ReadLocation(a,p[0],p[1],p[2]))continue;float dx=p[0]-me[0],dy=p[1]-me[1],dz=p[2]-me[2];if(dx*dx+dy*dy+dz*dz>range*range)continue;int t=Offset(ClassOf(a),"TargetingTeam");if(t&&team&&Read<int>(a+t)==team)++g_data.friendlyTurrets;else ++g_data.enemyTurrets;}
    }
  }
}
}  // namespace

void TickGameInfo(const GameContext& game, bool wantFps) {
  static Address sessionWorld = 0;
  if (game.world && game.world != sessionWorld) {
    sessionWorld = game.world;
    g_data.map = NameOf(game.world);
    g_data.sessionStartMs = GetTickCount64();
  }
  TickFps(wantFps);
  ReadExtraInfo(game);

  const Address pawn = game.pawn;
  g_data.inGame = game.world && pawn;
  g_lastSource = "not found";
  g_data.hasHealth = g_data.inGame && ReadHealth(pawn, g_data.health, g_data.maxHealth);
  g_diag.pawn = pawn != 0;
  g_diag.healthSource = g_data.hasHealth ? std::string(g_lastSource) + " " + std::to_string(static_cast<int>(g_data.health)) + "/" +
                                               std::to_string(static_cast<int>(g_data.maxHealth))
                                         : std::string(g_lastSource);
  const Address mount = g_data.inGame ? MountOf(pawn) : 0;
  g_data.riding = mount && ReadHealth(mount, g_data.mountHealth, g_data.mountMaxHealth);
  g_data.hasLocation = g_data.inGame && ReadLocation(mount ? mount : pawn, g_data.x, g_data.y, g_data.z);
  g_diag.mount = mount != 0;
  if (g_data.hasLocation) ToGps(g_data.map, g_data.x, g_data.y, g_data.lat, g_data.lon);
  g_diag.location = g_data.hasLocation;
  ReadArmor(g_data.inGame ? pawn : 0, game.controller);
  g_diag.map = g_data.map.empty() ? "-" : g_data.map;
}

const HudData& GameInfo() { return g_data; }

void ResetGameInfo() {
  g_data = {};
  g_offsets.clear();
  g_armorBest.clear();
  g_fps = {};
  RequestDebugger(DebuggerClient::FpsCounter, false);
}

}  // namespace wintek
