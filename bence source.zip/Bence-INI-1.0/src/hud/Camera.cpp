#include "hud/Camera.h"
#include <cmath>
#include <vector>

namespace wintek {

namespace {

constexpr std::size_t kSearchFrom = 0x200, kSearchTo = 0x2400;
constexpr float kNearCharacterCm = 3000.0f;

CameraView g_view;

struct {
  Address cameraClass = 0, cameraObject = 0;
  int fovAt = 0x28;  // ARK inserts AimRotation before FOV
  std::int32_t povAt = -1;  // offset of the cached view's location in the camera manager
  std::int32_t controlRotationAt = 0;
  Address controllerClass = 0;
} g_find;

float AngleDiff(float a, float b) {
  float d = std::fmod(a - b, 360.0f);
  if (d > 180.0f) d -= 360.0f;
  if (d < -180.0f) d += 360.0f;
  return std::fabs(d);
}

bool Finite(const float* v, int n) {
  for (int i = 0; i < n; ++i)
    if (!std::isfinite(v[i])) return false;
  return true;
}

bool PawnLocation(Address pawn, float out[3]) {
  const int rootAt=pawn ? PropertyOffset(ClassOf(pawn),"RootComponent") : 0;
  const Address root = rootAt ? Read<Address>(pawn + rootAt) : 0;
  const std::int32_t at = root ? PropertyOffset(ClassOf(root), "RelativeLocation") : 0;
  return at && g_memory.ReadRaw(root + at, out, 3 * sizeof(float));
}

}  // namespace

void TickCamera(const GameContext& game) {
  g_view.valid = false;
  g_view.approximate = false;
  if (!game.camera || !game.controller || !game.pawn) return;
  const Address camClass = ClassOf(game.camera);
  if (camClass != g_find.cameraClass || game.camera != g_find.cameraObject) {
    g_find.cameraClass = camClass;g_find.cameraObject=game.camera;
    g_find.povAt = -1;g_find.fovAt=0x28;
    auto fieldAt=[](Address owner,const char* name)->int {
      const Address field=MainReflection().FindField(owner,name);
      return field ? Read<int>(field+offsets::reflection::kPropertyOffset) : -1;
    };
    const Address cache=MainReflection().FindField(camClass,"CameraCache");
    if(cache && NameOf(ClassOf(cache))=="StructProperty") {
      const Address cacheType=Read<Address>(cache+0x70);
      const Address pov=cacheType ? MainReflection().FindField(cacheType,"POV") : 0;
      const Address viewType=pov && NameOf(ClassOf(pov))=="StructProperty" ? Read<Address>(pov+0x70) : 0;
      const int cacheAt=fieldAt(camClass,"CameraCache"),povAt=cacheType ? fieldAt(cacheType,"POV") : -1;
      const int loc=viewType ? fieldAt(viewType,"Location") : -1,rot=viewType ? fieldAt(viewType,"Rotation") : -1;
      const int fov=viewType ? fieldAt(viewType,"FOV") : -1;
      if(cacheAt>=0x200 && cacheAt<0x2400 && povAt>=0 && povAt<0x100 && loc==0 && rot==12 && fov>=24 && fov<=64 && fov%4==0) {
        g_find.povAt=cacheAt+povAt;g_find.fovAt=fov;
      }
    }
    // Layout from the supplied ARK SDK, gated by a reflected member at its expected offset.
    if(g_find.povAt<0 && IsA(camClass,"PlayerCameraManager") && PropertyOffset(camClass,"DefaultFOV")==0x498) {
      g_find.povAt=0x4F0;g_find.fovAt=0x28;
    }
  }
  if (ClassOf(game.controller) != g_find.controllerClass) {
    g_find.controllerClass = ClassOf(game.controller);
    g_find.controlRotationAt = PropertyOffset(g_find.controllerClass, "ControlRotation");
  }

  float fallbackPos[3], fallbackAim[3];
  if (g_find.controlRotationAt && PawnLocation(game.pawn, fallbackPos) &&
      g_memory.ReadRaw(game.controller + g_find.controlRotationAt, fallbackAim, sizeof(fallbackAim)) &&
      Finite(fallbackPos, 3) && Finite(fallbackAim, 3)) {
    for (int i = 0; i < 3; ++i) g_view.location[i] = fallbackPos[i];
    g_view.location[2] += 60.0f;
    g_view.pitch = fallbackAim[0]; g_view.yaw = fallbackAim[1]; g_view.roll = fallbackAim[2];
    const int fovAt = PropertyOffset(camClass, "DefaultFOV");
    const float fov = fovAt ? Read<float>(game.camera + fovAt) : 90.0f;
    g_view.fov = std::isfinite(fov) && fov >= 20.0f && fov <= 170.0f ? fov : 90.0f;
    g_view.valid = true;
    g_view.approximate = true;
  }

  if (g_find.povAt < 0) {
    // Support both ordinary UE and ARK's extra AimRotation layout, including orbit cameras.
    float pawn[3],aim[3]={};
    if(!PawnLocation(game.pawn,pawn))return;
    const bool haveAim=g_find.controlRotationAt && g_memory.ReadRaw(game.controller+g_find.controlRotationAt,aim,sizeof(aim));
    std::vector<float> mem((kSearchTo-kSearchFrom)/sizeof(float));
    if(!g_memory.ReadRaw(game.camera+kSearchFrom,mem.data(),mem.size()*sizeof(float)))return;
    float best=-1;
    for(std::size_t i=0;i+11<=mem.size();++i) {
      const float* v=&mem[i];if(!Finite(v,6))continue;
      const float dx=pawn[0]-v[0],dy=pawn[1]-v[1],dz=pawn[2]+60-v[2];
      const float distance=std::sqrt(dx*dx+dy*dy+dz*dz);
      if(!std::isfinite(distance)||distance>kNearCharacterCm)continue;
      if(std::fabs(v[3])>360||std::fabs(v[4])>360||std::fabs(v[5])>360)continue;
      const bool aimed=haveAim && AngleDiff(v[3],aim[0])<2 && AngleDiff(v[4],aim[1])<2;
      constexpr float rad=3.14159265359f/180.0f;
      const float cp=std::cos(v[3]*rad),sp=std::sin(v[3]*rad),cy=std::cos(v[4]*rad),sy=std::sin(v[4]*rad);
      const float toward=distance>50 ? (dx*cp*cy+dy*cp*sy+dz*sp)/distance : -1;
      if(!aimed && toward<0.8f)continue;
      for(int fovAt:{0x28,0x18}) {
        const float fov=v[fovAt/4];
        if(!std::isfinite(fov)||fov<20||fov>170)continue;
        const float score=(fovAt==0x28 ? 2.0f : 0.0f)+(aimed ? 1.0f : 0.0f)+(toward>0.8f ? 3.0f : 0.0f)-std::fabs(fov-g_view.fov)*0.01f;
        if(score>best){best=score;g_find.povAt=static_cast<int>(kSearchFrom+i*sizeof(float));g_find.fovAt=fovAt;}
      }
    }
    if (g_find.povAt < 0) return;
  }

  float v[22]={};
  if (!g_memory.ReadRaw(game.camera + g_find.povAt, v, (g_find.fovAt/4+1)*sizeof(float)) || !Finite(v, 6) || !std::isfinite(v[g_find.fovAt/4]) || v[g_find.fovAt/4] < 20.0f || v[g_find.fovAt/4] > 170.0f) {
    g_find.povAt = -1;  // moved or stale: look again
    return;
  }
  g_view.location[0] = v[0];
  g_view.location[1] = v[1];
  g_view.location[2] = v[2];
  g_view.pitch = v[3];
  g_view.yaw = v[4];
  g_view.roll = v[5];
  g_view.fov = v[g_find.fovAt/4];
  g_view.valid = true;
  g_view.approximate = false;
}

const CameraView& Camera() { return g_view; }

void ResetCamera() {
  g_view = {};
  g_find = {};
}

bool ProjectToScreen(const CameraView& view, const float world[3], int width, int height, float& x, float& y) {
  if (!view.valid || width <= 0 || height <= 0) return false;
  constexpr float kDeg = 3.14159265f / 180.0f;
  const float sp = std::sin(view.pitch * kDeg), cp = std::cos(view.pitch * kDeg);
  const float sy = std::sin(view.yaw * kDeg), cy = std::cos(view.yaw * kDeg);
  const float sr = std::sin(view.roll * kDeg), cr = std::cos(view.roll * kDeg);
  // Unreal's rotation matrix axes: forward (X), right (Y), up (Z).
  const float fwd[3] = { cp * cy, cp * sy, sp };
  const float right[3] = { sr * sp * cy - cr * sy, sr * sp * sy + cr * cy, -sr * cp };
  const float up[3] = { -(cr * sp * cy + sr * sy), cy * sr - cr * sp * sy, cr * cp };
  const float d[3] = { world[0] - view.location[0], world[1] - view.location[1], world[2] - view.location[2] };
  const float cx = d[0] * fwd[0] + d[1] * fwd[1] + d[2] * fwd[2];
  if (cx <= 1.0f) return false;
  const float rx = d[0] * right[0] + d[1] * right[1] + d[2] * right[2];
  const float uz = d[0] * up[0] + d[1] * up[1] + d[2] * up[2];
  const float focal = (width * 0.5f) / std::tan(view.fov * 0.5f * kDeg);  // the FOV is horizontal
  x = width * 0.5f + rx / cx * focal;
  y = height * 0.5f - uz / cx * focal;
  return true;
}

}  // namespace wintek
