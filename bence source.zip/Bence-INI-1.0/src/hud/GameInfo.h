#pragma once
#include "engine/Engine.h"
#include <string>
#include <vector>

// What the HUD overlays show, read from the game every feature tick. Only the local player's own character
// and the dino they're riding are read.
namespace wintek {

// Armor slots, in the order the Armor HUD shows them.
enum ArmorSlot { kHelmet, kChest, kGauntlets, kLeggings, kBoots, kShield, kArmorSlots };

struct ArmorPiece {
  int order = 99;          // stacking order, bottom up: boots 0, pants 1, gloves 2, chest 3, helmet 4, shield 5
  int slot = -1;           // ArmorSlot, for the icon
  float durability = 0.0f;
  float fraction = -1.0f;  // durability left, 0..1 (against the highest seen); -1 when unknown
  int quality = 0;         // ItemQualityIndex: 0 primitive .. 5 ascendant
  int spares = 0;          // copies of the same item in your inventory
  int icon = -1;           // index into the icon pack (hud/ArmorIcons.h), -1 for the plain pixel icon
};

struct HudData {
  bool inGame = false;   // a world with our character in it
  bool hasHealth = false;
  float health = 0.0f, maxHealth = 0.0f;
  bool riding = false;
  float mountHealth = 0.0f, mountMaxHealth = 0.0f;
  bool hasLocation = false;
  float x = 0.0f, y = 0.0f, z = 0.0f;
  float lat = 0.0f, lon = 0.0f;  // the map's GPS coordinates, as ARK's own map shows them
  std::string map;               // the world's name, e.g. "TheIsland"
  int ping=-1, players=-1, enemyTurrets=0, friendlyTurrets=0, inventoryUsed=-1, inventoryMax=-1;
  float serverFps=-1;std::wstring serverName;
  float fps = 0.0f;  // 0 while unknown
  std::vector<ArmorPiece> armor;  // equipped armor, sorted bottom-up (boots first)
  unsigned long long sessionStartMs = 0;  // when the current world loaded
};

// `wantFps`: the FPS line is showing, so frames are counted (this keeps the debugger attached, see
// engine/Debugger.h).
void TickGameInfo(const GameContext& game, bool wantFps);
const HudData& GameInfo();
void ResetGameInfo();

}  // namespace wintek
