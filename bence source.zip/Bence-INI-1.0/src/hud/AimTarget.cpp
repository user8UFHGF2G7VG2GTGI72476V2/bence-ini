#include "hud/AimTarget.h"
#include "core/Process.h"
#include "core/GameWindow.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <array>
#include <algorithm>
#include <cmath>
#include <unordered_map>
namespace wintek {namespace {
constexpr int kSlot=512;
struct Field{int at=-1,size=0;Address field=0;};
Field Param(Address type,const char* name,int bytes=0){
 Address f=MainReflection().FindField(type,name);if(!f)return {};
 int at=Read<int>(f+offsets::reflection::kPropertyOffset),size=Read<int>(f+0x34);
 if(at<0||size<1||at+size>kSlot||(bytes&&size!=bytes))return {};return {at,size,f};
}
template<class T>bool Put(std::array<unsigned char,kSlot>& b,Address fn,const char* name,const T& value){auto p=Param(fn,name,sizeof(T));if(p.at<0)return false;std::memcpy(b.data()+p.at,&value,sizeof(T));return true;}
Address Obj(Address o,const char* n){int at=o?PropertyOffset(ClassOf(o),n):0;return at?Read<Address>(o+at):0;}
float Number(Address o,const char* n){int at=o?PropertyOffset(ClassOf(o),n):0;float v=at?Read<float>(o+at):0;return std::isfinite(v)?v:0;}
std::wstring Text(Address o,const char* name){int at=o?PropertyOffset(ClassOf(o),name):0;TArray a=at?Read<TArray>(o+at):TArray{};if(!a.data||a.count<2||a.count>128)return {};std::wstring s(a.count,L'\0');if(!g_memory.ReadRaw(a.data,s.data(),s.size()*2)||s.back()!=0)return {};s.pop_back();return s;}
bool Position(Address a,float p[3]){Address root=Obj(a,"RootComponent");int at=root?PropertyOffset(ClassOf(root),"RelativeLocation"):0;return at&&g_memory.ReadRaw(root+at,p,12)&&std::isfinite(p[0])&&std::isfinite(p[1])&&std::isfinite(p[2]);}
Address Weak(Address p){int i=Read<int>(p),serial=Read<int>(p+4);if(i<0||serial<=0||i>=Read<int>(GObjects()+offsets::kObjectCount))return 0;Address chunks=Read<Address>(GObjects()),chunk=chunks?Read<Address>(chunks+(i/offsets::kObjectsPerChunk)*8):0;if(!chunk)return 0;Address slot=chunk+(i%offsets::kObjectsPerChunk)*offsets::kObjectItemSize;if(Read<int>(slot+8)!=serial)return 0;Address o=Read<Address>(slot);return o&&ObjectRef::Of(o).Alive()?o:0;}
Address world=0,buffer=0,function=0;DWORD pid=0;Field hit,actor,impact,blocking;unsigned char blockingMask=0;
std::uint64_t ticket=0;ULONGLONG sent=0,stamp=0,lastFire=0;ObjectRef requestedPawn,lastTarget;float lastHealth=-1;Address lastWeapon=0;
AimTargetData data;
struct Learned{std::array<float,4> samples{};int count=0,next=0;};
struct Key{Address weapon,target;bool operator==(const Key& b)const{return weapon==b.weapon&&target==b.target;}};
struct Hash{std::size_t operator()(const Key& k)const{return (k.weapon>>4)^(k.target<<1);}};
std::unordered_map<Key,Learned,Hash> learned;
bool Ready(){return !ticket||CompletedCalls()>=ticket;}
bool Resolve(Address pawn){
 Address fn=MainReflection().FindField(ClassOf(pawn),"GetAimedActor");if(!fn||NameOf(ClassOf(fn))!="Function")return false;
 if(function==fn)return true;
 Field h;int count=0;for(Address f=Read<Address>(fn+offsets::reflection::kChildren);f&&count++<32;f=Read<Address>(f+offsets::reflection::kNext))if(NameOf(ClassOf(f))=="StructProperty"){
  Address type=Read<Address>(f+0x70);if(NameOf(type)=="HitResult"){h=Param(fn,NameOf(f).c_str());break;}}
 if(h.at<0||h.size<100||h.size>256)return false;Address type=Read<Address>(h.field+0x70);
 auto a=Param(type,"Actor",8),p=Param(type,"ImpactPoint",12),b=Param(type,"bBlockingHit",1);
 if(a.at<0||p.at<0||b.at<0||a.at+8>h.size||p.at+12>h.size||b.at>=h.size||NameOf(ClassOf(a.field))!="WeakObjectProperty")return false;
 auto mask=Read<unsigned char>(b.field+offsets::reflection::kBoolFieldMask);b.at+=Read<unsigned char>(b.field+offsets::reflection::kBoolByteOffset);if(!mask||b.at>=h.size)return false;
 function=fn;hit=h;actor=a;impact=p;blocking=b;blockingMask=mask;return true;
}
void Consume(const GameContext& g,ULONGLONG now){
 if(!ticket||!Ready())return;ticket=0;data={};
 if(!requestedPawn.Alive()||requestedPawn.object!=g.pawn||now-sent>1000)return;
 float me[3];if(!Position(g.pawn,me))return;
 for(int n=0;n<2;++n){Address h=buffer+n*kSlot+hit.at;if(!(Read<unsigned char>(h+blocking.at)&blockingMask))continue;Address o=Weak(h+actor.at);if(!o||o==g.pawn)continue;
  float p[3];if(!g_memory.ReadRaw(h+impact.at,p,12))continue;float sq=0;for(int i=0;i<3;++i)sq+=(p[i]-me[i])*(p[i]-me[i]);float distance=std::sqrt(sq)/100.f;if(!std::isfinite(distance)||distance>700)continue;
  if(data.target.object&&distance>=data.distanceM)continue;
  data.target=ObjectRef::Of(o);data.distanceM=distance;
 }
 if(data.target.object){Address o=data.target.object;bool character=IsA(ClassOf(o),"PrimalCharacter");data.health=Number(o,character?"ReplicatedCurrentHealth":"ReplicatedHealth");data.maxHealth=Number(o,character?"ReplicatedMaxHealth":"MaxHealth");data.name=Text(o,"TamedName");if(data.name.empty())data.name=Text(o,"PlayerName");if(data.name.empty())data.name=Text(o,"DescriptiveName");if(data.name.empty()){auto n=NameOf(ClassOf(o));data.name.assign(n.begin(),n.end());}}
 stamp=now;
}
}
void TickAimTarget(const GameContext& game,const HudSettings& s,bool restoring){
 const auto now=GetTickCount64();if(world&&world!=game.world){if(!Ready())return;ResetAimTarget();}world=game.world;
 bool enabled=!restoring&&game.pawn&&game.hud&&(s.spyglass.on||s.tekIndicator.on)&&!Read<Address>(game.hud+offsets::hud::kOpenInventory);
 RequestDebugger(DebuggerClient::AimTarget,enabled||!Ready());
 if(Ready())Consume(game,now);
 if(!enabled){data={};lastTarget={};lastHealth=-1;return;}
 if(now-stamp>500)data={};
 Address weapon=Obj(game.pawn,"CurrentWeapon"),weaponClass=weapon?ClassOf(weapon):0;
 bool tek=weaponClass&&ToLower(NameOf(weaponClass)).find("tekrifle")!=std::string::npos;
 data.indicator=s.tekIndicator.on&&(s.tekAnyWeapon||tek)&&data.target.Alive()&&data.maxHealth>0&&data.health>=0&&data.health<=data.maxHealth*1.5f;
 if(data.indicator){
  if(FindGameWindow(g_process.pid).IsActive(GetForegroundWindow())&&(GetAsyncKeyState(VK_LBUTTON)&0x8000))lastFire=now;
  auto& sample=learned[{weaponClass,ClassOf(data.target.object)}];
  if(lastTarget==data.target&&lastWeapon==weaponClass&&lastHealth>data.health+.5f&&lastFire&&now-lastFire<=1500){sample.samples[sample.next]=lastHealth-data.health;sample.next=(sample.next+1)%4;sample.count=(std::min)(4,sample.count+1);}
  lastTarget=data.target;lastHealth=data.health;lastWeapon=weaponClass;
  float sum=0;for(int i=0;i<sample.count;++i)sum+=sample.samples[i];data.shots=sample.count&&sum>0?static_cast<int>((std::min)(1000000.f,std::ceil(data.health/(sum/sample.count)))):-1;
  data.inRange=data.distanceM<=std::clamp(s.tekRange,1,300);
 }else {lastTarget={};lastHealth=-1;}
 if(!Ready()||now-sent<100||!DebuggerAttached()||!Resolve(game.pawn))return;
 if(!buffer){buffer=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kSlot*2,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));pid=g_process.pid;}if(!buffer)return;
 for(int n=0;n<2;++n){std::array<unsigned char,kSlot>b{};unsigned char channel=n?2:3,yes=1;float distance=std::clamp(s.spyRange,20,700)*100.f;
  if(!Put(b,function,"CollisionChannel",channel)||!Put(b,function,"MaxDistanceOverride",distance)||!Put(b,function,"bForceUseCameraLocation",yes))return;
  if(!g_memory.WriteRaw(buffer+n*kSlot,b.data(),b.size()))return;
  auto t=QueueProcessEvent(game.pawn,function,buffer+n*kSlot);if(t)ticket=t;
 }
 sent=now;requestedPawn=ObjectRef::Of(game.pawn);
}
const AimTargetData& AimTarget(){return data;}
void FlushAimTarget(unsigned long timeout){auto until=GetTickCount64()+timeout;while(!Ready()&&GetTickCount64()<until){TickDebugger();Sleep(1);}}
void ResetAimTarget(){if(pid==g_process.pid&&buffer&&g_process.handle&&Ready())VirtualFreeEx(g_process.handle,reinterpret_cast<void*>(buffer),0,MEM_RELEASE);buffer=world=function=0;pid=0;ticket=sent=stamp=lastFire=0;data={};requestedPawn=lastTarget={};lastHealth=-1;lastWeapon=0;learned.clear();RequestDebugger(DebuggerClient::AimTarget,false);}
}
