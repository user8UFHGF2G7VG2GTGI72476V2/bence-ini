#pragma once
#include "engine/Engine.h"

// The game camera's view (location, rotation, field of view), for placing overlay markers on things in the
// world. Read from the camera manager's cached view; where that sits in memory is found once by looking for
// a location next to your character followed by the rotation you're aiming with and a sensible FOV.
namespace wintek {

struct CameraView {
  bool valid = false;
  bool approximate = false;  // pawn/controller fallback when the cached camera cannot be found
  float location[3] = {};
  float pitch = 0.0f, yaw = 0.0f, roll = 0.0f;  // degrees
  float fov = 90.0f;                            // horizontal, degrees
};

void TickCamera(const GameContext& game);
const CameraView& Camera();
void ResetCamera();

// World position -> overlay pixel for a `width` x `height` game window. False if it's behind the camera.
bool ProjectToScreen(const CameraView& view, const float world[3], int width, int height, float& x, float& y);

}  // namespace wintek
