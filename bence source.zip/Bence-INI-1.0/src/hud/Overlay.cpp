#include "hud/Overlay.h"
#include "core/Diagnostics.h"
#include "core/GameWindow.h"
#include "core/Process.h"
#include "core/Settings.h"
#include "hud/ArmorIcons.h"
#include "hud/GameInfo.h"
#include "hud/Spyglass.h"
#include "hud/AimTarget.h"
#include "hud/PlayerList.h"
#include "hud/Camera.h"
#include "hud/Targeting.h"
#include "misc/TurretFiller.h"
#include "hud/HudStyle.h"
#include "ui/Theme.h"
#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <cwctype>
#include <map>
#include <string>

namespace wintek {

namespace {

constexpr DWORD kFrameMs = 33;
constexpr DWORD kFindWindowMs = 1000;

// ---------------------------------------------------------------- pixels

// A 32-bit premultiplied-alpha pixel buffer (what UpdateLayeredWindow wants).
struct Canvas {
  std::uint32_t* px = nullptr;
  int w = 0, h = 0;

  void Clear() { std::memset(px, 0, static_cast<std::size_t>(w) * h * 4); }

  void Blend(int x, int y, std::uint32_t rgb, int a) {
    if (x < 0 || y < 0 || x >= w || y >= h || a <= 0) return;
    std::uint32_t& d = px[y * w + x];
    const int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
    if (a >= 255) {
      d = 0xFF000000u | (r << 16) | (g << 8) | b;
      return;
    }
    const int inv = 255 - a;
    const int da = d >> 24, dr = (d >> 16) & 0xFF, dg = (d >> 8) & 0xFF, db = d & 0xFF;
    d = (static_cast<std::uint32_t>(a + da * inv / 255) << 24) | ((r * a / 255 + dr * inv / 255) << 16) |
        ((g * a / 255 + dg * inv / 255) << 8) | (b * a / 255 + db * inv / 255);
  }

  void Rect(int x0, int y0, int x1, int y1, std::uint32_t rgb, int a = 255) {  // x1, y1 exclusive
    x0 = (std::max)(x0, 0);
    y0 = (std::max)(y0, 0);
    x1 = (std::min)(x1, w);
    y1 = (std::min)(y1, h);
    for (int y = y0; y < y1; ++y)
      for (int x = x0; x < x1; ++x) Blend(x, y, rgb, a);
  }

  // A box with stepped pixel corners and an outline, like the menu.
  void PixelBox(int x0, int y0, int x1, int y1, std::uint32_t fill, int fillA, std::uint32_t border, int s = 2) {
    Rect(x0 + 2 * s, y0, x1 - 2 * s, y1, fill, fillA);
    Rect(x0, y0 + 2 * s, x0 + 2 * s, y1 - 2 * s, fill, fillA);
    Rect(x1 - 2 * s, y0 + 2 * s, x1, y1 - 2 * s, fill, fillA);
    Rect(x0 + 2 * s, y0, x1 - 2 * s, y0 + s, border);
    Rect(x0 + 2 * s, y1 - s, x1 - 2 * s, y1, border);
    Rect(x0, y0 + 2 * s, x0 + s, y1 - 2 * s, border);
    Rect(x1 - s, y0 + 2 * s, x1, y1 - 2 * s, border);
    Rect(x0 + s, y0 + s, x0 + 2 * s, y0 + 2 * s, border);
    Rect(x1 - 2 * s, y0 + s, x1 - s, y0 + 2 * s, border);
    Rect(x0 + s, y1 - 2 * s, x0 + 2 * s, y1 - s, border);
    Rect(x1 - 2 * s, y1 - 2 * s, x1 - s, y1 - s, border);
  }

  // A flat panel in the menu's style: soft shadow, dark fill, 1 px border and a thin accent line along the top.
  void Panel(int x0, int y0, int x1, int y1, std::uint32_t fill, int fillA, std::uint32_t border, std::uint32_t accent) {
    for (int i = 4; i >= 1; --i) Rect(x0 - i + 3, y0 - i + 4, x1 + i + 1, y1 + i + 2, 0x000000, 18);  // soft shadow
    Rect(x0, y0, x1, y1, fill, fillA);
    Rect(x0, y0, x1, y0 + 1, border);
    Rect(x0, y1 - 1, x1, y1, border);
    Rect(x0, y0, x0 + 1, y1, border);
    Rect(x1 - 1, y0, x1, y1, border);
    Rect(x0, y0, x1, y0 + 2, accent);
  }

  // One solid bar filled to `fraction`: a dark track, the fill with a lighter top edge and a darker bottom edge,
  // and the last column blended so it moves smoothly.
  void SolidBar(int x0, int y0, int x1, int y1, float fraction, std::uint32_t rgb) {
    auto shade = [](std::uint32_t c, int delta) {
      auto ch = [&](int shift) { return static_cast<std::uint32_t>((std::clamp)(static_cast<int>((c >> shift) & 0xFF) + delta, 0, 255)) << shift; };
      return ch(16) | ch(8) | ch(0);
    };
    Rect(x0, y0, x1, y1, 0x000000, 150);
    Rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, shade(rgb, -150), 90);  // faint tint of the colour in the empty part
    fraction = (std::clamp)(fraction, 0.0f, 1.0f);
    const float width = (x1 - x0 - 2) * fraction;
    const int full = static_cast<int>(width);
    const int fx0 = x0 + 1, fx1 = fx0 + full;
    if (full > 0) {
      Rect(fx0, y0 + 1, fx1, y1 - 1, rgb);
      Rect(fx0, y0 + 1, fx1, y0 + 2, shade(rgb, 60));     // light top edge
      Rect(fx0, y1 - 2, fx1, y1 - 1, shade(rgb, -60));    // dark bottom edge
    }
    const int partial = static_cast<int>((width - full) * 255.0f);
    if (partial > 0 && fx1 < x1 - 1) Rect(fx1, y0 + 1, fx1 + 1, y1 - 1, rgb, partial);
  }

  // A premultiplied BGRA image (like the armor icons), alpha-blended in.
  void Image(int x, int y, const std::uint32_t* src, int w, int h) {
    for (int py = 0; py < h; ++py) {
      const int dy = y + py;
      if (dy < 0 || dy >= this->h) continue;
      for (int pxl = 0; pxl < w; ++pxl) {
        const int dx = x + pxl;
        if (dx < 0 || dx >= this->w) continue;
        const std::uint32_t s = src[py * w + pxl];
        const int a = s >> 24;
        if (!a) continue;
        std::uint32_t& d = px[dy * this->w + dx];
        if (a == 255) {
          d = s;
          continue;
        }
        const int inv = 255 - a;
        auto ch = [&](int shift) { return (((s >> shift) & 0xFF) + ((d >> shift) & 0xFF) * inv / 255) & 0xFF; };
        d = (static_cast<std::uint32_t>(ch(24)) << 24) | (ch(16) << 16) | (ch(8) << 8) | ch(0);
      }
    }
  }

  // The same image with a solid outline `thickness` px wide around its shape, so it reads on any background.
  void ImageOutlined(int x, int y, const std::uint32_t* src, int w, int h, int thickness, std::uint32_t outline) {
    for (int py = 0; py < h; ++py)
      for (int pxl = 0; pxl < w; ++pxl)
        if ((src[py * w + pxl] >> 24) > 96)
          for (int oy = -thickness; oy <= thickness; ++oy)
            for (int ox = -thickness; ox <= thickness; ++ox)
              if (ox * ox + oy * oy <= thickness * thickness + 1) Blend(x + pxl + ox, y + py + oy, outline, 255);
    Image(x, y, src, w, h);
  }

  // A small pixel-art icon from rows of '#' characters.
  void Icon(int x, int y, const char* const* rows, int count, int scale, std::uint32_t rgb) {
    for (int r = 0; r < count; ++r)
      for (int c = 0; rows[r][c]; ++c)
        if (rows[r][c] == '#') {
          Rect(x + c * scale + 2, y + r * scale + 2, x + (c + 1) * scale + 2, y + (r + 1) * scale + 2, 0x000000, 170);
          Rect(x + c * scale, y + r * scale, x + (c + 1) * scale, y + (r + 1) * scale, rgb);
        }
  }
};

// ---------------------------------------------------------------- text

// Text is drawn by GDI (without anti-aliasing, so the pixel fonts stay crisp) into a scratch bitmap, then
// copied onto the canvas in colour with a hard shadow.
struct TextPainter {
  HDC dc = nullptr;
  HBITMAP bitmap = nullptr;
  std::uint32_t* bits = nullptr;
  int w = 1400, h = 96;
  HFONT body = nullptr, title = nullptr, brand = nullptr;
  std::map<int, HFONT> brandSizes;  // bold Verdana at each watermark size used

  void Create() {
    dc = CreateCompatibleDC(nullptr);
    BITMAPINFO bi{};
    bi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, -h, 1, 32, BI_RGB };
    bitmap = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, reinterpret_cast<void**>(&bits), nullptr, 0);
    SelectObject(dc, bitmap);
    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(255, 255, 255));
    for (const wchar_t* name : { L"MENU_FONT", L"TITLE_FONT", L"FONT_PRESSSTART", L"FONT_VT323", L"FONT_JERSEY", L"FONT_TINY5", L"FONT_MICRO5" })
      LoadFontResource(name);
    body = CreateFontW(-18, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                       NONANTIALIASED_QUALITY, DEFAULT_PITCH, L"Pixelify Sans");
    // The watermark: bold blue Verdana with a dark outline.
    brand = CreateFontW(-20, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                        NONANTIALIASED_QUALITY, DEFAULT_PITCH, L"Verdana");
    title = CreateFontW(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                        NONANTIALIASED_QUALITY, DEFAULT_PITCH, L"Silkscreen");
  }

  static void LoadFontResource(const wchar_t* name) {
    const HRSRC resource = FindResourceW(nullptr, name, RT_RCDATA);
    const HGLOBAL loaded = resource ? LoadResource(nullptr, resource) : nullptr;
    void* data = loaded ? LockResource(loaded) : nullptr;
    DWORD count = 0;
    if (data) AddFontMemResourceEx(data, SizeofResource(nullptr, resource), nullptr, &count);
  }

  void Destroy() {
    if (body) DeleteObject(body);
    if (title) DeleteObject(title);
    if (brand) DeleteObject(brand);
    for (auto& [size, font] : brandSizes) DeleteObject(font);
    for (auto& [size, font] : plainSizes) DeleteObject(font);
    if (bitmap) DeleteObject(bitmap);
    if (dc) DeleteDC(dc);
    *this = {};
  }

  std::map<int, HFONT> plainSizes;  // the Armor HUD's plain text font at each size
  int face = 0;                     // the HUD Font in use (kHudFonts), which the cached fonts above were made with

  // Switches the HUD Font; the cached sizes belong to the old one, so they're dropped.
  void SetFace(int index) {
    index = std::clamp(index, 0, kHudFontCount - 1);
    if (index == face) return;
    for (auto& [size, font] : brandSizes) DeleteObject(font);
    for (auto& [size, font] : plainSizes) DeleteObject(font);
    brandSizes.clear();
    plainSizes.clear();
    face = index;
  }
  HFONT MakeFont(int px, int weight) const {
    const HudFont& f = kHudFonts[face];
    const int size = (std::max)(6, static_cast<int>(px * f.scale + 0.5f));
    return CreateFontW(-size, 0, 0, 0, f.pixel ? FW_NORMAL : weight, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                       NONANTIALIASED_QUALITY, DEFAULT_PITCH, f.face);
  }

  // A clean semibold sans (the Armor HUD's text, like ARK's own Roboto HUD text).
  HFONT Plain(int px) {
    auto it = plainSizes.find(px);
    if (it != plainSizes.end()) return it->second;
    // The original look is Segoe UI here (with Verdana elsewhere); any other HUD Font is used for everything.
    const HFONT font = face == 0 ? CreateFontW(-px, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                               NONANTIALIASED_QUALITY, DEFAULT_PITCH, L"Segoe UI")
                                 : MakeFont(px, FW_SEMIBOLD);
    return plainSizes[px] = font;
  }

  // Text with no outline and no shadow.
  int DrawPlain(Canvas& canvas, int x, int y, const std::wstring& text, HFONT font, std::uint32_t rgb) {
    const SIZE size = Measure(text, font);
    const int tw = (std::min)(static_cast<int>(size.cx) + 4, w), th = (std::min)(static_cast<int>(size.cy), h);
    std::memset(bits, 0, static_cast<std::size_t>(w) * h * 4);
    TextOutW(dc, 0, 0, text.c_str(), static_cast<int>(text.size()));
    GdiFlush();
    for (int py = 0; py < th; ++py)
      for (int pxl = 0; pxl < tw; ++pxl)
        if ((bits[py * w + pxl] & 0xFF) > 127) canvas.Blend(x + pxl, y + py, rgb, 255);
    return tw;
  }

  // The watermark font at `px` pixels tall.
  HFONT Brand(int px) {
    auto it = brandSizes.find(px);
    if (it != brandSizes.end()) return it->second;
    return brandSizes[px] = MakeFont(px, FW_BOLD);
  }

  SIZE Measure(const std::wstring& text, HFONT font) {
    SelectObject(dc, font);
    SIZE size{};
    GetTextExtentPoint32W(dc, text.c_str(), static_cast<int>(text.size()), &size);
    return size;
  }

  // Text with a 2 px dark outline all round, then the fill. Returns the width drawn.
  int DrawOutlined(Canvas& canvas, int x, int y, const std::wstring& text, HFONT font, std::uint32_t rgb, std::uint32_t outline,
                   int thickness = 2) {
    const SIZE size = Measure(text, font);
    const int tw = (std::min)(static_cast<int>(size.cx) + 4, w), th = (std::min)(static_cast<int>(size.cy), h);
    std::memset(bits, 0, static_cast<std::size_t>(w) * h * 4);
    TextOutW(dc, 0, 0, text.c_str(), static_cast<int>(text.size()));
    GdiFlush();
    for (int py = 0; py < th; ++py)
      for (int pxl = 0; pxl < tw; ++pxl)
        if ((bits[py * w + pxl] & 0xFF) > 127)
          for (int oy = -thickness; oy <= thickness; ++oy)
            for (int ox = -thickness; ox <= thickness; ++ox) canvas.Blend(x + pxl + ox, y + py + oy, outline, 255);
    for (int py = 0; py < th; ++py)
      for (int pxl = 0; pxl < tw; ++pxl)
        if ((bits[py * w + pxl] & 0xFF) > 127) canvas.Blend(x + pxl, y + py, rgb, 255);
    return tw;
  }

  // Returns the width drawn.
  int Draw(Canvas& canvas, int x, int y, const std::wstring& text, HFONT font, std::uint32_t rgb) {
    const SIZE size = Measure(text, font);
    const int tw = (std::min)(static_cast<int>(size.cx) + 4, w), th = (std::min)(static_cast<int>(size.cy), h);
    std::memset(bits, 0, static_cast<std::size_t>(w) * h * 4);
    TextOutW(dc, 0, 0, text.c_str(), static_cast<int>(text.size()));
    GdiFlush();
    for (int pass = 0; pass < 2; ++pass)
      for (int py = 0; py < th; ++py)
        for (int pxl = 0; pxl < tw; ++pxl)
          if ((bits[py * w + pxl] & 0xFF) > 127) {
            if (pass == 0) canvas.Blend(x + pxl + 2, y + py + 2, 0x000000, 190);
            else canvas.Blend(x + pxl, y + py, rgb, 255);
          }
    return tw;
  }
};

// ---------------------------------------------------------------- window

struct {
  HWND window = nullptr;
  HWND menu = nullptr;
  GameWindow game;
  DWORD gameFoundAt = 0;
  HDC dc = nullptr;
  HBITMAP bitmap = nullptr;
  Canvas canvas;
  TextPainter text;
  RECT area{};  // the game's client area on screen
  bool shown = false;
  DWORD drawnAt = 0;
} g_overlay;

std::uint32_t ToRgb(const ImVec4& c) {
  auto ch = [](float v) { return static_cast<std::uint32_t>(std::clamp(v, 0.0f, 1.0f) * 255.0f + 0.5f); };
  return (ch(c.x) << 16) | (ch(c.y) << 8) | ch(c.z);
}

void ResizeCanvas(int w, int h) {
  if (g_overlay.canvas.w == w && g_overlay.canvas.h == h) return;
  if (g_overlay.bitmap) DeleteObject(g_overlay.bitmap);
  BITMAPINFO bi{};
  bi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, -h, 1, 32, BI_RGB };
  void* bits = nullptr;
  g_overlay.bitmap = CreateDIBSection(g_overlay.dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  SelectObject(g_overlay.dc, g_overlay.bitmap);
  g_overlay.canvas = { static_cast<std::uint32_t*>(bits), w, h };
}

void Hide() {
  if (!g_overlay.shown) return;
  ShowWindow(g_overlay.window, SW_HIDE);
  g_overlay.shown = false;
}

// ---------------------------------------------------------------- drawing

void DrawCrosshair(Canvas& c, const HudSettings& s) {
  const int cx = c.w / 2, cy = c.h / 2;
  const int size = std::clamp(s.crossSize, 2, 40), t = std::clamp(s.crossThickness, 1, 8), gap = std::clamp(s.crossGap, 0, 20);
  const std::uint32_t rgb = kCrossColorRgb[std::clamp(s.crossColor, 0, kCrossColorCount - 1)];
  const int shape = std::clamp(s.crossShape, 0, kCrossShapeCount - 1);
  const int h0 = -(t / 2), h1 = h0 + t;  // thickness span around the centre line

  for (int pass = s.crossOutline ? 0 : 1; pass < 2; ++pass) {
    const int o = pass == 0 ? 1 : 0;  // the outline pass draws everything 1 px bigger in black
    const std::uint32_t col = pass == 0 ? 0x000000 : rgb;
    const int a = (pass == 0 ? 200 : 255)*std::clamp(s.crossOpacity,0,100)/100;
    auto rect = [&](int x0, int y0, int x1, int y1) { c.Rect(cx + x0 - o, cy + y0 - o, cx + x1 + o, cy + y1 + o, col, a); };
    const bool dot = shape == 0 || shape == 2;
    const bool cross = shape == 1 || shape == 2 || shape == 5;
    if (cross) {
      rect(-gap - size, h0, -gap, h1);              // left
      rect(gap + 1, h0, gap + 1 + size, h1);        // right
      rect(h0, gap + 1, h1, gap + 1 + size);        // down
      if (shape != 5) rect(h0, -gap - size, h1, -gap);  // up (not for T)
    }
    if (dot) rect(h0, h0, h1, h1);
    if (shape == 3) {  // pixel ring
      const int r = gap + size / 2 + 2;
      for (int i = 0; i < 360; i += 2) {
        const double rad = i * 3.14159265 / 180.0;
        const int x = static_cast<int>(std::lround(std::cos(rad) * r)), y = static_cast<int>(std::lround(std::sin(rad) * r));
        rect(x + h0, y + h0, x + h1, y + h1);
      }
      rect(h0, h0, h1, h1);
    }
    if (shape == 4) {  // diagonal X
      for (int d = gap + 1; d <= gap + size; ++d)
        for (int sx : { -1, 1 })
          for (int sy : { -1, 1 }) rect(sx * d + h0, sy * d + h0, sx * d + h1, sy * d + h1);
    }
  }
}

std::wstring Format(const wchar_t* fmt, ...) {
  wchar_t buffer[128];
  va_list args;
  va_start(args, fmt);
  _vsnwprintf(buffer, 127, fmt, args);
  va_end(args);
  buffer[127] = 0;
  return buffer;
}

constexpr wchar_t kWatermark[] = L"Bence INI";
constexpr int kWatermarkMargin = 12;

struct InfoLine {
  std::wstring label, value;
};

std::vector<InfoLine> InfoLines(const HudSettings& s, const HudData& d) {
  std::vector<InfoLine> lines;
  if(s.infoPing)lines.push_back({L"Ping",d.ping>=0?Format(L"%d ms",d.ping):L"--"});
  if(s.infoServerFps)lines.push_back({L"Server FPS",d.serverFps>=0?Format(L"%.0f",d.serverFps):L"--"});
  if(s.infoPlayers)lines.push_back({L"Players",d.players>=0?Format(L"%d",d.players):L"--"});
  if(s.infoTurrets)lines.push_back({L"Enemy turrets",Format(L"%d",d.enemyTurrets)});
  if(s.infoFriendlyTurrets)lines.push_back({L"Friendly turrets",Format(L"%d",d.friendlyTurrets)});
  if(s.infoSlots)lines.push_back({L"Slots",d.inventoryUsed>=0?Format(L"%d / %d",d.inventoryUsed,d.inventoryMax):L"--"});
  if(s.infoServerName)lines.push_back({L"Server",d.serverName.empty()?L"--":d.serverName});
  if (s.infoFps) lines.push_back({ L"FPS", d.fps > 0.0f ? Format(L"%d", static_cast<int>(d.fps + 0.5f)) : L"--" });
  if (s.infoClock) {
    SYSTEMTIME t;
    GetLocalTime(&t);
    const int hour = t.wHour % 12 == 0 ? 12 : t.wHour % 12;
    lines.push_back({ L"Time", Format(L"%d:%02d %s", hour, t.wMinute, t.wHour < 12 ? L"AM" : L"PM") });
  }
  if (s.infoTimer) {
    const ULONGLONG ms = d.sessionStartMs ? GetTickCount64() - d.sessionStartMs : 0;
    const unsigned secs = static_cast<unsigned>(ms / 1000);
    lines.push_back({ L"Session", Format(L"%02u:%02u:%02u", secs / 3600, (secs / 60) % 60, secs % 60) });
  }
  if (s.infoCoords) {
    lines.push_back({ L"Lat", d.hasLocation ? Format(L"%.1f", d.lat) : L"--" });
    lines.push_back({ L"Lon", d.hasLocation ? Format(L"%.1f", d.lon) : L"--" });
  }
  return lines;
}

// The watermark in its corner, and the info display under it in the same style when that's on too, as plain
// outlined "Label: value" lines in the watermark's colour.
std::uint32_t InfoColor(const HudSettings& s,std::uint32_t fallback){if(!s.infoRainbow)return fallback;float t=GetTickCount64()/1300.f;int r=static_cast<int>(128+127*std::sin(t)),g=static_cast<int>(128+127*std::sin(t+2.0944f)),b=static_cast<int>(128+127*std::sin(t+4.1888f));return(r<<16)|(g<<8)|b;}
void DrawWatermark(Canvas& c, TextPainter& text, const HudSettings& s, const HudData& d) {
  const bool right = std::clamp(s.watermarkCorner, 0, kWatermarkCornerCount - 1) == 1;
  const int size = std::clamp(s.watermarkSize, 12, 48);
  const std::uint32_t rgb = kWatermarkColorRgb[std::clamp(s.watermarkColor, 0, kWatermarkColorCount - 1)];
  const std::uint32_t outline = 0x0A0A28;
  auto line = [&](int y, const std::wstring& t, int px) {
    const HFONT font = text.Brand(px);
    const SIZE m = text.Measure(t, font);
    const int x = right ? c.w - kWatermarkMargin - m.cx : kWatermarkMargin;
    text.DrawOutlined(c, x, y, t, font, px==size?rgb:InfoColor(s,rgb), outline, px >= 22 ? 2 : 1);
    return static_cast<int>(m.cy);
  };

  int y = kWatermarkMargin;
  y += line(y, kWatermark, size) + 4;
  if (!s.info.on) return;
  const int small = (std::max)(10, size * 3 / 4 * std::clamp(s.infoScale,50,200)/100);
  for (const InfoLine& l : InfoLines(s, d)) y += line(y, l.label + L": " + l.value, small) + 1;
}

// The info display as its own pixel box, used when the watermark is off.
void DrawInfoBox(Canvas& c, TextPainter& text, const HudSettings& s, const HudData& d) {
  std::vector<InfoLine> lines = InfoLines(s, d);
  if (lines.empty()) return;
  for (InfoLine& l : lines)
    for (wchar_t& ch : l.label) ch = static_cast<wchar_t>(towupper(ch));

  const float scale=std::clamp(s.infoScale,50,200)/100.f;
  const int lineH = static_cast<int>(22*scale), pad = 12, labelW = static_cast<int>(136*scale);
  const HFONT infoBody=text.Brand(static_cast<int>(15*scale)),infoTitle=text.Brand(static_cast<int>(13*scale));
  int valueW = 0;
  for (const InfoLine& l : lines) valueW = (std::max)(valueW, static_cast<int>(text.Measure(l.value, infoBody).cx));
  const int boxW = pad * 2 + labelW + valueW + 4, boxH = pad * 2 + static_cast<int>(lines.size()) * lineH - 4;
  const int margin = 16;
  const int corner = std::clamp(s.infoCorner, 0, kCornerCount - 1);
  const int x = corner % 2 == 0 ? margin : c.w - margin - boxW;
  const int y = corner < 2 ? margin : c.h - margin - boxH;

  const std::uint32_t accent = ToRgb(ui::g_theme.accent), panel = ToRgb(ui::g_theme.bg), textRgb = ToRgb(ui::g_theme.text);
  c.PixelBox(x + 4, y + 4, x + boxW + 4, y + boxH + 4, 0x000000, 110, 0x000000);  // hard shadow
  c.PixelBox(x, y, x + boxW, y + boxH, panel, 215, accent);
  for (std::size_t i = 0; i < lines.size(); ++i) {
    const int ly = y + pad + static_cast<int>(i) * lineH;
    text.Draw(c, x + pad, ly + 2, lines[i].label, infoTitle, InfoColor(s,accent));
    text.Draw(c, x + pad + labelW, ly, lines[i].value, infoBody, InfoColor(s,textRgb));
  }
}

const char* const kHeart[] = { ".##.##.", "#######", "#######", ".#####.", "..###..", "...#..." };
const char* const kPaw[] = { "#.#.#", "#.#.#", ".....", ".###.", "#####", "#####", ".#.#." };

// An icon resized to `size` x `size` (bilinear, on premultiplied pixels), cached per icon and size.
const std::uint32_t* ScaledIcon(int icon, int size) {
  static std::map<std::pair<int, int>, std::vector<std::uint32_t>> cache;
  const std::uint32_t* src = ArmorIconPixels(icon);
  if (!src) return nullptr;
  if (size == kArmorIconSize) return src;
  auto key = std::make_pair(icon, size);
  auto it = cache.find(key);
  if (it != cache.end()) return it->second.data();
  std::vector<std::uint32_t> out(static_cast<std::size_t>(size) * size);
  const float scale = static_cast<float>(kArmorIconSize) / size;
  for (int y = 0; y < size; ++y)
    for (int x = 0; x < size; ++x) {
      const float sx = (std::max)(0.0f, (x + 0.5f) * scale - 0.5f), sy = (std::max)(0.0f, (y + 0.5f) * scale - 0.5f);
      const int x0 = (std::min)(static_cast<int>(sx), kArmorIconSize - 1), y0 = (std::min)(static_cast<int>(sy), kArmorIconSize - 1);
      const int x1 = (std::min)(x0 + 1, kArmorIconSize - 1), y1 = (std::min)(y0 + 1, kArmorIconSize - 1);
      const float fx = sx - x0, fy = sy - y0;
      std::uint32_t pixel = 0;
      for (int shift = 0; shift < 32; shift += 8) {
        auto ch = [&](int px, int py) { return static_cast<float>((src[py * kArmorIconSize + px] >> shift) & 0xFF); };
        const float v = ch(x0, y0) * (1 - fx) * (1 - fy) + ch(x1, y0) * fx * (1 - fy) + ch(x0, y1) * (1 - fx) * fy + ch(x1, y1) * fx * fy;
        pixel |= static_cast<std::uint32_t>(std::clamp(v + 0.5f, 0.0f, 255.0f)) << shift;
      }
      out[static_cast<std::size_t>(y) * size + x] = pixel;
    }
  return cache.emplace(key, std::move(out)).first->second.data();
}

// Armor HUD, laid out like ArmorHud.h: a column on the right edge that starts `yOffset` (at 1440p) above the
// bottom and stacks upward, boots first. Icon, then durability (or percent) centred under it, coloured by
// condition; spare copies you carry as "x2" to the left. Everything scales with the screen height.
void DrawArmor(Canvas& c, TextPainter& text, const HudData& d, const HudSettings& s) {
  if (d.armor.empty()) return;
  float hr = c.h / 1440.0f;
  if (hr < 0.25f) hr = 1.0f;
  const float scale = std::clamp(s.armorSize, 50, 200) / 100.0f * hr;
  const int icon = (std::max)(8, static_cast<int>(std::lround(40.0f * scale)));
  const int spacing = static_cast<int>(std::lround(25.0f * scale));
  const int x = static_cast<int>(std::lround(c.w - 50.0f * scale));
  int y = static_cast<int>(std::lround(c.h - std::clamp(s.armorYOffset, 0, 1440) * hr));
  // Text size scales with the screen like everything else (18 px at 1440p and 100%).
  const HFONT font = text.Plain((std::max)(9, static_cast<int>(std::lround(18.0f * hr * std::clamp(s.armorTextSize, 50, 300) / 100.0f))));
  static const std::uint32_t kQualityRgb[6] = { 0x808080, 0x00CC00, 0x3366FF, 0x9933CC, 0xFFD900, 0x00FFFF };
  constexpr int kEdgePad = 4;

  for (const ArmorPiece& p : d.armor) {
    if (const std::uint32_t* pixels = p.icon >= 0 ? ScaledIcon(p.icon, icon) : nullptr) c.Image(x, y, pixels, icon, icon);
    else c.Rect(x, y, x + icon, y + icon, 0x262626, 190);

    if (s.armorShowDurability || s.armorPercent) {
      const float pct = p.fraction >= 0.0f ? p.fraction * 100.0f : -1.0f;
      const std::wstring value = s.armorPercent && pct >= 0.0f ? Format(L"%.1f%%", pct) : Format(L"%.0f", p.durability);
      std::uint32_t color = kQualityRgb[std::clamp(p.quality, 0, 5)];
      if (pct >= 0.0f) color = pct > 66.0f ? 0x1AFF1A : pct > 33.0f ? 0xFFB300 : 0xFF2626;
      const int tw = text.Measure(value, font).cx;
      int tx = x + icon / 2 - tw / 2;
      tx = std::clamp(tx, kEdgePad, c.w - kEdgePad - tw);
      text.DrawPlain(c, tx, y + icon + static_cast<int>(scale), value, font, color);
    }
    if (s.armorCount && p.spares > 0) {
      const std::wstring count = Format(L"x%d", p.spares);
      const SIZE cs = text.Measure(count, font);
      text.DrawPlain(c, x - static_cast<int>(icon * 0.18f) - cs.cx, y + (icon - cs.cy) / 2, count, font, 0xFFCC00);
    }
    y -= icon + spacing;
  }
}


void DrawBar(Canvas& c, TextPainter& text, float xPct, float yPct, float current, float max, std::uint32_t barRgb, bool mount) {
  const int boxW = 280, boxH = 58;
  const int x = static_cast<int>(std::clamp(xPct, 0.0f, 100.0f) / 100.0f * (c.w - boxW));
  const int y = static_cast<int>(std::clamp(yPct, 0.0f, 100.0f) / 100.0f * (c.h - boxH));
  const std::uint32_t accent = ToRgb(ui::g_theme.accent), panel = ToRgb(ui::g_theme.bg), textRgb = ToRgb(ui::g_theme.text);
  const std::uint32_t border = ToRgb(ui::g_theme.border);
  constexpr std::uint32_t kOutline = 0x050508;
  c.Panel(x, y, x + boxW, y + boxH, panel, 225, border, accent);
  if (mount) c.Icon(x + 12, y + 15, kPaw, 7, 4, barRgb);
  else c.Icon(x + 10, y + 17, kHeart, 6, 4, barRgb);

  // Label and value on top, one solid bar under them.
  const int bx0 = x + 50, bx1 = x + boxW - 12;
  const HFONT labelFont = text.Brand(13), valueFont = text.Brand(15);
  const float fraction = max > 0.0f ? std::clamp(current / max, 0.0f, 1.0f) : 0.0f;
  text.DrawOutlined(c, bx0, y + 10, mount ? L"MOUNT" : L"HEALTH", labelFont, accent, kOutline, 1);
  const std::wstring value = Format(L"%.0f / %.0f", current, max);
  text.DrawOutlined(c, bx1 - text.Measure(value, valueFont).cx, y + 8, value, valueFont, textRgb, kOutline, 1);
  c.SolidBar(bx0, y + 32, bx1, y + 46, fraction, barRgb);
}

// Awesome Spyglass panel. Laid out twice: once to measure its height, once to draw.
void DrawSpyglass(Canvas& c, TextPainter& text, const HudSettings& s, const SpyglassData& d) {
  if (d.kind == SpyglassData::None) return;
  const std::uint32_t accent = ToRgb(ui::g_theme.accent), panel = ToRgb(ui::g_theme.bg), textRgb = ToRgb(ui::g_theme.text);
  const std::uint32_t dim = ToRgb(ui::g_theme.textDim);
  constexpr std::uint32_t kGreen = 0x5ED26E, kPurple = 0xA06CFF, kOrange = 0xFF9A3C;
  const float scale=std::clamp(s.spyScale,50,200)/100.f;auto px=[&](int n){return static_cast<int>(std::lround(n*scale));};
  const int kW=px(360),kPad=px(12),kBarH=px(12);
  // The HUD Font (bold Verdana by default, like the watermark and Armor HUD), every line with a thin dark outline.
  const HFONT titleFont = text.Brand(px(19)), bodyFont = text.Brand(px(15)), labelFont = text.Brand(px(13));
  constexpr std::uint32_t kOutline = 0x050508;
  const bool own = d.own;
  const bool dino = d.kind==SpyglassData::WildDino||d.kind==SpyglassData::OwnDino;

  auto layout = [&](bool draw, int x, int y0) {
    int y = y0 + kPad;
    const int left = x + kPad, right = x + kW - kPad, inner = kW - 2 * kPad;
    auto line = [&](const std::wstring& t, HFONT font, std::uint32_t rgb, int h) {
      if (draw) text.DrawOutlined(c, left, y, t, font, rgb, kOutline, 1);
      y += px(h);
    };
    auto bar = [&](const wchar_t* label, float cur, float max, std::uint32_t rgb, const std::wstring& valueText) {
      if (draw) {
        text.DrawOutlined(c, left, y, label, labelFont, accent, kOutline, 1);
        const int vw = text.Measure(valueText, bodyFont).cx;
        text.DrawOutlined(c, right - vw, y - 1, valueText, bodyFont, textRgb, kOutline, 1);
      }
      y += px(19);
      if (draw) c.SolidBar(left, y, right, y + kBarH, max > 0.0f ? cur / max : 0.0f, rgb);
      y += kBarH + px(8);
    };

    // Title and distance.
    if (draw) {
      text.DrawOutlined(c, left, y, d.name, titleFont, textRgb, kOutline, 1);
      if (d.distanceM >= 0.0f) {
        const std::wstring dist = Format(L"%.0f m", d.distanceM);
        text.DrawOutlined(c, right - text.Measure(dist, bodyFont).cx, y + 1, dist, bodyFont, dim, kOutline, 1);
      }
    }
    y += px(24);

    // Species and level, then sex, owner and state.
    std::wstring sub;
    if (dino) {
      if (d.kind == SpyglassData::OwnDino && d.name != d.species) sub += d.species + L"  -  ";
      if (d.level > 0)
        sub += d.extraLevel > 0 ? Format(L"Lvl %d (%d+%d)", d.level, d.baseLevel, d.extraLevel) : Format(L"Lvl %d", d.level);
    }
    if (!sub.empty()) line(sub, bodyFont, accent, 22);

    std::vector<std::wstring> tags;
    auto add = [&](const std::wstring& w) { tags.push_back(w); };
    if (dino) add(d.female ? L"Female" : L"Male");
    add(own ? L"Your tribe" : d.enemy?L"Other tribe":L"Wild / unowned");
    if(d.targetLocked)add(L"Target locked");
    if (d.dead) add(L"Dead");
    else if (d.knockedOut) add(L"Knocked out");
    if (d.babyAge >= 0.0f) add(Format(L"Baby %.0f%%", d.babyAge * 100.0f));
    if (d.imprint >= 0.0f) add(Format(L"Imprint %.0f%%", d.imprint * 100.0f));
    if (d.neutered) add(d.female ? L"Spayed" : L"Neutered");
    if (d.kind == SpyglassData::OwnStructure && d.locked) add(L"Locked");
    // Wrap the tags onto as many lines as they need.
    std::wstring current;
    for (const std::wstring& tag : tags) {
      const std::wstring joined = current.empty() ? tag : current + L"  -  " + tag;
      if (!current.empty() && text.Measure(joined, bodyFont).cx > inner) {
        line(current, bodyFont, dim, 22);
        current = tag;
      } else {
        current = joined;
      }
    }
    if (!current.empty()) line(current, bodyFont, dim, 22);

    if (draw) c.Rect(left, y + 4, right, y + 5, ToRgb(ui::g_theme.border));  // divider above the bars
    y += px(12);
    if (d.maxHealth > 0.0f) bar(L"HEALTH", d.health, d.maxHealth, kGreen, Format(L"%.0f / %.0f", d.health, d.maxHealth));
    if ((dino||d.kind==SpyglassData::Player) && d.maxTorpor > 0.0f) bar(L"TORPOR", d.torpor, d.maxTorpor, kPurple, Format(L"%.0f / %.0f", d.torpor, d.maxTorpor));
    if (d.tameProgress >= 0.0f)
      bar(L"TAMING", d.tameProgress, 1.0f, kOrange,
          d.tameEffectiveness >= 0.0f ? Format(L"%.0f%%  eff %.0f%%", d.tameProgress * 100.0f, d.tameEffectiveness * 100.0f)
                                      : Format(L"%.0f%%", d.tameProgress * 100.0f));

    if (d.kind == SpyglassData::OwnDino) {
      if (!d.tamer.empty()) line(L"Tamed by " + d.tamer, bodyFont, dim, 22);
      if (d.mutationsMale >= 0 || d.mutationsFemale >= 0)
        line(Format(L"Mutations  %d / %d", (std::max)(0, d.mutationsMale), (std::max)(0, d.mutationsFemale)), bodyFont, dim, 22);
      if (d.hasStats) {
        y += px(4);
        struct Cell { const wchar_t* label; std::wstring value; };
        const Cell cells[6] = { { L"STAMINA", Format(L"%.0f", d.stamina) }, { L"WEIGHT", Format(L"%.0f", d.weight) },
                                { L"OXYGEN", Format(L"%.0f", d.oxygen) },   { L"MELEE", Format(L"%.0f%%", d.melee) },
                                { L"FOOD", Format(L"%.0f", d.food) },       { L"SPEED", Format(L"%.0f%%", d.speed) } };
        const int colW = inner / 2;
        for (int r = 0; r < 3; ++r) {
          for (int col = 0; col < 2; ++col) {
            const Cell& cell = cells[r * 2 + col];
            const int cx = left + col * colW, cr = cx + colW - (col == 0 ? 12 : 0);
            if (draw) {
              text.DrawOutlined(c, cx, y + 1, cell.label, labelFont, accent, kOutline, 1);
              text.DrawOutlined(c, cr - text.Measure(cell.value, bodyFont).cx, y, cell.value, bodyFont, textRgb, kOutline, 1);
            }
          }
          y += px(22);
        }
      }
    }
    if (dino && d.hasWildPoints && (d.kind==SpyglassData::WildDino?s.spyWildPoints:s.spyTamedPoints)) {
      // The points each stat rolled; the dino's best stat is highlighted.
      y += px(2);
      line(L"STAT POINTS", labelFont, accent, 18);
      struct Cell { const wchar_t* label; int stat; };
      const Cell cells[6] = { { L"HEALTH", 0 }, { L"STAMINA", 1 }, { L"MELEE", 8 }, { L"WEIGHT", 7 }, { L"OXYGEN", 3 }, { L"FOOD", 4 } };
      int best = 0;
      for (const Cell& cell : cells) best = (std::max)(best, d.wildPoints[cell.stat]);
      const int colW = inner / 2;
      for (int r = 0; r < 3; ++r) {
        for (int col = 0; col < 2; ++col) {
          const Cell& cell = cells[r * 2 + col];
          const int points = d.wildPoints[cell.stat];
          const std::wstring value = d.kind==SpyglassData::OwnDino&&d.hasTamedPoints?Format(L"%d + %d",points,d.tamedPoints[cell.stat]):Format(L"%d", points);
          const int cx = left + col * colW, cr = cx + colW - (col == 0 ? 12 : 0);
          if (draw) {
            text.DrawOutlined(c, cx, y + 1, cell.label, labelFont, accent, kOutline, 1);
            text.DrawOutlined(c, cr - text.Measure(value, bodyFont).cx, y, value, bodyFont, points == best && best > 0 ? kGreen : textRgb, kOutline, 1);
          }
        }
        y += px(22);
      }
    }
    if (d.kind == SpyglassData::OwnStructure && d.items >= 0) line(Format(L"Items  %d", d.items), bodyFont, dim, 22);
    if(dino&&s.spyColors&&d.hasColors)line(Format(L"Colors  %d / %d / %d / %d / %d / %d",d.colors[0],d.colors[1],d.colors[2],d.colors[3],d.colors[4],d.colors[5]),labelFont,dim,22);
    if(!d.tribe.empty())line(L"Owner: "+d.tribe,bodyFont,dim,22);
    if(!d.heldItem.empty())line(L"Holding: "+d.heldItem,bodyFont,dim,22);
    if(d.kind==SpyglassData::Player&&d.level>0)line(Format(L"Level %d",d.level),bodyFont,dim,22);
    if(d.decaySec>=0){int sec=static_cast<int>(d.decaySec);line(Format(L"Decomposes in %d:%02d",sec/60,sec%60),bodyFont,dim,22);}
    if(d.offlineSec>=0){int sec=static_cast<int>(d.offlineSec);line(Format(L"Offline %d:%02d:%02d",sec/3600,sec/60%60,sec%60),bodyFont,dim,22);}
    return y + kPad - px(6) - y0;
  };

  const int h = layout(false, 0, 0);
  const int x = static_cast<int>(std::clamp(s.spyX, 0.0f, 100.0f) / 100.0f * (c.w - kW));
  const int y = static_cast<int>(std::clamp(s.spyY, 0.0f, 100.0f) / 100.0f * (c.h - h));
  if(s.spyBackground)c.Panel(x, y, x + kW, y + h, panel, 225, ToRgb(ui::g_theme.border), accent);
  layout(true, x, y);
}

// Turret Filler markers: a square on each of your turrets in range (green full, red short, amber unknown), the
// amount under it, bigger the closer it is; totals above the hotbar; a short out-of-ammo warning.
void DrawTurrets(Canvas& c, TextPainter& text, const TurretOverlay& t) {
  float hr = c.h / 1440.0f;
  if (hr < 0.25f) hr = 1.0f;
  const CameraView& view = Camera();
  constexpr std::uint32_t kFull = 0x33FF59, kShort = 0xFF3833, kUnknown = 0xFFB326, kOutline = 0x050508;
  if (view.valid) {
    for (const TurretMarker& m : t.markers) {
      float sx, sy;
      if (!ProjectToScreen(view, m.position, c.w, c.h, sx, sy)) continue;
      const float dx = m.position[0] - view.location[0], dy = m.position[1] - view.location[1], dz = m.position[2] - view.location[2];
      const float metres = std::sqrt(dx * dx + dy * dy + dz * dz) / 100.0f;
      const float closeness = 1.0f - (std::min)(metres, 60.0f) / 60.0f;
      const int size = static_cast<int>(std::lround((16.0f + 14.0f * closeness) * hr));
      const int border = (std::max)(2, static_cast<int>(std::lround(2.0f * hr)));
      const bool known = m.have >= 0, full = known && m.have >= m.target;
      const std::uint32_t color = full ? kFull : known ? kShort : kUnknown;
      const int x = static_cast<int>(sx) - size / 2, y = static_cast<int>(sy) - size / 2;
      c.Rect(x - border, y - border, x + size + border, y + size + border, 0x000000, 215);
      c.Rect(x, y, x + size, y + size, color);
      c.Rect(x, y, x + size, y + size * 2 / 5, 0xFFFFFF, 64);  // gloss
      const std::wstring label = full ? (m.tek ? L"TEK FULL" : L"HEAVY FULL")
                                 : known ? Format(L"%d / %d", m.have, m.target)
                                         : (m.tek ? L"TEK ?" : L"HEAVY ?");
      const HFONT font = text.Brand((std::max)(10, static_cast<int>(std::lround((13.0f + 4.0f * closeness) * hr * 1.4f))));
      const int tw = text.Measure(label, font).cx;
      text.DrawOutlined(c, static_cast<int>(sx) - tw / 2, y + size + border + 2, label, font, color, kOutline, 1);
    }
  }
  const HFONT font = text.Brand((std::max)(12, static_cast<int>(std::lround(20.0f * hr))));
  if (t.heavyTotal || t.tekTotal) {
    const std::wstring a = Format(L"Heavy %d / %d full", t.heavyFull, t.heavyTotal);
    const std::wstring b = Format(L"Tek %d / %d full", t.tekFull, t.tekTotal);
    const int aw = t.heavyTotal ? text.Measure(a, font).cx : 0, bw = t.tekTotal ? text.Measure(b, font).cx : 0;
    const int gap = static_cast<int>(28 * hr), total = aw + bw + (aw && bw ? gap : 0), h = text.Measure(a, font).cy;
    const int py = static_cast<int>(c.h * 0.80f), padX = static_cast<int>(12 * hr), padY = static_cast<int>(6 * hr);
    int x = (c.w - total) / 2;
    c.Rect(x - padX, py - padY, x + total + padX, py + h + padY, 0x050F14, 190);
    if (aw) {
      text.DrawOutlined(c, x, py, a, font, t.heavyFull >= t.heavyTotal ? kFull : kShort, kOutline, 1);
      x += aw + gap;
    }
    if (bw) text.DrawOutlined(c, x, py, b, font, t.tekFull >= t.tekTotal ? kFull : kShort, kOutline, 1);
  }
  if (!t.warning.empty() && GetTickCount64() < t.warningUntil) {
    const int tw = text.Measure(t.warning, font).cx;
    text.DrawOutlined(c, (c.w - tw) / 2, static_cast<int>(c.h * 0.74f), t.warning, font, 0xFFBE3C, kOutline, 1);
  }
}


// Player List (Admin): a column of connected players on the left or right edge. Each row: in-game player ID,
// gamertag, survivor name and level. New arrivals show green with a "+" for a minute; leavers stay greyed out
// with "(left)" for 30 seconds.
void DrawPlayerList(Canvas& c, TextPainter& text, const HudSettings& s, const PlayerListData& d) {
  if (d.status == PlayerListData::Off || d.status == PlayerListData::NotInGame) return;
  const std::uint32_t accent = ToRgb(ui::g_theme.accent), panel = ToRgb(ui::g_theme.bg), textRgb = ToRgb(ui::g_theme.text);
  const std::uint32_t dim = ToRgb(ui::g_theme.textDim);
  constexpr std::uint32_t kGreen = 0x5ED26E, kGrey = 0x7A7A82, kOutline = 0x050508;
  const int size = std::clamp(s.playerTextSize, 10, 30);
  const HFONT titleFont = text.Brand(size + 2), rowFont = text.Brand(size), smallFont = text.Brand((std::max)(10, size - 3));
  const int pad = (std::max)(8, size * 2 / 3), gap = (std::max)(10, size), rowH = size + (std::max)(3, size / 4);
  const int margin = 12;
  const DWORD now = GetTickCount();

  std::wstring title = L"PLAYERS";
  std::wstring note;
  switch (d.status) {
    case PlayerListData::Live:
      title += L"  " + std::to_wstring(d.connected);
      note = std::wstring(d.detail.begin(), d.detail.end());
      break;
    case PlayerListData::FromAdminManager: title += L"  " + std::to_wstring(d.connected); note = L"from admin manager"; break;
    case PlayerListData::NotAdmin: note = L"not admin on this server"; break;
    case PlayerListData::Waiting: note = d.detail.empty() ? L"waiting for the server..." : std::wstring(d.detail.begin(), d.detail.end()); break;
    case PlayerListData::Failed: note = L"not available - see the HUD tab"; break;
    default: break;
  }

  struct Row { std::wstring id, tag, name; std::uint32_t idRgb, tagRgb, nameRgb; };
  std::vector<Row> rows;
  const int maxRows = std::clamp(s.playerMaxRows, 5, 70);
  const bool listing = d.status == PlayerListData::Live || d.status == PlayerListData::FromAdminManager;
  int hidden = 0;
  if (listing) {
    for (const ListedPlayer& p : d.players) {
      if (static_cast<int>(rows.size()) >= maxRows) {
        if (!p.leftAt) ++hidden;
        continue;
      }
      Row r;
      const bool isNew = !p.leftAt && p.joinedAt && now - p.joinedAt < 60000;
      r.id = p.id.empty() ? L"-" : p.id;
      r.tag = (isNew ? L"+ " : L"") + (p.gamertag.empty() ? L"?" : p.gamertag);
      r.name = p.name;
      if (p.level > 0) r.name += (r.name.empty() ? L"Lvl " : L"  Lvl ") + std::to_wstring(p.level);
      if (p.leftAt) r.name += L" (left)";
      r.idRgb = p.leftAt ? kGrey : accent;
      r.tagRgb = p.leftAt ? kGrey : isNew ? kGreen : textRgb;
      r.nameRgb = p.leftAt ? kGrey : dim;
      rows.push_back(std::move(r));
    }
  }

  int idW = 0, tagW = 0, nameW = 0;
  for (const Row& r : rows) {
    idW = (std::max)(idW, static_cast<int>(text.Measure(r.id, rowFont).cx));
    tagW = (std::max)(tagW, static_cast<int>(text.Measure(r.tag, rowFont).cx));
    nameW = (std::max)(nameW, static_cast<int>(text.Measure(r.name, rowFont).cx));
  }
  const std::wstring more = hidden ? L"+" + std::to_wstring(hidden) + L" more" : L"";
  int width = rows.empty() ? 0 : idW + gap + tagW + gap + nameW;
  width = (std::max)(width, static_cast<int>(text.Measure(title, titleFont).cx));
  if (!note.empty()) width = (std::max)(width, static_cast<int>(text.Measure(note, smallFont).cx));
  width = (std::min)(width + pad * 2 + 4, c.w - 2 * margin);
  int height = pad + size + 6 + (note.empty() ? 0 : size + 2) + static_cast<int>(rows.size()) * rowH + (hidden ? rowH : 0) + pad;
  height = (std::min)(height, c.h - 2 * margin);

  const bool right = std::clamp(s.playerSide, 0, kSideCount - 1) == 1;
  const int x = right ? c.w - margin - width : margin;
  const int y = std::clamp(static_cast<int>(c.h * std::clamp(s.playerY, 0.0f, 100.0f) / 100.0f), margin, (std::max)(margin, c.h - margin - height));
  c.PixelBox(x + 4, y + 4, x + width + 4, y + height + 4, 0x000000, 110, 0x000000);  // hard shadow
  c.PixelBox(x, y, x + width, y + height, panel, 200, accent);

  int ly = y + pad;
  text.DrawOutlined(c, x + pad, ly, title, titleFont, accent, kOutline, 1);
  ly += size + 6;
  if (!note.empty()) {
    text.DrawOutlined(c, x + pad, ly, note, smallFont, dim, kOutline, 1);
    ly += size + 2;
  }
  const int bottom = y + height - pad;
  for (const Row& r : rows) {
    if (ly + rowH > bottom + 2) break;
    int lx = x + pad;
    text.DrawOutlined(c, lx, ly, r.id, rowFont, r.idRgb, kOutline, 1);
    lx += idW + gap;
    text.DrawOutlined(c, lx, ly, r.tag, rowFont, r.tagRgb, kOutline, 1);
    lx += tagW + gap;
    if (!r.name.empty()) text.DrawOutlined(c, lx, ly, r.name, rowFont, r.nameRgb, kOutline, 1);
    ly += rowH;
  }
  if (hidden && ly + rowH <= bottom + 2) text.DrawOutlined(c, x + pad, ly, more, smallFont, dim, kOutline, 1);
}

void DrawCorruptedDinos(Canvas& c, TextPainter& text) {
  const CameraView& view = Camera();
  if (!view.valid) return;
  const HFONT font = text.Brand((std::max)(12, static_cast<int>(18.0f * c.h / 1440.0f)));
  for (const auto& marker : CorruptedDinos()) {
    float sx, sy;
    if (!ProjectToScreen(view, marker.position, c.w, c.h, sx, sy) ||
        !std::isfinite(sx) || !std::isfinite(sy) || sx < 0 || sy < 0 || sx >= c.w || sy >= c.h) continue;
    const int x = static_cast<int>(sx), y = static_cast<int>(sy);
    c.Rect(x-4, y-4, x+5, y+5, 0x09050D);
    c.Rect(x-2, y-2, x+3, y+3, 0xDA71FF);
    const std::wstring label = marker.name + Format(L" [%.0f m]", marker.distanceM);
    text.DrawOutlined(c, x-text.Measure(label, font).cx/2, y+8, label, font, 0xDA71FF, 0x050508, 1);
  }
}

void DrawTrajectory(Canvas& c,TextPainter& text) {
 const auto& data=Trajectory();const auto& view=Camera();if(!view.valid||data.points.size()<2)return;
 auto line=[&](float x0,float y0,float x1,float y1,std::uint32_t color,int thickness) {
  if(!std::isfinite(x0)||!std::isfinite(y0)||!std::isfinite(x1)||!std::isfinite(y1))return;
  float dx=x1-x0,dy=y1-y0,lo=0,hi=1;
  auto clip=[&](float p,float q) {
   if(p==0)return q>=0;
   float t=q/p;if(p<0) {if(t>hi)return false;lo=(std::max)(lo,t);}else {if(t<lo)return false;hi=(std::min)(hi,t);}return true;
  };
  if(!clip(-dx,x0)||!clip(dx,c.w-1-x0)||!clip(-dy,y0)||!clip(dy,c.h-1-y0))return;
  int ax=static_cast<int>(x0+lo*dx),ay=static_cast<int>(y0+lo*dy),bx=static_cast<int>(x0+hi*dx),by=static_cast<int>(y0+hi*dy);
  int sx=ax<bx?1:-1,sy=ay<by?1:-1;int vx=std::abs(bx-ax),vy=-std::abs(by-ay),error=vx+vy;
  for(int limit=0;limit<c.w+c.h+4;++limit) {
   c.Rect(ax-thickness,ay-thickness,ax+thickness+1,ay+thickness+1,color);
   if(ax==bx&&ay==by)break;int twice=2*error;if(twice>=vy) {error+=vy;ax+=sx;}if(twice<=vx) {error+=vx;ay+=sy;}
  }
 };
 const auto color=data.impact ? 0x60FFAFu : 0x50DFFFu;
 for(std::size_t i=1;i<data.points.size();++i) {
  float ax,ay,bx,by;
  if(!ProjectToScreen(view,data.points[i-1].data(),c.w,c.h,ax,ay)||!ProjectToScreen(view,data.points[i].data(),c.w,c.h,bx,by))continue;
  line(ax,ay,bx,by,0x051015,2);line(ax,ay,bx,by,color,0);
 }
 if(!data.impact)return;float x,y;
 if(!ProjectToScreen(view,data.hit.data(),c.w,c.h,x,y)||!std::isfinite(x)||!std::isfinite(y)||x<0||y<0||x>=c.w||y>=c.h)return;
 for(int radius=8;radius<=10;++radius)for(int angle=0;angle<360;angle+=6) {
  float r=angle*0.0174532925f;c.Blend(static_cast<int>(x+radius*std::cos(r)),static_cast<int>(y+radius*std::sin(r)),color,255);
 }
 c.Rect(static_cast<int>(x)-2,static_cast<int>(y)-2,static_cast<int>(x)+3,static_cast<int>(y)+3,color);
 float distance=0;for(int j=0;j<3;++j)distance+=(data.hit[j]-view.location[j])*(data.hit[j]-view.location[j]);
 auto label=Format(L"Est. impact %.0f m",std::sqrt(distance)/100.0f);HFONT font=text.Brand(14);
 text.DrawOutlined(c,static_cast<int>(x)-text.Measure(label,font).cx/2,static_cast<int>(y)+14,label,font,color,0x050508,1);
}

void DrawSnapGuide(Canvas& c, TextPainter& text) {
  float position[3],x,y;
  if (!StructureSnapGuide(position) || !ProjectToScreen(Camera(),position,c.w,c.h,x,y) ||
      !std::isfinite(x) || !std::isfinite(y) || x<0 || y<0 || x>=c.w || y>=c.h) return;
  const int sx=static_cast<int>(x),sy=static_cast<int>(y);
  c.Rect(sx-8,sy-1,sx+9,sy+2,0x50E8FF); c.Rect(sx-1,sy-8,sx+2,sy+9,0x50E8FF);
  const HFONT font=text.Brand(14);
  text.DrawOutlined(c,sx+12,sy,L"Snap target",font,0x50E8FF,0x050508,1);
}

void DrawPenisEsp(Canvas& c,const HudSettings& settings) {
  const auto& view=Camera();if(!view.valid)return;
  const float scale=static_cast<float>(std::clamp(settings.penisEspSize,12,64))/28.0f;
  auto disk=[&](int x,int y,int radius,std::uint32_t color) {
    for(int dy=-radius;dy<=radius;++dy)for(int dx=-radius;dx<=radius;++dx)
      if(dx*dx+dy*dy<=radius*radius)c.Blend(x+dx,y+dy,color,255);
  };
  for(const auto& marker:PenisEspMarkers()) {
    float sx,sy;
    if(!ProjectToScreen(view,marker.position,c.w,c.h,sx,sy)||!std::isfinite(sx)||!std::isfinite(sy)||
       sx<0||sy<0||sx>=c.w||sy>=c.h)continue;
    const int x=static_cast<int>(sx),y=static_cast<int>(sy);
    const int r=(std::max)(2,static_cast<int>(5*scale)),half=(std::max)(2,static_cast<int>(4*scale));
    const int height=(std::max)(8,static_cast<int>(20*scale));
    constexpr std::uint32_t outline=0x160D17,pink=0xFF8FC9;
    disk(x-r,y,r+2,outline);disk(x+r,y,r+2,outline);
    c.Rect(x-half-2,y-height,x+half+3,y+2,outline);disk(x,y-height,half+2,outline);
    disk(x-r,y,r,pink);disk(x+r,y,r,pink);
    c.Rect(x-half,y-height,x+half+1,y+1,pink);disk(x,y-height,half,pink);
  }
}

void DrawTekIndicator(Canvas& c,TextPainter& text,const HudSettings& s){
 const auto& d=AimTarget();if(!d.indicator)return;float scale=std::clamp(s.tekScale,50,200)/100.f;int w=static_cast<int>(360*scale),h=static_cast<int>(88*scale),pad=static_cast<int>(12*scale);
 int x=static_cast<int>((c.w-w)*std::clamp(s.tekX,0.f,100.f)/100),y=static_cast<int>((c.h-h)*std::clamp(s.tekY,0.f,100.f)/100);
 auto rgb=d.inRange?0x5ED26E:0xFF5050;auto font=text.Brand(static_cast<int>(15*scale));
 c.Panel(x,y,x+w,y+h,ToRgb(ui::g_theme.bg),225,ToRgb(ui::g_theme.border),rgb);
 auto name=d.name;if(name.size()>32)name=name.substr(0,29)+L"...";
 text.DrawOutlined(c,x+pad,y+pad,name,font,0xFFFFFF,0x050508,1);
 auto range=Format(L"%.0f m",d.distanceM);text.DrawOutlined(c,x+w-pad-text.Measure(range,font).cx,y+pad,range,font,rgb,0x050508,1);
 c.SolidBar(x+pad,y+static_cast<int>(37*scale),x+w-pad,y+static_cast<int>(49*scale),d.health/d.maxHealth,rgb);
 auto hp=Format(L"%.0f / %.0f",d.health,d.maxHealth);text.DrawOutlined(c,x+pad,y+static_cast<int>(59*scale),hp,font,0xFFFFFF,0x050508,1);
 auto shots=!d.inRange?L"Out of range":d.shots>0?Format(L"~%d shots",d.shots):L"-- shots";text.DrawOutlined(c,x+w-pad-text.Measure(shots,font).cx,y+static_cast<int>(59*scale),shots,font,rgb,0x050508,1);
}
bool AnythingOn(const HudSettings& s) { return s.tekIndicator.on || s.trajectory.on || s.penisEsp.on || g_settings.misc.structureSnap.on || g_settings.misc.structureSnapOther.on || s.corruptedEsp.on || s.playerList.on || s.watermark.on || s.crosshair.on || s.info.on || s.armor.on || s.hp.on || s.mountHp.on || s.spyglass.on ||
         g_settings.misc.turretFiller.on || g_settings.misc.showTurretFill; }

}  // namespace

void CreateOverlay(HWND menuWindow) {
  g_overlay.menu = menuWindow;
  WNDCLASSEXW wc{ sizeof(wc) };
  wc.lpfnWndProc = DefWindowProcW;
  wc.hInstance = GetModuleHandleW(nullptr);
  wc.lpszClassName = L"BenceINIOverlay";
  RegisterClassExW(&wc);
  g_overlay.window = CreateWindowExW(WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
                                     wc.lpszClassName, L"Bence INI Overlay", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, wc.hInstance, nullptr);
  g_overlay.dc = CreateCompatibleDC(nullptr);
  g_overlay.text.Create();
}

void TickOverlay() {
  if (!g_overlay.window) return;
  const HudSettings& s = g_settings.hud;
  const DWORD now = GetTickCount();
  if (!AnythingOn(s) || !g_process.IsAttached()) {
    Hide();
    g_overlay.game = {};
    g_diag.overlayShown = false;
    return;
  }
  if (now - g_overlay.drawnAt < kFrameMs) return;
  g_overlay.drawnAt = now;

  if (!g_overlay.game.content || !IsWindow(g_overlay.game.content) || now - g_overlay.gameFoundAt > kFindWindowMs) {
    g_overlay.game = FindGameWindow(g_process.pid);
    g_overlay.gameFoundAt = now;
  }
  const HWND content = g_overlay.game.content;
  const HWND foreground = GetForegroundWindow();
  RECT client{};
  if (content) GetClientRect(content, &client);
  g_diag.gameWindow = content != nullptr;
  g_diag.gameWidth = client.right;
  g_diag.gameHeight = client.bottom;
  g_diag.gameActive = g_overlay.game.IsActive(foreground);
  const bool menuActive = foreground == g_overlay.menu;
  if (!content || IsIconic(g_overlay.game.root) || (!g_diag.gameActive && !menuActive)) {
    Hide();
    g_diag.overlayShown = false;
    return;
  }

  POINT origin{ 0, 0 };
  ClientToScreen(content, &origin);
  const int w = client.right, h = client.bottom;
  if (w < 64 || h < 64) {
    Hide();
    g_diag.overlayShown = false;
    return;
  }
  ResizeCanvas(w, h);
  Canvas& c = g_overlay.canvas;
  c.Clear();

  const HudData& d = GameInfo();
  g_overlay.text.SetFace(s.hudFont);
  if (s.crosshair.on && d.inGame) DrawCrosshair(c, s);
  if (s.watermark.on) DrawWatermark(c, g_overlay.text, s, d);  // includes the info lines when that's on
  else if (s.info.on) DrawInfoBox(c, g_overlay.text, s, d);
  if (s.hp.on && d.hasHealth) DrawBar(c, g_overlay.text, s.hpX, s.hpY, d.health, d.maxHealth, 0xE8414E, false);
  if ((g_settings.misc.structureSnap.on || g_settings.misc.structureSnapOther.on) && d.inGame) DrawSnapGuide(c,g_overlay.text);
  if (s.penisEsp.on && d.inGame) DrawPenisEsp(c,s);
  if (s.corruptedEsp.on && d.inGame) DrawCorruptedDinos(c, g_overlay.text);
  if (s.trajectory.on && d.inGame) DrawTrajectory(c,g_overlay.text);
  if(s.tekIndicator.on&&d.inGame)DrawTekIndicator(c,g_overlay.text,s);
  if (s.spyglass.on) DrawSpyglass(c, g_overlay.text, s, Spyglass());
  if (d.inGame && (g_settings.misc.showTurretFill || g_settings.misc.turretFiller.on)) DrawTurrets(c, g_overlay.text, TurretFill());
  if (s.armor.on && d.inGame) DrawArmor(c, g_overlay.text, d, s);
  if (s.mountHp.on && d.riding) DrawBar(c, g_overlay.text, s.mountX, s.mountY, d.mountHealth, d.mountMaxHealth, 0x5ED26E, true);
  if (s.playerList.on) DrawPlayerList(c, g_overlay.text, s, PlayerList());

  POINT source{ 0, 0 };
  SIZE size{ w, h };
  BLENDFUNCTION blend{ AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
  UpdateLayeredWindow(g_overlay.window, nullptr, &origin, &size, g_overlay.dc, &source, 0, &blend, ULW_ALPHA);
  if (!g_overlay.shown) {
    ShowWindow(g_overlay.window, SW_SHOWNOACTIVATE);
    g_overlay.shown = true;
  }
  g_diag.overlayShown = true;
  // Over the game, but under the menu while you're using it, so the crosshair never covers the menu.
  if (menuActive) {
    SetWindowPos(g_overlay.window, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    SetWindowPos(g_overlay.window, g_overlay.menu, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
  } else {
    SetWindowPos(g_overlay.window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
  }
}

void DestroyOverlay() {
  g_overlay.text.Destroy();
  if (g_overlay.bitmap) DeleteObject(g_overlay.bitmap);
  if (g_overlay.dc) DeleteDC(g_overlay.dc);
  if (g_overlay.window) DestroyWindow(g_overlay.window);
  g_overlay = {};
}

}  // namespace wintek
