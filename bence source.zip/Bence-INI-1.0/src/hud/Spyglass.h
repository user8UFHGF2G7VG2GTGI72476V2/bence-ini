#pragma once
#include "engine/Engine.h"
#include <string>
#include <vector>

// Awesome Spyglass: dinos, players, structures and dropped bags in the loaded world.
//
// Targeting uses ARK's own HUD target (ShooterHUD.LastTargetedActor, a weak pointer the game sets while you
// look at something), resolved through GObjects by index + serial so a destroyed actor is never read. The panel
// lingers a few seconds after you look away. Every field is read by name through reflection.
namespace wintek {

struct SpyglassData {
  enum Kind { None, WildDino, OwnDino, OwnStructure, Player, Bag };
  bool own=false, enemy=false, targetLocked=false, hasColors=false, hasTamedPoints=false;
  unsigned char colors[6]={};int tamedPoints[12]={};
  double decaySec=-1, offlineSec=-1;
  std::wstring tribe, heldItem;
  Kind kind = None;
  std::wstring name;      // species, tamed name, or structure name
  std::wstring species;   // for a named tame
  std::wstring tamer;
  int level = 0, baseLevel = 0, extraLevel = 0;
  bool female = false, knockedOut = false, dead = false, neutered = false;
  float babyAge = -1.0f;  // 0..1 while a baby
  float imprint = -1.0f;  // 0..1
  float health = 0.0f, maxHealth = 0.0f, torpor = 0.0f, maxTorpor = 0.0f;
  float tameProgress = -1.0f, tameEffectiveness = -1.0f;  // knocked-out wild dino
  int mutationsMale = -1, mutationsFemale = -1;
  bool hasStats = false;  // own tames: the stat grid
  float stamina = 0, oxygen = 0, food = 0, weight = 0, melee = 0, speed = 0;
  bool hasWildPoints = false;  // wild dinos: level-up points per stat (ARK's stat order: 0 health, 1 stamina, 3 oxygen,
  int wildPoints[12] = {};     // 4 food, 7 weight, 8 melee, 9 speed)
  int items = -1;          // own containers
  bool locked = false;
  float distanceM = -1.0f;
};

// `rangeM`: how far it reaches, 20 to 700 m.
void TickSpyglass(const GameContext& game, bool wanted, float rangeM);
const SpyglassData& Spyglass();
// The wild dino the spyglass showed most recently (0 if none yet). Main thread; for the Dino Dump test tool.
Address SpyglassWildDino();
struct CorruptedDinoMarker {
  float position[3] = {};
  std::wstring name;
  float distanceM = 0.0f;
};
struct PlayerJokeMarker { float position[3] = {}; };
void TickPenisEsp(const GameContext& game, bool wanted);
const std::vector<PlayerJokeMarker>& PenisEspMarkers();
void TickCorruptedEsp(const GameContext& game, bool wanted, float rangeM);
const std::vector<CorruptedDinoMarker>& CorruptedDinos();
struct MiscSettings;
void TickStructureSnap(const GameContext& game, const MiscSettings& settings, bool restoring);
const char* StructureSnapStatus();
bool StructureSnapGuide(float position[3]);
void ResetSpyglass();

}  // namespace wintek
