#pragma once
#include <cstdint>

// Choices shown on the HUD tab and used by the overlay.
namespace wintek {

inline constexpr const char* kCrossShapes[] = { "Dot", "Cross", "Cross + Dot", "Circle", "X", "T" };
inline constexpr int kCrossShapeCount = 6;

inline constexpr const char* kCrossColors[] = { "White", "Green", "Red", "Cyan", "Yellow", "Purple", "Pink" };
inline constexpr std::uint32_t kCrossColorRgb[] = { 0xFFFFFF, 0x3CFF5A, 0xFF3C46, 0x3CF0FF, 0xFFE63C, 0x9C6CFF, 0xFF6CD2 };
inline constexpr int kCrossColorCount = 7;

inline constexpr const char* kWatermarkCorners[] = { "Top Left", "Top Right" };
inline constexpr int kWatermarkCornerCount = 2;
inline constexpr const char* kWatermarkColors[] = { "Blue", "Purple", "Red", "Green", "Cyan", "Yellow", "Orange", "Pink", "White" };
inline constexpr std::uint32_t kWatermarkColorRgb[] = { 0x2B3CF0, 0x8C5AFF, 0xF03C3C, 0x3CDC5A, 0x3CE6F0, 0xF5DC32, 0xFF8C28, 0xFF6CD2, 0xFFFFFF };
inline constexpr int kWatermarkColorCount = 9;

// HUD Font (HUD tab): the font the overlay's text uses (watermark, spyglass, armor, player list, turret markers).
// The pixel fonts are compiled into the exe; the others come from Windows (a PC without one falls back to a default).
// `scale` evens out letter heights so every font fits the same layouts; pixel fonts aren't drawn bold.
struct HudFont {
  const char* name;
  const wchar_t* face;
  float scale;
  bool pixel;
};
inline constexpr HudFont kHudFonts[] = {
  { "Verdana", L"Verdana", 1.0f, false },          { "Segoe UI", L"Segoe UI", 1.05f, false },
  { "Arial", L"Arial", 1.05f, false },             { "Tahoma", L"Tahoma", 1.0f, false },
  { "Impact", L"Impact", 1.05f, false },           { "Consolas", L"Consolas", 1.0f, false },
  { "Comic Sans", L"Comic Sans MS", 1.0f, false }, { "Pixelify", L"Pixelify Sans", 1.15f, true },
  { "Silkscreen", L"Silkscreen", 0.95f, true },    { "Press Start", L"Press Start 2P", 0.7f, true },
  { "VT323", L"VT323", 1.35f, true },              { "Jersey", L"Jersey 10", 1.35f, true },
  { "Tiny5", L"Tiny5", 1.2f, true },               { "Micro5", L"Micro 5", 1.5f, true },
};
inline constexpr int kHudFontCount = static_cast<int>(sizeof(kHudFonts) / sizeof(kHudFonts[0]));
inline constexpr const char* kHudFontNames[] = { "Verdana", "Segoe UI", "Arial", "Tahoma", "Impact", "Consolas", "Comic Sans",
                                                 "Pixelify", "Silkscreen", "Press Start", "VT323", "Jersey", "Tiny5", "Micro5" };

inline constexpr const char* kSides[] = { "Left", "Right" };
inline constexpr int kSideCount = 2;

inline constexpr const char* kCorners[] = { "Top Left", "Top Right", "Bottom Left", "Bottom Right" };
inline constexpr int kCornerCount = 4;

}  // namespace wintek
