#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"
#include <array>
namespace wintek {
struct TrajectoryData {
 std::vector<std::array<float,3>> points;
 bool impact=false;
 std::array<float,3> hit{};
};
void TickTargeting(const GameContext&,const HudSettings&,bool restoring);
void ResetTargeting();
void FlushTargeting(unsigned long timeoutMs);
const TrajectoryData& Trajectory();
const char* TrajectoryStatus();
const char* OutlineStatus();
}
