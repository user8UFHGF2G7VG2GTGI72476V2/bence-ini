#include "hud/PlayerList.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cwchar>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <unordered_set>

namespace wintek {

namespace {

// Folder shared with config.json (see tabs/config/Config.cpp).
constexpr const wchar_t* kGameDataFolder = L"\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\AC";

// UProperty in this build: ElementSize at 0x34, and its subclasses' first field (UArrayProperty::Inner,
// UStructProperty::Struct) at 0x70, right after UProperty (UBoolProperty's fields start there, see Offsets.h).
constexpr Address kElementSize = 0x34;
constexpr Address kPropertyExtra = 0x70;

constexpr int kMaxPlayers = 500;
constexpr int kMaxChars = 256;
constexpr DWORD kReplyTimeoutMs = 4000;   // no reply this long after a request counts as unanswered
constexpr DWORD kLeftShowMs = 30000;      // players who left stay listed (greyed) this long
constexpr DWORD kFallbackScanMs = 3000;   // how often the admin-manager fallback may scan
// Object flags that mean "not a real live object": class default / archetype, pending kill, unreachable.
constexpr std::int32_t kSkipFlags = 0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000;

struct RawPlayer {
  std::wstring id, gamertag, name, account;
  int level = 0;
};

enum class Kind { None, Str, Int32, Int64 };

struct FieldRef {
  std::int32_t at = -1;
  Kind kind = Kind::None;
  std::string name;
};

// What the hook needs to decode the reply. Filled on the main thread before the hook is armed, read by the
// debugger thread only while armed (SetHookBreakpoint publishes it with an atomic store).
struct Layout {
  Address replyFunction = 0;
  std::int32_t listAt = 0;
  std::int32_t elementSize = 0;
  FieldRef id, gamertag, name, account, level;
} g_layout;

struct {
  Address playerStateClass = 0;
  Address requestFunction = 0;
  Address replyNative = 0;
  bool resolved = false;
  std::string problem;  // why resolving failed
  std::string layoutText;  // the reply's fields, for the log

  Address params = 0;  // an empty parameter block in ARK's memory (data only) for the request
  DWORD requestedAt = 0;
  std::uint64_t ticket = 0;
  bool requestPending = false;
  DWORD lastReplyAt = 0;
  bool active = false;  // holding the debugger / hook

  DWORD scanAt = 0;
  PlayerListData data;
  std::unordered_map<std::wstring, DWORD> joined;  // key -> joinedAt, for players currently connected
  bool firstReplyLogged = false;
} g_pl;

// Filled by the hook (debugger thread) and the fallback scan (worker thread), taken by the main thread.
std::mutex g_mutex;
std::vector<RawPlayer> g_captured, g_scanned;
bool g_capturedReady = false, g_scannedReady = false;
std::string g_hookNote;
std::atomic<int> g_hookHits{ 0 };
std::atomic<bool> g_scanning{ false };
std::atomic<std::uint32_t> g_generation{ 0 };  // bumped on reset, so late results from the old game are dropped

std::string g_statusText;

std::wstring Folder() {
  const wchar_t* localAppData = _wgetenv(L"LOCALAPPDATA");
  return std::wstring(localAppData ? localAppData : L"") + kGameDataFolder + L"\\Bence INI";
}

std::string Utf8(const std::wstring& text) {
  if (text.empty()) return {};
  const int size = WideCharToMultiByte(CP_UTF8, 0, text.c_str(), static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
  std::string out(static_cast<std::size_t>(size > 0 ? size : 0), '\0');
  if (size > 0) WideCharToMultiByte(CP_UTF8, 0, text.c_str(), static_cast<int>(text.size()), out.data(), size, nullptr, nullptr);
  return out;
}

std::string JsonString(const std::wstring& text) {
  std::string out = "\"";
  for (unsigned char ch : Utf8(text)) {
    if (ch == '"' || ch == '\\') out += '\\', out += static_cast<char>(ch);
    else if (ch < 0x20) {
      char esc[8];
      std::snprintf(esc, sizeof(esc), "\\u%04x", ch);
      out += esc;
    } else out += static_cast<char>(ch);
  }
  return out + "\"";
}

// An FString (TArray<wchar_t>) whose header is at `header` in our own copy of the data.
std::wstring ReadFString(const TArray& s) {
  if (!s.data || s.count <= 1 || s.count > kMaxChars) return {};
  std::wstring out(static_cast<std::size_t>(s.count - 1), L'\0');
  if (!g_memory.ReadRaw(s.data, out.data(), out.size() * sizeof(wchar_t))) return {};
  out.resize(std::wcslen(out.c_str()));
  return out;
}

std::wstring ReadFieldText(const std::uint8_t* element, const FieldRef& f) {
  if (f.at < 0) return {};
  switch (f.kind) {
    case Kind::Str: {
      TArray s;
      std::memcpy(&s, element + f.at, sizeof(s));
      return ReadFString(s);
    }
    case Kind::Int32: {
      std::uint32_t v;
      std::memcpy(&v, element + f.at, sizeof(v));
      return v ? std::to_wstring(v) : std::wstring();
    }
    case Kind::Int64: {
      std::uint64_t v;
      std::memcpy(&v, element + f.at, sizeof(v));
      return v ? std::to_wstring(v) : std::wstring();
    }
    default: return {};
  }
}

// "look - Lvl 120" -> name "look", level 120 (the admin manager shows names this way).
void SplitLevel(RawPlayer& p) {
  const std::size_t at = p.name.rfind(L" - Lvl ");
  if (at == std::wstring::npos) return;
  if (!p.level) p.level = _wtoi(p.name.c_str() + at + 7);
  p.name.resize(at);
}

// ---------------------------------------------------------------- the hook (debugger thread)

// Entered at the start of ClientGetPlayerConnectedData's native handler, called by ProcessEvent with
// rcx = the player state, rdx = the FFrame. The FFrame holds the function (Node), the object, the script code
// and Locals, the parameter block the server's list was received into; it's only valid until the handler
// returns, so everything is copied out now.
void OnReply(std::uintptr_t, std::uintptr_t frameAddress, std::uintptr_t, std::uintptr_t) {
  ++g_hookHits;
  const Layout& L = g_layout;
  Address frame[10] = {};
  if (!g_memory.ReadRaw(frameAddress, frame, sizeof(frame))) return;
  int node = -1;
  for (int i = 0; i + 3 < 10; ++i)
    if (frame[i] == L.replyFunction) {
      node = i;
      break;
    }
  std::lock_guard<std::mutex> lock(g_mutex);
  if (node < 0) {
    g_hookNote = "reply caught but its frame didn't match";
    return;
  }
  const Address locals = frame[node + 3];
  const TArray list = Read<TArray>(locals + L.listAt);
  if (list.count < 0 || list.count > kMaxPlayers || (list.count && !list.data) || L.elementSize <= 0) {
    g_hookNote = "reply caught but the list looked wrong";
    return;
  }
  std::vector<std::uint8_t> raw(static_cast<std::size_t>(list.count) * L.elementSize);
  if (!raw.empty() && !g_memory.ReadRaw(list.data, raw.data(), raw.size())) {
    g_hookNote = "reply caught but couldn't be read";
    return;
  }
  std::vector<RawPlayer> players;
  players.reserve(static_cast<std::size_t>(list.count));
  for (int i = 0; i < list.count; ++i) {
    const std::uint8_t* e = raw.data() + static_cast<std::size_t>(i) * L.elementSize;
    RawPlayer p;
    p.id = ReadFieldText(e, L.id);
    p.gamertag = ReadFieldText(e, L.gamertag);
    p.name = ReadFieldText(e, L.name);
    p.account = ReadFieldText(e, L.account);
    if (L.level.at >= 0) {
      std::int32_t level = 0;
      std::memcpy(&level, e + L.level.at, sizeof(level));
      if (level > 0 && level < 100000) p.level = level;
    }
    players.push_back(std::move(p));
  }
  g_captured = std::move(players);
  g_capturedReady = true;
  g_hookNote.clear();
}

// ---------------------------------------------------------------- resolving (main thread)

Kind KindOf(const std::string& propertyClass) {
  if (propertyClass == "StrProperty") return Kind::Str;
  if (propertyClass == "IntProperty" || propertyClass == "UInt32Property") return Kind::Int32;
  if (propertyClass == "Int64Property" || propertyClass == "UInt64Property") return Kind::Int64;
  return Kind::None;
}

bool Has(const std::string& lower, const char* word) { return lower.find(word) != std::string::npos; }

// Picks which of the reply's fields is which, by name. The fields are listed in player_list_log.txt, so a
// wrong pick can be fixed by name later.
void MapFields(Address strct) {
  Layout& L = g_layout;
  L.id = L.gamertag = L.name = L.account = L.level = {};
  FieldRef numericId;
  std::string text;
  for (Address s = strct; s; s = Read<Address>(s + offsets::reflection::kSuperStruct)) {
    int n = 0;
    for (Address f = Read<Address>(s + offsets::reflection::kChildren); f && n < 256; f = Read<Address>(f + offsets::reflection::kNext), ++n) {
      const std::string name = NameOf(f), cls = NameOf(ClassOf(f)), lower = ToLower(name);
      const std::int32_t at = Read<std::int32_t>(f + offsets::reflection::kPropertyOffset);
      char line[200];
      std::snprintf(line, sizeof(line), "    %s : %s @0x%X\n", name.c_str(), cls.c_str(), at);
      text += line;
      if (at < 0 || at >= L.elementSize) continue;
      const Kind kind = KindOf(cls);
      const FieldRef ref{ at, kind, name };
      const bool steamOrPlatform = Has(lower, "steam") || Has(lower, "platform") || Has(lower, "online") || Has(lower, "gamertag");
      if (kind == Kind::Str) {
        if (Has(lower, "linkedplayerid")) L.id = ref;
        else if ((Has(lower, "playerid") || Has(lower, "playerdataid")) && L.id.at < 0 && !steamOrPlatform) L.id = ref;
        else if (steamOrPlatform && Has(lower, "name")) L.gamertag = ref;
        else if (Has(lower, "name") && (Has(lower, "player") || Has(lower, "character") || Has(lower, "survivor")) && L.name.at < 0) L.name = ref;
        else if ((Has(lower, "steamid") || Has(lower, "uniqueid") || Has(lower, "netid")) && L.account.at < 0) L.account = ref;
      } else if (kind != Kind::None) {
        if ((Has(lower, "playerid") || Has(lower, "playerdataid") || Has(lower, "linkedplayer")) && numericId.at < 0) numericId = ref;
        else if (Has(lower, "level") && kind == Kind::Int32 && L.level.at < 0) L.level = ref;
      }
    }
  }
  if (L.id.at < 0) L.id = numericId;
  g_pl.layoutText = text;
}

void WriteLog() {
  const std::wstring path = Folder() + L"\\player_list_log.txt";
  CreateDirectoryW(Folder().c_str(), nullptr);
  FILE* file = _wfopen(path.c_str(), L"wb");
  if (!file) return;
  const Layout& L = g_layout;
  std::fprintf(file, "Bence INI - Player List (Admin) log. Send this if the panel shows the wrong things.\n\n");
  std::fprintf(file, "resolved: %s %s\n", g_pl.resolved ? "yes" : "no", g_pl.problem.c_str());
  std::fprintf(file, "request function: %s\n", g_pl.requestFunction ? "found" : "missing");
  std::fprintf(file, "reply handler: %s (0x%llX)\n", g_pl.replyNative ? "found" : "missing",
               static_cast<unsigned long long>(g_pl.replyNative ? g_pl.replyNative - g_process.base : 0));
  std::fprintf(file, "list at 0x%X, element size 0x%X\n", L.listAt, L.elementSize);
  std::fprintf(file, "picked: id=%s gamertag=%s name=%s account=%s level=%s\n", L.id.name.c_str(), L.gamertag.name.c_str(),
               L.name.name.c_str(), L.account.name.c_str(), L.level.name.c_str());
  std::fprintf(file, "reply fields:\n%s\n", g_pl.layoutText.c_str());
  std::fprintf(file, "hook hits: %d\n", g_hookHits.load());
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_hookNote.empty()) std::fprintf(file, "hook note: %s\n", g_hookNote.c_str());
  }
  const PlayerListData& d = g_pl.data;
  std::fprintf(file, "players connected: %d\n", d.connected);
  int shown = 0;
  for (const ListedPlayer& p : d.players) {
    if (p.leftAt || ++shown > 3) continue;
    std::fprintf(file, "  e.g. id=%s gamertag=%s name=%s level=%d\n", Utf8(p.id).c_str(), Utf8(p.gamertag).c_str(), Utf8(p.name).c_str(), p.level);
  }
  std::fclose(file);
}

bool Resolve(Address playerState) {
  const Address cls = ClassOf(playerState);
  if (cls == g_pl.playerStateClass) return g_pl.resolved;
  SetHookBreakpoint(0, 0, nullptr);  // the hook reads g_layout, so it's disarmed before g_layout changes
  g_pl.playerStateClass = cls;
  g_pl.resolved = false;
  g_pl.replyNative = 0;
  g_layout = {};

  g_pl.requestFunction = MainReflection().FindField(cls, "ServerGetPlayerConnectedData");
  const Address reply = MainReflection().FindField(cls, "ClientGetPlayerConnectedData");
  const Address list = reply ? MainReflection().FindField(reply, "list") : 0;
  const Address inner = list ? Read<Address>(list + kPropertyExtra) : 0;
  const Address strct = inner && NameOf(ClassOf(inner)) == "StructProperty" ? Read<Address>(inner + kPropertyExtra) : 0;
  if (!g_pl.requestFunction || !reply || !strct) {
    g_pl.problem = !g_pl.requestFunction ? "(request function not found)" : "(reply function not found)";
    WriteLog();
    return false;
  }
  g_layout.replyFunction = reply;
  g_layout.listAt = Read<std::int32_t>(list + offsets::reflection::kPropertyOffset);
  g_layout.elementSize = Read<std::int32_t>(inner + kElementSize);
  if (g_layout.listAt < 0 || g_layout.listAt >= 0x100 || g_layout.elementSize < 8 || g_layout.elementSize > 0x1000) {
    g_pl.problem = "(reply list layout looked wrong)";
    WriteLog();
    return false;
  }
  MapFields(strct);
  g_pl.replyNative = NativeOf(reply);
  g_pl.problem = g_pl.replyNative ? "" : "(reply handler not found - using the admin manager fallback)";
  g_pl.resolved = true;
  WriteLog();
  return true;
}

// ---------------------------------------------------------------- fallback: the admin manager's rows

void ScanAdminRows(std::uint32_t generation) {
  Reflection reflection;
  Address rowClass = 0;
  std::int32_t nameAt = 0, tagAt = 0, idAt = 0;
  std::unordered_map<Address, bool> isRow;
  std::vector<RawPlayer> rows;
  std::unordered_set<std::wstring> seen;
  ForEachObject([&](Address object, std::int32_t) {
    std::uint8_t header[0x28];
    if (!g_memory.ReadRaw(object, header, sizeof(header))) return true;
    std::int32_t flags;
    Address cls;
    std::memcpy(&flags, header + offsets::object::kFlags, sizeof(flags));
    std::memcpy(&cls, header + offsets::object::kClass, sizeof(cls));
    if (!cls || (flags & kSkipFlags)) return true;
    auto it = isRow.find(cls);
    if (it == isRow.end()) it = isRow.emplace(cls, reflection.IsA(cls, "AdminPlayerInfoEntryButton")).first;
    if (!it->second) return true;
    if (rowClass != cls) {
      rowClass = cls;
      nameAt = reflection.PropertyOffset(cls, "PlayerName");
      tagAt = reflection.PropertyOffset(cls, "SteamPlayerName");
      idAt = reflection.PropertyOffset(cls, "LinkedPlayerID");
    }
    if (!idAt) return true;
    RawPlayer p;
    p.id = ReadFString(Read<TArray>(object + idAt));
    if (p.id.empty() || !seen.insert(p.id).second) return true;  // rows without an ID are from the ban / whitelist tabs
    if (tagAt) p.gamertag = ReadFString(Read<TArray>(object + tagAt));
    if (nameAt) p.name = ReadFString(Read<TArray>(object + nameAt));
    rows.push_back(std::move(p));
    return true;
  });
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (generation == g_generation) {
      g_scanned = std::move(rows);
      g_scannedReady = true;
    }
  }
  g_scanning = false;
}

// ---------------------------------------------------------------- the list

void WriteJson(const PlayerListData& d, const char* source) {
  const std::wstring folder = Folder(), path = folder + L"\\players.json", temp = path + L".tmp";
  CreateDirectoryW(folder.c_str(), nullptr);
  FILE* file = _wfopen(temp.c_str(), L"wb");
  if (!file) return;
  std::fprintf(file, "{\n  \"updated\": %lld,\n  \"source\": \"%s\",\n  \"count\": %d,\n  \"players\": [", static_cast<long long>(time(nullptr)),
               source, d.connected);
  bool first = true;
  for (const ListedPlayer& p : d.players) {
    if (p.leftAt) continue;
    std::fprintf(file, "%s\n    { \"id\": %s, \"gamertag\": %s, \"name\": %s, \"level\": %d }", first ? "" : ",", JsonString(p.id).c_str(),
                 JsonString(p.gamertag).c_str(), JsonString(p.name).c_str(), p.level);
    first = false;
  }
  std::fprintf(file, "\n  ]\n}\n");
  std::fclose(file);
  MoveFileExW(temp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING);  // swapped in whole, so readers never see half a file
}

std::wstring KeyOf(const RawPlayer& p) { return p.id.empty() ? L"tag:" + p.gamertag : p.id; }

void Apply(std::vector<RawPlayer> raw, PlayerListData::Status status, bool writeJson) {
  PlayerListData& d = g_pl.data;
  const DWORD now = GetTickCount();
  const bool firstList = d.updatedAt == 0;

  std::vector<ListedPlayer> connected;
  std::unordered_map<std::wstring, DWORD> joined;
  for (RawPlayer& p : raw) {
    SplitLevel(p);
    if (p.id.empty() && p.gamertag.empty()) continue;
    const std::wstring key = KeyOf(p);
    if (joined.count(key)) continue;
    const auto was = g_pl.joined.find(key);
    const DWORD joinedAt = was != g_pl.joined.end() ? was->second : (firstList ? 0 : now);
    joined[key] = joinedAt;
    connected.push_back({ p.id, p.gamertag, p.name, p.level, joinedAt, 0 });
  }
  // Whoever was connected last time and isn't now has left; earlier leavers stay until they expire or rejoin.
  std::vector<ListedPlayer> left;
  for (const ListedPlayer& p : d.players) {
    const std::wstring key = p.id.empty() ? L"tag:" + p.gamertag : p.id;
    if (joined.count(key)) continue;
    ListedPlayer gone = p;
    if (!gone.leftAt) gone.leftAt = now;
    if (now - gone.leftAt < kLeftShowMs) left.push_back(gone);
  }
  std::sort(left.begin(), left.end(), [](const ListedPlayer& a, const ListedPlayer& b) { return a.leftAt > b.leftAt; });

  d.connected = static_cast<int>(connected.size());
  d.players = std::move(connected);
  d.players.insert(d.players.end(), left.begin(), left.end());
  d.updatedAt = now;
  d.status = status;
  d.detail.clear();
  g_pl.joined = std::move(joined);
  if (writeJson) WriteJson(d, status == PlayerListData::Live ? "server" : "admin manager");
}

void Release() {
  if (!g_pl.active) return;
  g_pl.active = false;
  SetHookBreakpoint(0, 0, nullptr);
  RequestDebugger(DebuggerClient::PlayerList, false);
}

BoolProperty g_isAdmin("bIsAdmin"), g_isCheatPlayer("bCheatPlayer");

}  // namespace

void TickPlayerList(const GameContext& game, bool wanted, int refreshSeconds) {
  constexpr bool writeJson=true;
  PlayerListData& d = g_pl.data;
  const DWORD now = GetTickCount();
  if (!wanted) {
    Release();
    d.status = PlayerListData::Off;
    return;
  }
  if (!game.controller) {
    Release();
    d.status = PlayerListData::NotInGame;
    return;
  }
  // The server sets these on admins' controllers (enablecheats / admin list). No admin flag, no requests.
  if (!g_isAdmin.Get(game.controller) && !g_isCheatPlayer.Get(game.controller)) {
    Release();
    d.status = PlayerListData::NotAdmin;
    return;
  }
  const std::int32_t psAt = PropertyOffset(ClassOf(game.controller), "PlayerState");
  const Address playerState = psAt ? Read<Address>(game.controller + psAt) : 0;
  if (!playerState) {
    d.status = PlayerListData::Waiting;
    return;
  }
  if (!Resolve(playerState)) {
    Release();
    d.status = PlayerListData::Failed;
    d.detail = g_pl.problem;
    return;
  }

  g_pl.active = true;
  RequestDebugger(DebuggerClient::PlayerList, true);
  if (g_pl.replyNative) SetHookBreakpoint(0, g_pl.replyNative, OnReply);

  // Results from the hook and the fallback scan.
  std::vector<RawPlayer> captured, scanned;
  bool gotCapture = false, gotScan = false;
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_capturedReady) {
      captured = std::move(g_captured);
      g_capturedReady = false;
      gotCapture = true;
    }
    if (g_scannedReady) {
      scanned = std::move(g_scanned);
      g_scannedReady = false;
      gotScan = true;
    }
  }
  const DWORD refreshMs = static_cast<DWORD>(std::clamp(refreshSeconds, 3, 60)) * 1000;
  if (gotCapture) {
    g_pl.lastReplyAt = now;
    g_pl.requestPending = false;
    Apply(std::move(captured), PlayerListData::Live, writeJson);
    if (!g_pl.firstReplyLogged) {
      g_pl.firstReplyLogged = true;
      WriteLog();
    }
  }
  const bool replyWorking = g_pl.lastReplyAt && now - g_pl.lastReplyAt < refreshMs * 2 + kReplyTimeoutMs;
  if (gotScan && !replyWorking && !scanned.empty()) Apply(std::move(scanned), PlayerListData::FromAdminManager, writeJson);

  // Ask the server again every refresh.
  if (DebuggerAttached() && g_pl.requestFunction && CompletedCalls() >= g_pl.ticket && (!g_pl.requestedAt || now - g_pl.requestedAt >= refreshMs)) {
    if (!g_pl.params)
      g_pl.params = reinterpret_cast<Address>(VirtualAllocEx(g_process.handle, nullptr, 0x100, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    if (g_pl.params) {
      g_pl.ticket = QueueProcessEvent(playerState, g_pl.requestFunction, g_pl.params);
      g_pl.requestedAt = now;
      g_pl.requestPending = true;
    }
  }
  // No working reply catch: read the admin manager's rows instead (they exist while showmyadminmanager is open).
  if (!replyWorking && !g_scanning && now - g_pl.scanAt >= (std::max)(refreshMs, kFallbackScanMs)) {
    g_pl.scanAt = now;
    g_scanning = true;
    std::thread(ScanAdminRows, g_generation.load()).detach();
  }

  // Drop leavers once they've been shown long enough.
  d.players.erase(std::remove_if(d.players.begin(), d.players.end(), [&](const ListedPlayer& p) { return p.leftAt && now - p.leftAt >= kLeftShowMs; }),
                  d.players.end());

  if (!d.updatedAt) {
    d.status = PlayerListData::Waiting;
    if (const char* error = DebuggerError()) d.detail = error;
    else if (g_pl.requestPending && now - g_pl.requestedAt > kReplyTimeoutMs)
      d.detail = g_pl.replyNative ? "No reply yet - open showmyadminmanager once if it stays empty" : "Open showmyadminmanager to fill the list";
    else d.detail.clear();
  } else if (d.status == PlayerListData::Live && !replyWorking) {
    d.detail = "no reply for " + std::to_string((now - g_pl.lastReplyAt) / 1000) + "s";  // keep the list, say it's old
  }
}

const PlayerListData& PlayerList() { return g_pl.data; }

const char* PlayerListStatusText() {
  const PlayerListData& d = g_pl.data;
  switch (d.status) {
    case PlayerListData::Off: g_statusText = "Off."; break;
    case PlayerListData::NotInGame: g_statusText = "Join your server to see the list."; break;
    case PlayerListData::NotAdmin: g_statusText = "Not admin on this server (log in as admin first)."; break;
    case PlayerListData::Waiting: g_statusText = "Waiting for the server" + (d.detail.empty() ? std::string("...") : ": " + d.detail); break;
    case PlayerListData::Live:
      g_statusText = std::to_string(d.connected) + " players, live from the server" + (d.detail.empty() ? "." : " (" + d.detail + ").");
      break;
    case PlayerListData::FromAdminManager: g_statusText = std::to_string(d.connected) + " players, from the admin manager."; break;
    case PlayerListData::Failed: g_statusText = "Not available: " + d.detail; break;
  }
  return g_statusText.c_str();
}

void ResetPlayerList() {
  SetHookBreakpoint(0, 0, nullptr);
  RequestDebugger(DebuggerClient::PlayerList, false);
  ++g_generation;
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_captured.clear();
    g_scanned.clear();
    g_capturedReady = g_scannedReady = false;
    g_hookNote.clear();
  }
  g_hookHits = 0;
  g_pl.playerStateClass = 0;
  g_pl.requestFunction = 0;
  g_pl.replyNative = 0;
  g_pl.resolved = false;
  g_pl.problem.clear();
  g_pl.layoutText.clear();
  g_pl.params = 0;  // belonged to the previous game process
  g_pl.requestedAt = 0;
  g_pl.ticket = 0;
  g_pl.requestPending = false;
  g_pl.lastReplyAt = 0;
  g_pl.active = false;
  g_pl.scanAt = 0;
  g_pl.data = {};
  g_pl.joined.clear();
  g_pl.firstReplyLogged = false;
  g_layout = {};
}

}  // namespace wintek
