#pragma once
#include "engine/Engine.h"
#include "core/Settings.h"
namespace wintek {
struct AimTargetData {
 ObjectRef target; float health=0,maxHealth=0,distanceM=-1; int shots=-1;
 bool indicator=false,inRange=false; std::wstring name;
};
void TickAimTarget(const GameContext&,const HudSettings&,bool restoring);
const AimTargetData& AimTarget();
void FlushAimTarget(unsigned long timeoutMs);
void ResetAimTarget();
}
