#include "hud/Targeting.h"
#include "hud/Ballistics.h"
#include "hud/Camera.h"
#include "tabs/ini/StalkerIni.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <unordered_set>

namespace wintek {
namespace {
constexpr int kSteps=24,kSlot=512;
struct Parameter {int at=-1,size=0;Address field=0;};
Parameter Param(Address fn,const char* name,int size=0) {
 Address f=MainReflection().FindField(fn,name);if(!f)return {};
 int at=Read<int>(f+offsets::reflection::kPropertyOffset),bytes=Read<int>(f+0x34);
 if(at<0||bytes<1||at+bytes>kSlot||(size&&bytes!=size))return {};
 return {at,bytes,f};
}
template<class T> bool Put(unsigned char* block,Address fn,const char* name,const T& value) {
 auto p=Param(fn,name,sizeof(T));if(p.at<0)return false;std::memcpy(block+p.at,&value,sizeof(T));return true;
}
Address Obj(Address object,const char* name) {
 int at=PropertyOffset(ClassOf(object),name);return at ? Read<Address>(object+at) : 0;
}
bool Float(Address object,const char* name,float& out) {
 int at=PropertyOffset(ClassOf(object),name);return at&&g_memory.ReadRaw(object+at,&out,4)&&std::isfinite(out);
}
bool Flag(Address object,const char* name,bool& value,int* byteAt=nullptr,unsigned char* bit=nullptr) {
 Address f=MainReflection().FindField(ClassOf(object),name);if(!f||NameOf(ClassOf(f))!="BoolProperty")return false;
 int at=Read<int>(f+offsets::reflection::kPropertyOffset)+Read<unsigned char>(f+offsets::reflection::kBoolByteOffset);
 auto mask=Read<unsigned char>(f+offsets::reflection::kBoolFieldMask);unsigned char byte=0;
 if(at<0x20||at>=0x8000||!mask||!g_memory.ReadRaw(object+at,&byte,1))return false;
 value=(byte&mask)!=0;if(byteAt)*byteAt=at;if(bit)*bit=mask;return true;
}
bool Location(Address actor,BallisticPoint& out) {
 Address root=Obj(actor,"RootComponent");int at=root ? PropertyOffset(ClassOf(root),"RelativeLocation") : 0;
 return at&&g_memory.ReadRaw(root+at,out.data(),12)&&std::isfinite(out[0])&&std::isfinite(out[1])&&std::isfinite(out[2]);
}
Address DefaultObject(Address cls) {
 // Validate the CDO by class, flags and the live object table instead of assuming a UClass layout.
 for(int at=0x80;at<0x300;at+=8) {
  Address object=Read<Address>(cls+at);
  if(object<0x10000||(object&7)||ClassOf(object)!=cls)continue;
  if((Read<unsigned int>(object+offsets::object::kFlags)&0x10)&&ObjectRef::Of(object).Alive())return object;
 }
 return 0;
}
Address activeWorld=0;
TrajectoryData trajectory;
std::string trajectoryStatus="off",outlineStatus="off";
float gravityZ=-980;
ULONGLONG gravityChecked=0;
void TickGravity(Address world) {
 if(!world||GetTickCount64()-gravityChecked<2000)return;gravityChecked=GetTickCount64();
 auto levels=Read<TArray>(world+offsets::world::kLevels);
 if(!levels.data||levels.count<1||levels.count>2048)return;
 Address level=Read<Address>(levels.data);if(!level)return;
 auto actors=Read<TArray>(level+offsets::world::kLevelActors);
 if(!actors.data||actors.count<1||actors.count>200000)return;
 for(int i=0;i<(std::min)(actors.count,64);++i) {
  Address actor=Read<Address>(actors.data+i*sizeof(Address));if(!actor||!IsA(ClassOf(actor),"WorldSettings"))continue;
  float value=0;if(Float(actor,"WorldGravityZ",value)&&value>=-10000&&value<=0)gravityZ=value;
  break;
 }
}

// Locate the blueprint collision library without blocking the menu on an object-table scan.
std::atomic<bool> searching{false};std::atomic<unsigned int> searchGeneration{0};
std::mutex searchMutex;Address library=0;
void StartSearch() {
 if(searching.exchange(true))return;
 {std::lock_guard<std::mutex> lock(searchMutex);if(library) {searching=false;return;}}
 const auto generation=searchGeneration.load();
 std::thread([generation] {
  Address found=0;Reflection reflection;
  ForEachObject([&](Address object,int) {
   if(generation!=searchGeneration.load())return false;
   if(!(Read<unsigned int>(object+offsets::object::kFlags)&0x10))return true;
   if(reflection.NameOf(object)=="Default__KismetSystemLibrary"&&reflection.IsA(ClassOf(object),"KismetSystemLibrary")) {found=object;return false;}
   return true;
  });
  {std::lock_guard<std::mutex> lock(searchMutex);if(generation==searchGeneration.load())library=found;}
  searching=false;
 }).detach();
}
struct TraceState {
 Address fn=0,buffer=0,weapon=0;
 std::uint64_t lastTicket=0;
 bool pending=false,valid=false;
 Parameter hit,result;
 int impactAt=-1;
 BallisticPoint origin{},velocity{};
 float gravity=0,seconds=0;
 ULONGLONG issued=0,finished=0;
 std::vector<BallisticPoint> points;
 bool impact=false;BallisticPoint endpoint{};
} trace;
bool ResolveTrace(Address lib) {
 if(trace.fn)return true;
 for(const char* name:{"SphereTraceSingle","SphereTraceSingle_NEW","LineTraceSingle","LineTraceSingle_NEW"}) {
  Address fn=MainReflection().FindField(ClassOf(lib),name);if(!fn)continue;
  auto hit=Param(fn,"OutHit"),result=Param(fn,"ReturnValue",1);
  if(hit.at<0||result.at<0||hit.size<12||hit.size>256||Param(fn,"Start",12).at<0||Param(fn,"End",12).at<0||
     Param(fn,"WorldContextObject",8).at<0||Param(fn,"TraceChannel",1).at<0||
     Param(fn,"ActorsToIgnore",16).at<0||Param(fn,"bIgnoreSelf",1).at<0)continue;
  Address type=Read<Address>(hit.field+0x70);Address field=type ? MainReflection().FindField(type,"ImpactPoint") : 0;
  int at=field ? Read<int>(field+offsets::reflection::kPropertyOffset) : -1;
  if(at<0||at+12>hit.size)continue;
  trace.fn=fn;trace.hit=hit;trace.result=result;trace.impactAt=at;return true;
 }
 return false;
}
bool Launch(const GameContext& game,BallisticPoint& origin,BallisticPoint& velocity,float& gravity,Address& weapon) {
 weapon=Obj(game.pawn,"CurrentWeapon");if(!weapon||!ObjectRef::Of(weapon).Alive())return false;
 Address projectileClass=Obj(weapon,"ProjectileClass");if(!projectileClass)return false;
 const auto name=ToLower(NameOf(projectileClass));
 if(name.find("arrow")==std::string::npos&&name.find("grappl")==std::string::npos) {trajectoryStatus="Equip a bow, crossbow or grapple";return false;}
 Address projectile=DefaultObject(projectileClass),movement=projectile ? Obj(projectile,"MovementComp") : 0;
 if(!movement&&projectile)movement=Obj(projectile,"ProjectileMovement");
 float speed=0,scale=0;
 if(!movement||!Float(movement,"InitialSpeed",speed)||!Float(movement,"ProjectileGravityScale",scale)||
    scale<0||scale>20) {trajectoryStatus="Projectile speed / gravity unavailable";return false;}
 if(IsA(ClassOf(weapon),"PrimalWeaponBow")) {
  float minimum=0,maximum=0,pull=0,full=0;
  if(!Float(weapon,"MinimumInitialSpeed",minimum)||!Float(weapon,"MaximumInitialSpeed",maximum)||
     !Float(weapon,"PullingTime",pull)||!Float(weapon,"PullingTimeForMaximumSpeed",full))return false;
  speed=BowLaunchSpeed(minimum,maximum,pull,full);if(speed<=0)return false;
 }
 if(speed<=0)Float(weapon,"ProjectileSpeed",speed);
 if(speed<=0||speed>200000)return false;
 const auto& view=Camera();if(!view.valid)return false;
 std::copy(view.location,view.location+3,origin.begin());
 float aim[3]={view.pitch,view.yaw,view.roll};
 int at=PropertyOffset(ClassOf(game.controller),"ControlRotation");if(!at||!g_memory.ReadRaw(game.controller+at,aim,12))return false;
 if(!std::isfinite(aim[0])||!std::isfinite(aim[1]))return false;
 constexpr float rad=0.017453292519943295f;
 velocity={std::cos(aim[0]*rad)*std::cos(aim[1]*rad)*speed,std::cos(aim[0]*rad)*std::sin(aim[1]*rad)*speed,std::sin(aim[0]*rad)*speed};
 gravity=gravityZ*scale;return true;
}
void TickTrajectory(const GameContext& game,const HudSettings& settings,bool restoring) {
 trajectory={};const bool wanted=settings.trajectory.on&&!restoring&&game.pawn&&game.controller;
 RequestDebugger(DebuggerClient::Trajectory,wanted||trace.pending);
 if(trace.pending&&CompletedCalls()>=trace.lastTicket) {
  trace.pending=false;trace.valid=true;trace.impact=false;trace.finished=GetTickCount64();
  for(int i=0;i<kSteps;++i)if(Read<unsigned char>(trace.buffer+i*kSlot+trace.result.at)) {
   BallisticPoint hit;
   if(g_memory.ReadRaw(trace.buffer+i*kSlot+trace.hit.at+trace.impactAt,hit.data(),12)&&
      std::isfinite(hit[0])&&std::isfinite(hit[1])&&std::isfinite(hit[2])) {
    trace.impact=true;trace.endpoint=hit;trace.points.resize(i+1);trace.points.push_back(hit);
   }
   break;
  }
 }
 if(!wanted) {trajectoryStatus="off";trace.valid=false;return;}
 if(game.hud&&Read<Address>(game.hud+offsets::hud::kOpenInventory)) {trajectoryStatus="Paused: inventory open";return;}
 BallisticPoint origin,velocity;float gravity=0;Address weapon=0;
 trajectoryStatus="Waiting for arrow / grapple weapon";
 if(!Launch(game,origin,velocity,gravity,weapon))return;
 float seconds=static_cast<float>(std::clamp(settings.trajectorySeconds,1,5));
 for(int i=0;i<=kSteps;++i)trajectory.points.push_back(BallisticPosition(origin,velocity,gravity,seconds*i/kSteps));
 Address lib=0;{std::lock_guard<std::mutex> lock(searchMutex);lib=library;}
 if(!lib) {StartSearch();trajectoryStatus="Flight estimate; locating collision trace";return;}
 if(!ObjectRef::Of(lib).Alive()||!ResolveTrace(lib)) {trajectoryStatus="Flight estimate; collision trace unavailable";return;}
 const auto now=GetTickCount64();
 if(trace.valid&&trace.weapon==weapon&&trace.seconds==seconds&&trace.gravity==gravity&&
    now-trace.finished<800&&SameLaunch(origin,trace.origin,velocity,trace.velocity)) {
  trajectory.points=trace.points;trajectory.impact=trace.impact;trajectory.hit=trace.endpoint;
  trajectoryStatus=trace.impact ? "Estimated impact (camera-origin / visibility collision)" : "No impact within prediction time";
 } else trajectoryStatus="Flight estimate; checking collisions";
 if(trace.pending||!DebuggerAttached()||now-trace.issued<150)return;
 if(!trace.buffer)trace.buffer=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kSteps*kSlot+32,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 if(!trace.buffer)return;
 Address ignored[2]={game.pawn,weapon};
 if(!g_memory.WriteRaw(trace.buffer+kSteps*kSlot,ignored,sizeof(ignored)))return;
 TArray ignore{trace.buffer+kSteps*kSlot,2,2};
 std::vector<unsigned char> blocks(kSteps*kSlot,0);
 for(int i=0;i<kSteps;++i) {
  auto block=blocks.data()+i*kSlot;
  auto start=BallisticPosition(origin,velocity,gravity,seconds*i/kSteps),end=BallisticPosition(origin,velocity,gravity,seconds*(i+1)/kSteps);
  Put(block,trace.fn,"WorldContextObject",game.pawn);Put(block,trace.fn,"Start",start);Put(block,trace.fn,"End",end);
  Put(block,trace.fn,"ActorsToIgnore",ignore);const unsigned char yes=1;Put(block,trace.fn,"bIgnoreSelf",yes);Put(block,trace.fn,"bTraceComplex",yes);
  float radius=2.0f;Address projectile=DefaultObject(Obj(weapon,"ProjectileClass"));Address collision=projectile ? Obj(projectile,"CollisionComp") : 0;
  float actual=0;if(collision&&Float(collision,"SphereRadius",actual)&&actual>0&&actual<100)radius=actual;
  Put(block,trace.fn,"Radius",radius);
 }
 if(!g_memory.WriteRaw(trace.buffer,blocks.data(),blocks.size()))return;
 trace.origin=origin;trace.velocity=velocity;trace.gravity=gravity;trace.weapon=weapon;trace.seconds=seconds;
 trace.points.clear();for(int i=0;i<=kSteps;++i)trace.points.push_back(BallisticPosition(origin,velocity,gravity,seconds*i/kSteps));
 trace.impact=false;trace.valid=false;trace.issued=now;
 for(int i=0;i<kSteps;++i)trace.lastTicket=QueueProcessEvent(lib,trace.fn,trace.buffer+i*kSlot);
 trace.pending=true;
}

struct MeshState {
 ObjectRef ref;Address cls=0;
 bool original=false,applied=false,wanted=false;
 int stencil=0;
 Address renderFn=0,stencilFn=0;
};
std::unordered_map<Address,MeshState> meshes;
std::unordered_set<Address> desired;
Address outlineBuffer=0;
std::uint64_t outlineTicket=0;
ULONGLONG outlineScan=0;
int playerCount=0,turretCount=0;
void AddMeshes(Address actor) {
 std::vector<Address> work;
 for(Address cls=ClassOf(actor),depth=0;cls&&depth<64;cls=Read<Address>(cls+offsets::reflection::kSuperStruct),++depth) {
  Address field=Read<Address>(cls+offsets::reflection::kChildren);
  for(int n=0;field&&n<8192;field=Read<Address>(field+offsets::reflection::kNext),++n) {
   if(NameOf(ClassOf(field))!="ObjectProperty")continue;
   int at=Read<int>(field+offsets::reflection::kPropertyOffset);if(at<0x20||at>0x8000)continue;
   Address component=Read<Address>(actor+at);
   if(component&&ObjectRef::Of(component).Alive()&&IsA(ClassOf(component),"SceneComponent"))work.push_back(component);
  }
 }
 std::unordered_set<Address> visited;
 for(std::size_t i=0;i<work.size()&&i<128;++i) {
  Address mesh=work[i];if(!visited.insert(mesh).second)continue;
  if(IsA(ClassOf(mesh),"MeshComponent"))desired.insert(mesh);
  int at=PropertyOffset(ClassOf(mesh),"AttachChildren");if(!at)continue;
  auto children=Read<TArray>(mesh+at);if(!children.data||children.count<1||children.count>128)continue;
  for(int n=0;n<children.count&&work.size()<128;++n) {
   Address child=Read<Address>(children.data+n*sizeof(Address));
   if(child&&ObjectRef::Of(child).Alive()&&IsA(ClassOf(child),"SceneComponent"))work.push_back(child);
  }
 }
}
void ScanOutlines(const GameContext& game,const HudSettings& s) {
 desired.clear();playerCount=turretCount=0;BallisticPoint me;if(!Location(game.pawn,me))return;
 int teamAt=PropertyOffset(ClassOf(game.pawn),"TargetingTeam");int myTeam=teamAt ? Read<int>(game.pawn+teamAt) : 0;
 const float range=std::clamp(s.outlineRange,20,240)*100.0f;
 auto levels=Read<TArray>(game.world+offsets::world::kLevels);if(!levels.data||levels.count<1||levels.count>2048)return;
 for(int n=0;n<levels.count;++n) {
  Address level=Read<Address>(levels.data+n*sizeof(Address));if(!level)continue;
  auto actors=Read<TArray>(level+offsets::world::kLevelActors);if(!actors.data||actors.count<1||actors.count>200000)continue;
  std::vector<Address> objects(actors.count);if(!g_memory.ReadRaw(actors.data,objects.data(),objects.size()*sizeof(Address)))continue;
  for(Address actor:objects) {
   if(!actor||actor==game.pawn)continue;
   if(Read<unsigned int>(actor+offsets::object::kFlags)&(0x30|0x100|0x4000|0x8000|0x10000))continue;
   Address cls=ClassOf(actor);if(!cls)continue;
   if(IsA(cls,"WorldSettings")) {float value=0;if(Float(actor,"WorldGravityZ",value)&&value>=-10000&&value<=0)gravityZ=value;continue;}
   bool player=s.playerOutlines.on&&IsA(cls,"ShooterCharacter");
   bool turret=s.turretOutlines.on&&IsA(cls,"PrimalStructureTurret");if(!player&&!turret)continue;
   bool dead=false;if(!Flag(actor,"bIsDead",dead)||dead)continue;
   if(s.outlineEnemiesOnly) {
    int at=PropertyOffset(cls,"TargetingTeam");if(!at||myTeam<=0)continue;
    if(Read<int>(actor+at)==myTeam)continue;
   }
   BallisticPoint pos;if(!Location(actor,pos))continue;float distance=0;
   for(int j=0;j<3;++j)distance+=(pos[j]-me[j])*(pos[j]-me[j]);if(distance>range*range)continue;
   AddMeshes(actor);if(player)++playerCount;else ++turretCount;
   if(desired.size()>=512)return;
  }
 }
}
bool CaptureMesh(Address object) {
 if(meshes.count(object))return true;bool original=false;
 if(!Flag(object,"bRenderCustomDepth",original))return false;
 int at=PropertyOffset(ClassOf(object),"CustomDepthStencilValue");if(!at)return false;
 int stencil=Read<int>(object+at);if(stencil<0||stencil>255)return false;
 Address renderFn=MainReflection().FindField(ClassOf(object),"SetRenderCustomDepth");
 Address stencilFn=MainReflection().FindField(ClassOf(object),"SetCustomDepthStencilValue");
 if(!renderFn||!stencilFn||Param(renderFn,"bValue",1).at<0||Param(stencilFn,"Value",4).at<0)return false;
 meshes.emplace(object,MeshState{ObjectRef::Of(object),ClassOf(object),original,false,true,stencil,renderFn,stencilFn});return true;
}
void TickOutlines(const GameContext& game,const HudSettings& settings,bool restoring) {
 bool wanted=!restoring&&(settings.playerOutlines.on||settings.turretOutlines.on)&&game.world&&game.pawn;
 RequestDebugger(DebuggerClient::TargetOutlines,wanted||!meshes.empty());
 if(outlineTicket&&CompletedCalls()<outlineTicket)return;
 if(!wanted)desired.clear();
 else if(!outlineScan||GetTickCount64()-outlineScan>=1000) {outlineScan=GetTickCount64();ScanOutlines(game,settings);}
 for(Address mesh:desired)if(ObjectRef::Of(mesh).Alive())CaptureMesh(mesh);
 int batch=0;
 for(auto it=meshes.begin();it!=meshes.end();) {
  auto& m=it->second;
  if(!m.ref.Alive()||ClassOf(m.ref.object)!=m.cls) {it=meshes.erase(it);continue;}
  m.wanted=desired.count(it->first)!=0;
  if(m.wanted==m.applied) {if(!m.wanted)it=meshes.erase(it);else ++it;continue;}
  if(!DebuggerAttached())break;
  if(!outlineBuffer)outlineBuffer=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,16*kSlot,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
  if(!outlineBuffer)break;
  unsigned char block[2*kSlot]={};unsigned char enable=m.wanted ? 1 : m.original;
  int stencil=m.wanted ? 1 : m.stencil;
  Put(block,m.stencilFn,"Value",stencil);Put(block+kSlot,m.renderFn,"bValue",enable);
  const Address slot=outlineBuffer+batch*2*kSlot;
  if(!g_memory.WriteRaw(slot,block,sizeof(block)))break;
  QueueProcessEvent(m.ref.object,m.stencilFn,slot);
  outlineTicket=QueueProcessEvent(m.ref.object,m.renderFn,slot+kSlot);m.applied=m.wanted;
  if(++batch>=8)break;
  ++it;
 }
 outlineStatus=wanted && !StalkerOutlineReady() ? "Waiting for the Stalker outline material" : wanted ? "Players: "+std::to_string(playerCount)+" | Turrets: "+std::to_string(turretCount)+" | Meshes: "+std::to_string(meshes.size()) : "off";
}
}
void TickTargeting(const GameContext& game,const HudSettings& settings,bool restoring) {
 if(activeWorld&&activeWorld!=game.world)ResetTargeting();activeWorld=game.world;
 if(settings.trajectory.on&&!restoring)TickGravity(game.world);
 TickOutlines(game,settings,restoring);TickTrajectory(game,settings,restoring);
}
void ResetTargeting() {
 ++searchGeneration;{std::lock_guard<std::mutex> lock(searchMutex);library=0;}
 trace={};trajectory={};activeWorld=0;meshes.clear();desired.clear();outlineBuffer=0;outlineTicket=0;outlineScan=0;gravityZ=-980;gravityChecked=0;
 RequestDebugger(DebuggerClient::Trajectory,false);RequestDebugger(DebuggerClient::TargetOutlines,false);
 trajectoryStatus=outlineStatus="off";
}
void FlushTargeting(unsigned long timeoutMs) {
 auto until=GetTickCount64()+timeoutMs;
 while((!meshes.empty()||trace.pending)&&GetTickCount64()<until) {
  TickTargeting(ReadContext(),HudSettings{},true);TickDebugger();Sleep(1);
 }
}
const TrajectoryData& Trajectory() {return trajectory;}
const char* TrajectoryStatus() {return trajectoryStatus.c_str();}
const char* OutlineStatus() {return outlineStatus.c_str();}
}
