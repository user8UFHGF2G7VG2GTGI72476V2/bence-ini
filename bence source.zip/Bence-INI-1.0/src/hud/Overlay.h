#pragma once
#include <windows.h>

// A see-through, click-through window laid over ARK's window. It draws the HUD tab's crosshair, info display
// and HP bars. It only shows while ARK (or this menu) is the active window, and needs ARK in windowed or
// borderless mode: nothing can draw over exclusive fullscreen.
namespace wintek {

void CreateOverlay(HWND menuWindow);
void TickOverlay();  // main thread, every loop; redraws about 30 times a second
void DestroyOverlay();

}  // namespace wintek
