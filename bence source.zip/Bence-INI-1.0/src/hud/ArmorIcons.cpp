#include "hud/ArmorIcons.h"
#include "hud/ArmorIconData.h"
#include "hud/GameInfo.h"
#include <windows.h>
#include <wincodec.h>
#include <cctype>
#include <memory>
#include <unordered_map>
#include <vector>

namespace wintek {

namespace {

std::string Upper(std::string s) {
  for (char& ch : s) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
  return s;
}

// Lower-case runs of letters, dropping one-letter noise and "and" ("Heavy Miner's Helmet" -> heavy, miner, helmet).
std::vector<std::string> Tokens(const std::string& name) {
  std::vector<std::string> out;
  std::string current;
  auto flush = [&] {
    if (current.size() > 1 && current != "and") out.push_back(current);
    current.clear();
  };
  for (char ch : name) {
    if (std::isalpha(static_cast<unsigned char>(ch))) current += static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    else flush();
  }
  flush();
  return out;
}

int MatchIcon(const std::string& className, int slot) {
  // The class's tokens, plus "flak" for any metal token: the game's Metal armor is the Flak set in the icon pack.
  std::vector<std::string> classTokens;
  for (const std::string& t : Tokens(className)) {
    classTokens.push_back(t);
    if (t.find("metal") != std::string::npos) classTokens.push_back("flak");
  }
  if (classTokens.empty()) return -1;

  int best = -1, bestScore = 0, bestExact = 0;
  for (int i = 0; i < armoricons::kIconCount; ++i) {
    const std::string iconName = armoricons::kIcons[i].name;
    if (ArmorSlotFromName(iconName) != slot) continue;
    int score = 0, exact = 0;
    for (const std::string& n : Tokens(iconName)) {
      if (ArmorSlotFromName(n) >= 0) continue;  // slot words ("helmet") don't say which set it is
      for (const std::string& c : classTokens) {
        if (n == c) {
          score += 2;
          ++exact;
          break;
        }
        if (c.find(n) != std::string::npos || n.find(c) != std::string::npos) {
          score += 1;
          break;
        }
        std::size_t common = 0;  // wood / wooden, miner / miners
        while (common < n.size() && common < c.size() && n[common] == c[common]) ++common;
        if (common >= 4) {
          score += 1;
          break;
        }
      }
    }
    if (score > bestScore || (score == bestScore && score > 0 && exact > bestExact)) {
      bestScore = score;
      bestExact = exact;
      best = i;
    }
  }
  return best;
}

std::vector<std::uint32_t> Decode(const unsigned char* png, std::size_t size) {
  std::vector<std::uint32_t> pixels;
  CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  IWICImagingFactory* factory = nullptr;
  IWICStream* stream = nullptr;
  IWICBitmapDecoder* decoder = nullptr;
  IWICBitmapFrameDecode* frame = nullptr;
  IWICFormatConverter* converter = nullptr;
  UINT w = 0, h = 0;
  if (SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory))) &&
      SUCCEEDED(factory->CreateStream(&stream)) &&
      SUCCEEDED(stream->InitializeFromMemory(const_cast<BYTE*>(png), static_cast<DWORD>(size))) &&
      SUCCEEDED(factory->CreateDecoderFromStream(stream, nullptr, WICDecodeMetadataCacheOnLoad, &decoder)) &&
      SUCCEEDED(decoder->GetFrame(0, &frame)) && SUCCEEDED(factory->CreateFormatConverter(&converter)) &&
      SUCCEEDED(converter->Initialize(frame, GUID_WICPixelFormat32bppPBGRA, WICBitmapDitherTypeNone, nullptr, 0.0,
                                      WICBitmapPaletteTypeCustom)) &&
      SUCCEEDED(converter->GetSize(&w, &h)) && w == kArmorIconSize && h == kArmorIconSize) {
    pixels.resize(static_cast<std::size_t>(w) * h);
    if (FAILED(converter->CopyPixels(nullptr, w * 4, static_cast<UINT>(pixels.size() * 4), reinterpret_cast<BYTE*>(pixels.data()))))
      pixels.clear();
  }
  for (IUnknown* p : { static_cast<IUnknown*>(converter), static_cast<IUnknown*>(frame), static_cast<IUnknown*>(decoder),
                       static_cast<IUnknown*>(stream), static_cast<IUnknown*>(factory) })
    if (p) p->Release();
  return pixels;
}

}  // namespace

int ArmorSlotFromName(const std::string& name) {
  static const char* const kWords[kArmorSlots][6] = {
    { "SHIELD", "", "", "", "", "" },  // first, so a shield never lands in another slot
    { "HELMET", "HAT", "CAP", "MASK", "GOGGLE", "HEAD" },
    { "CHESTPIECE", "CHEST", "SHIRT", "TANK", "BODY", "" },
    { "GAUNTLET", "GLOVE", "", "", "", "" },
    { "LEGGING", "PANT", "", "", "", "" },
    { "BOOT", "FLIPPER", "", "", "", "" },
  };
  static const int kSlotFor[kArmorSlots] = { kShield, kHelmet, kChest, kGauntlets, kLeggings, kBoots };
  const std::string upper = Upper(name);
  for (int group = 0; group < kArmorSlots; ++group)
    for (const char* word : kWords[group])
      if (word[0] && upper.find(word) != std::string::npos) return kSlotFor[group];
  return -1;
}

int ArmorIconFor(const std::string& className, int slot) {
  static std::unordered_map<std::string, int> cache;
  const std::string key = className + "#" + std::to_string(slot);
  auto it = cache.find(key);
  if (it == cache.end()) it = cache.emplace(key, MatchIcon(className, slot)).first;
  return it->second;
}

const std::uint32_t* ArmorIconPixels(int icon) {
  static std::unordered_map<int, std::vector<std::uint32_t>> decoded;
  if (icon < 0 || icon >= armoricons::kIconCount) return nullptr;
  auto it = decoded.find(icon);
  if (it == decoded.end()) it = decoded.emplace(icon, Decode(armoricons::kIcons[icon].png, armoricons::kIcons[icon].size)).first;
  return it->second.empty() ? nullptr : it->second.data();
}

}  // namespace wintek
