#include "hud/Spyglass.h"
#include "hud/AimTarget.h"
#include "misc/AutoMating.h"
#include "core/Diagnostics.h"
#include "core/Process.h"
#include "core/Settings.h"
#include "engine/Debugger.h"
#include "engine/Signatures.h"
#include "misc/SnapMath.h"
#include "core/GameWindow.h"
#include "ui/Hotkeys.h"
#include <windows.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <mutex>
#include <thread>
#include <vector>

namespace wintek {

namespace {

constexpr ULONGLONG kLingerMs = 5000;   // the panel stays this long after you look away
constexpr std::int32_t kFirstPlayerTeam = 50000;  // teams below this are wild
constexpr std::int32_t kTeamFallback = 0x0230;     // AActor::TargetingTeam on the Store build
constexpr std::size_t kSerialAt = 0x08;            // FUObjectItem::SerialNumber

struct SnapAnchor { float position[3] = {}; float yaw = 0; };
struct SnapRequest {
  Address controller = 0, function = 0;
  int locationAt = -1, rotationAt = -1, snappedAt = -1, attachedAt = -1, dinoAt = -1;
  int structureIndexAt=-1, structureIndex=-1;
  unsigned char snappedMask = 0;
  bool vaultDock=false;
  float vaultGap=2;
  SnapFootprint footprint;
  int spacing = 100, angle = 90;
  ULONGLONG updatedAt = 0;
  Address placer=0, preview=0, previewFunction=0, previewParams=0;
  int previewLocationAt=-1, previewRotationAt=-1, previewResultAt=-1;
  unsigned char previewResultMask=0;
  std::vector<SnapAnchor> anchors;
};
std::mutex g_snapMutex;
SnapRequest g_snapRequest;
std::string g_snapStatus = "off";
Address g_snapHook = 0;
bool g_snapSearched = false;
std::atomic<unsigned int> g_snapApplied{0};
float g_snapGuide[3] = {};
bool g_snapGuideValid = false;
Address g_autoSnapParams=0;
std::uint64_t g_autoSnapTicket=0;
int g_autoSnapResultAt=-1;
unsigned char g_autoSnapResultMask=0;
std::atomic<unsigned int> g_previewOk{0},g_previewFailed{0};
struct BoundsQuery {
  Address params=0,actor=0,cls=0;
  std::uint64_t ticket=0;
  int originAt=-1,extentAt=-1,mode=0;
  Address mesh=0;
  float position[3]={},yaw=0;
} g_boundsQuery;
std::unordered_map<Address,SnapFootprint> g_vaultFootprints;
std::unordered_map<Address,int> g_vaultBoundsStage;
std::unordered_map<Address,ULONGLONG> g_vaultRetryAt;

bool SnapToNearest(const SnapRequest&,float[3],float[3]);

void UpdateAutoSnapPreview(std::uintptr_t) {
  std::lock_guard<std::mutex> lock(g_snapMutex);
  const auto& r=g_snapRequest;
  if (!r.previewFunction || !r.previewParams || GetTickCount64()-r.updatedAt>250 ||
      Read<Address>(r.placer+0x498)!=r.preview || Read<unsigned char>(r.placer+0x490)!=2 ||
      (g_autoSnapTicket && CompletedCalls()<g_autoSnapTicket)) return;
  if (g_autoSnapTicket) {
    const bool result=g_autoSnapResultAt>=0 && (Read<unsigned char>(r.previewParams+g_autoSnapResultAt)&g_autoSnapResultMask);
    if(result) ++g_previewOk; else ++g_previewFailed;
    g_autoSnapTicket=0;
  }
  float position[3],rotation[3];
  // Read the game's unsnapped placement inputs. Never overwrite these caches.
  if (!g_memory.ReadRaw(r.placer+0x514,position,sizeof(position)) ||
      !g_memory.ReadRaw(r.placer+0x504,rotation,sizeof(rotation)) ||
      !SnapToNearest(r,position,rotation)) return;
  unsigned char parameters[128]={};
  std::memcpy(parameters+r.previewLocationAt,position,12);
  std::memcpy(parameters+r.previewRotationAt,rotation,12);
  if (!g_memory.WriteRaw(r.previewParams,parameters,sizeof(parameters))) return;
  g_autoSnapResultAt=r.previewResultAt; g_autoSnapResultMask=r.previewResultMask;
  g_autoSnapTicket=QueueProcessEvent(r.preview,r.previewFunction,r.previewParams);
}

bool SnapToNearest(const SnapRequest& request, float pos[3], float rot[3]) {
  const SnapAnchor* pick = nullptr;
  float nearest = 1000.0f*1000.0f;
  for (const auto& a : request.anchors) {
    const float dx=pos[0]-a.position[0], dy=pos[1]-a.position[1], dz=pos[2]-a.position[2];
    const float distance=dx*dx+dy*dy+dz*dz;
    if (std::isfinite(distance) && distance < nearest) { nearest=distance; pick=&a; }
  }
  if(!pick) return false;
  return request.vaultDock ? DockVault(pos,rot,pick->position,pick->yaw,request.footprint,request.footprint,request.vaultGap) :
    AlignSnapGrid(pos,rot,pick->position,pick->yaw,request.spacing,request.angle);
}

// UNetDriver::ProcessRemoteFunction: driver, actor, function, parameter buffer.
// Changes only the two transform fields of a normal unsnapped placement request.
void OnSnapRequest(std::uintptr_t, std::uintptr_t actor, std::uintptr_t function, std::uintptr_t params) {
  ObserveMatingRequest(actor,function,params);
  std::lock_guard<std::mutex> lock(g_snapMutex);
  const auto& request=g_snapRequest;
  if (!request.function || actor != request.controller || function != request.function || !params ||
      GetTickCount64()-request.updatedAt > 250) return;
  if (request.structureIndexAt<0 || Read<int>(params+request.structureIndexAt)!=request.structureIndex) return;
  if ((Read<unsigned char>(params+request.snappedAt)&request.snappedMask) ||
      Read<Address>(params+request.attachedAt) || Read<Address>(params+request.dinoAt)) return;
  float position[3],rotation[3];
  if (!g_memory.ReadRaw(params+request.locationAt,position,sizeof(position)) ||
      !g_memory.ReadRaw(params+request.rotationAt,rotation,sizeof(rotation))) return;
  if (!SnapToNearest(request,position,rotation)) return;
  unsigned char original[128] = {}, replacement[128] = {};
  const int start=(std::min)(request.locationAt,request.rotationAt);
  const int end=(std::max)(request.locationAt+12,request.rotationAt+12);
  if (end-start > 128 || !g_memory.ReadRaw(params+start,original,end-start)) return;
  std::memcpy(replacement,original,end-start);
  std::memcpy(replacement+request.locationAt-start,position,12);
  std::memcpy(replacement+request.rotationAt-start,rotation,12);
  if (g_memory.WriteRaw(params+start,replacement,end-start)) ++g_snapApplied;
}

void OnPlacementThunk(std::uintptr_t actor,std::uintptr_t frame,std::uintptr_t,std::uintptr_t) {
  Address function=0;
  { std::lock_guard<std::mutex> lock(g_snapMutex); function=g_snapRequest.function; }
  if(!function || !frame) return;
  const Address params=FrameLocals(frame,function);
  if(params) OnSnapRequest(0,actor,function,params);
}

SpyglassData g_data;
std::vector<CorruptedDinoMarker> g_corrupted;
std::vector<PlayerJokeMarker> g_playerJokes;
std::unordered_map<Address, bool> g_corruptedClasses;

struct {
  std::int32_t index = 0, serial = 0;  // the actor being shown
  ULONGLONG seenAt = 0;
} g_target;
ObjectRef g_locked;int g_lockSerial=0;Address g_spyWorld=0;

std::unordered_map<Address, std::int32_t> g_offsets;  // (class ^ hash(name)) -> offset
std::int32_t Offset(Address cls, const char* name) {
  const Address key = cls ^ (std::hash<std::string>{}(name) << 1);
  auto it = g_offsets.find(key);
  if (it == g_offsets.end()) it = g_offsets.emplace(key, PropertyOffset(cls, name)).first;
  return it->second;
}

template <typename T>
bool ReadField(Address object, const char* name, T& out) {
  if (!object) return false;
  const std::int32_t offset = Offset(ClassOf(object), name);
  if (!offset) return false;
  out = Read<T>(object + offset);
  return true;
}

float ReadFloat(Address object, const char* name, float fallback = 0.0f) {
  float v = fallback;
  return ReadField(object, name, v) && std::isfinite(v) ? v : fallback;
}

Address ReadObject(Address object, const char* name) {
  Address v = 0;
  return ReadField(object, name, v) ? v : 0;
}

bool ReadBool(Address object, const char* name) {
  static std::unordered_map<std::string, BoolProperty> props;
  auto it = props.find(name);
  if (it == props.end()) it = props.emplace(name, BoolProperty(name)).first;
  return it->second.Get(object);
}

std::wstring ReadString(Address object, const char* name) {
  TArray text{};
  if (!ReadField(object, name, text) || !text.data || text.count <= 1 || text.count > 128) return {};
  std::wstring out(static_cast<std::size_t>(text.count - 1), L'\0');
  if (!g_memory.ReadRaw(text.data, out.data(), out.size() * sizeof(wchar_t))) return {};
  return out;
}

// "Raptor_Character_BP_C" -> "Raptor"
std::wstring SpeciesOf(Address cls) {
  std::string name = NameOf(cls);
  const std::size_t cut = name.find('_');
  if (cut != std::string::npos && cut > 0) name.resize(cut);
  return std::wstring(name.begin(), name.end());
}

// An object by GObjects index. The serial number is only used as a tie-breaker: the item layout (where the
// serial sits) isn't confirmed for this build, so an index whose object still reports that same index is enough.
Address Resolve(std::int32_t index, std::int32_t serial) {
  using namespace offsets;
  if (index <= 0) return 0;
  const Address chunks = Read<Address>(GObjects());
  const Address chunk = chunks ? Read<Address>(chunks + (index / kObjectsPerChunk) * sizeof(Address)) : 0;
  if (!chunk) return 0;
  const Address entry=chunk+(index%kObjectsPerChunk)*kObjectItemSize;
  if(serial&&Read<int>(entry+kSerialAt)!=serial)return 0;
  const Address object = Read<Address>(entry);
  if (!object || Read<std::int32_t>(object + object::kIndex) != index) return 0;
  const std::uint32_t flags = Read<std::uint32_t>(object + object::kFlags);
  return (flags & (0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000)) ? 0 : object;  // on its way out
}

std::int32_t TeamOf(Address actor) {
  const std::int32_t offset = Offset(ClassOf(actor), "TargetingTeam");
  return Read<std::int32_t>(actor + (offset ? offset : kTeamFallback));
}

bool LocationOf(Address actor, float out[3]) {
  const Address root = ReadObject(actor, "RootComponent");
  const std::int32_t offset = root ? Offset(ClassOf(root), "RelativeLocation") : 0;
  return offset && g_memory.ReadRaw(root + offset, out, 3 * sizeof(float));
}

Address g_lastWild = 0;

int SerialOf(Address object){int index=Read<int>(object+offsets::object::kIndex);if(index<0)return 0;Address chunks=Read<Address>(GObjects()),chunk=chunks?Read<Address>(chunks+(index/offsets::kObjectsPerChunk)*8):0;return chunk?Read<int>(chunk+(index%offsets::kObjectsPerChunk)*offsets::kObjectItemSize+kSerialAt):0;}
double NetworkTime(Address world){Address state=ReadObject(world,"GameState");if(!state)return 0;int at=Offset(ClassOf(state),"NetworkTime");if(!at)at=Offset(ClassOf(state),"ReplicatedNetworkTime");if(!at&&IsA(ClassOf(state),"ShooterGameState"))at=0x598;double t=at?Read<double>(state+at):0;return std::isfinite(t)&&t>0?t:0;}
void ExtraTarget(Address actor,Address world){auto& d=g_data;d.tribe=ReadString(actor,"TribeName");if(d.tribe.empty())d.tribe=ReadString(actor,"OwnerName");double now=NetworkTime(world);for(const char* key:{"CorpseDestructionTime","NetDestructionTime"}){int at=Offset(ClassOf(actor),key);if(!at)continue;double t=Read<double>(actor+at);if(now>0&&std::isfinite(t)&&t>now&&t-now<86400)d.decaySec=t-now;}int at=Offset(ClassOf(actor),"LastInAllyRangeTime");if(at&&now>0){double t=Read<double>(actor+at);if(std::isfinite(t)&&t>0&&t<=now&&now-t<5184000)d.offlineSec=now-t;}}
void ReadPlayer(Address actor){auto& d=g_data;d.kind=SpyglassData::Player;d.name=ReadString(actor,"PlayerName");if(d.name.empty())d.name=L"Player";d.dead=ReadBool(actor,"bIsDead");d.knockedOut=ReadBool(actor,"bIsSleeping");d.health=ReadFloat(actor,"ReplicatedCurrentHealth");d.maxHealth=ReadFloat(actor,"ReplicatedMaxHealth");d.torpor=ReadFloat(actor,"ReplicatedCurrentTorpor");d.maxTorpor=ReadFloat(actor,"ReplicatedMaxTorpor");Address weapon=ReadObject(actor,"CurrentWeapon");if(weapon){Address item=ReadObject(weapon,"AssociatedPrimalItem");if(item)d.heldItem=ReadString(item,"DescriptiveNameBase");if(d.heldItem.empty())d.heldItem=SpeciesOf(ClassOf(weapon));}Address status=ReadObject(actor,"MyCharacterStatusComponent");int base=0;unsigned short extra=0;if(ReadField(status,"BaseCharacterLevel",base)&&ReadField(status,"ExtraCharacterLevel",extra)&&base>0&&base<100000)d.level=base+extra;}
void ReadDino(Address dino, bool wild) {
  SpyglassData& d = g_data;
  d.kind = wild ? SpyglassData::WildDino : SpyglassData::OwnDino;
  int colorsAt=Offset(ClassOf(dino),"ColorSetIndices");if(!colorsAt)colorsAt=0x15f0;
  d.hasColors=g_memory.ReadRaw(dino+colorsAt,d.colors,6);
  d.species = SpeciesOf(ClassOf(dino));
  d.name = d.species;
  d.female = ReadBool(dino, "bIsFemale");
  d.dead = ReadBool(dino, "bIsDead");
  d.knockedOut = !d.dead && ReadBool(dino, "bIsSleeping");
  d.health = ReadFloat(dino, "ReplicatedCurrentHealth");
  d.maxHealth = ReadFloat(dino, "ReplicatedMaxHealth");
  d.torpor = ReadFloat(dino, "ReplicatedCurrentTorpor");
  d.maxTorpor = ReadFloat(dino, "ReplicatedMaxTorpor");

  if (const Address status = ReadObject(dino, "MyCharacterStatusComponent")) {
    std::int32_t base = 0;
    std::uint16_t extra = 0;
    ReadField(status, "BaseCharacterLevel", base);
    ReadField(status, "ExtraCharacterLevel", extra);
    if (base > 0 && base < 100000) {
      d.baseLevel = base;
      d.extraLevel = extra;
      d.level = base + extra;
    }
    if(!wild){int at=Offset(ClassOf(status),"NumberOfLevelUpPointsAppliedTamed");unsigned char points[12]{};if(at&&g_memory.ReadRaw(status+at,points,12)){d.hasTamedPoints=true;for(int i=0;i<12;++i)d.tamedPoints[i]=points[i];}
      at=Offset(ClassOf(status),"NumberOfLevelUpPointsApplied");if(at&&g_memory.ReadRaw(status+at,points,12)){d.hasWildPoints=true;for(int i=0;i<12;++i)d.wildPoints[i]=points[i];}}
    if (!wild) {
      const float imprint = ReadFloat(status, "DinoImprintingQuality", -1.0f);
      if (imprint > 0.0f && imprint <= 1.5f) d.imprint = imprint;
      const std::int32_t maxAt = Offset(ClassOf(status), "MaxStatusValues");
      if (maxAt) {
        float max[12] = {};
        if (g_memory.ReadRaw(status + maxAt, max, sizeof(max))) {
          d.stamina = max[1];
          d.oxygen = max[3];
          d.food = max[4];
          d.weight = max[7];
          d.melee = (1.0f + max[8]) * 100.0f;  // melee and speed are stored as bonuses over 100%
          d.speed = (1.0f + max[9]) * 100.0f;
          d.hasStats = std::isfinite(d.stamina) && d.stamina > 0.0f && d.weight > 0.0f;
        }
      }
    }
  }

  if (wild) {
    // The level-up points each stat rolled (the wild dino's levels, spread over its stats), one byte per stat.
    if (const Address status = ReadObject(dino, "MyCharacterStatusComponent")) {
      const std::int32_t pointsAt = Offset(ClassOf(status), "NumberOfLevelUpPointsApplied");
      std::uint8_t points[12] = {};
      if (pointsAt && g_memory.ReadRaw(status + pointsAt, points, sizeof(points))) {
        int total = 0;
        for (int i = 0; i < 12; ++i) total += d.wildPoints[i] = points[i];
        // Sanity: the points add up to about the dino's level (wild dinos start at level 1).
        d.hasWildPoints = total > 0 && (d.level <= 0 || total <= d.level + 2);
      }
    }
    // Taming progress on a knocked-out wild dino, and effectiveness = 1 / (1 + ineffectiveness).
    if (d.knockedOut) {
      const float need = ReadFloat(dino, "RequiredTameAffinity"), have = ReadFloat(dino, "CurrentTameAffinity");
      if (need > 0.0f && have >= 0.0f) d.tameProgress = std::clamp(have / need, 0.0f, 1.0f);
      const float ineff = ReadFloat(dino, "TameIneffectivenessModifier", -1.0f);
      if (ineff >= 0.0f && d.tameProgress >= 0.0f) d.tameEffectiveness = 1.0f / (1.0f + ineff);
    }
    return;
  }

  const std::wstring tamedName = ReadString(dino, "TamedName");
  if (!tamedName.empty()) d.name = tamedName;
  d.tamer = ReadString(dino, "TamerString");
  d.neutered = ReadBool(dino, "bNeutered");
  std::int32_t m = -1, f = -1;
  if (ReadField(dino, "RandomMutationsMale", m) && m >= 0 && m < 10000) d.mutationsMale = m;
  if (ReadField(dino, "RandomMutationsFemale", f) && f >= 0 && f < 10000) d.mutationsFemale = f;
  const float age = ReadFloat(dino, "BabyAge", -1.0f);
  if (age >= 0.0f && age < 1.0f) d.babyAge = age;
}

void ReadStructure(Address structure) {
  SpyglassData& d = g_data;
  d.kind = SpyglassData::OwnStructure;
  d.name = ReadString(structure, "DescriptiveName");
  if (d.name.empty()) d.name = SpeciesOf(ClassOf(structure));
  d.health = ReadFloat(structure, "ReplicatedHealth",ReadFloat(structure,"Health"));
  d.maxHealth = ReadFloat(structure, "MaxHealth");
  std::int32_t items = -1;
  if (ReadField(structure, "CurrentItemCount", items) && items >= 0 && items < 100000) d.items = items;
  d.locked = ReadBool(structure, "bIsLocked");
}

// ------------------------------------------------------------------ long-range aim
// ARK's own HUD target only reaches a few metres, so for range the spyglass aims by itself: the direction you're
// looking (the controller's ControlRotation) from your eye, against every dino and every one of your tribe's
// structures in the world, found by a background scan. The nearest one close enough to that line wins.
// Walls don't block this aim (it has no line-of-sight test), unlike the game's own target.
constexpr DWORD kScanMs = 2500;
constexpr float kEyeHeightCm = 60.0f;
constexpr float kDinoReachCm = 350.0f;       // how far off the aim line a dino can be and still count
constexpr float kStructureReachCm = 200.0f;

struct StructureSpot {
  ObjectRef ref;
  float pos[3];
};

struct {
  std::vector<ObjectRef> dinos;
  std::vector<StructureSpot> structures;  // your tribe's, with their (fixed) positions
  std::int32_t team = 0;                  // the team the structures were collected for
  DWORD scannedAt = 0;
  std::mutex mutex;
  std::vector<ObjectRef> foundDinos;
  std::vector<StructureSpot> foundStructures;
  bool foundReady = false;
  std::atomic<bool> scanning{ false };
} g_scan;

void Scan(std::uint32_t generation, std::int32_t myTeam) {
  using namespace offsets;
  Reflection reflection;
  enum Kind { kOther, kDino, kStructure };
  std::unordered_map<Address, Kind> kinds;
  std::unordered_map<Address, std::int32_t> teamAt, rootAt, locationAt;
  auto cached = [&](std::unordered_map<Address, std::int32_t>& cache, Address cls, const char* name) {
    auto it = cache.find(cls);
    if (it == cache.end()) it = cache.emplace(cls, reflection.PropertyOffset(cls, name)).first;
    return it->second;
  };
  std::vector<ObjectRef> dinos;
  std::vector<StructureSpot> structures;
  ForEachObject([&](Address object, std::int32_t index) {
    if (g_scanGeneration != generation) return false;
    std::uint8_t header[0x28];
    if (!g_memory.ReadRaw(object, header, sizeof(header))) return true;
    std::uint32_t flags;
    Address cls, outer;
    std::memcpy(&flags, header + object::kFlags, sizeof(flags));
    std::memcpy(&cls, header + object::kClass, sizeof(cls));
    std::memcpy(&outer, header + object::kOuter, sizeof(outer));
    if (!cls || !outer || (flags & (0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000))) return true;
    auto kind = kinds.find(cls);
    if (kind == kinds.end())
      kind = kinds.emplace(cls, (reflection.IsA(cls, "PrimalDinoCharacter")||reflection.IsA(cls,"ShooterCharacter")||reflection.NameOf(cls).find("DeathItemCache")!=std::string::npos) ? kDino
                                : reflection.IsA(cls, "PrimalStructure")    ? kStructure
                                                                             : kOther).first;
    if (kind->second == kOther || reflection.NameOf(ClassOf(outer)) != "Level") return true;
    if (kind->second == kDino) {
      dinos.push_back({ object, index });
      return true;
    }
    const std::int32_t t = cached(teamAt, cls, "TargetingTeam");

    const std::int32_t r = cached(rootAt, cls, "RootComponent");
    const Address root = r ? Read<Address>(object + r) : 0;
    const std::int32_t l = root ? cached(locationAt, ClassOf(root), "RelativeLocation") : 0;
    StructureSpot spot{ { object, index }, {} };
    if (l && g_memory.ReadRaw(root + l, spot.pos, sizeof(spot.pos))) structures.push_back(spot);
    return true;
  });
  {
    std::lock_guard<std::mutex> lock(g_scan.mutex);
    if (g_scanGeneration == generation) {
      g_scan.foundDinos = std::move(dinos);
      g_scan.foundStructures = std::move(structures);
      g_scan.foundReady = true;
    }
  }
  g_scan.scanning = false;
}

void TickScan(std::int32_t myTeam) {
  const DWORD now = GetTickCount();
  if (!g_scan.scanning && (!g_scan.scannedAt || now - g_scan.scannedAt >= kScanMs || myTeam != g_scan.team)) {
    g_scan.scannedAt = now;
    g_scan.team = myTeam;
    g_scan.scanning = true;
    std::thread(Scan, g_scanGeneration.load(), myTeam).detach();
  }
  std::lock_guard<std::mutex> lock(g_scan.mutex);
  if (g_scan.foundReady) {
    g_scan.foundReady = false;
    g_scan.dinos = std::move(g_scan.foundDinos);
    g_scan.structures = std::move(g_scan.foundStructures);
  }
}

// The thing nearest along your aim within `rangeCm`: wild dinos, your tribe's dinos and structures only.
Address PickByAim(const GameContext& game, float rangeCm, std::int32_t myTeam) {
  float eye[3];
  if (!game.controller || !LocationOf(game.pawn, eye)) return 0;
  eye[2] += kEyeHeightCm;
  const std::int32_t rotAt = Offset(ClassOf(game.controller), "ControlRotation");
  if (!rotAt) return 0;
  float rot[3];  // pitch, yaw, roll in degrees
  if (!g_memory.ReadRaw(game.controller + rotAt, rot, sizeof(rot))) return 0;
  const float pitch = rot[0] * 3.14159265f / 180.0f, yaw = rot[1] * 3.14159265f / 180.0f;
  const float dir[3] = { std::cos(pitch) * std::cos(yaw), std::cos(pitch) * std::sin(yaw), std::sin(pitch) };

  Address best = 0;
  float bestAlong = rangeCm;
  auto consider = [&](Address actor, const float pos[3], float reach) {
    const float v[3] = { pos[0] - eye[0], pos[1] - eye[1], pos[2] - eye[2] };
    const float along = v[0] * dir[0] + v[1] * dir[1] + v[2] * dir[2];
    if (along <= 50.0f || along >= bestAlong) return;
    const float off[3] = { v[0] - dir[0] * along, v[1] - dir[1] * along, v[2] - dir[2] * along };
    // A little more slack further out, where things look smaller.
    const float allowed = reach + along * 0.01f;
    if (off[0] * off[0] + off[1] * off[1] + off[2] * off[2] > allowed * allowed) return;
    best = actor;
    bestAlong = along;
  };
  for (const ObjectRef& d : g_scan.dinos) {
    if (!d.Alive() || d.object == game.pawn) continue;
    const std::int32_t team = TeamOf(d.object);

    float pos[3];
    if (LocationOf(d.object, pos)) consider(d.object, pos, kDinoReachCm);
  }
  for (const StructureSpot& st : g_scan.structures)
    if (st.ref.Alive()) consider(st.ref.object, st.pos, kStructureReachCm);
  return best;
}

}  // namespace

void TickSpyglass(const GameContext& game, bool wanted, float rangeM) {
  const ULONGLONG now = GetTickCount64();
  if(g_spyWorld!=game.world){g_spyWorld=game.world;g_locked={};g_target={};g_lockSerial=0;}
  if (!wanted || !game.pawn || !game.hud) {
    g_data = {};
    g_locked={};g_lockSerial=0;
    if (!game.world) g_target = {};
    g_diag.spyglass = wanted ? "not in game" : "off";
    return;
  }
  // Hidden while the inventory or another game screen is open.
  if (Read<Address>(game.hud + offsets::hud::kOpenInventory)) {
    g_data = {};
    return;
  }

  // ARK's own HUD target. It's a weak pointer (object index + serial) on most builds, a plain pointer on some.
  const Address field = MainReflection().FindField(ClassOf(game.hud), "LastTargetedActor");
  const std::int32_t at = Offset(ClassOf(game.hud), "LastTargetedActor");
  if (!field || !at) {
    g_data = {};
    g_diag.spyglass = "no HUD target field";
    return;
  }
  const bool weak = NameOf(ClassOf(field)).find("Weak") != std::string::npos;
  Address seen = 0;
  if (weak) {
    const std::int32_t index = Read<std::int32_t>(game.hud + at), serial = Read<std::int32_t>(game.hud + at + 4);
    seen = Resolve(index, serial);
    if (seen) {
      g_target.index = index;
      g_target.serial = serial;
    }
  } else {
    seen = Read<Address>(game.hud + at);
    if (seen) {
      g_target.index = Read<std::int32_t>(seen + offsets::object::kIndex);
      g_target.serial = SerialOf(seen);
    }
  }
  const std::int32_t myTeam = TeamOf(game.pawn);
  const float rangeCm = std::clamp(rangeM, 20.0f, 700.0f) * 100.0f;
  float me[3];
  const bool haveMe = LocationOf(game.pawn, me);
  auto inRange = [&](Address a) {
    float p[3];
    if (!haveMe || !LocationOf(a, p)) return true;
    const float dx = p[0] - me[0], dy = p[1] - me[1], dz = p[2] - me[2];
    return dx * dx + dy * dy + dz * dz <= rangeCm * rangeCm;
  };
  if(AimTarget().target.Alive()){seen=AimTarget().target.object;g_target.index=AimTarget().target.index;g_target.serial=SerialOf(seen);}
  if (seen && !inRange(seen)) seen = 0;
  // Nothing from ARK's short-range target: aim ourselves, out to the range set on the HUD tab.
  TickScan(myTeam);
  bool aimed = false;
  if (!seen) {
    if (const Address picked = PickByAim(game, rangeCm, myTeam)) {
      seen = picked;
      aimed = true;
      g_target.index = Read<std::int32_t>(picked + offsets::object::kIndex);
      g_target.serial = SerialOf(seen);
    }
  }
  if (seen) g_target.seenAt = now;
  Address actor = now - g_target.seenAt <= kLingerMs ? Resolve(g_target.index, g_target.serial) : 0;
  if(g_settings.hud.spyglass.on&&g_settings.hud.spyLockKey&&FindGameWindow(g_process.pid).IsActive(GetForegroundWindow())&&wintek::ui::ActionPressed(g_settings.hud.spyLockKey)){if(g_locked.object){g_locked={};g_lockSerial=0;}else if(actor){g_locked=ObjectRef::Of(actor);g_lockSerial=SerialOf(actor);}}
  if(g_locked.object){if(!g_locked.Alive()||Resolve(g_locked.index,g_lockSerial)!=g_locked.object||!inRange(g_locked.object)){g_locked={};g_lockSerial=0;}else actor=g_locked.object;}
  g_data = {};
  if (!actor || actor == game.pawn) {
    g_diag.spyglass = std::string(weak ? "weak" : "ptr") + " target: none (" + std::to_string(g_scan.dinos.size()) + " dinos, " +
                      std::to_string(g_scan.structures.size()) + " of your structures in range scan)";
    return;
  }

  const Address cls = ClassOf(actor);
  const std::int32_t team = TeamOf(actor), mine = TeamOf(game.pawn);
  const bool wild = team < kFirstPlayerTeam, own = mine >= kFirstPlayerTeam && team == mine;
  g_diag.spyglass = std::string(aimed ? "[aim] " : "[ark] ") + NameOf(cls) + " team " + std::to_string(team) + " / mine " + std::to_string(mine) +
                    (wild ? " (wild)" : own ? " (yours)" : " (other tribe)");

  if (IsA(cls, "PrimalDinoCharacter")) {
    ReadDino(actor, wild);
    if (wild) g_lastWild = actor;
  } else if(IsA(cls,"ShooterCharacter"))ReadPlayer(actor);
  else if(NameOf(cls).find("DeathItemCache")!=std::string::npos){ReadStructure(actor);g_data.kind=SpyglassData::Bag;}
  else if (IsA(cls, "PrimalStructure"))ReadStructure(actor);
  g_data.own=own;g_data.enemy=!wild&&!own;g_data.targetLocked=g_locked.object==actor&&actor;
  ExtraTarget(actor,game.world);
  if (g_data.kind == SpyglassData::None) return;

  float it[3];
  if (haveMe && LocationOf(actor, it)) {
    const float dx = it[0] - me[0], dy = it[1] - me[1], dz = it[2] - me[2];
    g_data.distanceM = std::sqrt(dx * dx + dy * dy + dz * dz) / 100.0f;
  }
}

void TickPenisEsp(const GameContext& game,bool wanted) {
  g_playerJokes.clear();
  if(!wanted||!game.world||!game.pawn)return;
  if(game.hud&&Read<Address>(game.hud+offsets::hud::kOpenInventory))return;
  float me[3];if(!LocationOf(game.pawn,me))return;
  if(!ReadBool(game.pawn,"bIsDead")) {
    PlayerJokeMarker local;
    std::copy(me,me+3,local.position);
    // The character root follows the capsule centre, near the pelvis, rather than the feet.
    // Keep the marker at the groin area instead of adding the old overhead-label offset.
    float scaleZ=1.0f;
    const Address root=ReadObject(game.pawn,"RootComponent");
    const int scaleAt=root ? Offset(ClassOf(root),"RelativeScale3D") : 0;
    if(scaleAt) {
      const float value=Read<float>(root+scaleAt+2*sizeof(float));
      if(std::isfinite(value)&&value>0&&value<=10)scaleZ=value;
    }
    local.position[2]-=10.0f*scaleZ;
    g_playerJokes.push_back(local);
  }

}

const std::vector<PlayerJokeMarker>& PenisEspMarkers() {return g_playerJokes;}

void TickCorruptedEsp(const GameContext& game, bool wanted, float rangeM) {
  g_corrupted.clear();
  g_diag.corruptedEsp = wanted ? "waiting for world / pawn" : "off";
  if (!wanted || !game.world || !game.pawn) return;
  if (game.hud && Read<Address>(game.hud + offsets::hud::kOpenInventory)) {
    g_diag.corruptedEsp = "paused: inventory open";
    return;
  }
  TickScan(TeamOf(game.pawn));
  float me[3];
  if (!LocationOf(game.pawn, me)) { g_diag.corruptedEsp = "cannot read player position"; return; }
  const float range = std::clamp(rangeM, 20.0f, 700.0f);
  int alive = 0, matched = 0, dead = 0, noPosition = 0, outside = 0;
  std::string examples;
  for (const ObjectRef& ref : g_scan.dinos) {
    if (!ref.Alive()) continue;
    ++alive;
    const std::string sample = NameOf(ClassOf(ref.object));
    if (examples.size() < 150 && examples.find(sample) == std::string::npos) {
      if (!examples.empty()) examples += ", ";
      examples += sample;
    }
    const Address actor = ref.object, cls = ClassOf(actor);
    auto match = g_corruptedClasses.find(cls);
    if (match == g_corruptedClasses.end()) {
      bool corrupted = false;
      // Inspect class ancestry, never an actor's editable display name.
      for (Address base = cls, depth = 0; base && depth < 64; ++depth) {
        if (ToLower(NameOf(base)).find("corrupt") != std::string::npos) { corrupted = true; break; }
        base = Read<Address>(base + offsets::reflection::kSuperStruct);
      }
      match = g_corruptedClasses.emplace(cls, corrupted).first;
    }
    if (!match->second) continue;
    ++matched;
    if (ReadBool(actor, "bIsDead")) { ++dead; continue; }
    CorruptedDinoMarker marker;
    if (!LocationOf(actor, marker.position)) { ++noPosition; continue; }
    const float dx = marker.position[0]-me[0], dy = marker.position[1]-me[1], dz = marker.position[2]-me[2];
    marker.distanceM = std::sqrt(dx*dx+dy*dy+dz*dz)/100.0f;
    if (!std::isfinite(marker.distanceM) || marker.distanceM > range) { ++outside; continue; }
    const std::string className = NameOf(cls);
    marker.name.assign(className.begin(), className.end());
    const auto suffix = marker.name.find(L"_Character");
    if (suffix != std::wstring::npos) marker.name.resize(suffix);
    g_corrupted.push_back(std::move(marker));
  }
  g_diag.corruptedClasses = examples.empty() ? "none" : examples;
  g_diag.corruptedEsp = std::to_string(g_scan.dinos.size()) + " scanned, " + std::to_string(alive) +
      " alive, " + std::to_string(matched) + " corrupted, " + std::to_string(g_corrupted.size()) + " markers; " +
      std::to_string(noPosition) + " no position, " + std::to_string(outside) + " outside range, " + std::to_string(dead) + " dead";
}

const std::vector<CorruptedDinoMarker>& CorruptedDinos() { return g_corrupted; }

Address VaultMesh(Address actor) {
  const Address root=ReadObject(actor,"RootComponent");
  if(root && IsA(ClassOf(root),"StaticMeshComponent"))return root;
  for(const char* name:{"MyStaticMesh","StaticMeshComponent","Mesh","StaticMesh"}) {
    const Address value=ReadObject(actor,name);
    if(value && ObjectRef::Of(value).Alive() && IsA(ClassOf(value),"StaticMeshComponent"))return value;
  }
  for(Address cls=ClassOf(actor),depth=0;cls&&depth<48;++depth) {
    int count=0;
    for(Address f=Read<Address>(cls+offsets::reflection::kChildren);f&&count<8192;f=Read<Address>(f+offsets::reflection::kNext),++count) {
      if(NameOf(ClassOf(f))!="ObjectProperty")continue;
      const int at=Read<int>(f+offsets::reflection::kPropertyOffset);
      if(at<0x20||at>=0x8000)continue;
      const Address value=Read<Address>(actor+at);
      if(value&&ObjectRef::Of(value).Alive()&&IsA(ClassOf(value),"StaticMeshComponent"))return value;
    }
    cls=Read<Address>(cls+offsets::reflection::kSuperStruct);
  }
  return 0;
}

bool LocalVaultFootprint(Address actor,Address mesh,const float minimum[3],const float maximum[3],SnapFootprint& out) {
  if(!actor||!mesh||!ObjectRef::Of(actor).Alive()||!ObjectRef::Of(mesh).Alive())return false;
  const Address root=ReadObject(actor,"RootComponent");
  if(!root)return false;
  std::vector<SnapLocalTransform> chain;
  Address component=mesh;
  for(int n=0;component!=root&&n<16;++n) {
    if(!component)return false;
    SnapLocalTransform transform;
    const Address cls=ClassOf(component);
    const int p=Offset(cls,"RelativeLocation"),r=Offset(cls,"RelativeRotation"),scale=Offset(cls,"RelativeScale3D");
    if(!p||!r||!scale||!g_memory.ReadRaw(component+p,transform.position,12)||
       !g_memory.ReadRaw(component+r,transform.rotation,12)||!g_memory.ReadRaw(component+scale,transform.scale,12))return false;
    chain.push_back(transform);
    const Address parent=ReadObject(component,"AttachParent");
    if(parent==component)return false;
    component=parent;
  }
  if(component!=root)return false;
  float scale[3];const int at=Offset(ClassOf(root),"RelativeScale3D");
  if(!at||!g_memory.ReadRaw(root+at,scale,12))return false;
  return FootprintFromLocalBox(minimum,maximum,chain.data(),static_cast<int>(chain.size()),scale,out);
}

void TickStructureSnap(const GameContext& game, const MiscSettings& settings, bool restoring) {
  const bool wanted=!restoring && (settings.structureSnap.on || settings.structureSnapOther.on);
  static bool callbackSet=false;
  if (!callbackSet) { SetFrameCallback(DebuggerClient::StructureSnap,UpdateAutoSnapPreview); callbackSet=true; }
  struct ClearIfNotPublished {
    bool published=false;
    ~ClearIfNotPublished() {
      if (!published) { std::lock_guard<std::mutex> lock(g_snapMutex); g_snapRequest={}; }
    }
  } publish;
  g_snapGuideValid=false;
  g_snapStatus=wanted ? "Waiting for placement" : "off";
  RequestDebugger(DebuggerClient::StructureSnap,wanted && game.pawn && game.world);
  const bool mating = !restoring && settings.autoMating.on;
  if ((!wanted && !mating) || !game.pawn || !game.world || !game.controller) { SetHookBreakpoint(1,0,nullptr); SetHookBreakpoint(2,0,nullptr); return; }
  if (!g_snapSearched) {
    g_snapSearched=true;
    g_snapHook=FindPatterns(g_process.base,{"48 85 ? 0F 84 ? ? ? ? 4C 89 ? ? ? 4C 89 ? ? ? 48 89"})[0];
  }

  if(g_snapHook) SetHookBreakpoint(1,g_snapHook,OnSnapRequest);
  if (!wanted) { SetHookBreakpoint(2,0,nullptr); return; }
  if (!DebuggerAttached()) { g_snapStatus=DebuggerError() ? DebuggerError() : "Attaching placement helper"; return; }
  if (game.hud && Read<Address>(game.hud+offsets::hud::kOpenInventory)) { g_snapStatus="Paused: inventory open"; return; }
  const int placerAt=Offset(ClassOf(game.controller),"StructurePlacer");
  const Address placer=placerAt ? Read<Address>(game.controller+placerAt) : 0;
  if (!placer || !ObjectRef::Of(placer).Alive()) return;
  const Address placerClass=ClassOf(placer);
  const int stateAt=Offset(placerClass,"CurrentState"), previewAt=Offset(placerClass,"CurrentPlacingStructure");
  if (!stateAt || !previewAt || Read<unsigned char>(placer+stateAt)!=2) return;
  const Address preview=Read<Address>(placer+previewAt);
  if (!preview || !ObjectRef::Of(preview).Alive()) { g_snapStatus="No live placement preview"; return; }
  // Never override the game's foundation/native snap-point placement.
  bool foundation=false;
  for (Address base=ClassOf(preview),depth=0; base && depth<64; ++depth) {
    if (ToLower(NameOf(base)).find("foundation")!=std::string::npos) { foundation=true; break; }
    base=Read<Address>(base+offsets::reflection::kSuperStruct);
  }
  const int snapPointsAt=Offset(ClassOf(preview),"SnapPoints");
  const TArray snapPoints=snapPointsAt ? Read<TArray>(preview+snapPointsAt) : TArray{};
  if (foundation || snapPoints.count>0) {
    g_snapStatus="Native snapping preserved: "+NameOf(ClassOf(preview)); return;
  }
  const bool turret=IsA(ClassOf(preview),"PrimalStructureTurret");
  bool vault=false;
  for (Address base=ClassOf(preview),depth=0; base && depth<64; ++depth) {
    const std::string name=ToLower(NameOf(base));
    if (name.find("vault")!=std::string::npos || name.find("storagebox_huge")!=std::string::npos) { vault=true; break; }
    base=Read<Address>(base+offsets::reflection::kSuperStruct);
  }
  if (!vault) {
    const std::wstring name=ReadString(preview,"DescriptiveName");
    vault=name.find(L"Vault")!=std::wstring::npos || name.find(L"vault")!=std::wstring::npos;
  }
  if (turret ? !settings.structureSnap.on :
      (!settings.structureSnapOther.on || (vault ? !settings.snapVaults : !settings.snapOtherStructures))) {
    g_snapStatus=std::string(turret ? "Turret Snap is off: " : "Structure Snap filter excludes: ")+NameOf(ClassOf(preview));
    return;
  }
  if (!IsA(ClassOf(preview),"PrimalStructure")) return;
  const int spacingCm=turret ? settings.snapSpacing : settings.structureSnapSpacing;
  const int angleDegrees=turret ? settings.snapAngle : settings.structureSnapAngle;
  SnapRequest request;
  request.vaultDock=vault;request.vaultGap=static_cast<float>(std::clamp(settings.vaultSnapGap,0,50));
  request.controller=game.controller;
  request.function=MainReflection().FindField(ClassOf(game.controller),"ServerRequestPlaceStructure");
  auto param=[&](const char* name,const char* type,int bytes)->int {
    const Address f=MainReflection().FindField(request.function,name);
    if (!f || NameOf(ClassOf(f))!=type) return -1;
    const int at=Read<int>(f+offsets::reflection::kPropertyOffset);
    return at>=0 && at+bytes<=128 ? at : -1;
  };
  if (!request.function) { g_snapStatus="Placement request function unavailable"; return; }
  request.structureIndexAt=param("StructureIndex","IntProperty",4);
  const int currentIndexAt=Offset(placerClass,"CurrentPlacingStructureIndex");
  request.structureIndex=currentIndexAt ? Read<int>(placer+currentIndexAt) : -1;
  if (request.structureIndexAt<0 || request.structureIndex<0) { g_snapStatus="Cannot match placement item index"; return; }
  request.locationAt=param("BuildLocation","StructProperty",12);
  request.rotationAt=param("BuildRotation","StructProperty",12);
  request.snappedAt=param("bSnapped","BoolProperty",1);
  request.attachedAt=param("AttachToPawn","ObjectProperty",8);
  request.dinoAt=param("DinoCharacter","ObjectProperty",8);
  const Address boolField=MainReflection().FindField(request.function,"bSnapped");
  if (boolField && request.snappedAt>=0) {
    request.snappedAt+=Read<unsigned char>(boolField+offsets::reflection::kBoolByteOffset);
    request.snappedMask=Read<unsigned char>(boolField+offsets::reflection::kBoolFieldMask);
  }
  if (request.locationAt<0 || request.rotationAt<0 || request.snappedAt<0 || request.snappedAt>=128 ||
      request.attachedAt<0 || request.dinoAt<0 || !request.snappedMask ||
      std::abs(request.locationAt-request.rotationAt)<12) { g_snapStatus="Unsupported placement parameter layout"; return; }
  request.spacing=std::clamp(spacingCm,10,600); request.angle=std::clamp(angleDegrees,5,90);
  const int team=TeamOf(game.pawn);
  if (team<kFirstPlayerTeam) { g_snapStatus="No tribe/team available"; return; }
  TickScan(team);
  const Address getter=MainReflection().FindField(placerClass,"GetLastPlacementProperties");
  const Address native=getter ? NativeOf(getter) : 0;
  unsigned char code[640]={};
  const unsigned char locLoad[]={0xF2,0x41,0x0F,0x10,0x86,0x14,0x05,0,0};
  const unsigned char rotLoad[]={0x0F,0x10,0x86,0x04,0x05,0,0};
  const bool validCache=stateAt==0x490 && previewAt==0x498 && native && g_memory.ReadRaw(native,code,sizeof(code)) &&
    std::search(std::begin(code),std::end(code),std::begin(locLoad),std::end(locLoad))!=std::end(code) &&
    std::search(std::begin(code),std::end(code),std::begin(rotLoad),std::end(rotLoad))!=std::end(code);
  float previewPosition[3];
  // The placement hit is a world position; a ghost's root can be relative to another component.
  const bool havePosition=validCache ? g_memory.ReadRaw(placer+0x514,previewPosition,sizeof(previewPosition)) : LocationOf(preview,previewPosition);
  if (!havePosition) { g_snapStatus="Cannot read placement position: "+NameOf(ClassOf(preview)); return; }
  for (int i=0;i<3;++i) if (!std::isfinite(previewPosition[i])) return;
  Address boundsActor=0; float boundsNearest=1000.0f*1000.0f;
  for (const auto& spot : g_scan.structures) {
    if(vault && ClassOf(spot.ref.object)!=ClassOf(preview)) continue;
    const float dx=spot.pos[0]-previewPosition[0], dy=spot.pos[1]-previewPosition[1], dz=spot.pos[2]-previewPosition[2];
    if (dx*dx+dy*dy+dz*dz>1500.0f*1500.0f) continue;
    if (!spot.ref.Alive() || spot.ref.object==preview || TeamOf(spot.ref.object)!=team) continue;
    const Address root=ReadObject(spot.ref.object,"RootComponent");
    const int at=root ? Offset(ClassOf(root),"RelativeRotation") : 0;
    float rot[3]; SnapAnchor anchor;
    if (!at || !g_memory.ReadRaw(root+at,rot,sizeof(rot)) || !LocationOf(spot.ref.object,anchor.position)) continue;
    if (!std::isfinite(rot[0]) || !std::isfinite(rot[1]) || !std::isfinite(rot[2]) || std::fabs(rot[0])>1 || std::fabs(rot[2])>1) continue;
    anchor.yaw=rot[1]; request.anchors.push_back(anchor);
    if(vault) {
      const float d=dx*dx+dy*dy+dz*dz;
      if(d<boundsNearest) { boundsNearest=d;boundsActor=spot.ref.object; }
    }
  }
  if (request.anchors.empty()) { g_snapStatus=vault ? "No matching owned vault nearby; place the first vault normally" : "No eligible tribe anchor near preview"; return; }
  if(vault) {
    const Address previewClass=ClassOf(preview);
    if(g_boundsQuery.ticket && CompletedCalls()>=g_boundsQuery.ticket) {
      float first[3],second[3];SnapFootprint footprint;
      const bool read=g_memory.ReadRaw(g_boundsQuery.params+g_boundsQuery.originAt,first,sizeof(first)) &&
        g_memory.ReadRaw(g_boundsQuery.params+g_boundsQuery.extentAt,second,sizeof(second));
      const bool measured=read && (g_boundsQuery.mode==2 ?
        LocalVaultFootprint(g_boundsQuery.actor,g_boundsQuery.mesh,first,second,footprint) :
        FootprintFromWorldBounds(g_boundsQuery.position,g_boundsQuery.yaw,first,second,footprint));
      if(measured) {g_vaultFootprints[g_boundsQuery.cls]=footprint;g_vaultBoundsStage.erase(g_boundsQuery.cls);}
      else {
        g_vaultBoundsStage[g_boundsQuery.cls]=g_boundsQuery.mode+1;
        if(g_boundsQuery.mode==2)g_vaultRetryAt[g_boundsQuery.cls]=GetTickCount64()+5000;
      }
      g_boundsQuery.ticket=0;
    }
    const auto found=g_vaultFootprints.find(previewClass);
    if(found==g_vaultFootprints.end()) {
      if(g_boundsQuery.ticket) {g_snapStatus="Measuring vault bounds...";return;}
      int stage=g_vaultBoundsStage[previewClass];
      if(stage>=3) {
        if(GetTickCount64()<g_vaultRetryAt[previewClass]) {g_snapStatus="Vault bounds unavailable; retrying automatically";return;}
        g_vaultBoundsStage[previewClass]=0;stage=0;
      }
      if(!boundsActor) {g_snapStatus="No matching owned vault within 10 m";return;}
      const Address root=ReadObject(boundsActor,"RootComponent");
      float rotation[3];const int rotationAt=root ? Offset(ClassOf(root),"RelativeRotation") : 0;
      if(!rotationAt||!g_memory.ReadRaw(root+rotationAt,rotation,sizeof(rotation))||
         !LocationOf(boundsActor,g_boundsQuery.position)) {g_snapStatus="Cannot read vault transform";return;}
      if(stage<2 && std::fabs(std::cos(rotation[1]*3.14159265359f/90.0f))<0.1f) {
        stage=2;g_vaultBoundsStage[previewClass]=2;
      }
      const Address mesh=stage==2 ? VaultMesh(boundsActor) : 0;
      const Address target=stage==2 ? mesh : boundsActor;
      const Address fn=target ? MainReflection().FindField(ClassOf(target),stage==2 ? "GetLocalBounds" : "GetActorBounds") : 0;
      auto at=[&](const char* name,const char* type,int size)->int {
        const Address f=fn ? MainReflection().FindField(fn,name) : 0;
        if(!f || NameOf(ClassOf(f))!=type)return -1;
        const int offset=Read<int>(f+offsets::reflection::kPropertyOffset);
        return offset>=0 && offset+size<=128 ? offset : -1;
      };
      const int origin=at(stage==2 ? "Min" : "Origin","StructProperty",12);
      const int extent=at(stage==2 ? "Max" : "BoxExtent","StructProperty",12);
      const int collide=stage==2 ? -1 : at("bOnlyCollidingComponents","BoolProperty",1);
      if(!fn||origin<0||extent<0||(stage!=2&&collide<0)) {
        g_vaultBoundsStage[previewClass]=stage+1;
        if(stage==2)g_vaultRetryAt[previewClass]=GetTickCount64()+5000;
        g_snapStatus=stage==2 ? "Local vault bounds function unavailable; will retry" : "Trying an alternate vault measurement";
        return;
      }
      if(!g_boundsQuery.params)g_boundsQuery.params=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,128,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
      if(!g_boundsQuery.params){g_snapStatus="Cannot allocate vault bounds query";return;}
      unsigned char args[128]={};
      if(stage==0)args[collide]=1;
      if(!g_memory.WriteRaw(g_boundsQuery.params,args,sizeof(args)))return;
      g_boundsQuery.actor=boundsActor;g_boundsQuery.mesh=mesh;g_boundsQuery.cls=previewClass;g_boundsQuery.yaw=rotation[1];
      g_boundsQuery.originAt=origin;g_boundsQuery.extentAt=extent;g_boundsQuery.mode=stage;
      g_boundsQuery.ticket=QueueProcessEvent(target,fn,g_boundsQuery.params);
      g_snapStatus=stage==2 ? "Measuring vault mesh directly..." : stage==1 ? "Measuring all vault components..." : "Measuring collision bounds...";
      return;
    }
    request.footprint=found->second;
    std::size_t chosen=0;float nearest=INFINITY;
    for(std::size_t i=0;i<request.anchors.size();++i) {
      const auto& a=request.anchors[i];
      const float dx=previewPosition[0]-a.position[0],dy=previewPosition[1]-a.position[1],dz=previewPosition[2]-a.position[2];
      const float distance=dx*dx+dy*dy+dz*dz;
      if(distance<nearest){nearest=distance;chosen=i;}
    }
    const SnapAnchor anchor=request.anchors[chosen];request.anchors.assign(1,anchor);
  }
  float pos[3],rot[3]={};
  const Address previewRoot=ReadObject(preview,"RootComponent");
  const int previewRotationAt=previewRoot ? Offset(ClassOf(previewRoot),"RelativeRotation") : 0;
  std::copy(previewPosition,previewPosition+3,pos);
  const bool haveRotation=validCache ? g_memory.ReadRaw(placer+0x504,rot,sizeof(rot)) :
    (previewRotationAt && g_memory.ReadRaw(previewRoot+previewRotationAt,rot,sizeof(rot)));
  if (haveRotation && SnapToNearest(request,pos,rot)) {
    std::copy(pos,pos+3,g_snapGuide); g_snapGuideValid=true;
  }
  // Automatic ghost alignment requires the verified placement layout.
  bool previewReady=false;
  if (validCache) {
    const Address fn=MainReflection().FindField(ClassOf(preview),"SetActorLocationAndRotation");
    auto parameter=[&](const char* name,const char* type,int bytes)->int {
      const Address field=fn ? MainReflection().FindField(fn,name) : 0;
      if (!field || NameOf(ClassOf(field))!=type) return -1;
      const int at=Read<int>(field+offsets::reflection::kPropertyOffset);
      return at>=0 && at+bytes<=128 ? at : -1;
    };
    const int location=parameter("NewLocation","StructProperty",12);
    const int rotation=parameter("NewRotation","StructProperty",12);
    const int sweep=parameter("bSweep","BoolProperty",1);
    const int result=parameter("ReturnValue","BoolProperty",1);
    const Address resultField=fn ? MainReflection().FindField(fn,"ReturnValue") : 0;
    const unsigned char resultMask=resultField ? Read<unsigned char>(resultField+offsets::reflection::kBoolFieldMask) : 0;
    if (location>=0 && rotation>=0 && sweep>=0 && result>=0 && resultMask && std::abs(location-rotation)>=12) {
      if (!g_autoSnapParams) g_autoSnapParams=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,128,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
      if (g_autoSnapParams) {
        request.placer=placer; request.preview=preview;
        request.previewFunction=fn; request.previewParams=g_autoSnapParams;
        request.previewLocationAt=location; request.previewRotationAt=rotation;
        request.previewResultAt=result;request.previewResultMask=resultMask;
        previewReady=true;
      }
    }
  }
  request.updatedAt=GetTickCount64();
  { std::lock_guard<std::mutex> lock(g_snapMutex); g_snapRequest=std::move(request); }
  publish.published=true;
  if(g_snapHook) SetHookBreakpoint(1,g_snapHook,OnSnapRequest);
  const Address thunk=NativeOf(MainReflection().FindField(ClassOf(game.controller),"ServerRequestPlaceStructure"));
  if(thunk) SetHookBreakpoint(2,thunk,OnPlacementThunk);
  g_snapStatus=std::string(previewReady ? (vault ? "Vault docking" : "Grid alignment") : "Preview unavailable")+
    " | preview OK "+std::to_string(g_previewOk.load())+" / failed "+std::to_string(g_previewFailed.load())+
    " | requests "+std::to_string(g_snapApplied.load());
}

const char* StructureSnapStatus() { return g_snapStatus.c_str(); }
bool StructureSnapGuide(float position[3]) {
  if (!g_snapGuideValid) return false;
  std::copy(g_snapGuide,g_snapGuide+3,position); return true;
}

Address SpyglassWildDino() { return g_lastWild; }

const SpyglassData& Spyglass() { return g_data; }

void ResetSpyglass() {
  SetHookBreakpoint(1,0,nullptr);SetHookBreakpoint(2,0,nullptr);
  { std::lock_guard<std::mutex> lock(g_snapMutex); g_snapRequest = {}; }
  g_snapHook=0; g_snapSearched=false; g_snapApplied=0; g_snapGuideValid=false;
  g_autoSnapParams=0; g_autoSnapTicket=0;
  g_autoSnapResultAt=-1;g_previewOk=0;g_previewFailed=0;g_boundsQuery={};g_vaultFootprints.clear();g_vaultBoundsStage.clear();g_vaultRetryAt.clear();
  g_snapStatus="off";
  g_corrupted.clear();
  g_playerJokes.clear();
  g_corruptedClasses.clear();
  g_data = {};
  g_target = {};
  g_lastWild = 0;g_locked={};g_lockSerial=0;g_spyWorld=0;
  g_offsets.clear();
  std::lock_guard<std::mutex> lock(g_scan.mutex);
  g_scan.dinos.clear();
  g_scan.structures.clear();
  g_scan.foundDinos.clear();
  g_scan.foundStructures.clear();
  g_scan.foundReady = false;
  g_scan.scannedAt = 0;
}

}  // namespace wintek

