#pragma once
#include "engine/Engine.h"
#include <string>
#include <vector>

// Player List (Admin): the server's list of connected players (in-game player ID, gamertag, survivor name and
// level) in a panel on the side of the screen, kept up to date as people join and leave.
//
// It asks the server the same way ARK's own admin manager does (ShooterPlayerState.ServerGetPlayerConnectedData,
// sent through ProcessEvent on the game thread) and catches the reply (ClientGetPlayerConnectedData) with a
// hardware breakpoint on its native handler. The server only answers admins, and the request is only sent while
// the server has flagged you as admin (bIsAdmin / bCheatPlayer on your controller), so it does nothing for
// anyone else. If the reply can't be caught, it falls back to reading the admin manager's own rows whenever
// showmyadminmanager has been opened.
//
// Each update can also be written to players.json in the Bence INI folder, for other tools (like a /kit
// script) to look IDs up without opening the admin manager.
namespace wintek {

struct ListedPlayer {
  std::wstring id;        // in-game player ID (what GiveItemToPlayer takes)
  std::wstring gamertag;  // platform name
  std::wstring name;      // survivor name, without the level
  int level = 0;
  DWORD joinedAt = 0;     // GetTickCount when first seen this session (0 = there when the list started)
  DWORD leftAt = 0;       // nonzero: gone from the server's list; shown greyed out for a while
};

struct PlayerListData {
  enum Status { Off, NotInGame, NotAdmin, Waiting, Live, FromAdminManager, Failed };
  Status status = Off;
  std::vector<ListedPlayer> players;  // connected first (in server order), then recently left
  int connected = 0;
  DWORD updatedAt = 0;
  std::string detail;  // a short reason when something isn't working
};

void TickPlayerList(const GameContext& game, bool wanted, int refreshSeconds);
const PlayerListData& PlayerList();
const char* PlayerListStatusText();  // one line for the HUD tab
void ResetPlayerList();

}  // namespace wintek
