#pragma once
#include <array>
#include <cmath>
namespace wintek {
using BallisticPoint=std::array<float,3>;
inline BallisticPoint BallisticPosition(const BallisticPoint& origin,const BallisticPoint& velocity,float gravity,float time) {
 return {origin[0]+velocity[0]*time,origin[1]+velocity[1]*time,origin[2]+velocity[2]*time+0.5f*gravity*time*time};
}
inline float BowLaunchSpeed(float minimum,float maximum,float pull,float fullPull) {
 if(!std::isfinite(minimum)||!std::isfinite(maximum)||!std::isfinite(pull)||!std::isfinite(fullPull)||minimum<=0||maximum<minimum||fullPull<=0)return 0;
 const float f=pull<0?0:pull>fullPull?1:pull/fullPull;
 return minimum+(maximum-minimum)*f;
}
inline bool SameLaunch(const BallisticPoint& a,const BallisticPoint& b,const BallisticPoint& va,const BallisticPoint& vb) {
 float pos=0,vel=0,speed=0;
 for(int i=0;i<3;++i) {pos+=(a[i]-b[i])*(a[i]-b[i]);vel+=(va[i]-vb[i])*(va[i]-vb[i]);speed+=va[i]*va[i];}
 return std::isfinite(pos)&&std::isfinite(vel)&&speed>0&&pos<=625&&vel<=speed*0.0004f;
}
}
