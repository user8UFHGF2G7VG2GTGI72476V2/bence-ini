#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// Better Input (Misc tab). While your inventory is open, the game's own Drop, Transfer and Use keys fire as fast as
// the game takes them: held, one action every frame with no key-repeat wait; tapped quickly, the taps join into one
// run. Ported from BetterInput.h.
//
// It edits the Store build's two 256-byte key tables (keyNow / keyPrev, found by signature in
// FUWPInputInterface::ConditionalScanForKeyboardChanges) so the game's per-frame keyboard scan sees a fresh key-down
// every frame. No input is sent to Windows, so no key can be left stuck down. The table edits run on their own
// thread every millisecond, since the game checks the tables once a frame.
//
// Off while an inventory search box is being typed in, while Shift / Ctrl / Alt is held (split stacks use the same
// keys), while this menu is open, or when the game isn't the active window. The keys are read from your in-game
// bindings (PlayerInput ActionMappings), O / T / E if they can't be read.
namespace wintek {

void TickBetterInput(const GameContext& game, const MiscSettings& settings, bool restoring);
void ResetBetterInput();

}  // namespace wintek
