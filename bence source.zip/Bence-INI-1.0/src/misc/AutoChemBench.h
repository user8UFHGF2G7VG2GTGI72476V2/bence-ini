#pragma once
#include "engine/Engine.h"
#include "core/Settings.h"
namespace wintek {
inline constexpr const char* kChemRecipeNames[] = {"Sparkpowder", "Gunpowder", "Cementing Paste", "Narcotic", "Stimulant", "Bug Repellant", "Propellant", "Absorbent Substrate", "Lesser Antidote"};
inline constexpr int kChemRecipeCount = 9;
void TickAutoChemBench(const GameContext&, const MiscSettings&, bool restoring);
void ResetAutoChemBench();
const char* AutoChemBenchStatus();
bool AutoChemBenchBusy();
}
