#include "misc/NativeInventoryPull.h"
#include "engine/Debugger.h"
#include "core/Process.h"
#include <array>
#include <unordered_map>
#include <string>
#include <algorithm>
namespace wintek { namespace {
constexpr int kBlock=2048,kSlots=32;
struct Method {Address fn=0,params=0;};
struct Button {ObjectRef widget,button,content;Address delegate=0;std::array<unsigned char,16> original{};bool toPlayer=false;};
struct Row {Address panel=0;ObjectRef edit;std::array<Button,2> buttons;};
struct Layout {ObjectRef slot;std::array<float,4> offsets;};
ObjectRef menu,canvas;Address library=0,textLibrary=0,buttonType=0,editType=0,arena=0;
std::unordered_map<Address,Method> methods;
std::array<Row,2> rows{};std::vector<Layout> layouts;
std::uint64_t pending=0;bool failed=false;ULONGLONG retryAt=0;
std::wstring lastMessage;bool wasBusy=false;
Address Object(Address o,const char* name){if(!o)return 0;int at=PropertyOffset(ClassOf(o),name);return at?Read<Address>(o+at):0;}
Address ObjectEntry(int index){if(index<0||index>=Read<int>(GObjects()+offsets::kObjectCount))return 0;Address chunk=Read<Address>(Read<Address>(GObjects())+(index/offsets::kObjectsPerChunk)*8);return chunk?chunk+(index%offsets::kObjectsPerChunk)*offsets::kObjectItemSize:0;}
Address Weak(Address where){int index=Read<int>(where),serial=Read<int>(where+4);Address entry=ObjectEntry(index);if(!entry||serial<=0||Read<int>(entry+8)!=serial)return 0;Address o=Read<Address>(entry);return o&&ObjectRef::Of(o).Alive()?o:0;}
bool SetBool(Address o,const char* name,bool on){Address f=MainReflection().FindField(ClassOf(o),name);if(!f||NameOf(ClassOf(f))!="BoolProperty")return false;int at=Read<int>(f+offsets::reflection::kPropertyOffset)+Read<unsigned char>(f+offsets::reflection::kBoolByteOffset);auto mask=Read<unsigned char>(f+offsets::reflection::kBoolFieldMask);if(at<0x20||at>0x8000||!mask)return false;SetBits(o+at,mask,on);return true;}
bool Bool(Address o,const char* name){Address f=MainReflection().FindField(ClassOf(o),name);if(!f||NameOf(ClassOf(f))!="BoolProperty")return false;int at=Read<int>(f+offsets::reflection::kPropertyOffset)+Read<unsigned char>(f+offsets::reflection::kBoolByteOffset);return at>=0x20&&at<0x8000&&(Read<unsigned char>(o+at)&Read<unsigned char>(f+offsets::reflection::kBoolFieldMask));}
// Output values stay in their own parameter blocks. In particular, subsequent
// FText/FString assignments release previous results instead of losing them.
bool Call(Address object,const char* name,void* args,int bytes,int inputBytes=-1){
 if(!object||!ObjectRef::Of(object).Alive()||!DebuggerAttached()||failed)return false;
 if(pending&&CompletedCalls()<pending)return false;
 Address fn=MainReflection().FindField(ClassOf(object),name);if(!fn||NameOf(ClassOf(fn))!="Function"||bytes>kBlock)return false;
 for(Address f=Read<Address>(fn+offsets::reflection::kChildren),n=0;f&&n<64;f=Read<Address>(f+offsets::reflection::kNext),++n){int at=Read<int>(f+offsets::reflection::kPropertyOffset),size=Read<int>(f+0x34);if(at<0||size<1||at+size>bytes)return false;}
 if(!arena)arena=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kBlock*kSlots,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 if(!arena)return false;
 auto it=methods.find(fn);if(it==methods.end()){if(methods.size()>=kSlots)return false;it=methods.emplace(fn,Method{fn,arena+methods.size()*kBlock}).first;}
 Address params=it->second.params;int write=inputBytes<0?bytes:inputBytes;
 if(write&&!g_memory.WriteRaw(params,args,write))return false;
 pending=QueueProcessEvent(object,fn,params);auto until=GetTickCount64()+1000;
 while(CompletedCalls()<pending&&GetTickCount64()<until)Sleep(1);
 if(CompletedCalls()<pending){failed=true;return false;}
 RefreshObjectTable();return !bytes||g_memory.ReadRaw(params,args,bytes);
}
bool Visibility(Address o,unsigned char value){return Call(o,"SetVisibility",&value,1);}
bool Enabled(Address o,bool on){unsigned char v=on;return Call(o,"SetIsEnabled",&v,1);}
bool Text(Address object,const std::wstring& value){
 if(value.size()>250||!arena)return false;
 Address data=arena+kBlock*kSlots-512;
 if(!g_memory.WriteRaw(data,value.c_str(),(value.size()+1)*2))return false;
 struct Args {Address data;int count,max;std::array<unsigned char,40> result;};
 Args a{data,static_cast<int>(value.size()+1),static_cast<int>(value.size()+1),{}};
 return Call(textLibrary,"Conv_StringToText",&a,sizeof(a),16)&&Call(object,"SetText",a.result.data(),40);
}
bool Add(Address parent,Address child,Address& slot){std::array<Address,2> p{child,0};if(!Call(parent,"AddChild",p.data(),16))return false;slot=p[1];return slot&&ObjectRef::Of(slot).Alive();}
bool Remove(Address parent,Address child){std::array<Address,2> p{child,0};return parent&&child&&Call(parent,"RemoveChild",p.data(),16)&&(p[1]&0xff);}
Address Create(const GameContext& g,Address type){std::array<Address,4> a{g.world,type,g.controller,0};return type&&IsA(type,"UserWidget")&&Call(library,"Create",a.data(),32)?a[3]:0;}
bool Place(Address child,float x){Address slot=0;if(!Add(canvas.object,child,slot)||!IsA(ClassOf(slot),"CanvasPanelSlot"))return false;float anchors[4]={.5f,0,.5f,0},position[2]={x,0},size[2]={76,44};int z=100;return Call(slot,"SetAnchors",anchors,16)&&Call(slot,"SetPosition",position,8)&&Call(slot,"SetSize",size,8)&&Call(slot,"SetZOrder",&z,4);}
Address FindWidget(Address owner,const char* name){Address tree=Object(owner,"WidgetTree");auto a=Read<TArray>(tree+PropertyOffset(ClassOf(tree),"AllWidgets"));if(!a.data||a.count<0||a.count>5000)return 0;for(int i=0;i<a.count;++i){Address w=Read<Address>(a.data+i*8);if(NameOf(w)==name)return w;}return 0;}
bool MakeButton(const GameContext& g,Button& b,float x,bool toPlayer){
 Address w=Create(g,buttonType);if(!w)return false;b.widget=ObjectRef::Of(w);b.toPlayer=toPlayer;
 Address button=Object(w,"Button");if(!button||!IsA(ClassOf(button),"Button"))return false;b.button=ObjectRef::Of(button);
 if(!Place(w,x)||!Visibility(w,0)||!Visibility(button,0)||!Enabled(button,true))return false;
 Address caption=FindWidget(w,"caption");if(!caption||!Text(caption,toPlayer?L"GET":L"PULL"))return false;
 int slotAt=PropertyOffset(ClassOf(button),"Slots");auto slots=Read<TArray>(button+slotAt);if(!slotAt||slots.count!=1)return false;
 Address content=Object(Read<Address>(slots.data),"Content");if(!content)return false;b.content=ObjectRef::Of(content);
 int clicked=PropertyOffset(ClassOf(button),"OnClicked");auto listeners=Read<TArray>(button+clicked);
 if(!clicked||listeners.count!=1||listeners.max<1||!g_memory.ReadRaw(listeners.data,b.original.data(),16)||Weak(listeners.data)!=w)return false;
 Address entry=ObjectEntry(b.button.index),clear=MainReflection().FindField(ClassOf(button),"ClearChildren");
 if(!entry||!clear||Read<Address>(clear+offsets::reflection::kChildren))return false;
 // A no-argument native UI signal: a click removes this button's own content.
 // The next tick observes it and reattaches the content. No shared hook slots,
 // foreign delegates, injected code or short-lived mouse-state polling.
 std::array<unsigned char,16> signal{};int serial=Read<int>(entry+8);auto name=Read<std::uint64_t>(clear+offsets::object::kName);
 std::memcpy(signal.data(),&b.button.index,4);std::memcpy(signal.data()+4,&serial,4);std::memcpy(signal.data()+8,&name,8);
 b.delegate=listeners.data;return serial>0&&g_memory.WriteRaw(b.delegate,signal.data(),16);
}
bool MakeEdit(const GameContext& g,Row& row,float x){
 Address owner=Create(g,editType);if(!owner)return false;Address edit=Object(owner,"EditBox");if(!edit||!IsA(ClassOf(edit),"EditableTextBox"))return false;
 row.edit=ObjectRef::Of(edit);SetBool(edit,"IsReadOnly",false);SetBool(edit,"IsPassword",false);
 for(const char* event:{"OnTextChanged","OnTextCommitted"}){int at=PropertyOffset(ClassOf(edit),event);if(at){auto a=Read<TArray>(edit+at);if(a.count<0||a.count>32)return false;Write(edit+at+8,0);}}
 int delegate=PropertyOffset(ClassOf(edit),"TextDelegate");if(delegate){std::array<unsigned char,16> empty{};g_memory.WriteRaw(edit+delegate,empty.data(),16);}
 Address parent=Object(Object(edit,"Slot"),"Parent");if(parent&&!Remove(parent,edit))return false;
 return Place(edit,x)&&Visibility(edit,0)&&Enabled(edit,true)&&Text(edit,L"1");
}
bool ReadQuantity(Address edit,int& count){
 std::array<unsigned char,40> text{};if(!Call(edit,"GetText",text.data(),40,0))return false;
 struct Args {std::array<unsigned char,40> text;Address data;int count,max;} a{text,0,0,0};
 if(!Call(textLibrary,"Conv_TextToString",&a,sizeof(a),40)||a.count<2||a.count>6||!a.data)return false;
 wchar_t value[6]={};if(!g_memory.ReadRaw(a.data,value,a.count*2)||value[a.count-1])return false;
 count=0;for(int i=0;i<a.count-1;++i){if(value[i]<L'0'||value[i]>L'9')return false;count=count*10+value[i]-L'0';}return count>=1&&count<=10000;
}
bool Prepare(const GameContext& g,Address ui){
 library=textLibrary=buttonType=editType=0;
 ForEachObject([&](Address o,int){if(!(Read<unsigned>(o+offsets::object::kFlags)&0x10))return true;auto n=NameOf(o);if(n=="Default__WidgetBlueprintLibrary")library=o;else if(n=="Default__KismetTextLibrary")textLibrary=o;else if(n=="Default__ContextMenuItem_SimpleButton_C")buttonType=ClassOf(o);else if(n=="Default__TextEntryUI_C")editType=ClassOf(o);return true;});
 if(!library||!textLibrary||!buttonType||!editType)return false;
 menu=ObjectRef::Of(ui);Address root=Object(Object(ui,"WidgetTree"),"RootWidget");if(!root||!IsA(ClassOf(root),"CanvasPanel"))return false;canvas=ObjectRef::Of(root);
 auto slots=Read<TArray>(root+PropertyOffset(ClassOf(root),"Slots"));if(slots.count<0||slots.count>100)return false;
 for(int i=0;i<slots.count;++i){Address slot=Read<Address>(slots.data+i*8),child=Object(slot,"Content");auto n=NameOf(child);if(n!="LeftPanelBorder"&&n!="CenterPanelBorder"&&n!="RightPanelBorder")continue;
  int at=PropertyOffset(ClassOf(slot),"LayoutData");Layout saved{ObjectRef::Of(slot),{}};if(!at||!g_memory.ReadRaw(slot+at,saved.offsets.data(),16)||saved.offsets[3]<100)return false;layouts.push_back(saved);auto adjusted=saved.offsets;adjusted[1]+=52;adjusted[3]-=52;if(!Call(slot,"SetOffsets",adjusted.data(),16))return false;
 }
 rows[0].panel=Object(ui,"PlayerInventoryPanel");rows[1].panel=Bool(ui,"bHasRemoteInventory")?Object(ui,"RemoteInventoryPanel"):0;
 for(int i=0;i<2;++i){auto& row=rows[i];if(!row.panel)continue;float x=i?450.f:-650.f;if(!MakeButton(g,row.buttons[0],x,false)||!MakeEdit(g,row,x+80)||!MakeButton(g,row.buttons[1],x+160,true))return false;}
 return true;
}
} // namespace
bool TickNativeInventoryPull(const GameContext& g,Address ui,bool busy,InventoryPullClick& click){
 click={};if(menu.object&&(!menu.Alive()||menu.object!=ui))CloseNativeInventoryPull();if(!ui)return false;
 if(!DebuggerAttached()||failed||GetTickCount64()<retryAt)return false;
 if(!menu.object){if(!Prepare(g,ui)){CloseNativeInventoryPull();retryAt=GetTickCount64()+5000;return false;}}
 if(wasBusy!=busy){for(auto& row:rows)for(auto& b:row.buttons)if(b.button.Alive())Enabled(b.button.object,!busy);wasBusy=busy;}
 for(int rowIndex=0;rowIndex<2;++rowIndex){auto& row=rows[rowIndex];if(!row.panel)continue;for(auto& b:row.buttons){if(!b.button.Alive())continue;auto slots=Read<TArray>(b.button.object+PropertyOffset(ClassOf(b.button.object),"Slots"));if(slots.count!=0)continue;
  Address newSlot=0;if(b.content.Alive())Add(b.button.object,b.content.object,newSlot);
  if(busy)continue;int quantity=0;Address item=0;
  if(!Call(g.controller,rowIndex?"GetInventoryUISelectedItemRemote":"GetInventoryUISelectedItemLocal",&item,8,0)||
     !item||!ObjectRef::Of(item).Alive()||!IsA(ClassOf(item),"PrimalItem"))item=0;
  if(row.edit.Alive())ReadQuantity(row.edit.object,quantity);
  click={item?ObjectRef::Of(item):ObjectRef{},quantity,b.toPlayer};return true;
 }}return false;
}
void CloseNativeInventoryPull(){
 if(pending&&CompletedCalls()<pending)return;
 for(auto& row:rows){for(auto& b:row.buttons){if(b.button.Alive()&&b.delegate)g_memory.WriteRaw(b.delegate,b.original.data(),16);if(canvas.Alive()&&b.widget.Alive())Remove(canvas.object,b.widget.object);}if(canvas.Alive()&&row.edit.Alive())Remove(canvas.object,row.edit.object);}
 for(auto& saved:layouts)if(saved.slot.Alive())Call(saved.slot.object,"SetOffsets",saved.offsets.data(),16);
 if(library&&DebuggerAttached())Call(library,"SetFocusToGameViewport",nullptr,0);
 rows={};layouts.clear();menu={};canvas={};lastMessage.clear();wasBusy=false;
}
void NativeInventoryPullMessage(const std::wstring& value){
 if(value==lastMessage||!menu.object||failed)return;lastMessage=value;
 if(value.size()>250||!arena)return;Address data=arena+kBlock*kSlots-512;g_memory.WriteRaw(data,value.c_str(),(value.size()+1)*2);
 struct Args{Address data;int count,max;std::array<unsigned char,40> result;};Args a{data,static_cast<int>(value.size()+1),static_cast<int>(value.size()+1),{}};
 if(!Call(textLibrary,"Conv_StringToText",&a,sizeof(a),16))return;
 for(auto& row:rows)for(auto& b:row.buttons)if(b.button.Alive())Call(b.button.object,"SetToolTipText",a.result.data(),40);
}
void ResetNativeInventoryPull(){CloseNativeInventoryPull();if(pending&&CompletedCalls()<pending)return;if(arena&&g_process.handle)VirtualFreeEx(g_process.handle,reinterpret_cast<void*>(arena),0,MEM_RELEASE);arena=library=textLibrary=buttonType=editType=0;methods.clear();pending=0;failed=false;retryAt=0;}
} // namespace wintek

