#include "misc/AutoChemBench.h"
#include "misc/ChemBenchPolicy.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <unordered_map>
#include <unordered_set>

namespace wintek {
namespace {
constexpr int kBuffer=128;
constexpr const char* kRecipeKeys[]={"sparkpowder","gunpowder","chitinpaste","narcotic","stimulant","bugrepellant","propellant","substrateabsorbent","curelow"};
struct Field {int at=-1; int bytes=0; std::string kind;};
struct Call {
 Address fn=0;std::unordered_map<std::string,Field> fields;
 int At(const char* name,int bytes,const char* kind)const {
  auto it=fields.find(ToLower(name));
  return it!=fields.end()&&it->second.bytes==bytes&&it->second.kind==kind ? it->second.at : -1;
 }
 bool Has(const char* name,int bytes,const char* kind)const {return At(name,bytes,kind)>=0;}
};
Call Resolve(Address cls,const char* name) {
 Call c;c.fn=MainReflection().FindField(cls,name);if(!c.fn)return c;
 Address field=Read<Address>(c.fn+offsets::reflection::kChildren);
 for(int n=0;field&&n<128;field=Read<Address>(field+offsets::reflection::kNext),++n) {
  int at=Read<int>(field+offsets::reflection::kPropertyOffset);
  int bytes=Read<int>(field+0x34); // UProperty::ElementSize
  if(at<0||bytes<1||at+bytes>kBuffer)continue;
  c.fields.emplace(ToLower(NameOf(field)),Field{at,bytes,NameOf(ClassOf(field))});
 }
 return c;
}
struct Calls {Call allow,view,request,close,to,from,craft; Address pcClass=0,invClass=0;} calls;
struct Stack {ObjectRef ref;Address cls=0;std::uint64_t id=0;int qty=0;bool recipe=false;};
struct Requirement {Address cls=0;float base=0;bool exact=false;};
enum class Phase {Idle,Allow,View,Request,Wait,Decide,Action,Close};
enum class Action {None,Supply,Collect,Craft};
Phase phase=Phase::Idle;
Action action=Action::None;
ObjectRef bench,inventory;
Address world=0,buffer=0,activeController=0;
std::uint64_t ticket=0;
ULONGLONG phaseAt=0,lastCall=0,visitAt=0,scanAt=0;
int selected=-1,actions=0,completed=0;
bool viewing=false;
std::vector<ObjectRef> benches;
std::unordered_map<Address,ULONGLONG> due;
std::string status="off";
Address actionClass=0;
int playerBefore=0,benchBefore=0,queueBefore=0;
ObjectRef recipeRef;

bool Bool(Address object,const char* name,bool& result) {
 Address f=MainReflection().FindField(ClassOf(object),name);
 if(!f||NameOf(ClassOf(f))!="BoolProperty")return false;
 int at=Read<int>(f+offsets::reflection::kPropertyOffset)+Read<unsigned char>(f+offsets::reflection::kBoolByteOffset);
 auto mask=Read<unsigned char>(f+offsets::reflection::kBoolFieldMask);unsigned char v=0;
 if(at<0x20||at>0x8000||!mask||!g_memory.ReadRaw(object+at,&v,1))return false;
 result=(v&mask)!=0;return true;
}
Address Object(Address actor,const char* name) {
 const int at=PropertyOffset(ClassOf(actor),name);return at ? Read<Address>(actor+at) : 0;
}
bool Location(Address actor,float out[3]) {
 Address root=Object(actor,"RootComponent");int at=root ? PropertyOffset(ClassOf(root),"RelativeLocation") : 0;
 return at&&g_memory.ReadRaw(root+at,out,12)&&std::isfinite(out[0])&&std::isfinite(out[1])&&std::isfinite(out[2]);
}
bool ClassMatches(Address cls,Address target,bool exact=false) {
 for(int n=0;cls&&n<64;cls=Read<Address>(cls+offsets::reflection::kSuperStruct),++n) {
  if(cls==target)return true;if(exact)return false;
 }
 return false;
}
bool RecipeMatches(Address cls,int recipe) {
 for(int n=0;cls&&n<64;cls=Read<Address>(cls+offsets::reflection::kSuperStruct),++n)
  if(ToLower(NameOf(cls)).find(kRecipeKeys[recipe])!=std::string::npos)return true;
 return false;
}
bool IsBench(Address cls) {
 if(!IsA(cls,"PrimalStructureItemContainer"))return false;
 for(int n=0;cls&&n<64;cls=Read<Address>(cls+offsets::reflection::kSuperStruct),++n) {
  const auto name=ToLower(NameOf(cls));
  if(name.find("chembench")!=std::string::npos||name.find("chemistrybench")!=std::string::npos)return true;
 }
 return false;
}
bool Snapshot(Address inv,std::vector<Stack>& out) {
 out.clear();bool receiving=false;if(Bool(inv,"bReceivingInventoryItems",receiving)&&receiving)return false;
 const int at=PropertyOffset(ClassOf(inv),"InventoryItems");if(!at)return false;
 TArray array{};if(!g_memory.ReadRaw(inv+at,&array,sizeof(array))||array.count<0||array.count>20000||array.max<array.count)return false;
 if(!array.count)return true;if(!array.data)return false;
 std::vector<Address> items(array.count);
 if(!g_memory.ReadRaw(array.data,items.data(),items.size()*sizeof(Address)))return false;
 for(Address item:items) {
  if(!item)continue;
  const ObjectRef ref=ObjectRef::Of(item);if(!ref.Alive())continue;
  const Address cls=ClassOf(item);if(!IsA(cls,"PrimalItem"))continue;
  bool blueprint=false,engram=false;
  if(!Bool(item,"bIsBlueprint",blueprint)||!Bool(item,"bIsEngram",engram))return false;
  const int q=PropertyOffset(cls,"ItemQuantity"),id=PropertyOffset(cls,"ItemId");
  if(!q||!id)return false;
  int qty=Read<int>(item+q);auto net=Read<std::uint64_t>(item+id);
  if(qty<0||qty>10000000)return false;
  out.push_back({ref,cls,net,qty,blueprint||engram});
 }
 return true;
}
int Count(const std::vector<Stack>& items,Address cls,bool exact=false) {
 long long n=0;for(const auto& s:items)if(!s.recipe&&ClassMatches(s.cls,cls,exact))n+=s.qty;
 return static_cast<int>((std::min)(n,10000000LL));
}
int Queue(Address recipe) {
 const int at=PropertyOffset(ClassOf(recipe),"CraftQueue");
 if(!at)return -1;std::uint16_t count=0;return g_memory.ReadRaw(recipe+at,&count,2) ? count : -1;
}
int StructField(Address type,const char* name,int bytes,int stride) {
 const Address f=MainReflection().FindField(type,name);if(!f)return -1;
 const int at=Read<int>(f+offsets::reflection::kPropertyOffset),size=Read<int>(f+0x34);
 return at>=0&&size==bytes&&at+bytes<=stride ? at : -1;
}
bool Requirements(Address item,std::vector<Requirement>& out) {
 out.clear();Address cls=ClassOf(item);
 for(const char* name:{"CustomResourceRequirements","BaseCraftingResourceRequirements"}) {
  const Address field=MainReflection().FindField(cls,name);
  if(!field||NameOf(ClassOf(field))!="ArrayProperty")continue;
  const int at=Read<int>(field+offsets::reflection::kPropertyOffset);
  if(at<0x20||at>0x8000)return false;
  const auto array=Read<TArray>(item+at);if(!array.count)continue;
  if(!array.data||array.count<1||array.count>32)return false;
  const Address inner=Read<Address>(field+0x70);
  if(!inner||NameOf(ClassOf(inner))!="StructProperty")return false;
  const int stride=Read<int>(inner+0x34);
  const Address type=Read<Address>(inner+0x70);
  if(!type||NameOf(type)!="CraftingResourceRequirement"||stride<16||stride>128)return false;
  const int resource=StructField(type,"ResourceItemType",8,stride),base=StructField(type,"BaseResourceRequirement",4,stride);
  const int exact=StructField(type,"bCraftingRequireExactResourceType",1,stride);
  if(resource<0||base<0||exact<0)return false;
  const int group=StructField(type,"GroupId",4,stride),multiple=StructField(type,"ForceMultipleResourceTypesRequirement",4,stride);
  for(int i=0;i<array.count;++i) {
   Address row=array.data+static_cast<Address>(i)*stride;
   if((group>=0&&Read<int>(row+group)>0)||(multiple>=0&&Read<int>(row+multiple)>0))return false;
   Requirement r{Read<Address>(row+resource),Read<float>(row+base),Read<unsigned char>(row+exact)!=0};
   if(!r.cls||!IsA(r.cls,"PrimalItem")||!std::isfinite(r.base)||r.base<=0||r.base>1000000)return false;
   out.push_back(r);
  }
  return !out.empty();
 }
 return false;
}
bool ResolveCalls(Address pc,Address inv) {
 const Address pcClass=ClassOf(pc),invClass=ClassOf(inv);
 if(calls.pcClass!=pcClass||calls.invClass!=invClass) {
  calls={};calls.pcClass=pcClass;calls.invClass=invClass;
  calls.allow=Resolve(invClass,"RemoteInventoryAllowViewing");
  calls.view=Resolve(pcClass,"ServerActorViewRemoteInventory");calls.close=Resolve(pcClass,"ServerActorCloseRemoteInventory");
  calls.request=Resolve(pcClass,"ServerRequestActorItems");calls.to=Resolve(pcClass,"ServerTransferToRemoteInventory");
  calls.from=Resolve(pcClass,"ServerTransferFromRemoteInventory");calls.craft=Resolve(pcClass,"ServerCraftItem");
 }
 auto invParam=[](const Call& c){return c.Has("inventoryComp",8,"ObjectProperty");};
 const bool ok=calls.allow.Has("PC",8,"ObjectProperty")&&calls.allow.Has("ReturnValue",1,"BoolProperty")&&
 invParam(calls.view)&&invParam(calls.close)&&calls.request.Has("forInventory",8,"ObjectProperty")&&
 calls.request.Has("bInventoryItems",1,"BoolProperty")&&calls.request.Has("bIsFirstSpawn",1,"BoolProperty")&&
 invParam(calls.to)&&calls.to.Has("itemID",8,"StructProperty")&&calls.to.Has("requestedQuantity",4,"IntProperty")&&
 (calls.to.Has("bAlsoTryToEqup",1,"BoolProperty")||calls.to.Has("bAlsoTryToEquip",1,"BoolProperty"))&&invParam(calls.from)&&calls.from.Has("itemID",8,"StructProperty")&&
 calls.from.Has("requestedQuantity",4,"IntProperty")&&calls.from.Has("ToSlotIndex",4,"IntProperty")&&calls.from.Has("bEquipItem",1,"BoolProperty")&&
 invParam(calls.craft)&&calls.craft.Has("itemID",8,"StructProperty");
 if(!ok)status="Chem Bench: inventory calls unavailable on this build";
 return ok;
}
template<class T> void Put(unsigned char* b,const Call& c,const char* name,const T& value,const char* kind) {
 const int at=c.At(name,sizeof(T),kind);if(at>=0)std::memcpy(b+at,&value,sizeof(T));
}
bool Send(Address obj,const Call& c,const unsigned char* block,ULONGLONG now) {
 if(!obj||!c.fn||!DebuggerAttached()||(ticket&&CompletedCalls()<ticket)||now-lastCall<150)return false;
 if(!buffer)buffer=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kBuffer,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 if(!buffer||!g_memory.WriteRaw(buffer,block,kBuffer))return false;
 ticket=QueueProcessEvent(obj,c.fn,buffer);lastCall=phaseAt=now;return ticket!=0;
}
void Idle(ULONGLONG now) {
 if(bench.object)due[bench.object]=now+5000;
 bench={};inventory={};phase=Phase::Idle;viewing=false;actions=0;action=Action::None;
}
void Close(ULONGLONG now) {
 if(!viewing) {Idle(now);return;}
 if(!inventory.Alive()||!activeController) {Idle(now);return;}
 unsigned char block[kBuffer]={};Put(block,calls.close,"inventoryComp",inventory.object,"ObjectProperty");
 if(Send(activeController,calls.close,block,now))phase=Phase::Close;
}
void Scan(Address gameWorld,int team) {
 benches.clear();const auto levels=Read<TArray>(gameWorld+offsets::world::kLevels);
 if(!levels.data||levels.count<1||levels.count>2048)return;
 for(int n=0;n<levels.count;++n) {
  const Address level=Read<Address>(levels.data+n*sizeof(Address));if(!level)continue;
  const auto actors=Read<TArray>(level+offsets::world::kLevelActors);
  if(!actors.data||actors.count<1||actors.count>200000)continue;
  std::vector<Address> all(actors.count);if(!g_memory.ReadRaw(actors.data,all.data(),all.size()*sizeof(Address)))continue;
  for(Address actor:all) {
   if(!actor)continue;
   if(Read<unsigned int>(actor+offsets::object::kFlags)&(0x30|0x100|0x4000|0x8000|0x10000))continue;
   const Address cls=ClassOf(actor);if(!cls||!IsBench(cls))continue;
   const int at=PropertyOffset(cls,"TargetingTeam");
   if(at&&Read<int>(actor+at)==team)benches.push_back(ObjectRef::Of(actor));
   if(benches.size()>=2048)return;
  }
 }
}
bool NearOwn(const ObjectRef& ref,int team,const float me[3],float range) {
 if(!ref.Alive())return false;const Address cls=ClassOf(ref.object);if(!IsBench(cls))return false;
 const int at=PropertyOffset(cls,"TargetingTeam");bool dead=true;
 if(!at||Read<int>(ref.object+at)!=team||!Bool(ref.object,"bIsDead",dead)||dead)return false;
 float pos[3];if(!Location(ref.object,pos))return false;
 float d=0;for(int i=0;i<3;++i)d+=(pos[i]-me[i])*(pos[i]-me[i]);return d<=range*range;
}
bool Transfer(const GameContext& game,const Stack& stack,int quantity,bool collect,ULONGLONG now,
              const std::vector<Stack>& player,const std::vector<Stack>& remote) {
 if(!stack.id||quantity<=0||!stack.ref.Alive())return false;
 quantity=(std::min)(quantity,stack.qty);if(quantity<=0)return false;
 const Call& c=collect ? calls.from : calls.to;unsigned char block[kBuffer]={};
 Put(block,c,"inventoryComp",inventory.object,"ObjectProperty");Put(block,c,"itemID",stack.id,"StructProperty");
 Put(block,c,"requestedQuantity",quantity,"IntProperty");
 if(collect) {const int slot=-1;Put(block,c,"ToSlotIndex",slot,"IntProperty");}
 if(!Send(game.controller,c,block,now))return false;
 actionClass=stack.cls;playerBefore=Count(player,actionClass,true);benchBefore=Count(remote,actionClass,true);
 action=collect ? Action::Collect : Action::Supply;phase=Phase::Action;++actions;
 status=collect ? "Chem Bench: collecting output" : "Chem Bench: supplying materials";return true;
}
}
void TickAutoChemBench(const GameContext& game,const MiscSettings& s,bool restoring) {
 const ULONGLONG now=GetTickCount64();
 const bool enabled=s.autoChemBench.on&&!restoring&&game.world&&game.pawn&&game.controller;
 if(world&&game.world!=world)ResetAutoChemBench();
 world=game.world;
 const bool open=game.hud&&Read<Address>(game.hud+offsets::hud::kOpenInventory);
 RequestDebugger(DebuggerClient::AutoChemBench,enabled||viewing||phase==Phase::Close);
 if(ticket&&CompletedCalls()<ticket)return;
 if(phase==Phase::Close) {Idle(now);return;}
 if(!enabled||open) {
  if(viewing)Close(now);else Idle(now);
  status=enabled ? "Chem Bench paused: inventory open" : "off";return;
 }
 const int teamAt=PropertyOffset(ClassOf(game.pawn),"TargetingTeam");const int team=teamAt ? Read<int>(game.pawn+teamAt) : 0;
 float me[3];if(team<50000||!Location(game.pawn,me)) {Close(now);status="Chem Bench: waiting for character";return;}
 const float range=std::clamp(s.chemRange,1,15)*100.0f;const int recipe=std::clamp(s.chemRecipe,0,kChemRecipeCount-1);
 if(phase!=Phase::Idle&&(!NearOwn(bench,team,me,range)||!inventory.Alive()||selected!=recipe||activeController!=game.controller)) {
  Close(now);return;
 }
 if(phase!=Phase::Idle&&now-visitAt>20000) {status="Chem Bench: waiting for next pass";Close(now);return;}
 if(!DebuggerAttached()) {status="Chem Bench: waiting for game connection";return;}
 if(phase==Phase::Idle) {
  if(!scanAt||now-scanAt>=2500) {scanAt=now;Scan(game.world,team);}
  ObjectRef pick;ULONGLONG oldest=~ULONGLONG{0};
  for(const auto& ref:benches) {
   auto it=due.find(ref.object);const auto when=it==due.end() ? 0 : it->second;
   if(when>now||when>=oldest||!NearOwn(ref,team,me,range))continue;pick=ref;oldest=when;
  }
  if(!pick.object) {status="Chem Bench: waiting for an accessible tribe bench";return;}
  const Address inv=Object(pick.object,"MyInventoryComponent");
  if(!inv||!ObjectRef::Of(inv).Alive()||!ResolveCalls(game.controller,inv)) {due[pick.object]=now+10000;return;}
  bench=pick;inventory=ObjectRef::Of(inv);activeController=game.controller;selected=recipe;visitAt=now;actions=0;
  unsigned char block[kBuffer]={};Put(block,calls.allow,"PC",game.controller,"ObjectProperty");
  if(Send(inv,calls.allow,block,now))phase=Phase::Allow;else Idle(now);return;
 }
 if(phase==Phase::Allow) {
  const int result=calls.allow.At("ReturnValue",1,"BoolProperty");
  if(result<0||!Read<unsigned char>(buffer+result)) {status="Chem Bench: outside normal access range";Idle(now);return;}
  unsigned char block[kBuffer]={};Put(block,calls.view,"inventoryComp",inventory.object,"ObjectProperty");
  if(Send(game.controller,calls.view,block,now)) {viewing=true;phase=Phase::View;}return;
 }
 if(phase==Phase::View) {
  unsigned char block[kBuffer]={};Put(block,calls.request,"forInventory",inventory.object,"ObjectProperty");
  const unsigned char yes=1;Put(block,calls.request,"bInventoryItems",yes,"BoolProperty");
  if(Send(game.controller,calls.request,block,now))phase=Phase::Request;return;
 }
 if(phase==Phase::Request) {phase=Phase::Wait;phaseAt=now;return;}
 if(phase==Phase::Wait) {if(now-phaseAt<800)return;phase=Phase::Decide;}
 const Address playerInv=Object(game.pawn,"MyInventoryComponent");
 std::vector<Stack> player,remote;
 if(!playerInv||!Snapshot(playerInv,player)||!Snapshot(inventory.object,remote)) {status="Chem Bench: waiting for inventory data";Close(now);return;}
 if(phase==Phase::Action) {
  bool acknowledged=false;
  if(action==Action::Supply)acknowledged=Count(player,actionClass,true)<playerBefore&&Count(remote,actionClass,true)>benchBefore;
  if(action==Action::Collect)acknowledged=Count(player,actionClass,true)>playerBefore&&Count(remote,actionClass,true)<benchBefore;
  if(action==Action::Craft)acknowledged=recipeRef.Alive()&&(Queue(recipeRef.object)>queueBefore||Count(remote,actionClass,true)>benchBefore);
  if(!acknowledged) {
   if(now-phaseAt>5000) {status="Chem Bench: action unconfirmed; retrying later";Close(now);}return;
  }
  ++completed;phase=Phase::Decide;
 }
 if(phase!=Phase::Decide)return;
 if(actions>=24||now-visitAt>15000) {Close(now);return;}
 const Stack* blueprint=nullptr;
 for(const auto& item:remote)if(item.recipe&&item.id&&RecipeMatches(item.cls,recipe)) {blueprint=&item;break;}
 if(!blueprint) {status="Chem Bench: selected recipe not available in this bench";Close(now);return;}
 if(s.chemCollect)for(const auto& item:remote)if(!item.recipe&&item.qty>0&&ClassMatches(item.cls,blueprint->cls,true)) {
  Transfer(game,item,item.qty,true,now,player,remote);return;
 }
 const int queued=Queue(blueprint->ref.object),target=std::clamp(s.chemQueue,1,100);
 std::vector<Requirement> requirements;
 const int multiplierAt=PropertyOffset(ClassOf(inventory.object),"DefaultCraftingRequirementsMultiplier");
 const float multiplier=multiplierAt ? Read<float>(inventory.object+multiplierAt) : 0;
 if(!Requirements(blueprint->ref.object,requirements)||!std::isfinite(multiplier)||multiplier<=0||multiplier>100) {
  status="Chem Bench: recipe requirements unavailable";Close(now);return;
 }
 if(s.chemFuel) {
  int fuelHave=0;for(const auto& item:remote)if(!item.recipe&&ToLower(NameOf(item.cls))=="primalitemresource_gasoline_c")fuelHave+=item.qty;
  int deficit=ChemDeficit(std::clamp(s.chemGasoline,1,100),fuelHave);
  if(deficit)for(const auto& item:player)if(!item.recipe&&ToLower(NameOf(item.cls))=="primalitemresource_gasoline_c"&&item.qty>0) {
   Transfer(game,item,(std::min)(deficit,item.qty),false,now,player,remote);return;
  }
 }
 bool resources=true;
 for(const auto& need:requirements) {
  const int per=ChemMaterialTarget(need.base,multiplier,1),materialTarget=ChemMaterialTarget(need.base,multiplier,target);
  if(!per||!materialTarget) {status="Chem Bench: unsupported material quantity";Close(now);return;}
  const int have=Count(remote,need.cls,need.exact);if(have<per)resources=false;
  const int deficit=ChemDeficit(materialTarget,have);
  if(s.chemSupply&&deficit>0)for(const auto& item:player)if(!item.recipe&&item.qty>0&&ClassMatches(item.cls,need.cls,need.exact)) {
   Transfer(game,item,(std::min)(deficit,item.qty),false,now,player,remote);return;
  }
 }
 bool powered=false,active=false;
 const bool powerKnown=Bool(bench.object,"bIsPowered",powered),activeKnown=Bool(bench.object,"bIsActivated",active);
 if(ChemCanQueue(true,powerKnown&&powered,activeKnown&&active,queued,target,resources)) {
  unsigned char block[kBuffer]={};Put(block,calls.craft,"inventoryComp",inventory.object,"ObjectProperty");
  Put(block,calls.craft,"itemID",blueprint->id,"StructProperty");
  if(Send(game.controller,calls.craft,block,now)) {
   action=Action::Craft;actionClass=blueprint->cls;recipeRef=blueprint->ref;queueBefore=queued;benchBefore=Count(remote,actionClass,true);
   phase=Phase::Action;++actions;status="Chem Bench: crafting "+std::string(kChemRecipeNames[recipe]);
  }
  return;
 }
 status=!powerKnown||!activeKnown ? "Chem Bench: power state unavailable" : !powered||!active ? "Chem Bench: needs power and must be switched on" :
        !resources ? "Chem Bench: missing ingredients" : queued<0 ? "Chem Bench: craft queue unavailable" : "Chem Bench: queue target reached";
 Close(now);
}
void ResetAutoChemBench() {
 RequestDebugger(DebuggerClient::AutoChemBench,false);phase=Phase::Idle;action=Action::None;bench={};inventory={};
 world=buffer=activeController=0;ticket=0;phaseAt=lastCall=visitAt=scanAt=0;selected=-1;actions=completed=0;viewing=false;
 benches.clear();due.clear();calls={};status="off";recipeRef={};
}
const char* AutoChemBenchStatus() {return status.c_str();}
bool AutoChemBenchBusy() {return phase!=Phase::Idle;}
}
