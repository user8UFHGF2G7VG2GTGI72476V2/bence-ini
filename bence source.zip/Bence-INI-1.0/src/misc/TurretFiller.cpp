#include "misc/TurretFiller.h"
#include "core/Diagnostics.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <mutex>
#include <thread>
#include <unordered_map>

namespace wintek {

namespace {

// Store-build offsets from TurretFiller.h, used when a name isn't found by reflection.
constexpr std::int32_t kTeamAt = 0x0230;           // AActor::TargetingTeam
constexpr std::int32_t kContainerInvAt = 0x0AF8;   // PrimalStructureItemContainer::MyInventoryComponent
constexpr std::int32_t kAmmoClassAt = 0x0E28;      // PrimalStructureTurret::AmmoItemTemplate
constexpr std::int32_t kInvItemsAt = 0x0118;       // UPrimalInventoryComponent::InventoryItems
constexpr std::int32_t kItemIdAt = 0x0210;         // UPrimalItem::ItemId (FItemNetID, 8 bytes)
constexpr std::int32_t kItemQtyAt = 0x05F8;        // UPrimalItem::ItemQuantity
constexpr std::int32_t kCharInvAt = 0x0D20;        // APrimalCharacter::MyInventoryComponent
constexpr std::int32_t kCurItemsAt = 0x0C1C;       // PrimalStructureItemContainer::CurrentItemCount (replicated)
constexpr int kHeavyStack = 100, kTekStack = 1000; // advanced rifle bullets, element shards per stack

constexpr ULONGLONG kTickMs = 60;
constexpr DWORD kScanMs = 1500;
constexpr ULONGLONG kSettleMs = 350;      // after the items reply, before trusting the count
constexpr ULONGLONG kRecheckMs = 10000;   // re-count a turret this often
constexpr ULONGLONG kPendingMs = 2500;    // what was just sent counts as present this long (until the count moves)
constexpr ULONGLONG kSendGapMs = 120;     // between two stack transfers, so the server takes every one
constexpr ULONGLONG kRecountMs = 700;     // after a run of transfers, count the turret again
constexpr ULONGLONG kExactMs = 15000;     // an up-close count is trusted this long for the marker
constexpr ULONGLONG kStepTimeoutMs = 4000;
constexpr float kNearCm = 1500.0f;        // candidates for filling (ARK's own check decides reach)
constexpr int kMaxSends = 60;
constexpr std::size_t kParamBytes = 0x2000;
constexpr std::size_t kSlot = 0x40;       // one parameter block per call

struct Turret {
  ObjectRef ref;
  bool tek;
  float pos[3];
};

struct State {
  ULONGLONG requestedAt = 0, sentAt = 0, unreachableAt = 0;
  int sentHave = 0, sentGave = 0;
  int have = -1;
};

struct Reserved {
  std::uint64_t id;
  std::int32_t seen, sent;
  ULONGLONG at;
};

struct Stack {
  std::uint64_t id;
  std::int32_t seen, left;
};

// Game functions and their parameter layouts, resolved by name once per class.
struct Calls {
  Address controllerClass = 0, inventoryClass = 0;
  Address transfer = 0, request = 0, allowViewing = 0;
  std::int32_t tInv = 0, tId = 8, tEquip = 16, tQty = 20;       // ServerTransferToRemoteInventory
  std::int32_t rInv = 0, rItems = 8, rFirst = 9;                // ServerRequestActorItems
  std::int32_t vPc = 0, vOffset = 8, vResult = 12;              // RemoteInventoryAllowViewing
};

enum class Phase { Idle, Viewing, Requesting, Settling, Sending };

struct {
  // scan (background thread)
  std::vector<Turret> turrets;
  std::int32_t team = 0;
  DWORD scannedAt = 0;
  std::mutex mutex;
  std::vector<Turret> found;
  bool foundReady = false;
  std::atomic<bool> scanning{ false };

  // filling
  std::unordered_map<Address, State> states;
  std::vector<Reserved> reserved;
  Calls calls;
  Address params = 0;
  Phase phase = Phase::Idle;
  ObjectRef current;
  std::uint64_t ticket = 0;
  ULONGLONG phaseAt = 0, tickAt = 0;
  // the current run of transfers, one stack at a time
  Address sendInv = 0, sendAmmo = 0;
  int sendNeed = 0, sendGave = 0, sendCount = 0;
  bool sendTek = false;
  ULONGLONG sendAt = 0;
  ULONGLONG warnedAt[2] = {};

  TurretOverlay overlay;
} g_tf;

std::unordered_map<Address, std::int32_t> g_offsets;
std::int32_t Off(Address cls, const char* name, std::int32_t fallback) {
  const Address key = cls ^ (std::hash<std::string>{}(name) << 1);
  auto it = g_offsets.find(key);
  if (it == g_offsets.end()) it = g_offsets.emplace(key, PropertyOffset(cls, name)).first;
  return it->second ? it->second : fallback;
}

// A parameter's offset inside a function's parameter block (0 is valid here), or `fallback`.
std::int32_t ParamAt(Address function, const char* name, std::int32_t fallback) {
  const Address field = MainReflection().FindField(function, name);
  if (!field) return fallback;
  const std::int32_t at = Read<std::int32_t>(field + offsets::reflection::kPropertyOffset);
  return at >= 0 && at < 0x40 ? at : fallback;
}

bool IsBlueprintOrEngram(Address item) {
  static BoolProperty blueprint("bIsBlueprint"), engram("bIsEngram");
  return blueprint.Get(item) || engram.Get(item);
}

// The item's class is (or derives from) the ammo class.
bool IsAmmo(Address item, Address ammoClass) {
  int depth = 0;
  for (Address cls = ClassOf(item); cls && depth < 16; cls = Read<Address>(cls + offsets::reflection::kSuperStruct), ++depth)
    if (cls == ammoClass) return true;
  return false;
}

std::vector<Address> Items(Address inventory) {
  std::vector<Address> items;
  if (!inventory) return items;
  const auto array = Read<TArray>(inventory + Off(ClassOf(inventory), "InventoryItems", kInvItemsAt));
  if (!array.data || array.count <= 0 || array.count > 20000) return items;
  items.resize(array.count);
  if (!g_memory.ReadRaw(array.data, items.data(), items.size() * sizeof(Address))) items.clear();
  return items;
}

int CountAmmo(Address inventory, Address ammoClass) {
  int total = 0;
  for (const Address item : Items(inventory)) {
    if (!item || IsBlueprintOrEngram(item) || !IsAmmo(item, ammoClass)) continue;
    const std::int32_t q = Read<std::int32_t>(item + Off(ClassOf(item), "ItemQuantity", kItemQtyAt));
    if (q > 0 && q < 1000000) total += q;
  }
  return total;
}

bool Location(Address actor, float out[3]) {
  const Address root = Read<Address>(actor + Off(ClassOf(actor), "RootComponent", 0x0268));
  if (!root) return false;
  return g_memory.ReadRaw(root + Off(ClassOf(root), "RelativeLocation", 0), out, 3 * sizeof(float));
}

float Dist2(const float a[3], const float b[3]) {
  const float dx = a[0] - b[0], dy = a[1] - b[1], dz = a[2] - b[2];
  return dx * dx + dy * dy + dz * dz;
}

// ---- turret list: your tribe's heavy and Tek turrets, from a background scan ----
void Scan(std::uint32_t generation, std::int32_t myTeam) {
  using namespace offsets;
  Reflection reflection;
  std::unordered_map<Address, int> kinds;  // 0 not a fillable turret, 1 heavy, 2 Tek
  std::unordered_map<Address, std::int32_t> teamAt, rootAt, locAt;
  auto cached = [&](std::unordered_map<Address, std::int32_t>& cache, Address cls, const char* name) {
    auto it = cache.find(cls);
    if (it == cache.end()) it = cache.emplace(cls, reflection.PropertyOffset(cls, name)).first;
    return it->second;
  };
  std::vector<Turret> found;
  ForEachObject([&](Address object, std::int32_t index) {
    if (g_scanGeneration != generation) return false;
    std::uint8_t header[0x28];
    if (!g_memory.ReadRaw(object, header, sizeof(header))) return true;
    std::uint32_t flags;
    Address cls, outer;
    std::memcpy(&flags, header + object::kFlags, sizeof(flags));
    std::memcpy(&cls, header + object::kClass, sizeof(cls));
    std::memcpy(&outer, header + object::kOuter, sizeof(outer));
    if (!cls || !outer || (flags & (0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000))) return true;
    auto kind = kinds.find(cls);
    if (kind == kinds.end()) {
      int k = 0;
      if (reflection.IsA(cls, "PrimalStructureTurret")) {
        const std::string& n = reflection.NameOf(cls);
        k = n.find("Tek") != std::string::npos ? 2 : n.find("Heavy") != std::string::npos ? 1 : 0;
      }
      kind = kinds.emplace(cls, k).first;
    }
    if (!kind->second || reflection.NameOf(ClassOf(outer)) != "Level") return true;
    const std::int32_t t = cached(teamAt, cls, "TargetingTeam");
    if (Read<std::int32_t>(object + (t ? t : kTeamAt)) != myTeam) return true;
    const std::int32_t r = cached(rootAt, cls, "RootComponent");
    const Address root = Read<Address>(object + (r ? r : 0x0268));
    const std::int32_t l = root ? cached(locAt, ClassOf(root), "RelativeLocation") : 0;
    Turret turret{ { object, index }, kind->second == 2, {} };
    if (l && g_memory.ReadRaw(root + l, turret.pos, sizeof(turret.pos))) found.push_back(turret);
    return found.size() < 4096;
  });
  {
    std::lock_guard<std::mutex> lock(g_tf.mutex);
    if (g_scanGeneration == generation) {
      g_tf.found = std::move(found);
      g_tf.foundReady = true;
    }
  }
  g_tf.scanning = false;
}

void TickScan(std::int32_t myTeam) {
  const DWORD now = GetTickCount();
  if (!g_tf.scanning && (!g_tf.scannedAt || now - g_tf.scannedAt >= kScanMs || myTeam != g_tf.team)) {
    g_tf.scannedAt = now;
    g_tf.team = myTeam;
    g_tf.scanning = true;
    std::thread(Scan, g_scanGeneration.load(), myTeam).detach();
  }
  std::lock_guard<std::mutex> lock(g_tf.mutex);
  if (g_tf.foundReady) {
    g_tf.foundReady = false;
    g_tf.turrets = std::move(g_tf.found);
  }
}

// ---- game calls ----
bool ResolveCalls(Address controller, Address turretInventory) {
  Calls& c = g_tf.calls;
  if (ClassOf(controller) != c.controllerClass) {
    c.controllerClass = ClassOf(controller);
    c.transfer = MainReflection().FindField(c.controllerClass, "ServerTransferToRemoteInventory");
    c.request = MainReflection().FindField(c.controllerClass, "ServerRequestActorItems");
    if (c.transfer) {
      c.tInv = ParamAt(c.transfer, "InventoryComp", 0);
      c.tId = ParamAt(c.transfer, "ItemID", 8);
      c.tEquip = ParamAt(c.transfer, "bAlsoTryToEquip", 16);
      c.tQty = ParamAt(c.transfer, "RequestedQuantity", 20);
    }
    if (c.request) {
      c.rInv = ParamAt(c.request, "forInventory", 0);
      c.rItems = ParamAt(c.request, "bInventoryItems", 8);
      c.rFirst = ParamAt(c.request, "bIsFirstSpawn", 9);
    }
  }
  if (ClassOf(turretInventory) != c.inventoryClass) {
    c.inventoryClass = ClassOf(turretInventory);
    c.allowViewing = MainReflection().FindField(c.inventoryClass, "RemoteInventoryAllowViewing");
    if (c.allowViewing) {
      c.vPc = ParamAt(c.allowViewing, "PC", 0);
      c.vOffset = ParamAt(c.allowViewing, "MaxAllowedDistanceOffset", 8);
      c.vResult = ParamAt(c.allowViewing, "ReturnValue", 12);
    }
  }
  if (!c.transfer || !c.request || !c.allowViewing) {
    g_diag.turrets = "game functions not found";
    return false;
  }
  if (!g_tf.params) {
    g_tf.params = reinterpret_cast<Address>(VirtualAllocEx(g_process.handle, nullptr, kParamBytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    if (!g_tf.params) return false;
  }
  return true;
}

Address Slot(int i) { return g_tf.params + i * kSlot; }

std::uint64_t QueueCall(Address object, Address function, Address params, const std::uint8_t* block) {
  g_memory.WriteRaw(params, block, kSlot);
  return QueueProcessEvent(object, function, params);
}

// ---- your ammo stacks, minus what was just sent from them ----
std::vector<Stack> MyStacks(Address myInventory, Address ammoClass, ULONGLONG now) {
  std::vector<Stack> out;
  g_tf.reserved.erase(std::remove_if(g_tf.reserved.begin(), g_tf.reserved.end(),
                                     [&](const Reserved& r) { return now - r.at >= kPendingMs; }),
                      g_tf.reserved.end());
  for (const Address item : Items(myInventory)) {
    if (!item || IsBlueprintOrEngram(item) || !IsAmmo(item, ammoClass)) continue;
    const Address cls = ClassOf(item);
    const std::int32_t q = Read<std::int32_t>(item + Off(cls, "ItemQuantity", kItemQtyAt));
    const std::uint64_t id = Read<std::uint64_t>(item + Off(cls, "ItemId", kItemIdAt));
    if (q <= 0 || q >= 1000000 || !id) continue;
    std::int32_t left = q;
    for (const Reserved& r : g_tf.reserved)
      if (r.id == id && r.seen == q) left -= r.sent;
    if (left > 0) out.push_back({ id, q, left });
  }
  return out;
}

void Reserve(std::uint64_t id, std::int32_t seen, std::int32_t sent, ULONGLONG now) {
  for (Reserved& r : g_tf.reserved)
    if (r.id == id && r.seen == seen) {
      r.sent += sent;
      r.at = now;
      return;
    }
  g_tf.reserved.push_back({ id, seen, sent, now });
}

void Warn(bool tek, ULONGLONG now) {
  ULONGLONG& last = g_tf.warnedAt[tek ? 1 : 0];
  if (now - last < 20000) return;
  last = now;
  g_tf.overlay.warning = tek ? L"Turret Filler: no element shards on you" : L"Turret Filler: no advanced rifle bullets on you";
  g_tf.overlay.warningUntil = now + 4000;
}

void Fill(const GameContext& game, const MiscSettings& s, Address me, const float myPos[3], ULONGLONG now) {
  auto targetFor = [&](bool tek) {
    return tek ? std::clamp(s.tekStacks, 0, 50) * kTekStack : std::clamp(s.heavyStacks, 0, 100) * kHeavyStack;
  };
  auto stepDone = [&] { return CompletedCalls() >= g_tf.ticket; };
  if (g_tf.phase != Phase::Idle && now - g_tf.phaseAt > kStepTimeoutMs) g_tf.phase = Phase::Idle;  // never stall

  switch (g_tf.phase) {
    case Phase::Idle: {
      // The nearest turret of yours that's due a check.
      const Turret* pick = nullptr;
      float best = kNearCm * kNearCm;
      for (const Turret& t : g_tf.turrets) {
        if (!t.ref.Alive() || targetFor(t.tek) <= 0) continue;
        const float d2 = Dist2(t.pos, myPos);
        if (d2 > best) continue;
        const State& st = g_tf.states[t.ref.object];
        if (st.requestedAt && now - st.requestedAt < kRecheckMs) continue;
        if (st.unreachableAt && now - st.unreachableAt < 1500) continue;
        pick = &t;
        best = d2;
      }
      if (!pick) return;
      const Address inv = Read<Address>(pick->ref.object + Off(ClassOf(pick->ref.object), "MyInventoryComponent", kContainerInvAt));
      if (!inv || !ResolveCalls(game.controller, inv) || !DebuggerAttached()) return;
      std::uint8_t block[kSlot] = {};
      std::memcpy(block + g_tf.calls.vPc, &game.controller, sizeof(Address));
      g_tf.ticket = QueueCall(inv, g_tf.calls.allowViewing, Slot(0), block);
      g_tf.current = pick->ref;
      g_tf.phase = Phase::Viewing;
      g_tf.phaseAt = now;
      return;
    }
    case Phase::Viewing: {
      if (!stepDone()) return;
      const Address turret = g_tf.current.Alive() ? g_tf.current.object : 0;
      const bool reachable = turret && Read<std::uint8_t>(Slot(0) + g_tf.calls.vResult) != 0;
      if (!reachable) {
        if (turret) g_tf.states[turret].unreachableAt = now;
        g_tf.phase = Phase::Idle;
        return;
      }
      const Address inv = Read<Address>(turret + Off(ClassOf(turret), "MyInventoryComponent", kContainerInvAt));
      std::uint8_t block[kSlot] = {};
      std::memcpy(block + g_tf.calls.rInv, &inv, sizeof(Address));
      block[g_tf.calls.rItems] = 1;
      g_tf.ticket = QueueCall(game.controller, g_tf.calls.request, Slot(1), block);
      g_tf.phase = Phase::Requesting;
      g_tf.phaseAt = now;
      return;
    }
    case Phase::Requesting:
      if (!stepDone()) return;
      if (g_tf.current.Alive()) g_tf.states[g_tf.current.object].requestedAt = now;
      g_tf.phase = Phase::Settling;
      g_tf.phaseAt = now;
      return;
    case Phase::Settling: {
      if (now - g_tf.phaseAt < kSettleMs) return;  // the reply is still on its way
      g_tf.phase = Phase::Idle;
      if (!g_tf.current.Alive()) return;
      const Address turret = g_tf.current.object;
      const Address cls = ClassOf(turret);
      const bool tek = NameOf(cls).find("Tek") != std::string::npos;
      const Address inv = Read<Address>(turret + Off(cls, "MyInventoryComponent", kContainerInvAt));
      const Address ammo = Read<Address>(turret + Off(cls, "AmmoItemTemplate", kAmmoClassAt));
      if (!inv || !ammo) return;
      State& st = g_tf.states[turret];
      const int have = CountAmmo(inv, ammo);
      const int target = targetFor(tek);
      // What was just sent counts as there until the turret's count moves (the transfer is still on its way).
      int effective = have;
      if (st.sentAt && now - st.sentAt < kPendingMs && have <= st.sentHave) effective = (std::max)(have, st.sentHave + st.sentGave);
      st.have = have;
      if (effective >= target) return;
      g_tf.sendInv = inv;
      g_tf.sendAmmo = ammo;
      g_tf.sendTek = tek;
      g_tf.sendNeed = target - effective;
      g_tf.sendGave = g_tf.sendCount = 0;
      g_tf.sendAt = 0;
      st.sentHave = have;
      g_tf.phase = Phase::Sending;
      g_tf.phaseAt = now;
      return;
    }
    case Phase::Sending: {
      // One stack per step: wait for the last call, leave a short gap, send the next, until the target is met.
      if (g_tf.sendCount && !stepDone()) return;
      if (g_tf.sendAt && now - g_tf.sendAt < kSendGapMs) return;
      const Address turret = g_tf.current.Alive() ? g_tf.current.object : 0;
      std::vector<Stack> stacks;
      if (turret && g_tf.sendNeed > 0 && g_tf.sendCount < kMaxSends) {
        const Address myInv = Read<Address>(me + Off(ClassOf(me), "MyInventoryComponent", kCharInvAt));
        stacks = MyStacks(myInv, g_tf.sendAmmo, now);
      }
      if (stacks.empty()) {  // done: target met, nothing left on you, or the turret is gone
        g_tf.phase = Phase::Idle;
        if (!turret) return;
        if (!g_tf.sendGave && g_tf.sendNeed > 0) Warn(g_tf.sendTek, now);
        State& st = g_tf.states[turret];
        if (g_tf.sendGave) {
          st.sentGave = g_tf.sendGave;
          st.sentAt = now;
        }
        st.requestedAt = now - kRecheckMs + kRecountMs;  // count it again shortly and top up anything that didn't land
        return;
      }
      // Fullest stack first, so the fewest transfers fill the turret.
      const Stack& stack = *std::max_element(stacks.begin(), stacks.end(), [](const Stack& a, const Stack& b) { return a.left < b.left; });
      const int give = (std::min)(stack.left, g_tf.sendNeed);
      std::uint8_t block[kSlot] = {};
      std::memcpy(block + g_tf.calls.tInv, &g_tf.sendInv, sizeof(Address));
      std::memcpy(block + g_tf.calls.tId, &stack.id, sizeof(stack.id));
      std::memcpy(block + g_tf.calls.tQty, &give, sizeof(give));
      g_tf.ticket = QueueCall(game.controller, g_tf.calls.transfer, Slot(2 + g_tf.sendCount % 64), block);
      Reserve(stack.id, stack.seen, give, now);
      g_tf.sendNeed -= give;
      g_tf.sendGave += give;
      ++g_tf.sendCount;
      g_tf.sendAt = now;
      g_tf.phaseAt = now;  // the step timeout counts from the last send
      return;
    }
  }
}

int RemoteAmount(Address turret, bool tek) {
  const std::int32_t stacks = Read<std::int32_t>(turret + Off(ClassOf(turret), "CurrentItemCount", kCurItemsAt));
  if (stacks < 0 || stacks > 10000) return -1;
  return stacks * (tek ? kTekStack : kHeavyStack);
}

void BuildOverlay(const MiscSettings& s, const float myPos[3], ULONGLONG now) {
  TurretOverlay& o = g_tf.overlay;
  o.markers.clear();
  o.heavyTotal = o.heavyFull = o.tekTotal = o.tekFull = 0;
  if (!s.showTurretFill) return;
  const float range = std::clamp(s.turretRange, 20, 700) * 100.0f;
  for (const Turret& t : g_tf.turrets) {
    if (!t.ref.Alive() || Dist2(t.pos, myPos) > range * range) continue;
    const int target = t.tek ? std::clamp(s.tekStacks, 0, 50) * kTekStack : std::clamp(s.heavyStacks, 0, 100) * kHeavyStack;
    auto it = g_tf.states.find(t.ref.object);
    const bool exact = it != g_tf.states.end() && it->second.have >= 0 && now - it->second.requestedAt < kExactMs;
    const int have = exact ? it->second.have : RemoteAmount(t.ref.object, t.tek);
    TurretMarker m{ { t.pos[0], t.pos[1], t.pos[2] + 80.0f }, t.tek, have, target, exact };
    o.markers.push_back(m);
    (t.tek ? o.tekTotal : o.heavyTotal)++;
    if (have >= 0 && have >= target) (t.tek ? o.tekFull : o.heavyFull)++;
  }
}

}  // namespace

void TickTurretFiller(const GameContext& game, const MiscSettings& s, bool restoring) {
  const bool fill = s.turretFiller.on && !restoring;
  const bool want = fill || (s.showTurretFill && !restoring);
  RequestDebugger(DebuggerClient::TurretFiller, fill && game.pawn);
  if (!want || !game.pawn || !game.controller) {
    g_tf.overlay.markers.clear();
    g_tf.phase = Phase::Idle;
    g_diag.turrets = want ? "not in game" : "off";
    return;
  }
  const ULONGLONG now = GetTickCount64();
  if (now - g_tf.tickAt < kTickMs) return;
  g_tf.tickAt = now;

  const Address me = game.pawn;
  float myPos[3];
  if (!Location(me, myPos)) return;
  const std::int32_t myTeam = Read<std::int32_t>(me + Off(ClassOf(me), "TargetingTeam", kTeamAt));
  if (myTeam <= 0) return;
  TickScan(myTeam);

  // Hidden behind an open inventory or menu: markers stay, filling waits.
  const bool screenOpen = game.hud && Read<Address>(game.hud + offsets::hud::kOpenInventory);
  if (fill && !screenOpen) Fill(game, s, me, myPos, now);
  BuildOverlay(s, myPos, now);

  g_diag.turrets = std::to_string(g_tf.turrets.size()) + " of your turrets found, " + std::to_string(g_tf.overlay.markers.size()) +
                   " in range" + (fill ? (DebuggerAttached() ? ", filler ready" : ", filler waiting for debugger") : "");
  if (g_tf.states.size() > 4096) g_tf.states.clear();
}

const TurretOverlay& TurretFill() { return g_tf.overlay; }

void ResetTurretFiller() {
  RequestDebugger(DebuggerClient::TurretFiller, false);
  std::lock_guard<std::mutex> lock(g_tf.mutex);
  g_tf.turrets.clear();
  g_tf.found.clear();
  g_tf.foundReady = false;
  g_tf.scannedAt = 0;
  g_tf.states.clear();
  g_tf.reserved.clear();
  g_tf.calls = {};
  g_tf.params = 0;  // belonged to the previous game process
  g_tf.phase = Phase::Idle;
  g_tf.overlay = {};
  g_offsets.clear();
}

}  // namespace wintek
