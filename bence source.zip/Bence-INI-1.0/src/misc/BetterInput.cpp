#include "misc/BetterInput.h"
#include "client/Window.h"
#include "core/Diagnostics.h"
#include "core/GameWindow.h"
#include "core/Process.h"
#include "engine/Signatures.h"
#include <windows.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace wintek {

namespace {

constexpr const char* kKeyTableSig =
    "42 0F B6 84 3E ?? ?? ?? ?? 84 C0 75 ?? 42 80 BC 3E ?? ?? ?? ?? 01 75 ?? B3 01 EB ?? 32 DB";
constexpr std::int32_t kActionMappingsAt = 0x00E8;  // UPlayerInput::ActionMappings (0x28 each)
constexpr std::int32_t kMappingSize = 0x28;
constexpr std::int32_t kNameFilterAt = 0x0770;      // DataListPanel::NameFilter (FString)
constexpr std::int32_t kInvFlagsAt = 0x1260;        // AShooterCharacter: bIsViewingInventory byte
constexpr std::uint8_t kInvOpenBit = 1u << 5;
constexpr ULONGLONG kSpamGapMs = 150;

// ---- shared with the key thread ----
struct Shared {
  std::atomic<bool> active{ false };     // inventory open, nothing in the way
  std::atomic<int> vk[3] = { { 'O' }, { 'T' }, { 'E' } };  // drop, transfer, use
  std::atomic<HWND> content{ nullptr }, root{ nullptr };
  Address keyNow = 0, keyPrev = 0;       // set before the thread starts
  HANDLE process = nullptr;              // the thread's own copy of the game handle
  std::atomic<bool> stop{ false };
  std::thread thread;
} g_shared;

// ---- main thread state ----
struct {
  std::atomic<int> sigState{ 0 };  // 0 not searched, 1 searching, 2 found, 3 not found
  std::atomic<Address> sigNow{ 0 }, sigPrev{ 0 };
  DWORD sigPid = 0;

  ULONGLONG bindingsAt = 0, windowAt = 0;

  // inventory search boxes
  std::mutex panelMutex;
  std::vector<Address> panelFound;
  bool panelFresh = false;
  std::atomic<bool> panelBusy{ false };
  std::unordered_map<Address, std::uint32_t> panels;  // panel -> NameFilter hash
  ULONGLONG panelsAt = 0, lastTypedMs = 0, lastLmbMs = 0, typedAtClick = 0;
  bool searchFocused = false, prevLmb = false, prevEsc = false, wasOpen = false;
} g_bi;

bool KeyDown(int vk) { return vk > 0 && vk <= 0xFF && (GetAsyncKeyState(vk) & 0x8000); }

// ---- the key table edit (key thread) ----
struct KeyState {
  ULONGLONG releaseMs = 0;
  int pendingVk = 0, fakeVk = 0;
  bool active = false, spamming = false;
};

std::uint8_t Get(Address table, int vk) {
  std::uint8_t v = 0;
  ReadProcessMemory(g_shared.process, reinterpret_cast<LPCVOID>(table + vk), &v, 1, nullptr);
  return v;
}

void Set(Address table, int vk, std::uint8_t v) {
  WriteProcessMemory(g_shared.process, reinterpret_cast<LPVOID>(table + vk), &v, 1, nullptr);
}

void Cancel(KeyState& st) {
  if (st.pendingVk) Set(g_shared.keyPrev, st.pendingVk, Get(g_shared.keyNow, st.pendingVk));
  if (st.fakeVk) Set(g_shared.keyNow, st.fakeVk, 0);
  st = {};
}

void TickKey(KeyState& st, int vk, bool focused, ULONGLONG now) {
  const Address keyNow = g_shared.keyNow, keyPrev = g_shared.keyPrev;
  if (vk <= 0 || vk > 0xFF) return;
  if (!focused || !KeyDown(vk)) {
    if (!st.active) return;
    if (!st.releaseMs) {
      if (st.pendingVk && !Get(keyNow, vk) && !Get(keyPrev, vk)) Set(keyPrev, vk, 1);
      st.pendingVk = 0;
      st.releaseMs = now;
    }
    if (!focused || now - st.releaseMs > kSpamGapMs) {
      if (st.fakeVk) {
        Set(keyNow, vk, 0);
        Set(keyPrev, vk, 1);
      }
      st = {};
      return;
    }
    if (!st.spamming) return;
    if (!st.fakeVk) {
      if (Get(keyNow, vk) || Get(keyPrev, vk)) return;
      Set(keyNow, vk, 1);  // keeps a spammed run going between taps
      st.fakeVk = vk;
      return;
    }
  } else if (st.releaseMs) {
    st.spamming = true;
    st.releaseMs = 0;
    st.fakeVk = 0;
  } else if (!st.active) {
    st.active = true;
    return;
  }

  if (st.pendingVk) {
    if (Get(keyNow, vk) && !Get(keyPrev, vk)) return;  // the game hasn't taken the last key-down yet
    st.pendingVk = 0;
  }
  if (!Get(keyNow, vk)) return;
  Set(keyPrev, vk, 0);  // next frame the game sees a new key-down
  st.pendingVk = vk;
}

void KeyThread() {
  KeyState states[3];
  int keys[3] = {};
  bool wasActive = false;
  while (!g_shared.stop) {
    const ULONGLONG now = GetTickCount64();
    const HWND fg = GetForegroundWindow();
    const GameWindow window{ g_shared.content.load(), g_shared.root.load() };
    const bool focused = window.content && window.IsActive(fg);
    const bool modifier = KeyDown(VK_SHIFT) || KeyDown(VK_CONTROL) || KeyDown(VK_MENU);
    const bool active = g_shared.active && !modifier;
    for (int i = 0; i < 3; ++i) {
      const int vk = g_shared.vk[i];
      if (vk != keys[i]) {
        Cancel(states[i]);
        keys[i] = vk;
      }
    }
    if (!active) {
      if (wasActive)
        for (KeyState& st : states) Cancel(st);
      wasActive = false;
      Sleep(5);
      continue;
    }
    wasActive = true;
    for (int i = 0; i < 3; ++i) {
      bool dup = false;  // two actions bound to one key: edit it once
      for (int j = 0; j < i; ++j) dup |= keys[j] == keys[i];
      if (!dup) TickKey(states[i], keys[i], focused, now);
    }
    Sleep(1);
  }
  for (KeyState& st : states) Cancel(st);
}

void StopThread() {
  g_shared.active = false;
  if (g_shared.thread.joinable()) {
    g_shared.stop = true;
    g_shared.thread.join();
  }
  if (g_shared.process) CloseHandle(g_shared.process);
  g_shared.process = nullptr;
  g_shared.stop = false;
}

bool StartThread() {
  if (g_shared.thread.joinable()) return true;
  HANDLE copy = nullptr;
  if (!DuplicateHandle(GetCurrentProcess(), g_process.handle, GetCurrentProcess(), &copy, 0, FALSE, DUPLICATE_SAME_ACCESS))
    return false;
  g_shared.process = copy;
  g_shared.keyNow = g_bi.sigNow;
  g_shared.keyPrev = g_bi.sigPrev;
  g_shared.stop = false;
  g_shared.thread = std::thread(KeyThread);
  return true;
}

// ---- key tables, by signature (once per game process, off the main thread) ----
void FindTables() {
  if (g_bi.sigPid != g_process.pid) {
    g_bi.sigPid = g_process.pid;
    g_bi.sigState = 0;
  }
  if (g_bi.sigState != 0) return;
  g_bi.sigState = 1;
  const Address base = g_process.base;
  const DWORD pid = g_process.pid;
  std::thread([base, pid] {
    const auto found = FindPatterns(base, { kKeyTableSig });
    const Address hit = found.empty() ? 0 : found[0];
    if (g_bi.sigPid != pid) return;  // the game was restarted meanwhile
    if (hit) {
      g_bi.sigNow = base + static_cast<Address>(static_cast<std::int64_t>(Read<std::int32_t>(hit + 0x05)));
      g_bi.sigPrev = base + static_cast<Address>(static_cast<std::int64_t>(Read<std::int32_t>(hit + 0x11)));
    }
    g_bi.sigState = hit ? 2 : 3;
  }).detach();
}

// ---- inventory open ----
bool InventoryOpen(const GameContext& game) {
  if (game.hud && Read<Address>(game.hud + offsets::hud::kOpenInventory)) return true;
  if (!game.pawn) return false;
  static Address cls = 0;
  static bool player = false;
  static BoolProperty viewing("bIsViewingInventory");
  static bool byName = false;
  if (ClassOf(game.pawn) != cls) {
    cls = ClassOf(game.pawn);
    player = IsA(cls, "ShooterCharacter");
    byName = PropertyOffset(cls, "bIsViewingInventory") != 0;
  }
  if (!player) return false;
  if (byName) return viewing.Get(game.pawn);
  return (Read<std::uint8_t>(game.pawn + kInvFlagsAt) & kInvOpenBit) != 0;
}

// ---- your bindings: PlayerInput::ActionMappings (ActionName FName @0, Key FName @8) ----
int KeyNameToVk(const std::string& n) {
  if (n.empty()) return 0;
  if (n.size() == 1 && ((n[0] >= 'A' && n[0] <= 'Z') || (n[0] >= '0' && n[0] <= '9'))) return n[0];
  if (n.size() >= 2 && n[0] == 'F') {
    int fn = 0;
    std::size_t i = 1;
    for (; i < n.size() && n[i] >= '0' && n[i] <= '9'; ++i) fn = fn * 10 + (n[i] - '0');
    if (i == n.size() && fn >= 1 && fn <= 24) return VK_F1 + fn - 1;
  }
  static const std::unordered_map<std::string, int> named = {
    { "LeftMouseButton", VK_LBUTTON }, { "RightMouseButton", VK_RBUTTON }, { "MiddleMouseButton", VK_MBUTTON },
    { "ThumbMouseButton", VK_XBUTTON1 }, { "ThumbMouseButton2", VK_XBUTTON2 }, { "SpaceBar", VK_SPACE },
    { "Enter", VK_RETURN }, { "Tab", VK_TAB }, { "BackSpace", VK_BACK }, { "LeftShift", VK_LSHIFT },
    { "RightShift", VK_RSHIFT }, { "LeftControl", VK_LCONTROL }, { "RightControl", VK_RCONTROL },
    { "LeftAlt", VK_LMENU }, { "RightAlt", VK_RMENU }, { "Up", VK_UP }, { "Down", VK_DOWN }, { "Left", VK_LEFT },
    { "Right", VK_RIGHT }, { "Insert", VK_INSERT }, { "Delete", VK_DELETE }, { "Home", VK_HOME }, { "End", VK_END },
    { "PageUp", VK_PRIOR }, { "PageDown", VK_NEXT },
  };
  auto it = named.find(n);
  return it == named.end() ? 0 : it->second;
}

void ResolveBindings(Address controller, ULONGLONG now) {
  if (now - g_bi.bindingsAt < 1000 || !controller) return;
  g_bi.bindingsAt = now;
  const std::int32_t piAt = PropertyOffset(ClassOf(controller), "PlayerInput");
  if (!piAt) return;
  const Address input = Read<Address>(controller + piAt);
  if (!input) return;
  const TArray mappings = Read<TArray>(input + kActionMappingsAt);
  if (!mappings.data || mappings.count <= 0 || mappings.count > 4096) return;
  std::vector<std::uint8_t> raw(static_cast<std::size_t>(mappings.count) * kMappingSize);
  if (!g_memory.ReadRaw(mappings.data, raw.data(), raw.size())) return;
  int drop = 0, transfer = 0, use = 0;
  Reflection& names = MainReflection();
  for (int i = 0; i < mappings.count; ++i) {
    const std::uint8_t* e = raw.data() + i * kMappingSize;
    std::int32_t actionId, keyId;
    std::memcpy(&actionId, e, 4);
    std::memcpy(&keyId, e + 8, 4);
    const std::string& action = names.Name(actionId);
    const int vk = KeyNameToVk(names.Name(keyId));
    if (!vk) continue;
    if (!drop && (action == "DropItem" || action == "DropCurrentItem" || action == "DropHeldItem" || action == "Drop" ||
                  action == "DropItemFromInventory"))
      drop = vk;
    if (!transfer && action == "TransferItem") transfer = vk;
    if (!use && (action == "UseItem" || action == "Use" || action == "InteractUse" || action == "InteractObject")) use = vk;
  }
  if (drop) g_shared.vk[0] = drop;
  if (transfer) g_shared.vk[1] = transfer;
  if (use) g_shared.vk[2] = use;
}

// ---- inventory search boxes: typing changes a DataListPanel's NameFilter ----
void PanelScan(std::uint32_t generation) {
  Reflection reflection;
  std::unordered_map<Address, bool> isPanel;
  std::vector<Address> found;
  ForEachObject([&](Address object, std::int32_t) {
    if (g_scanGeneration != generation) return false;
    const Address cls = Read<Address>(object + offsets::object::kClass);
    if (!cls) return true;
    auto it = isPanel.find(cls);
    if (it == isPanel.end()) it = isPanel.emplace(cls, reflection.IsA(cls, "DataListPanel")).first;
    if (!it->second) return true;
    if (Read<std::uint32_t>(object + offsets::object::kFlags) & 0x10) return true;  // class default object
    found.push_back(object);
    return found.size() < 512;
  });
  {
    std::lock_guard<std::mutex> lock(g_bi.panelMutex);
    g_bi.panelFound = std::move(found);
    g_bi.panelFresh = true;
  }
  g_bi.panelBusy = false;
}

std::uint32_t FilterHash(Address panel) {
  static std::unordered_map<Address, std::int32_t> at;
  const Address cls = ClassOf(panel);
  auto it = at.find(cls);
  if (it == at.end()) {
    const std::int32_t off = PropertyOffset(cls, "NameFilter");
    it = at.emplace(cls, off ? off : kNameFilterAt).first;
  }
  const TArray text = Read<TArray>(panel + it->second);
  if (!text.data || text.count <= 0 || text.count > 4096) return 0;
  wchar_t chars[64];
  const int n = text.count > 64 ? 64 : text.count;
  if (!g_memory.ReadRaw(text.data, chars, n * sizeof(wchar_t))) return 0;
  std::uint32_t h = 2166136261u;
  for (int i = 0; i < n; ++i) h = (h ^ static_cast<std::uint16_t>(chars[i])) * 16777619u;
  return h;
}

void TickSearch(ULONGLONG now, bool justOpened) {
  if ((justOpened || now - g_bi.panelsAt > 10000) && !g_bi.panelBusy) {
    g_bi.panelsAt = now;
    g_bi.panelBusy = true;
    std::thread(PanelScan, g_scanGeneration.load()).detach();
  }
  {
    std::lock_guard<std::mutex> lock(g_bi.panelMutex);
    if (g_bi.panelFresh) {
      g_bi.panelFresh = false;
      std::unordered_map<Address, std::uint32_t> rebuilt;
      for (Address p : g_bi.panelFound) {
        auto old = g_bi.panels.find(p);
        rebuilt[p] = old == g_bi.panels.end() ? 0xFFFFFFFFu : old->second;
      }
      g_bi.panels.swap(rebuilt);
    }
  }
  for (auto& [panel, hash] : g_bi.panels) {
    const std::uint32_t h = FilterHash(panel);
    if (hash != 0xFFFFFFFFu && hash != h) g_bi.lastTypedMs = now;
    hash = h;
  }

  if (g_bi.lastTypedMs && now - g_bi.lastTypedMs < 200) g_bi.searchFocused = true;
  const bool lmb = KeyDown(VK_LBUTTON);
  if (lmb && !g_bi.prevLmb) {
    g_bi.lastLmbMs = now;
    g_bi.typedAtClick = g_bi.lastTypedMs;
  }
  g_bi.prevLmb = lmb;
  if (g_bi.lastLmbMs && now - g_bi.lastLmbMs > 600) {
    if (g_bi.lastTypedMs == g_bi.typedAtClick) g_bi.searchFocused = false;  // clicked away without typing
    g_bi.lastLmbMs = 0;
  }
  const bool esc = KeyDown(VK_ESCAPE);
  if (esc && !g_bi.prevEsc) g_bi.searchFocused = false;
  g_bi.prevEsc = esc;
}

std::string VkName(int vk) {
  if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) return std::string(1, static_cast<char>(vk));
  char buf[8];
  std::snprintf(buf, sizeof(buf), "0x%02X", vk);
  return buf;
}

}  // namespace

void TickBetterInput(const GameContext& game, const MiscSettings& s, bool restoring) {
  if (!s.betterInput.on || restoring || !g_process.IsAttached()) {
    if (g_shared.thread.joinable()) StopThread();
    g_bi.wasOpen = false;
    g_bi.searchFocused = false;
    g_diag.betterInput = "off";
    return;
  }
  FindTables();
  if (g_bi.sigState == 1) {
    g_diag.betterInput = "looking for the key tables";
    return;
  }
  if (g_bi.sigState == 3) {
    g_diag.betterInput = "key tables not found (signature)";
    return;
  }
  if (!StartThread()) {
    g_diag.betterInput = "couldn't start";
    return;
  }

  const ULONGLONG now = GetTickCount64();
  if (now - g_bi.windowAt > 1000) {
    g_bi.windowAt = now;
    const GameWindow window = FindGameWindow(g_process.pid);
    g_shared.content = window.content;
    g_shared.root = window.root;
  }
  ResolveBindings(game.controller, now);

  const bool open = InventoryOpen(game);
  if (!open) {
    g_bi.wasOpen = false;
    g_bi.searchFocused = false;
  } else {
    TickSearch(now, !g_bi.wasOpen);
    g_bi.wasOpen = true;
  }
  const bool menu = IsAppWindowVisible() && GetForegroundWindow() != g_shared.root.load() &&
                    GetForegroundWindow() != g_shared.content.load();
  g_shared.active = open && !g_bi.searchFocused && !menu;

  const std::string keys = "drop " + VkName(g_shared.vk[0]) + ", transfer " + VkName(g_shared.vk[1]) + ", use " + VkName(g_shared.vk[2]);
  g_diag.betterInput = !open ? "ready (" + keys + ")" : g_bi.searchFocused ? "paused: search box in use" : "running (" + keys + ")";
}

void ResetBetterInput() {
  StopThread();
  g_bi.sigState = 0;
  g_bi.sigPid = 0;
  g_bi.sigNow = 0;
  g_bi.sigPrev = 0;
  g_bi.bindingsAt = g_bi.windowAt = 0;
  {
    std::lock_guard<std::mutex> lock(g_bi.panelMutex);
    g_bi.panelFound.clear();
    g_bi.panelFresh = false;
  }
  g_bi.panels.clear();
  g_bi.searchFocused = g_bi.wasOpen = false;
  g_shared.vk[0] = 'O';
  g_shared.vk[1] = 'T';
  g_shared.vk[2] = 'E';
}

}  // namespace wintek
