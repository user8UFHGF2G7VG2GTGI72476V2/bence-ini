#pragma once
#include <algorithm>
#include <cmath>

namespace wintek {
struct SnapFootprint { float minX=0,maxX=0,minY=0,maxY=0; };
struct SnapLocalTransform { float position[3]={},rotation[3]={},scale[3]={1,1,1}; };

inline bool FootprintFromLocalBox(const float minimum[3],const float maximum[3],
                                  const SnapLocalTransform* chain,int count,const float rootScale[3],SnapFootprint& out) {
  if(count<0||count>16||(!chain&&count))return false;
  for(int i=0;i<3;++i)if(!std::isfinite(minimum[i])||!std::isfinite(maximum[i])||maximum[i]<=minimum[i]||
    !std::isfinite(rootScale[i])||rootScale[i]<=0)return false;
  for(int n=0;n<count;++n)for(int i=0;i<3;++i)if(!std::isfinite(chain[n].position[i])||!std::isfinite(chain[n].rotation[i])||
    !std::isfinite(chain[n].scale[i])||chain[n].scale[i]<=0)return false;
  out={INFINITY,-INFINITY,INFINITY,-INFINITY};
  constexpr float rad=3.14159265359f/180.0f;
  for(int corner=0;corner<8;++corner) {
    float p[3]={corner&1?maximum[0]:minimum[0],corner&2?maximum[1]:minimum[1],corner&4?maximum[2]:minimum[2]};
    for(int n=0;n<count;++n) {
      const auto& t=chain[n];
      const float sp=std::sin(t.rotation[0]*rad),cp=std::cos(t.rotation[0]*rad);
      const float sy=std::sin(t.rotation[1]*rad),cy=std::cos(t.rotation[1]*rad);
      const float sr=std::sin(t.rotation[2]*rad),cr=std::cos(t.rotation[2]*rad);
      const float x=p[0]*t.scale[0],y=p[1]*t.scale[1],z=p[2]*t.scale[2];
      p[0]=t.position[0]+x*cp*cy+y*(sr*sp*cy-cr*sy)-z*(cr*sp*cy+sr*sy);
      p[1]=t.position[1]+x*cp*sy+y*(sr*sp*sy+cr*cy)+z*(cy*sr-cr*sp*sy);
      p[2]=t.position[2]+x*sp-y*sr*cp+z*cr*cp;
    }
    p[0]*=rootScale[0];p[1]*=rootScale[1];
    if(!std::isfinite(p[0])||!std::isfinite(p[1]))return false;
    out.minX=(std::min)(out.minX,p[0]);out.maxX=(std::max)(out.maxX,p[0]);
    out.minY=(std::min)(out.minY,p[1]);out.maxY=(std::max)(out.maxY,p[1]);
  }
  return out.maxX>out.minX&&out.maxY>out.minY;
}

inline bool DockVault(float position[3],float rotation[3],const float anchor[3],float yaw,
                      const SnapFootprint& target,const SnapFootprint& child,float gap) {
  const float values[]={position[0],position[1],position[2],rotation[0],rotation[1],rotation[2],
    anchor[0],anchor[1],anchor[2],yaw,target.minX,target.maxX,target.minY,target.maxY,
    child.minX,child.maxX,child.minY,child.maxY,gap};
  for (float v:values) if (!std::isfinite(v)) return false;
  if (target.maxX<=target.minX || target.maxY<=target.minY || child.maxX<=child.minX || child.maxY<=child.minY || gap<0) return false;
  constexpr float rad=3.14159265359f/180.0f;
  const float c=std::cos(yaw*rad),s=std::sin(yaw*rad);
  const float dx=position[0]-anchor[0],dy=position[1]-anchor[1];
  const float x=c*dx+s*dy,y=-s*dx+c*dy;
  const float cx=(target.minX+target.maxX-child.minX-child.maxX)*0.5f;
  const float cy=(target.minY+target.maxY-child.minY-child.maxY)*0.5f;
  const float candidates[4][2]={{target.maxX-child.minX+gap,cy},{target.minX-child.maxX-gap,cy},
    {cx,target.maxY-child.minY+gap},{cx,target.minY-child.maxY-gap}};
  int best=0;float distance=INFINITY;
  for (int i=0;i<4;++i) {
    const float ex=x-candidates[i][0],ey=y-candidates[i][1],d=ex*ex+ey*ey;
    if (d<distance) { distance=d;best=i; }
  }
  position[0]=anchor[0]+c*candidates[best][0]-s*candidates[best][1];
  position[1]=anchor[1]+s*candidates[best][0]+c*candidates[best][1];
  rotation[1]=std::remainder(yaw,360.0f);
  return true;
}

// Recover an actor-local upright footprint from world-axis bounds at a known yaw.
// At 45 degrees the inverse is singular: refuse rather than guess the dimensions.
inline bool FootprintFromWorldBounds(const float position[3],float yaw,const float center[3],const float extent[3],SnapFootprint& out) {
  for(int i=0;i<3;++i) if(!std::isfinite(position[i])||!std::isfinite(center[i])||!std::isfinite(extent[i])||extent[i]<=0) return false;
  if(!std::isfinite(yaw)) return false;
  constexpr float rad=3.14159265359f/180.0f;
  const float c=std::cos(yaw*rad),s=std::sin(yaw*rad),ac=std::fabs(c),as=std::fabs(s),det=ac*ac-as*as;
  if(std::fabs(det)<0.1f) return false;
  const float ex=(ac*extent[0]-as*extent[1])/det,ey=(ac*extent[1]-as*extent[0])/det;
  if(ex<1||ey<1||ex>5000||ey>5000) return false;
  const float dx=center[0]-position[0],dy=center[1]-position[1],cx=c*dx+s*dy,cy=-s*dx+c*dy;
  if(std::fabs(cx)>5000||std::fabs(cy)>5000) return false;
  out={cx-ex,cx+ex,cy-ey,cy+ey};return true;
}

inline bool AlignSnapGrid(float position[3], float rotation[3], const float origin[3], float yaw, int spacingCm, int angleDegrees) {
  for (int i=0; i<3; ++i)
    if (!std::isfinite(position[i]) || !std::isfinite(rotation[i]) || !std::isfinite(origin[i])) return false;
  if (!std::isfinite(yaw)) return false;
  constexpr float rad=3.14159265359f/180.0f;
  const float c=std::cos(yaw*rad), s=std::sin(yaw*rad);
  const float dx=position[0]-origin[0], dy=position[1]-origin[1];
  const float spacing=static_cast<float>(std::clamp(spacingCm,10,600));
  const float x=std::round((c*dx+s*dy)/spacing)*spacing;
  const float y=std::round((-s*dx+c*dy)/spacing)*spacing;
  position[0]=origin[0]+c*x-s*y; position[1]=origin[1]+s*x+c*y;
  const float step=static_cast<float>(std::clamp(angleDegrees,5,90));
  const float delta=std::remainder(rotation[1]-yaw,360.0f);
  rotation[1]=std::remainder(yaw+std::round(delta/step)*step,360.0f);
  return std::isfinite(position[0]) && std::isfinite(position[1]) && std::isfinite(rotation[1]);
}
}
