#pragma once
#include <algorithm>
#include <cmath>
#include <limits>
namespace wintek {
inline int ChemDeficit(int target,int available) {
 return target>0&&available>=0 ? (std::max)(0,target-available) : 0;
}
inline int ChemMaterialTarget(float base,float multiplier,int batches) {
 const double n=std::ceil(static_cast<double>(base)*multiplier)*batches;
 return base>0&&multiplier>0&&batches>0&&std::isfinite(n)&&n<=1000000 ? static_cast<int>(n) : 0;
}
inline bool ChemCanQueue(bool accessible,bool powered,bool active,int queued,int target,bool resources) {
 return accessible&&powered&&active&&queued>=0&&queued<target&&target>0&&resources;
}
}
