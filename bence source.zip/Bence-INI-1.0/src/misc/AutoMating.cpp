#include "misc/AutoMating.h"
#include "misc/MatingPolicy.h"
#include "engine/Debugger.h"
#include "core/Process.h"
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <mutex>
#include <unordered_map>

namespace wintek {
namespace {
struct Bit { int at=0; unsigned char mask=0; };
struct Layout { Bit mating,dead,baby,neutered; int team=0,root=0; };
struct Observation { ObjectRef ref; Address cls=0; int index=-1; Bit mating; ULONGLONG at=0; };
std::mutex mutex;
Address controller=0, function=0;
int actorAt=-1,indexAt=-1;
bool observing=false;
Observation observed;
Address world=0,params=0;
std::uint64_t ticket=0;
ULONGLONG scanAt=0,sendAt=0;
std::vector<ObjectRef> dinos;
std::unordered_map<Address,Layout> layouts;
std::unordered_map<Address,int> learned;
std::unordered_map<Address,ULONGLONG> lastSent;
std::string status="off";
int requests=0;

Bit BoolLayout(Reflection& r, Address cls, const char* name) {
  const Address field=r.FindField(cls,name);
  if(!field || r.NameOf(ClassOf(field))!="BoolProperty")return {};
  const int at=Read<int>(field+offsets::reflection::kPropertyOffset)+Read<unsigned char>(field+offsets::reflection::kBoolByteOffset);
  const auto mask=Read<unsigned char>(field+offsets::reflection::kBoolFieldMask);
  if(at<0x20||at>=0x8000||!mask||(mask&(mask-1)))return {};
  return {at,mask};
}
bool GetBit(Address actor,Bit bit,bool& value) {
  unsigned char byte=0;
  if(!bit.at || !g_memory.ReadRaw(actor+bit.at,&byte,1))return false;
  value=(byte&bit.mask)!=0;return true;
}
Layout& ActorLayout(Address cls) {
  auto it=layouts.find(cls);
  if(it!=layouts.end())return it->second;
  auto& r=MainReflection();Layout l;
  l.mating=BoolLayout(r,cls,"bEnableTamedMating");l.dead=BoolLayout(r,cls,"bIsDead");
  l.baby=BoolLayout(r,cls,"bIsBaby");l.neutered=BoolLayout(r,cls,"bNeutered");
  l.team=r.PropertyOffset(cls,"TargetingTeam");l.root=r.PropertyOffset(cls,"RootComponent");
  return layouts.emplace(cls,l).first->second;
}
bool Location(Address actor,float out[3]) {
  const int rootAt=PropertyOffset(ClassOf(actor),"RootComponent");
  const Address root=rootAt ? Read<Address>(actor+rootAt) : 0;
  const int locAt=root ? PropertyOffset(ClassOf(root),"RelativeLocation") : 0;
  return locAt && g_memory.ReadRaw(root+locAt,out,12) &&
         std::isfinite(out[0])&&std::isfinite(out[1])&&std::isfinite(out[2]);
}
bool Eligible(const ObjectRef& ref,int team,const float me[3],float rangeSquared,bool needLearned) {
  if(!ref.Alive())return false;
  const Address actor=ref.object,cls=ClassOf(actor);
  if(!IsA(cls,"PrimalDinoCharacter"))return false;
  const auto l=ActorLayout(cls);
  bool enabled=false,dead=false,baby=false,neutered=false;
  // Missing eligibility properties are not treated as permission to send an action.
  const bool readable=GetBit(actor,l.mating,enabled)&&GetBit(actor,l.dead,dead)&&
                      GetBit(actor,l.baby,baby)&&GetBit(actor,l.neutered,neutered);
  const bool own=l.team && Read<int>(actor+l.team)==team;
  float pos[3];if(!Location(actor,pos))return false;
  float distance=0;for(int i=0;i<3;++i)distance+=(pos[i]-me[i])*(pos[i]-me[i]);
  return MayEnableMating(own,!dead,!baby,neutered,enabled,readable,
                        !needLearned||learned.count(cls)!=0,distance,rangeSquared);
}
void Scan(Address gameWorld) {
  dinos.clear();
  const TArray levels=Read<TArray>(gameWorld+offsets::world::kLevels);
  if(!levels.data||levels.count<1||levels.count>2048)return;
  for(int n=0;n<levels.count;++n) {
    const Address level=Read<Address>(levels.data+n*sizeof(Address));if(!level)continue;
    const TArray actors=Read<TArray>(level+offsets::world::kLevelActors);
    if(!actors.data||actors.count<1||actors.count>200000)continue;
    std::vector<Address> all(actors.count);
    if(!g_memory.ReadRaw(actors.data,all.data(),all.size()*sizeof(Address)))continue;
    for(Address actor:all) {
      if(!actor)continue;
      const unsigned int flags=Read<unsigned int>(actor+offsets::object::kFlags);
      if(flags&(0x30|0x100|0x4000|0x8000|0x10000))continue;
      const Address cls=ClassOf(actor);
      if(cls && IsA(cls,"PrimalDinoCharacter"))dinos.push_back(ObjectRef::Of(actor));
      if(dinos.size()>=8192)return;
    }
  }
}
int Param(Address fn,const char* name,const char* type,int bytes) {
  const Address field=MainReflection().FindField(fn,name);
  if(!field||NameOf(ClassOf(field))!=type)return -1;
  const int at=Read<int>(field+offsets::reflection::kPropertyOffset);
  return at>=0&&at+bytes<=64 ? at : -1;
}
}

// Called by the existing shared outgoing-RPC observer, before the game sends the request.
void ObserveMatingRequest(Address pc,Address fn,Address buffer) {
  std::lock_guard<std::mutex> lock(mutex);
  if(!observing||pc!=controller||fn!=function||!buffer||actorAt<0||indexAt<0)return;
  const Address actor=Read<Address>(buffer+actorAt);
  const int index=Read<int>(buffer+indexAt);
  if(!actor||index<0)return;
  Reflection r;const Address cls=ClassOf(actor);
  if(!cls||!r.IsA(cls,"PrimalDinoCharacter"))return;
  Bit mating=BoolLayout(r,cls,"bEnableTamedMating");
  bool enabled=false;
  // Only a false -> true server replication can establish the enable action.
  if(!GetBit(actor,mating,enabled)||enabled)return;
  observed={ObjectRef::Of(actor),cls,index,mating,GetTickCount64()};
}

void TickAutoMating(const GameContext& game,const MiscSettings& s,bool restoring) {
  const bool wanted=s.autoMating.on&&!restoring&&game.pawn&&game.world&&game.controller;
  RequestDebugger(DebuggerClient::AutoMating,wanted);
  if(!wanted) {
    std::lock_guard<std::mutex> lock(mutex);observing=false;observed={};status="off";return;
  }
  if(world!=game.world) {
    ResetAutoMating();world=game.world;RequestDebugger(DebuggerClient::AutoMating,true);
  }
  const Address fn=MainReflection().FindField(ClassOf(game.controller),"ServerMultiUse");
  const int a=fn ? Param(fn,"UseActor","ObjectProperty",8) : -1;
  const int i=fn ? Param(fn,"UseIndex","IntProperty",4) : -1;
  if(!fn||a<0||i<0||!(a+8<=i||i+4<=a)) {status="Mating action unavailable on this game build";return;}
  {
    std::lock_guard<std::mutex> lock(mutex);
    controller=game.controller;function=fn;actorAt=a;indexAt=i;observing=true;
  }
  const int teamAt=PropertyOffset(ClassOf(game.pawn),"TargetingTeam");
  const int team=teamAt ? Read<int>(game.pawn+teamAt) : 0;
  float me[3];if(team<50000||!Location(game.pawn,me)) {status="Waiting for your character";return;}
  const ULONGLONG now=GetTickCount64();
  const float range=static_cast<float>(std::clamp(s.matingRange,1,15))*100.0f;
  Observation sample;
  {std::lock_guard<std::mutex> lock(mutex);sample=observed;}
  if(sample.ref.object) {
    bool enabled=false;
    if(!sample.ref.Alive()||ClassOf(sample.ref.object)!=sample.cls||now-sample.at>3000) {
      std::lock_guard<std::mutex> lock(mutex);if(observed.at==sample.at)observed={};
    } else if(GetBit(sample.ref.object,sample.mating,enabled)&&enabled) {
      // Verify ownership and adulthood after replication as well as at send time.
      const auto l=ActorLayout(sample.cls);bool dead=true,baby=true,neutered=true;
      if(l.team&&Read<int>(sample.ref.object+l.team)==team&&GetBit(sample.ref.object,l.dead,dead)&&!dead&&
         GetBit(sample.ref.object,l.baby,baby)&&!baby&&GetBit(sample.ref.object,l.neutered,neutered)&&!neutered)
        learned[sample.cls]=sample.index;
      std::lock_guard<std::mutex> lock(mutex);if(observed.at==sample.at)observed={};
    }
  }
  if(!scanAt||now-scanAt>=2000) {scanAt=now;Scan(game.world);}
  status=learned.empty() ? "Enable mating once on an adult tribe dino to learn its action" :
    "Dino types learned: "+std::to_string(learned.size())+" | Requests sent: "+std::to_string(requests);
  if(!DebuggerAttached()||learned.empty()||now-sendAt<500||
     (ticket&&CompletedCalls()<ticket))return;
  if(game.hud&&Read<Address>(game.hud+offsets::hud::kOpenInventory))return;
  for(const auto& ref:dinos) {
    if(!Eligible(ref,team,me,range*range,true))continue;
    const auto prior=lastSent.find(ref.object);
    if(prior!=lastSent.end()&&now-prior->second<10000)continue;
    if(!params)params=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,64,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
    if(!params) {status="Could not allocate action parameters";return;}
    unsigned char block[64]={};const Address actor=ref.object;const int action=learned.at(ClassOf(actor));
    std::memcpy(block+a,&actor,8);std::memcpy(block+i,&action,4);
    if(!g_memory.WriteRaw(params,block,sizeof(block)))return;
    ticket=QueueProcessEvent(game.controller,fn,params);
    if(ticket) {lastSent[actor]=now;sendAt=now;++requests;}
    break;
  }
  if(lastSent.size()>16384)lastSent.clear();
}
void ResetAutoMating() {
  RequestDebugger(DebuggerClient::AutoMating,false);
  {std::lock_guard<std::mutex> lock(mutex);observing=false;controller=function=0;actorAt=indexAt=-1;observed={};}
  world=params=0;ticket=0;scanAt=sendAt=0;dinos.clear();layouts.clear();learned.clear();lastSent.clear();requests=0;status="off";
}
const char* AutoMatingStatus() {return status.c_str();}
}
