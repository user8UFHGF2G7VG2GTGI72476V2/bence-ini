#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"
#include <string>
#include <vector>

// Turret Filler (Misc tab). Walk along your tribe's heavy / Tek turrets and they are topped up from your
// inventory: advanced rifle bullets into heavies, element shards into Tek turrets, up to the amounts set on the
// Misc tab. Ported from TurretFiller.h. It uses the game's ordinary transfer
// (ServerTransferToRemoteInventory), so it only moves what you carry, only into turrets you could open
// yourself, and ARK's own reach check (RemoteInventoryAllowViewing) decides what's close enough.
//
// The calls run on the game thread through the debugger's per-frame breakpoint (engine/Debugger.h), the same
// way Low Memory changes settings, so the debugger stays attached while the filler is on.
//
// Show Turret Fill: a marker on each of your turrets within the Turret Range (20 - 700 m): green full,
// red short with the amount, amber unknown, plus totals. Far turrets are judged from the replicated stack count
// (CurrentItemCount) x the stack size; a turret checked up close uses that exact count for 15 s.
namespace wintek {

struct TurretMarker {
  float position[3];
  bool tek;
  int have;    // -1 unknown
  int target;
  bool exact;  // counted up close
};

struct TurretOverlay {
  std::vector<TurretMarker> markers;  // your turrets within range
  int heavyTotal = 0, heavyFull = 0, tekTotal = 0, tekFull = 0;
  std::wstring warning;               // "no element shards on you", shown for a few seconds
  unsigned long long warningUntil = 0;
};

void TickTurretFiller(const GameContext& game, const MiscSettings& settings, bool restoring);
const TurretOverlay& TurretFill();
void ResetTurretFiller();

}  // namespace wintek
