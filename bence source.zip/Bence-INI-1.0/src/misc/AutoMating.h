#pragma once
#include "engine/Engine.h"
#include "core/Settings.h"
namespace wintek {
void TickAutoMating(const GameContext&, const MiscSettings&, bool restoring);
void ResetAutoMating();
void ObserveMatingRequest(Address controller, Address function, Address params);
const char* AutoMatingStatus();
}
