#pragma once
#include "engine/Engine.h"
namespace wintek {
struct InventoryPullClick {
 ObjectRef item;
 int quantity=0;
 bool toPlayer=false;
};
// ARK-owned UMG controls, attached only while its inventory is open.
bool TickNativeInventoryPull(const GameContext&,Address inventoryUI,bool busy,InventoryPullClick&);
void CloseNativeInventoryPull();
void ResetNativeInventoryPull();
void NativeInventoryPullMessage(const std::wstring&);
}
