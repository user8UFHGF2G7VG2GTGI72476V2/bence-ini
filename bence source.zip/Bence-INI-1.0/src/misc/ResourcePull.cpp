#include "misc/ResourcePull.h"
#include "misc/Automation.h"
#include "misc/AutoChemBench.h"
#include "misc/NativeInventoryPull.h"
#include "misc/PullPolicy.h"
#include "engine/Debugger.h"
#include "core/Process.h"
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <cwchar>
namespace wintek {
namespace {
constexpr int kBuffer=128;
struct Field {int at=-1; int bytes=0; std::string kind;};
struct Call {
 Address fn=0;std::unordered_map<std::string,Field> fields;
 int At(const char* name,int bytes,const char* kind)const {
  auto it=fields.find(ToLower(name));
  return it!=fields.end()&&it->second.bytes==bytes&&it->second.kind==kind ? it->second.at : -1;
 }
 bool Has(const char* name,int bytes,const char* kind)const {return At(name,bytes,kind)>=0;}
};
Call Resolve(Address cls,const char* name) {
 Call c;c.fn=MainReflection().FindField(cls,name);if(!c.fn)return c;
 Address field=Read<Address>(c.fn+offsets::reflection::kChildren);
 for(int n=0;field&&n<128;field=Read<Address>(field+offsets::reflection::kNext),++n) {
  int at=Read<int>(field+offsets::reflection::kPropertyOffset);
  int bytes=Read<int>(field+0x34); // UProperty::ElementSize
  if(at<0||bytes<1||at+bytes>kBuffer)continue;
  c.fields.emplace(ToLower(NameOf(field)),Field{at,bytes,NameOf(ClassOf(field))});
 }
 return c;
}
struct Stack {ObjectRef ref;Address cls=0;std::uint64_t id=0;int qty=0;bool recipe=false;};
struct Requirement {Address cls=0;float base=0;bool exact=false;};
bool Bool(Address object,const char* name,bool& result) {
 Address f=MainReflection().FindField(ClassOf(object),name);
 if(!f||NameOf(ClassOf(f))!="BoolProperty")return false;
 int at=Read<int>(f+offsets::reflection::kPropertyOffset)+Read<unsigned char>(f+offsets::reflection::kBoolByteOffset);
 auto mask=Read<unsigned char>(f+offsets::reflection::kBoolFieldMask);unsigned char v=0;
 if(at<0x20||at>0x8000||!mask||!g_memory.ReadRaw(object+at,&v,1))return false;
 result=(v&mask)!=0;return true;
}
Address Object(Address actor,const char* name) {
 const int at=PropertyOffset(ClassOf(actor),name);return at ? Read<Address>(actor+at) : 0;
}
bool Location(Address actor,float out[3]) {
 Address root=Object(actor,"RootComponent");int at=root ? PropertyOffset(ClassOf(root),"RelativeLocation") : 0;
 return at&&g_memory.ReadRaw(root+at,out,12)&&std::isfinite(out[0])&&std::isfinite(out[1])&&std::isfinite(out[2]);
}
bool ClassMatches(Address cls,Address target,bool exact=false) {
 for(int n=0;cls&&n<64;cls=Read<Address>(cls+offsets::reflection::kSuperStruct),++n) {
  if(cls==target)return true;if(exact)return false;
 }
 return false;
}
bool Snapshot(Address inv,std::vector<Stack>& out) {
 out.clear();bool receiving=false;if(Bool(inv,"bReceivingInventoryItems",receiving)&&receiving)return false;
 const int at=PropertyOffset(ClassOf(inv),"InventoryItems");if(!at)return false;
 TArray array{};if(!g_memory.ReadRaw(inv+at,&array,sizeof(array))||array.count<0||array.count>20000||array.max<array.count)return false;
 if(!array.count)return true;if(!array.data)return false;
 std::vector<Address> items(array.count);
 if(!g_memory.ReadRaw(array.data,items.data(),items.size()*sizeof(Address)))return false;
 for(Address item:items) {
  if(!item)continue;
  const ObjectRef ref=ObjectRef::Of(item);if(!ref.Alive())continue;
  const Address cls=ClassOf(item);if(!IsA(cls,"PrimalItem"))continue;
  bool blueprint=false,engram=false;
  if(!Bool(item,"bIsBlueprint",blueprint)||!Bool(item,"bIsEngram",engram))return false;
  const int q=PropertyOffset(cls,"ItemQuantity"),id=PropertyOffset(cls,"ItemId");
  if(!q||!id)return false;
  int qty=Read<int>(item+q);auto net=Read<std::uint64_t>(item+id);
  if(qty<0||qty>10000000)return false;
  out.push_back({ref,cls,net,qty,blueprint||engram});
 }
 return true;
}
int Count(const std::vector<Stack>& items,Address cls,bool exact=false) {
 long long n=0;for(const auto& s:items)if(!s.recipe&&ClassMatches(s.cls,cls,exact))n+=s.qty;
 return static_cast<int>((std::min)(n,10000000LL));
}
int StructField(Address type,const char* name,int bytes,int stride) {
 const Address f=MainReflection().FindField(type,name);if(!f)return -1;
 const int at=Read<int>(f+offsets::reflection::kPropertyOffset),size=Read<int>(f+0x34);
 return at>=0&&size==bytes&&at+bytes<=stride ? at : -1;
}
bool Requirements(Address item,std::vector<Requirement>& out) {
 out.clear();Address cls=ClassOf(item);
 for(const char* name:{"CustomResourceRequirements","BaseCraftingResourceRequirements"}) {
  const Address field=MainReflection().FindField(cls,name);
  if(!field||NameOf(ClassOf(field))!="ArrayProperty")continue;
  const int at=Read<int>(field+offsets::reflection::kPropertyOffset);
  if(at<0x20||at>0x8000)return false;
  const auto array=Read<TArray>(item+at);if(!array.count)continue;
  if(!array.data||array.count<1||array.count>32)return false;
  const Address inner=Read<Address>(field+0x70);
  if(!inner||NameOf(ClassOf(inner))!="StructProperty")return false;
  const int stride=Read<int>(inner+0x34);
  const Address type=Read<Address>(inner+0x70);
  if(!type||NameOf(type)!="CraftingResourceRequirement"||stride<16||stride>128)return false;
  const int resource=StructField(type,"ResourceItemType",8,stride),base=StructField(type,"BaseResourceRequirement",4,stride);
  const int exact=StructField(type,"bCraftingRequireExactResourceType",1,stride);
  if(resource<0||base<0||exact<0)return false;
  const int group=StructField(type,"GroupId",4,stride),multiple=StructField(type,"ForceMultipleResourceTypesRequirement",4,stride);
  for(int i=0;i<array.count;++i) {
   Address row=array.data+static_cast<Address>(i)*stride;
   if((group>=0&&Read<int>(row+group)>0)||(multiple>=0&&Read<int>(row+multiple)>0))return false;
   Requirement r{Read<Address>(row+resource),Read<float>(row+base),Read<unsigned char>(row+exact)!=0};
   if(!r.cls||!IsA(r.cls,"PrimalItem")||!std::isfinite(r.base)||r.base<=0||r.base>1000000)return false;
   out.push_back(r);
  }
  return !out.empty();
 }
 return false;
}

struct Destination {ObjectRef actor,inv;std::wstring label;bool player=false;};
struct Target {Requirement requirement;int total=0,budget=0,delivered=0;};
std::vector<Destination> destinations;
Address uiRoot=0,world=0;
ULONGLONG scanned=0,recipesAt=0;
bool wasOpen=false,requestPull=false,requestRefresh=false,requestCancel=false;
std::wstring message=L"Select a recipe and press PULL, or select an item and press GET.";
enum class Phase {Idle,Start,DestAllow,DestView,DestRequest,DestWait,Costs,Destination,SourceAllow,SourceView,SourceRequest,SourceWait,Action,SourceClose,Finish,DestClose};
enum class Operation {None,Take,Put};
Phase phase=Phase::Idle;Operation operation=Operation::None;
Destination jobDest,currentSource;
ObjectRef jobRecipe;
std::vector<Destination> sources;
std::vector<Requirement> requirements;
std::vector<Target> targets;
std::unordered_set<Address> exhausted;
Call allow,view,request,close,to,from,cost;
Address params=0,controller=0;
std::uint64_t ticket=0;
ULONGLONG phaseAt=0,lastSent=0;
bool destViewed=false,sourceViewed=false,closeDestination=false,refreshOnly=false,stop=false;
int jobCrafts=1,activeTarget=-1,amount=0,destBefore=0,sourceBefore=0,playerBefore=0,added=0;
Address transferClass=0;
std::wstring finishMessage;
ObjectRef selectedNativeItem;
bool requestDirect=false,jobDirect=false;
int nativeQuantity=1;

Address WeakObject(Address at) {
 int index=Read<int>(at),serial=Read<int>(at+4);if(index<0||serial<=0||index>=Read<int>(GObjects()+offsets::kObjectCount))return 0;
 Address chunk=Read<Address>(Read<Address>(GObjects())+(index/offsets::kObjectsPerChunk)*8);if(!chunk)return 0;
 Address entry=chunk+(index%offsets::kObjectsPerChunk)*offsets::kObjectItemSize;
 if(Read<int>(entry+8)!=serial)return 0;Address object=Read<Address>(entry);return object&&ObjectRef::Of(object).Alive()?object:0;
}

std::wstring ClassLabel(Address cls) {
 std::string n=NameOf(cls);
 for(const char* prefix:{"PrimalItemResource_","PrimalItemConsumable_","PrimalItemStructure_","PrimalItemArmor_","PrimalItem_"}) {
  if(n.rfind(prefix,0)==0) {n.erase(0,std::strlen(prefix));break;}
 }
 if(n.size()>2&&n.substr(n.size()-2)=="_C")n.resize(n.size()-2);
 std::replace(n.begin(),n.end(),'_', ' ');return {n.begin(),n.end()};
}
std::wstring Label(Address object) {
 for(const char* name:{"DescriptiveNameBase","DescriptiveName","CustomName"}) {
  int at=PropertyOffset(ClassOf(object),name);if(!at)continue;
  TArray text=Read<TArray>(object+at);
  if(!text.data||text.count<2||text.count>256)continue;
  std::wstring value(text.count,L'\0');
  if(g_memory.ReadRaw(text.data,value.data(),value.size()*sizeof(wchar_t))) {auto end=value.find(L'\0');if(end!=std::wstring::npos)value.resize(end);return value;}
 }
 return ClassLabel(ClassOf(object));
}
int Team(Address object) {int at=PropertyOffset(ClassOf(object),"TargetingTeam");return at?Read<int>(object+at):0;}
bool ValidDestination(const Destination& d,const GameContext& game,int range) {
 if(!d.inv.Alive()||!d.actor.Alive()||!IsA(ClassOf(d.inv.object),"PrimalInventoryComponent"))return false;
 if(d.player)return d.actor.object==game.pawn&&Object(game.pawn,"MyInventoryComponent")==d.inv.object;
 bool dead=true;
 if(!IsA(ClassOf(d.actor.object),"PrimalStructureItemContainer")||Team(game.pawn)<50000||Team(d.actor.object)!=Team(game.pawn)||
    !Bool(d.actor.object,"bIsDead",dead)||dead||Object(d.actor.object,"MyInventoryComponent")!=d.inv.object)return false;
 float me[3],pos[3];if(!Location(game.pawn,me)||!Location(d.actor.object,pos))return false;
 float distance=0;for(int i=0;i<3;++i)distance+=(me[i]-pos[i])*(me[i]-pos[i]);
 return distance<=static_cast<float>(range*range)*10000;
}
void Scan(const GameContext& game,const MiscSettings& settings) {
 std::vector<Destination> found;Address player=Object(game.pawn,"MyInventoryComponent");
 if(player&&ObjectRef::Of(player).Alive())found.push_back({ObjectRef::Of(game.pawn),ObjectRef::Of(player),L"Your inventory",true});
 int team=Team(game.pawn);float me[3];
 if(team>=50000&&Location(game.pawn,me)) {
  auto levels=Read<TArray>(game.world+offsets::world::kLevels);
  if(levels.data&&levels.count>0&&levels.count<=2048)for(int n=0;n<levels.count;++n) {
   Address level=Read<Address>(levels.data+n*sizeof(Address));if(!level)continue;
   auto actors=Read<TArray>(level+offsets::world::kLevelActors);
   if(!actors.data||actors.count<1||actors.count>200000)continue;
   std::vector<Address> all(actors.count);if(!g_memory.ReadRaw(actors.data,all.data(),all.size()*sizeof(Address)))continue;
   for(Address actor:all) {
    if(!actor||found.size()>=2048)continue;
    if(Read<unsigned int>(actor+offsets::object::kFlags)&(0x30|0x100|0x4000|0x8000|0x10000))continue;
    if(!IsA(ClassOf(actor),"PrimalStructureItemContainer"))continue;
    Address inv=Object(actor,"MyInventoryComponent");if(!inv)continue;
    Destination d{ObjectRef::Of(actor),ObjectRef::Of(inv),Label(actor),false};
    if(!ValidDestination(d,game,std::clamp(settings.pullRange,1,100)))continue;
    float pos[3];if(Location(actor,pos)) {
     float d2=0;for(int j=0;j<3;++j)d2+=(pos[j]-me[j])*(pos[j]-me[j]);
     d.label+=L" ["+std::to_wstring(static_cast<int>(std::sqrt(d2)/100))+L" m]";
    }
    found.push_back(std::move(d));
   }
  }
 }
 destinations=std::move(found);
}
void UpdatePanel(const GameContext& game,bool enabled) {
 Address opened=enabled&&game.hud?Read<Address>(game.hud+offsets::hud::kOpenInventory):0;
 if(!opened||!ObjectRef::Of(opened).Alive()) {CloseNativeInventoryPull();wasOpen=false;uiRoot=0;return;}
 if(!wasOpen||uiRoot!=opened) {scanned=0;recipesAt=0;}wasOpen=true;uiRoot=opened;
 RequestDebugger(DebuggerClient::ResourcePull,true);
 if(phase==Phase::Idle&&(!scanned||GetTickCount64()-scanned>=2000)) {scanned=GetTickCount64();Scan(game,g_settings.misc);}
 InventoryPullClick clicked;
 if(TickNativeInventoryPull(game,opened,phase!=Phase::Idle,clicked)) {
  selectedNativeItem=clicked.item;nativeQuantity=clicked.quantity;requestDirect=clicked.toPlayer;requestPull=true;
 }
 NativeInventoryPullMessage(message);
}
template<class T> void Put(unsigned char* block,const Call& c,const char* name,const T& value,const char* kind) {
 int at=c.At(name,sizeof(T),kind);if(at>=0)std::memcpy(block+at,&value,sizeof(T));
}
bool ResolveCalls(Address pc,Address inv) {
 Address cls=ClassOf(pc);allow=Resolve(ClassOf(inv),"RemoteInventoryAllowViewing");
 view=Resolve(cls,"ServerActorViewRemoteInventory");request=Resolve(cls,"ServerRequestActorItems");close=Resolve(cls,"ServerActorCloseRemoteInventory");
 to=Resolve(cls,"ServerTransferToRemoteInventory");from=Resolve(cls,"ServerTransferFromRemoteInventory");
 auto inventory=[](const Call& c){return c.Has("inventoryComp",8,"ObjectProperty");};
 return allow.Has("PC",8,"ObjectProperty")&&allow.Has("ReturnValue",1,"BoolProperty")&&inventory(view)&&inventory(close)&&
 request.Has("forInventory",8,"ObjectProperty")&&request.Has("bInventoryItems",1,"BoolProperty")&&
 inventory(to)&&to.Has("itemID",8,"StructProperty")&&to.Has("requestedQuantity",4,"IntProperty")&&
 inventory(from)&&from.Has("itemID",8,"StructProperty")&&from.Has("requestedQuantity",4,"IntProperty")&&from.Has("ToSlotIndex",4,"IntProperty");
}
bool Send(Address object,const Call& c,const unsigned char* block,ULONGLONG now) {
 if(!object||!c.fn||!DebuggerAttached()||(ticket&&CompletedCalls()<ticket)||now-lastSent<150)return false;
 if(!params)params=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kBuffer*40,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 if(!params||!g_memory.WriteRaw(params,block,kBuffer))return false;
 ticket=QueueProcessEvent(object,c.fn,params);lastSent=phaseAt=now;return ticket!=0;
}
bool InvCall(const Call& c,Address inv,ULONGLONG now) {
 unsigned char block[kBuffer]={};Put(block,c,"inventoryComp",inv,"ObjectProperty");return Send(controller,c,block,now);
}
bool RequestItems(Address inv,ULONGLONG now) {
 unsigned char block[kBuffer]={};Put(block,request,"forInventory",inv,"ObjectProperty");unsigned char yes=1;Put(block,request,"bInventoryItems",yes,"BoolProperty");
 return Send(controller,request,block,now);
}
bool AllowInventory(Address inv,ULONGLONG now) {
 allow=Resolve(ClassOf(inv),"RemoteInventoryAllowViewing");
 if(!allow.Has("PC",8,"ObjectProperty")||!allow.Has("ReturnValue",1,"BoolProperty"))return false;
 unsigned char block[kBuffer]={};Put(block,allow,"PC",controller,"ObjectProperty");return Send(inv,allow,block,now);
}
void End(std::wstring reason) {finishMessage=std::move(reason);phase=Phase::Finish;}
void ClearJob() {
 phase=Phase::Idle;operation=Operation::None;jobDest={};currentSource={};jobRecipe={};sources.clear();targets.clear();requirements.clear();exhausted.clear();
 destViewed=sourceViewed=closeDestination=refreshOnly=stop=false;activeTarget=-1;added=0;requestCancel=false;
}
std::wstring Summary(const std::vector<Stack>& destination) {
 if(jobDirect)return L"Pulled "+std::to_wstring(added)+L" of "+std::to_wstring(jobCrafts)+L" requested items into your inventory.";
 std::wstring missing;int count=0;
 for(const auto& t:targets) {
  int n=PullMissing(t.total,Count(destination,t.requirement.cls,t.requirement.exact));if(!n)continue;
  if(count<3) {if(!missing.empty())missing+=L", ";missing+=ClassLabel(t.requirement.cls)+L" x"+std::to_wstring(n);}++count;
 }
 if(!count)return L"Resources ready for "+std::to_wstring(jobCrafts)+L" crafts. Added "+std::to_wstring(added)+L" items.";
 if(count>3)missing+=L" + "+std::to_wstring(count-3)+L" more";
 return L"Still missing: "+missing+L". Added "+std::to_wstring(added)+L" items.";
}
bool BuildTargets(const std::vector<Stack>& stock,bool native) {
 targets.clear();float multiplier=1;
 if(!native) {
  int at=PropertyOffset(ClassOf(jobDest.inv.object),"DefaultCraftingRequirementsMultiplier");
  float rating=0;int ratingAt=PropertyOffset(ClassOf(jobRecipe.object),"ItemRating"),qualityAt=PropertyOffset(ClassOf(jobRecipe.object),"ItemQualityIndex");
  if(!at||!ratingAt||!qualityAt)return false;
  multiplier=Read<float>(jobDest.inv.object+at);rating=Read<float>(jobRecipe.object+ratingAt);
  if(!std::isfinite(multiplier)||multiplier<=0||multiplier>100||!std::isfinite(rating)||rating!=0||Read<unsigned char>(jobRecipe.object+qualityAt)!=0)return false;
 }
 for(std::size_t i=0;i<requirements.size();++i) {
  int unit=0;
  if(native)unit=Read<int>(params+(4+i)*kBuffer+cost.At("ReturnValue",4,"IntProperty"));
  else {double quantity=std::ceil(requirements[i].base*multiplier);if(!std::isfinite(quantity)||quantity<=0||quantity>1000000)return false;unit=static_cast<int>(quantity);}
  int total=PullTotal(unit,jobCrafts);if(!total)return false;
  int budget=PullMissing(total,Count(stock,requirements[i].cls,requirements[i].exact));
  // Overlapping alternative resource groups need an allocation solver, so don't double-count them.
  for(const auto& t:targets)if(ClassMatches(requirements[i].cls,t.requirement.cls)||ClassMatches(t.requirement.cls,requirements[i].cls))return false;
  targets.push_back({requirements[i],total,budget,0});
 }
 return !targets.empty();
}
bool Move(const Stack& item,int quantity,Address inv,bool taking,int target,const std::vector<Stack>& player,const std::vector<Stack>& destination,const std::vector<Stack>& source,ULONGLONG now) {
 if(!item.ref.Alive()||!item.id||item.recipe||quantity<=0)return false;
 const Call& c=taking?from:to;unsigned char block[kBuffer]={};quantity=PullTransfer(quantity,item.qty);if(!quantity)return false;
 Put(block,c,"inventoryComp",inv,"ObjectProperty");Put(block,c,"itemID",item.id,"StructProperty");Put(block,c,"requestedQuantity",quantity,"IntProperty");
 if(taking) {int slot=-1;Put(block,c,"ToSlotIndex",slot,"IntProperty");}
 if(!Send(controller,c,block,now))return false;
 activeTarget=target;amount=quantity;transferClass=item.cls;playerBefore=Count(player,item.cls,true);destBefore=Count(destination,item.cls,true);sourceBefore=Count(source,item.cls,true);
 operation=taking?Operation::Take:Operation::Put;phase=Phase::Action;
 message=taking?L"Pulling ingredients from tribe storage...":L"Moving ingredients into the crafting inventory...";return true;
}

} // namespace

void TickResourcePull(const GameContext& game,const MiscSettings& settings,bool restoring) {
 const ULONGLONG now=GetTickCount64();
 if(world&&world!=game.world)ResetResourcePull();world=game.world;
 const bool enabled=!restoring&&game.world&&game.pawn&&game.controller;
 UpdatePanel(game,enabled);
 if(requestCancel) {requestCancel=false;stop=true;}
 bool wanted=enabled||phase!=Phase::Idle;
 RequestDebugger(DebuggerClient::ResourcePull,wanted&&(uiRoot||phase!=Phase::Idle||requestPull||requestRefresh));
 if(ticket&&CompletedCalls()<ticket)return;
 if(phase==Phase::Idle) {
  stop=false;
  if(!enabled||!uiRoot) {requestPull=requestRefresh=false;return;}
  if(!requestPull&&!requestRefresh)return;
  if(AutomationInventoryBusy()||AutoChemBenchBusy()){message=L"Waiting for the active automation inventory to close.";return;}
  refreshOnly=requestRefresh&&!requestPull;requestPull=requestRefresh=false;
  if(destinations.empty()) {message=L"No destination inventory is available.";return;}
  if(!selectedNativeItem.Alive()) {message=L"Select an item or recipe in this inventory first.";return;}
  if(nativeQuantity<1||nativeQuantity>10000) {message=L"Enter a quantity from 1 to 10000.";return;}
  jobDirect=requestDirect;
  int ownerAt=PropertyOffset(ClassOf(selectedNativeItem.object),"OwnerInventory");
  Address owner=ownerAt?WeakObject(selectedNativeItem.object+ownerAt):0;
  Address destination=jobDirect?Object(game.pawn,"MyInventoryComponent"):owner;
  auto chosen=std::find_if(destinations.begin(),destinations.end(),[&](const Destination& d){return d.inv.object==destination;});
  if(chosen==destinations.end()) {message=L"The selected item's inventory is unavailable.";return;}
  jobDest=*chosen;
  if(!ValidDestination(jobDest,game,std::clamp(settings.pullRange,1,100))) {message=L"Destination is not an accessible tribe inventory.";return;}
  if(!refreshOnly) {
   jobRecipe=selectedNativeItem;
   if(!jobRecipe.Alive()) {message=L"Recipe changed. Refresh the recipe list.";return;}
  }
  controller=game.controller;jobCrafts=std::clamp(nativeQuantity,1,10000);added=0;targets.clear();requirements.clear();exhausted.clear();
  closeDestination=false;
  if(!ResolveCalls(controller,jobDest.inv.object)) {message=L"Resource Pull: inventory calls unavailable on this build.";ClearJob();return;}
  phase=Phase::Start;message=L"Connecting to the game for this pull...";return;
 }
 if(phase!=Phase::Finish&&phase!=Phase::DestClose) {
  if(stop||!enabled||!uiRoot)End(L"Pull stopped. Any staged materials remain in your inventory.");
  else if(controller!=game.controller||!ValidDestination(jobDest,game,std::clamp(settings.pullRange,1,100)))End(L"Destination changed or moved out of range; pull stopped.");
 }
 if(phase==Phase::DestClose) {message=finishMessage;ClearJob();recipesAt=0;return;}
 if(phase==Phase::Finish) {
  if(sourceViewed&&currentSource.inv.Alive()) {
   if(InvCall(close,currentSource.inv.object,now))sourceViewed=false;return;
  }
  sourceViewed=false;
  if(closeDestination&&destViewed&&jobDest.inv.Alive()) {
   if(InvCall(close,jobDest.inv.object,now)) {destViewed=false;phase=Phase::DestClose;}return;
  }
  message=finishMessage;ClearJob();recipesAt=0;return;
 }
 if(!DebuggerAttached()) {message=L"Waiting for the game connection...";return;}
 if(phase==Phase::Start) {
  if(jobDest.player) {phase=Phase::DestWait;phaseAt=now>800?now-800:0;}
  else if(AllowInventory(jobDest.inv.object,now)) {phase=Phase::DestAllow;message=L"Checking destination access...";}
  return;
 }
 if(phase==Phase::DestAllow) {
  int result=allow.At("ReturnValue",1,"BoolProperty");
  if(result<0||!Read<unsigned char>(params+result)) {End(L"Destination is outside the game's normal access range.");return;}
  if(InvCall(view,jobDest.inv.object,now)) {destViewed=true;phase=Phase::DestView;}return;
 }
 if(phase==Phase::DestView) {if(RequestItems(jobDest.inv.object,now))phase=Phase::DestRequest;return;}
 if(phase==Phase::DestRequest) {phase=Phase::DestWait;phaseAt=now;return;}
 if(phase==Phase::DestWait) {
  if(now-phaseAt<800)return;
  std::vector<Stack> stock;
  if(!Snapshot(jobDest.inv.object,stock)) {if(now-phaseAt>5000)End(L"Destination inventory did not finish loading.");return;}
  if(refreshOnly) {End(L"Recipe list refreshed. Choose a recipe and press Pull Resources.");return;}
  if(jobDirect) {
   if(!jobRecipe.Alive()) {End(L"The selected item changed; pull stopped.");return;}
   Address cls=ClassOf(jobRecipe.object);int initial=Count(stock,cls,true);
   targets.push_back({Requirement{cls,0,true},initial+jobCrafts,jobCrafts,0});sources=destinations;phase=Phase::Destination;return;
  }
  bool blueprint=false,engram=false;
  int ownerAt=jobRecipe.Alive()?PropertyOffset(ClassOf(jobRecipe.object),"OwnerInventory"):0;
  if(!ownerAt||WeakObject(jobRecipe.object+ownerAt)!=jobDest.inv.object||
     !Bool(jobRecipe.object,"bIsBlueprint",blueprint)||!Bool(jobRecipe.object,"bIsEngram",engram)||
     (!blueprint&&!engram)||!Requirements(jobRecipe.object,requirements)) {End(L"Select a crafting recipe or blueprint before pulling ingredients.");return;}
  cost=Resolve(ClassOf(jobRecipe.object),"GetCraftingResourceRequirement");
  if(cost.Has("CraftingResourceIndex",4,"IntProperty")&&cost.Has("ReturnValue",4,"IntProperty")) {
   if(!params)params=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kBuffer*40,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
   if(!params) {End(L"Could not allocate crafting query parameters.");return;}
   for(std::size_t i=0;i<requirements.size();++i) {
    unsigned char block[kBuffer]={};int index=static_cast<int>(i);Put(block,cost,"CraftingResourceIndex",index,"IntProperty");
    Address slot=params+(4+i)*kBuffer;
    if(!g_memory.WriteRaw(slot,block,kBuffer)) {End(L"Could not query recipe costs.");return;}
    ticket=QueueProcessEvent(jobRecipe.object,cost.fn,slot);
   }
   phase=Phase::Costs;phaseAt=now;message=L"Calculating exact recipe requirements...";return;
  }
  if(!BuildTargets(stock,false)) {End(L"Exact costs are unavailable for this blueprint; nothing was pulled.");return;}
  sources=destinations;phase=Phase::Destination;return;
 }
 std::vector<Stack> player,stock;
 Address playerInv=Object(game.pawn,"MyInventoryComponent");
 if(!playerInv||!ObjectRef::Of(playerInv).Alive()||!Snapshot(playerInv,player)||!Snapshot(jobDest.inv.object,stock)) {
  if(now-phaseAt>5000)End(L"Inventory data became unavailable; pull stopped.");return;
 }
 if(phase==Phase::Costs) {
  if(!jobRecipe.Alive()||!BuildTargets(stock,true)) {End(L"Exact recipe quantities are unsupported; nothing was pulled.");return;}
  sources=destinations;phase=Phase::Destination;
 }
 if(phase==Phase::Action) {
  bool confirmed=false;int received=0;
  if(operation==Operation::Put) {
   received=Count(stock,transferClass,true)-destBefore;
   confirmed=received>0&&Count(player,transferClass,true)<playerBefore;
  } else {
   std::vector<Stack> source;
   if(currentSource.inv.Alive()&&Snapshot(currentSource.inv.object,source)) {
    received=Count(player,transferClass,true)-playerBefore;
    confirmed=received>0&&Count(source,transferClass,true)<sourceBefore;
   }
  }
  if(!confirmed) {if(now-phaseAt>5000)End(L"Transfer was not confirmed; stopped to avoid pulling extra. Check your inventory.");return;}
  if(operation==Operation::Put||jobDest.player) {
   auto& t=targets[activeTarget];int accepted=(std::min)(amount,(std::min)(received,t.budget-t.delivered));
   t.delivered+=accepted;added+=accepted;
  }
  phase=operation==Operation::Take?Phase::SourceClose:Phase::Destination;
 }
 if(phase==Phase::SourceClose) {
  if(sourceViewed&&currentSource.inv.Alive()) {
   if(InvCall(close,currentSource.inv.object,now))sourceViewed=false;return;
  }
  sourceViewed=false;currentSource={};phase=Phase::Destination;
 }
 if(phase==Phase::Destination) {
  bool needAnything=false;
  for(std::size_t i=0;i<targets.size();++i) {
   auto& t=targets[i];int need=PullNeed(t.total,Count(stock,t.requirement.cls,t.requirement.exact),t.budget,t.delivered);
   if(!need)continue;needAnything=true;
   if(!jobDest.player)for(const auto& item:player)if(!item.recipe&&item.qty>0&&ClassMatches(item.cls,t.requirement.cls,t.requirement.exact)) {
    Move(item,need,jobDest.inv.object,false,static_cast<int>(i),player,stock,{},now);return;
   }
  }
  if(!needAnything) {End(Summary(stock));return;}
  for(const auto& d:sources) {
   if(d.player||d.inv.object==jobDest.inv.object||exhausted.count(d.inv.object)||!ValidDestination(d,game,std::clamp(settings.pullRange,1,100)))continue;
   currentSource=d;
   if(AllowInventory(d.inv.object,now)) {phase=Phase::SourceAllow;message=L"Searching nearby tribe inventories...";}
   else if(now-lastSent>=150)exhausted.insert(d.inv.object);
   return;
  }
  End(Summary(stock));return;
 }
 if((phase==Phase::SourceAllow||phase==Phase::SourceView||phase==Phase::SourceRequest||phase==Phase::SourceWait)&&
    !ValidDestination(currentSource,game,std::clamp(settings.pullRange,1,100))) {exhausted.insert(currentSource.inv.object);phase=Phase::SourceClose;return;}
 if(phase==Phase::SourceAllow) {
  int result=allow.At("ReturnValue",1,"BoolProperty");
  if(result<0||!Read<unsigned char>(params+result)) {exhausted.insert(currentSource.inv.object);currentSource={};phase=Phase::Destination;return;}
  if(InvCall(view,currentSource.inv.object,now)) {sourceViewed=true;phase=Phase::SourceView;}return;
 }
 if(phase==Phase::SourceView) {if(RequestItems(currentSource.inv.object,now))phase=Phase::SourceRequest;return;}
 if(phase==Phase::SourceRequest) {phase=Phase::SourceWait;phaseAt=now;return;}
 if(phase==Phase::SourceWait) {
  if(now-phaseAt<800)return;std::vector<Stack> source;
  if(!Snapshot(currentSource.inv.object,source)) {
   if(now-phaseAt>5000) {exhausted.insert(currentSource.inv.object);phase=Phase::SourceClose;}return;
  }
  for(std::size_t i=0;i<targets.size();++i) {
   auto& t=targets[i];int need=PullNeed(t.total,Count(stock,t.requirement.cls,t.requirement.exact),t.budget,t.delivered);
   if(!jobDest.player)need=PullMissing(need,Count(player,t.requirement.cls,t.requirement.exact));
   if(!need)continue;
   for(const auto& item:source)if(!item.recipe&&item.qty>0&&ClassMatches(item.cls,t.requirement.cls,t.requirement.exact)) {
    Move(item,need,currentSource.inv.object,true,static_cast<int>(i),player,stock,source,now);return;
   }
  }
  exhausted.insert(currentSource.inv.object);phase=Phase::SourceClose;return;
 }
}
bool ResourcePullBusy() {return phase!=Phase::Idle;}
const wchar_t* ResourcePullStatus() {return message.c_str();}
void ResetResourcePull() {
 ResetNativeInventoryPull();selectedNativeItem={};requestDirect=jobDirect=false;nativeQuantity=1;
 RequestDebugger(DebuggerClient::ResourcePull,false);ClearJob();destinations.clear();
 uiRoot=world=params=controller=0;ticket=0;scanned=recipesAt=lastSent=phaseAt=0;requestPull=requestRefresh=requestCancel=false;
 wasOpen=false;message=L"Select a recipe and press PULL, or select an item and press GET.";
}
void FlushResourcePull(unsigned long timeoutMs) {
 const auto until=GetTickCount64()+timeoutMs;
 while(ResourcePullBusy()&&GetTickCount64()<until) {TickResourcePull(ReadContext(),g_settings.misc,true);TickDebugger();Sleep(1);}
}
void DestroyResourcePullPanel() {
 ResetNativeInventoryPull();
}
} // namespace wintek


