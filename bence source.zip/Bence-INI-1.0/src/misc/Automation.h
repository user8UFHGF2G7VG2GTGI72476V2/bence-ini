#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"
namespace wintek {
void TickAutomation(const GameContext&,const Settings&,bool restoring);
void ResetAutomation();
void FlushAutomation(unsigned long timeoutMs);
bool AutomationInventoryBusy();
const char* DinoAutomationStatus();
const char* AutoForgeStatus();
}
