#pragma once
#include <algorithm>
#include <cstdint>
namespace wintek {
inline int PullTotal(int perCraft,int crafts) {
 std::int64_t n=static_cast<std::int64_t>(perCraft)*crafts;
 return perCraft>0&&crafts>0&&n<=1000000 ? static_cast<int>(n) : 0;
}
inline int PullMissing(int target,int have) {return target>0&&have>=0 ? (std::max)(0,target-have) : 0;}
inline int PullNeed(int target,int have,int budget,int delivered) {
 if(budget<0||delivered<0||delivered>budget)return 0;
 return (std::min)(PullMissing(target,have),budget-delivered);
}
inline int PullTransfer(int need,int available) {return need>0&&available>0 ? (std::min)(need,available) : 0;}
}
