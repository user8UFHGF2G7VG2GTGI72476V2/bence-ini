#include "misc/Automation.h"
#include "misc/ResourcePull.h"
#include "misc/AutoChemBench.h"
#include "engine/Debugger.h"
#include "core/Process.h"
#include "core/GameWindow.h"
#include "ui/Hotkeys.h"
#include <windows.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

// Breeding and inventory automation. Game calls use the shared queue.
namespace wintek { namespace {
constexpr int kParams=256;
struct Field {int at=-1,size=0;std::string kind;};
struct Method {
 Address fn=0;std::unordered_map<std::string,Field> fields;
 int At(const char* n,int size,const char* kind)const {auto i=fields.find(ToLower(n));return i!=fields.end()&&i->second.size==size&&i->second.kind==kind?i->second.at:-1;}
 template<class T>bool Put(std::array<unsigned char,kParams>& b,const char* n,const T& v,const char* kind)const {int at=At(n,sizeof(T),kind);if(at<0)return false;std::memcpy(b.data()+at,&v,sizeof(v));return true;}
};
std::unordered_map<Address,Method> methods;
Method Resolve(Address object,const char* name){
 Method result;Address fn=MainReflection().FindField(ClassOf(object),name);if(!fn||NameOf(ClassOf(fn))!="Function")return result;
 auto known=methods.find(fn);if(known!=methods.end())return known->second;result.fn=fn;
 int n=0;for(Address f=Read<Address>(fn+offsets::reflection::kChildren);f&&n++<64;f=Read<Address>(f+offsets::reflection::kNext)){
  int at=Read<int>(f+offsets::reflection::kPropertyOffset),size=Read<int>(f+0x34);if(at<0||size<1||at+size>kParams){result.fn=0;return result;}
  result.fields[ToLower(NameOf(f))]={at,size,NameOf(ClassOf(f))};
 }methods.emplace(fn,result);return result;
}
Address Object(Address o,const char* n){int at=o?PropertyOffset(ClassOf(o),n):0;return at?Read<Address>(o+at):0;}
bool Flag(Address o,const char* n,bool& value){Address f=MainReflection().FindField(ClassOf(o),n);if(!f||NameOf(ClassOf(f))!="BoolProperty")return false;int at=Read<int>(f+offsets::reflection::kPropertyOffset)+Read<unsigned char>(f+offsets::reflection::kBoolByteOffset);auto mask=Read<unsigned char>(f+offsets::reflection::kBoolFieldMask);if(at<0x20||at>0x10000||!mask)return false;unsigned char b=0;if(!g_memory.ReadRaw(o+at,&b,1))return false;value=(b&mask)!=0;return true;}
bool On(Address o,const char* n){bool v=false;return Flag(o,n,v)&&v;}
int Team(Address o){int at=o?PropertyOffset(ClassOf(o),"TargetingTeam"):0;return at?Read<int>(o+at):0;}
bool Position(Address a,std::array<float,3>& p){Address root=Object(a,"RootComponent");int at=root?PropertyOffset(ClassOf(root),"RelativeLocation"):0;if(!at||!g_memory.ReadRaw(root+at,p.data(),12))return false;return std::isfinite(p[0])&&std::isfinite(p[1])&&std::isfinite(p[2]);}
float Distance(Address a,Address b){std::array<float,3> x{},y{};if(!Position(a,x)||!Position(b,y))return 1e12f;float n=0;for(int i=0;i<3;++i)n+=(x[i]-y[i])*(x[i]-y[i]);return std::sqrt(n);}
bool Living(Address a){bool dead=true;return ObjectRef::Of(a).Alive()&&Flag(a,"bIsDead",dead)&&!dead;}
bool Mine(Address a,const GameContext& g){if(!a||!ObjectRef::Of(a).Alive()||Team(g.pawn)<50000||Team(a)!=Team(g.pawn))return false;bool dead=false;if(Flag(a,"bIsDead",dead))return !dead;return IsA(ClassOf(a),"PrimalStructure");}
bool ClassMatches(Address cls,Address base){for(int n=0;cls&&n<64;++n,cls=Read<Address>(cls+offsets::reflection::kSuperStruct))if(cls==base)return true;return false;}
Address Weak(Address at){int index=Read<int>(at),serial=Read<int>(at+4);if(index<0||serial<=0||index>=Read<int>(GObjects()+offsets::kObjectCount))return 0;Address chunk=Read<Address>(Read<Address>(GObjects())+(index/offsets::kObjectsPerChunk)*8);if(!chunk)return 0;Address entry=chunk+(index%offsets::kObjectsPerChunk)*offsets::kObjectItemSize;if(Read<int>(entry+8)!=serial)return 0;Address value=Read<Address>(entry);return value&&ObjectRef::Of(value).Alive()?value:0;}
std::wstring StringAt(Address at,int limit=256){auto a=Read<TArray>(at);if(!a.data||a.count<1||a.count>limit)return {};std::wstring s(a.count,L'\0');if(!g_memory.ReadRaw(a.data,s.data(),s.size()*2)||s.back()!=0)return {};s.pop_back();return s;}
std::wstring StringProperty(Address o,const char* n){int at=PropertyOffset(ClassOf(o),n);return at?StringAt(o+at):std::wstring{};}
struct Item {ObjectRef ref;Address cls=0;std::uint64_t id=0;int count=0;};
bool Items(Address inv,std::vector<Item>& out,const char* list="InventoryItems"){
 out.clear();if(!inv||!ObjectRef::Of(inv).Alive()||On(inv,"bReceivingInventoryItems"))return false;int at=PropertyOffset(ClassOf(inv),list);if(!at)return false;auto a=Read<TArray>(inv+at);if(a.count<0||a.count>20000||a.max<a.count||(!a.data&&a.count))return false;
 std::vector<Address> values(a.count);if(a.count&&!g_memory.ReadRaw(a.data,values.data(),values.size()*8))return false;
 for(Address o:values){if(!o||!ObjectRef::Of(o).Alive()||!IsA(ClassOf(o),"PrimalItem"))continue;bool blueprint=false,engram=false;if(!Flag(o,"bIsBlueprint",blueprint)||!Flag(o,"bIsEngram",engram)||blueprint||engram)continue;int quantity=PropertyOffset(ClassOf(o),"ItemQuantity"),id=PropertyOffset(ClassOf(o),"ItemId");if(!quantity||!id)continue;int count=Read<int>(o+quantity);auto net=Read<std::uint64_t>(o+id);if(count>0&&count<=10000000&&net)out.push_back({ObjectRef::Of(o),ClassOf(o),net,count});
 }return true;
}
int Count(const std::vector<Item>& a,Address cls){long long n=0;for(auto& i:a)if(i.cls==cls)n+=i.count;return static_cast<int>((std::min)(n,10000000LL));}
enum Kind {Dino=1,Forge=2,Industrial=4,Cloner=8,Incubator=16,Dedi=32,Egg=64,Structure=128};
struct Actor {ObjectRef ref;int kind=0;};
std::vector<Actor> actors;std::unordered_map<Address,int> kinds;std::unordered_map<std::uint64_t,ULONGLONG> due;
Address currentWorld=0,remote=0,hatchRemote=0;DWORD remotePid=0;std::uint64_t ticket=0;ULONGLONG scanAt=0,lastRpc=0,lastUse=0;
std::string dinoStatus="off",forgeStatus="off";
Method pendingMethod;
bool Ready(){return !ticket||CompletedCalls()>=ticket;}
bool Allocate(){if(remote)return true;remote=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));remotePid=g_process.pid;return remote!=0;}
bool Send(Address o,const Method& f,const std::array<unsigned char,kParams>& b,ULONGLONG now,Address custom=0){if(!o||!ObjectRef::Of(o).Alive()||!f.fn||!DebuggerAttached()||!Ready()||now-lastRpc<100||!Allocate())return false;Address p=custom?custom:remote;if(!g_memory.WriteRaw(p,b.data(),kParams))return false;ticket=QueueProcessEvent(o,f.fn,p);lastRpc=now;pendingMethod=f;return ticket!=0;}
bool InventoryCall(Address pc,const char* name,Address inv,ULONGLONG now){auto f=Resolve(pc,name);std::array<unsigned char,kParams> b{};return f.Put(b,"InventoryComp",inv,"ObjectProperty")&&Send(pc,f,b,now);}
bool RequestItems(Address pc,Address inv,ULONGLONG now){auto f=Resolve(pc,"ServerRequestActorItems");std::array<unsigned char,kParams>b{};unsigned char yes=1;return f.Put(b,"forInventory",inv,"ObjectProperty")&&f.Put(b,"bInventoryItems",yes,"BoolProperty")&&Send(pc,f,b,now);}
bool MultiUse(const GameContext& g,Address actor,int index,ULONGLONG now){if(now-lastUse<450)return false;auto f=Resolve(g.controller,"ServerMultiUse");std::array<unsigned char,kParams>b{};if(!f.Put(b,"ForObject",actor,"ObjectProperty")||!f.Put(b,"UseIndex",index,"IntProperty")||!Send(g.controller,f,b,now))return false;lastUse=now;return true;}
bool Due(Address o,int action,ULONGLONG now,ULONGLONG gap=2000){auto key=(static_cast<std::uint64_t>(o)<<5)^action;auto it=due.find(key);return it==due.end()||now-it->second>=gap;}
void Mark(Address o,int action,ULONGLONG now){due[(static_cast<std::uint64_t>(o)<<5)^action]=now;}
bool WantsDinos(const DinoSettings& d){return d.saddle.on||d.imprint.on||d.name.on||d.claim.on||d.neuter.on||d.level.on||d.clone.on||d.fillCloning.on||d.pickupEggs.on||d.transferEggs.on||d.hatchEggs.on;}
int KindOf(Address o){Address cls=ClassOf(o);auto k=kinds.find(cls);if(k!=kinds.end())return k->second;int flags=0;if(IsA(cls,"PrimalDinoCharacter"))flags|=Dino;if(IsA(cls,"PrimalStructure"))flags|=Structure;auto n=NameOf(cls);if(n.find("FertilizedEgg")!=std::string::npos)flags|=Egg;if(IsA(cls,"TekCloningChamber_C"))flags|=Cloner;if(IsA(cls,"EggIncubator_C"))flags|=Incubator;Address inv=Object(o,"MyInventoryComponent"),ic=inv?ClassOf(inv):0;if(ic&&IsA(ic,"PrimalInventoryBP_IndustrialForge_C"))flags|=Forge|Industrial;else if(ic&&IsA(ic,"PrimalInventoryBP_Forge_C"))flags|=Forge;if(ic&&IsA(ic,"PrimalInventory_DedicatedStorage_C"))flags|=Dedi;return kinds[cls]=flags;}
void Scan(const GameContext& g){actors.clear();auto levels=Read<TArray>(g.world+offsets::world::kLevels);if(!levels.data||levels.count<1||levels.count>2048)return;for(int n=0;n<levels.count;++n){Address level=Read<Address>(levels.data+n*8);auto a=Read<TArray>(level+offsets::world::kLevelActors);if(!a.data||a.count<0||a.count>200000)continue;std::vector<Address> all(a.count);if(!g_memory.ReadRaw(a.data,all.data(),all.size()*8))continue;for(Address o:all){if(!o||Read<unsigned>(o+offsets::object::kFlags)&(0x30|0x100|0x4000|0x8000|0x10000))continue;int kind=KindOf(o);if(kind)actors.push_back({ObjectRef::Of(o),kind});}}}
enum class VisitPurpose {Saddle,CloneFill,IncubatorEggs,Forge,Dedi};
enum class VisitPhase {None,Allow,View,Request,Wait,Work,Transfer,Equip,Close};
struct Visit {Actor target;ObjectRef inventory;VisitPurpose purpose=VisitPurpose::Forge;VisitPhase phase=VisitPhase::None;bool viewed=false,taking=false;Address itemClass=0;std::uint64_t itemId=0;int playerBefore=0,stationBefore=0,quantity=0;ULONGLONG at=0;};
Visit visit;
struct LevelState {std::array<unsigned short,8> applied{};int nextStat=0;int pending=-1;unsigned short before=0;ULONGLONG at=0;ObjectRef status;};
std::unordered_map<std::uint64_t,LevelState> levels;bool levelsLoaded=false,levelsDirty=false;
std::wstring LevelPath(){auto app=_wgetenv(L"LOCALAPPDATA");return app?std::wstring(app)+L"\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\AC\\Bence INI\\autolevel.dat":L"";}
void LoadLevels(){if(levelsLoaded)return;levelsLoaded=true;auto p=LevelPath();FILE*f=_wfopen(p.c_str(),L"rb");if(!f)return;char magic[8]{};unsigned n=0;if(std::fread(magic,1,8,f)!=8||std::memcmp(magic,"BNLEVEL1",8)||std::fread(&n,4,1,f)!=1||n>100000){std::fclose(f);return;}for(unsigned i=0;i<n;++i){std::uint64_t id=0;LevelState s;if(std::fread(&id,8,1,f)!=1||std::fread(s.applied.data(),2,8,f)!=8)break;if(id&&std::all_of(s.applied.begin(),s.applied.end(),[](unsigned v){return v<=255;}))levels[id]=s;}std::fclose(f);}
void SaveLevels(){if(!levelsDirty)return;auto p=LevelPath();if(p.empty())return;FILE*f=_wfopen((p+L".tmp").c_str(),L"wb");if(!f)return;unsigned n=static_cast<unsigned>(levels.size());bool ok=std::fwrite("BNLEVEL1",1,8,f)==8&&std::fwrite(&n,4,1,f)==1;for(auto& pair:levels){ok=ok&&std::fwrite(&pair.first,8,1,f)==1&&std::fwrite(pair.second.applied.data(),2,8,f)==8;}ok=std::fclose(f)==0&&ok;if(ok&&MoveFileExW((p+L".tmp").c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))levelsDirty=false;}
std::uint64_t DinoId(Address d){int a=PropertyOffset(ClassOf(d),"DinoID1"),b=PropertyOffset(ClassOf(d),"DinoID2");return a&&b?(static_cast<std::uint64_t>(Read<unsigned>(d+a))<<32)|Read<unsigned>(d+b):0;}
struct LevelQuery {ObjectRef actor,status;int stat=-1;std::uint64_t id=0;Method method;};LevelQuery levelQuery;
ObjectRef cuddleAfterFood;ULONGLONG foodAt=0;
int cloneName=0,nameCursor=1;
int FindCloneName(){if(cloneName)return cloneName;for(int n=0;n<2048&&nameCursor<1024*1024;++n,++nameCursor){Address table=Read<Address>(GNames()),chunk=table?Read<Address>(table+(nameCursor/offsets::kNamesPerChunk)*8):0;if(!chunk){nameCursor=1024*1024;break;}Address entry=Read<Address>(chunk+(nameCursor%offsets::kNamesPerChunk)*8);char s[8]{};if(entry&&g_memory.ReadRaw(entry+offsets::kNameText,s,sizeof(s))&&!std::memcmp(s,"Clone",6))return cloneName=nameCursor;}return 0;}
struct HatchQuery {ObjectRef actor;Method method;Address buffer=0;int result=-1;};HatchQuery hatch;
std::unordered_map<Address,int> hatchActions;
struct PlanKey {Address actor=0;int material=0;bool operator==(const PlanKey& o)const{return actor==o.actor&&material==o.material;}};
struct PlanHash {std::size_t operator()(const PlanKey& p)const{return (p.actor>>4)^p.material;}};
std::unordered_map<PlanKey,int,PlanHash> allocations;
ULONGLONG plannedAt=0;
int Material(Address cls){const char* names[]={"PrimalItemResource_Gasoline_C","PrimalItemResource_Metal_C","PrimalItemResource_ScrapMetal_C","PrimalItemResource_MetalIngot_C","PrimalItemResource_ScrapMetalIngot_C"};for(int i=0;i<5;++i)if(IsA(cls,names[i]))return i;return -1;}
void PlanForge(const GameContext& g,const MiscSettings& s,const std::vector<Item>& mine,ULONGLONG now){bool remaining=false;for(auto&p:allocations)if(p.second>0)remaining=true;if(remaining&&now-plannedAt<30000)return;if(now-plannedAt<1200)return;allocations.clear();plannedAt=now;for(int m=0;m<3;++m){if((m==0&&!s.forgeGas)||(m>0&&!s.forgeMetal))continue;std::vector<Address> targets;for(auto&a:actors)if(a.ref.Alive()&&(a.kind&Forge)&&(m!=0||(a.kind&Industrial))&&Mine(a.ref.object,g)&&Distance(a.ref.object,g.pawn)<=std::clamp(s.forgeRange,1,100)*100.f)targets.push_back(a.ref.object);if(targets.empty())continue;std::int64_t sum=0;for(auto&i:mine)if(Material(i.cls)==m)sum+=(std::min)(i.count,1000000);int total=static_cast<int>((std::min)(sum,std::int64_t(1000000000)));for(std::size_t i=0;i<targets.size();++i)allocations[{targets[i],m}]=total/static_cast<int>(targets.size())+(i<static_cast<std::size_t>(total%targets.size()));}}

constexpr unsigned char statIndices[]={0,1,3,4,7,8,9,11};
bool PendingLevels(){for(auto& p:levels)if(p.second.pending>=0)return true;return false;}
void ConfirmLevels(ULONGLONG now){for(auto& pair:levels){auto& s=pair.second;if(s.pending<0)continue;int at=s.status.Alive()?PropertyOffset(ClassOf(s.status.object),"ExtraCharacterLevel"):0;if(at&&Read<unsigned short>(s.status.object+at)>s.before){if(s.applied[s.pending]<255)++s.applied[s.pending];s.pending=-1;levelsDirty=true;}else if(!at||now-s.at>1500)s.pending=-1;}}
bool CheckLevels(const GameContext& g,ULONGLONG now){
 if(levelQuery.actor.object){
  if(now-lastRpc<100)return true;
  auto q=levelQuery;levelQuery={};int result=q.method.At("ReturnValue",1,"BoolProperty");
  if(result>=0&&Read<unsigned char>(remote+result)&&q.actor.Alive()&&q.status.Alive()&&Mine(q.actor.object,g)){
   auto f=Resolve(g.controller,"ServerRequestLevelUp");std::array<unsigned char,kParams>b{};auto stat=statIndices[q.stat];int extra=PropertyOffset(ClassOf(q.status.object),"ExtraCharacterLevel");
   if(extra&&f.Put(b,"forStatusComp",q.status.object,"ObjectProperty")&&f.Put(b,"ValueType",stat,"ByteProperty")&&Send(g.controller,f,b,now)){
    auto& s=levels[q.id];s.pending=q.stat;s.before=Read<unsigned short>(q.status.object+extra);s.at=now;s.status=q.status;return true;
   }
  }return false;
 }
 ConfirmLevels(now);return false;
}
bool StartLevel(const GameContext& g,Address d,const DinoSettings& settings,ULONGLONG now){
 if(!Due(d,6,now,1500))return false;Address status=Object(d,"MyCharacterStatusComponent");auto id=DinoId(d);if(!status||!id)return false;LoadLevels();auto& state=levels[id];if(state.pending>=0)return false;
 auto method=Resolve(status,"CanLevelUp");if(method.At("ReturnValue",1,"BoolProperty")<0)return false;
 for(int n=0;n<8;++n){int i=(state.nextStat+n)%8;if(state.applied[i]>=std::clamp(settings.levelPoints[i],0,255))continue;
  std::array<unsigned char,kParams>b{};unsigned char yes=1;if(!method.Put(b,"Stat",statIndices[i],"ByteProperty")||!method.Put(b,"bCheckExperience",yes,"BoolProperty"))return false;
  if(Send(status,method,b,now)){state.nextStat=(i+1)%8;levelQuery={ObjectRef::Of(d),ObjectRef::Of(status),i,id,method};Mark(d,6,now);return true;}return false;
 }return false;
}
bool Rename(const GameContext& g,Address d,const DinoSettings& settings,ULONGLONG now){
 if(!settings.nameText[0]||!Due(d,3,now,4000)||!Allocate())return false;
 int len=0;while(len<63&&settings.nameText[len])++len;int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,settings.nameText,len,nullptr,0);if(count<1||count>63)return false;
 std::wstring name(count,L'\0');MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,settings.nameText,len,name.data(),count);
 auto current=StringProperty(d,"TamedName");if(current==name||(!current.empty()&&!settings.renameNamed))return false;
 if(!g_memory.WriteRaw(remote+1024,name.c_str(),(name.size()+1)*2))return false;
 auto f=Resolve(g.controller,"ServerNotifyEditText");std::array<unsigned char,kParams>b{};struct Str {Address data;int count,max;} text{remote+1024,count+1,count+1};
 int a=PropertyOffset(ClassOf(d),"DinoID1"),c=PropertyOffset(ClassOf(d),"DinoID2");if(!a||!c)return false;auto cls=ClassOf(d);auto id1=Read<unsigned>(d+a),id2=Read<unsigned>(d+c);
 bool ids=f.Put(b,"ExtraID1",id1,"UInt32Property")&&f.Put(b,"ExtraID2",id2,"UInt32Property");
 if(!ids)ids=f.Put(b,"ExtraID1",id1,"IntProperty")&&f.Put(b,"ExtraID2",id2,"IntProperty");
 if(!ids||!f.Put(b,"TextToUse",text,"StrProperty")||!f.Put(b,"ForObjectClass",cls,"ClassProperty")||!f.Put(b,"ForObject",d,"ObjectProperty"))return false;
 if(Send(g.controller,f,b,now)){Mark(d,3,now);return true;}return false;
}
bool Imprint(const GameContext& g,Address d,const std::vector<Item>& mine,ULONGLONG now){
 if(!Due(d,2,now)||Distance(d,g.pawn)>360)return false;Address state=Object(g.world,"GameState");int dueAt=PropertyOffset(ClassOf(d),"BabyNextCuddleTime");
 // Cuddle times use the game state's network clock.
 int nt=PropertyOffset(ClassOf(state),"NetworkTime");if(!nt)nt=PropertyOffset(ClassOf(state),"ReplicatedNetworkTime");
 double time=nt?Read<double>(state+nt):0;
 if(!nt&&state&&IsA(ClassOf(state),"ShooterGameState"))time=Read<double>(state+0x598);
 if(!std::isfinite(time)||time<=0||!dueAt||Read<double>(d+dueAt)<=0||time<Read<double>(d+dueAt))return false;
 int typeAt=PropertyOffset(ClassOf(d),"BabyCuddleType");if(!typeAt)return false;auto type=Read<unsigned char>(d+typeAt);if(type>1){dinoStatus="Imprint walk care still needs walking the baby.";return false;}
 if(type==1){Address food=Object(d,"BabyCuddleFood");if(!food)return false;for(auto&i:mine)if(ClassMatches(i.cls,food)){
   Address inv=Object(g.pawn,"MyInventoryComponent");auto f=Resolve(inv,"ServerAddItemToSlot");std::array<unsigned char,kParams>b{};int slot=9;
   if(f.Put(b,"ItemId",i.id,"StructProperty")&&f.Put(b,"SlotIndex",slot,"IntProperty")&&Send(inv,f,b,now)){cuddleAfterFood=ObjectRef::Of(d);foodAt=now;Mark(d,2,now);return true;}return false;
  }dinoStatus="Imprint food is missing from your inventory.";return false;
 }
 if(MultiUse(g,d,139,now)){Mark(d,2,now);return true;}return false;
}
bool Clone(const GameContext& g,const DinoSettings& s,ULONGLONG now){
 int name=FindCloneName();if(!name)return false;auto method=Resolve(g.controller,"ServerProcessNetExecCommand");
 for(auto& chamber:actors)if(chamber.kind&Cloner){Address c=chamber.ref.object;if(!chamber.ref.Alive()||!Mine(c,g)||Distance(c,g.pawn)>std::clamp(s.cloneRange,1,300)*100.f||On(c,"bIsCloning")||!Due(c,7,now,5000))continue;
  int rangeAt=PropertyOffset(ClassOf(c),"CloningSearchRange");float range=rangeAt?Read<float>(c+rangeAt):0;if(!std::isfinite(range)||range<=0||range>50000)continue;
  Address target=0;float best=range;for(auto& a:actors)if((a.kind&Dino)&&a.ref.Alive()&&Mine(a.ref.object,g)&&!On(a.ref.object,"bIsBaby")){float distance=Distance(a.ref.object,c);if(distance<best){best=distance;target=a.ref.object;}}
  if(!target)continue;std::array<unsigned char,kParams>b{};struct Name {int index,number;} command{name,0};std::array<unsigned char,64> params{};std::memcpy(params.data()+0x18,&target,8);
  if(method.Put(b,"ForActor",c,"ObjectProperty")&&method.Put(b,"CommandName",command,"NameProperty")&&method.Put(b,"ExecParams",params,"StructProperty")&&Send(g.controller,method,b,now)){Mark(c,7,now);dinoStatus="Clone request sent to an owned chamber.";return true;}
 }return false;
}
bool QueryHatch(const GameContext& g,Address actor,ULONGLONG now){
 if(!Due(actor,10,now,10000))return false;auto f=Resolve(actor,"BPGetMultiUseEntries");int result=f.At("ReturnValue",16,"ArrayProperty");if(result<0)return false;
 if(!hatchRemote)hatchRemote=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));if(!hatchRemote||!Ready()||now-lastRpc<100||!DebuggerAttached())return false;
 std::array<unsigned char,kParams>b{};g_memory.ReadRaw(hatchRemote,b.data(),b.size());if(!f.Put(b,"ForPC",g.controller,"ObjectProperty"))return false;
 // Keep the prior returned array alive for the next game-owned assignment.
 int in=f.At("MultiUseEntries",16,"ArrayProperty");if(in>=0)std::memset(b.data()+in,0,16);
 if(!Send(actor,f,b,now,hatchRemote))return false;hatch={ObjectRef::Of(actor),f,hatchRemote,result};Mark(actor,10,now);return true;
}
void FinishHatch(){
 if(!hatch.actor.object)return;auto q=hatch;hatch={};if(!q.actor.Alive())return;auto array=Read<TArray>(q.buffer+q.result);if(!array.data||array.count<1||array.count>64)return;
 Address prop=MainReflection().FindField(q.method.fn,"ReturnValue"),inner=Read<Address>(prop+0x70),type=Read<Address>(inner+0x70);int stride=Read<int>(inner+0x34);
 Address label=MainReflection().FindField(type,"UseString"),index=MainReflection().FindField(type,"UseIndex");if(stride<32||stride>256||!label||!index||NameOf(ClassOf(label))!="StrProperty"||NameOf(ClassOf(index))!="IntProperty")return;
 int labelAt=Read<int>(label+offsets::reflection::kPropertyOffset),indexAt=Read<int>(index+offsets::reflection::kPropertyOffset);if(labelAt<0||labelAt+16>stride||indexAt<0||indexAt+4>stride)return;
 auto expected=StringProperty(q.actor.object,"HatchEggString");for(int i=0;i<array.count;++i){Address row=array.data+i*stride;auto text=StringAt(row+labelAt);auto lower=text;std::transform(lower.begin(),lower.end(),lower.begin(),[](wchar_t c){return c>=L'A'&&c<=L'Z'?c+32:c;});if((!expected.empty()&&text==expected)||lower.find(L"hatch")!=std::wstring::npos){int action=Read<int>(row+indexAt);if(action>=0)hatchActions[ClassOf(q.actor.object)]=action;return;}}
}
bool DinoActions(const GameContext& g,const DinoSettings& s,const std::vector<Item>& mine,ULONGLONG now){
 if(CheckLevels(g,now))return true;if(cuddleAfterFood.object){if(!cuddleAfterFood.Alive()||now-foodAt>5000){cuddleAfterFood={};}else if(now-foodAt>=450&&Mine(cuddleAfterFood.object,g)&&MultiUse(g,cuddleAfterFood.object,139,now)){cuddleAfterFood={};return true;}else return true;}
 static std::size_t cursor=0;if(actors.empty())return false;for(std::size_t n=0;n<actors.size();++n){const auto& a=actors[cursor++%actors.size()];Address d=a.ref.object;if(!a.ref.Alive())continue;float distance=Distance(d,g.pawn);
  if((a.kind&Egg)&&s.pickupEggs.on&&distance<=320&&Due(d,8,now)&&MultiUse(g,d,100,now)){Mark(d,8,now);return true;}
  if(!(a.kind&Dino)||!Living(d))continue;
  if(s.claim.on&&Team(d)==2000000000&&distance<=360&&Due(d,1,now)&&MultiUse(g,d,122,now)){Mark(d,1,now);dinoStatus="Claim request sent.";return true;}
  if(!Mine(d,g))continue;
  if(s.imprint.on&&On(d,"bIsBaby")&&Imprint(g,d,mine,now))return true;
  if(s.neuter.on&&!On(d,"bIsBaby")&&!On(d,"bNeutered")&&!On(d,"bPreventNeuter")&&distance<=std::clamp(s.neuterRange,1,60)*100.f&&distance<=360&&Due(d,4,now)&&MultiUse(g,d,77391,now)){Mark(d,4,now);dinoStatus="Neuter request sent.";return true;}
  if(s.name.on&&distance<=std::clamp(s.nameRange,1,60)*100.f&&Rename(g,d,s,now)){dinoStatus="Rename request sent.";return true;}
  if(s.level.on&&distance<=6000&&StartLevel(g,d,s,now))return true;
 }
 if(s.clone.on&&Clone(g,s,now))return true;
 if(s.hatchEggs.on)for(auto&a:actors)if((a.kind&Incubator)&&a.ref.Alive()&&Mine(a.ref.object,g)&&Distance(a.ref.object,g.pawn)<=1500){auto known=hatchActions.find(ClassOf(a.ref.object));if(known==hatchActions.end()){if(QueryHatch(g,a.ref.object,now))return true;}else if(Due(a.ref.object,9,now,2000)&&MultiUse(g,a.ref.object,known->second,now)){Mark(a.ref.object,9,now);return true;}}
 return false;
}

bool SaddleFits(const Item& item,Address d){
 int at=PropertyOffset(item.cls,"MyEquipmentType");if(!at||Read<unsigned char>(item.ref.object+at)!=5)return false;
 Address saddle=Object(d,"SaddleItemClass");if(saddle&&ClassMatches(item.cls,saddle))return true;
 at=PropertyOffset(item.cls,"EquipRequiresExplicitOwnerClasses");if(at){auto a=Read<TArray>(item.ref.object+at);if(a.data&&a.count>0&&a.count<=64)for(int i=0;i<a.count;++i)if(ClassMatches(ClassOf(d),Read<Address>(a.data+i*8)))return true;}
 int tagAt=PropertyOffset(ClassOf(d),"CustomTag");at=PropertyOffset(item.cls,"EquipRequiresExplicitOwnerTags");if(tagAt&&at){auto tag=Read<std::uint64_t>(d+tagAt);auto a=Read<TArray>(item.ref.object+at);if(tag&&a.data&&a.count>0&&a.count<=64)for(int i=0;i<a.count;++i)if(Read<std::uint64_t>(a.data+i*8)==tag)return true;}return false;
}
bool HasSaddle(Address actor,Address inv){
 Address f=MainReflection().FindField(ClassOf(actor),"SaddleStruct");if(f&&NameOf(ClassOf(f))=="StructProperty"){
  Address type=Read<Address>(f+0x70),id=MainReflection().FindField(type,"ItemId");int at=Read<int>(f+offsets::reflection::kPropertyOffset),size=Read<int>(f+0x34);
  if(id){int inside=Read<int>(id+offsets::reflection::kPropertyOffset);if(inside>=0&&inside+8<=size&&Read<std::uint64_t>(actor+at+inside))return true;}
 }
 std::vector<Item> equipped;if(Items(inv,equipped,"EquippedItems"))for(auto&i:equipped)if(SaddleFits(i,actor))return true;return false;
}
Address DedicatedType(Address actor){if(!ObjectRef::Of(actor).Alive()||!(KindOf(actor)&Dedi))return 0;Address cls=Read<Address>(actor+0xf00);return cls&&ObjectRef::Of(cls).Alive()&&IsA(cls,"PrimalItem")?cls:0;}
int StationCount(const Visit& job,const std::vector<Item>& items,Address cls){if(job.purpose==VisitPurpose::Dedi&&DedicatedType(job.target.ref.object)==cls){int n=Read<int>(job.target.ref.object+0xf08);return n>=0?n:0;}return Count(items,cls);}
bool PlayerRoom(const GameContext& g,Address inv,const std::vector<Item>& items,Address cls){
 int at=PropertyOffset(ClassOf(inv),"MaxInventoryItems");if(at){int limit=Read<int>(inv+at);if(limit>0&&items.size()+5>=static_cast<std::size_t>(limit)&&!Count(items,cls))return false;}
 Address status=Object(g.pawn,"MyCharacterStatusComponent");int cur=PropertyOffset(ClassOf(status),"CurrentStatusValues"),mx=PropertyOffset(ClassOf(status),"MaxStatusValues");
 if(cur&&mx){float weight=Read<float>(status+cur+7*4),max=Read<float>(status+mx+7*4);if(std::isfinite(weight)&&std::isfinite(max)&&max>0&&weight>=max)return false;}return true;
}
bool Transfer(const GameContext& g,const Item& item,int quantity,bool taking,const std::vector<Item>& mine,const std::vector<Item>& stock,ULONGLONG now){
 quantity=(std::min)(quantity,item.count);if(quantity<=0||!item.ref.Alive()||!item.id)return false;
 auto f=Resolve(g.controller,taking?"ServerTransferFromRemoteInventory":"ServerTransferToRemoteInventory");std::array<unsigned char,kParams>b{};
 if(!f.Put(b,"InventoryComp",visit.inventory.object,"ObjectProperty")||!f.Put(b,"ItemId",item.id,"StructProperty")||!f.Put(b,"RequestedQuantity",quantity,"IntProperty"))return false;
 if(taking){int slot=-1;if(!f.Put(b,"ToSlotIndex",slot,"IntProperty"))return false;}
 else if(visit.purpose==VisitPurpose::Saddle){unsigned char yes=1;if(!f.Put(b,"bAlsoTryToEquip",yes,"BoolProperty")&&!f.Put(b,"bAlsoTryToEqup",yes,"BoolProperty"))return false;}
 if(!Send(g.controller,f,b,now))return false;visit.taking=taking;visit.itemClass=item.cls;visit.itemId=item.id;visit.quantity=quantity;visit.playerBefore=Count(mine,item.cls);visit.stationBefore=StationCount(visit,stock,item.cls);visit.phase=VisitPhase::Transfer;visit.at=now;return true;
}
bool StartVisit(const GameContext& g,const Actor& target,VisitPurpose purpose,ULONGLONG now){
 Address actor=target.ref.object,inv=Object(actor,"MyInventoryComponent");if(!target.ref.Alive()||!Mine(actor,g)||!inv||!ObjectRef::Of(inv).Alive()||!Due(actor,12,now,2000))return false;
 auto method=Resolve(inv,"RemoteInventoryAllowViewing");std::array<unsigned char,kParams>b{};if(method.At("ReturnValue",1,"BoolProperty")<0||!method.Put(b,"PC",g.controller,"ObjectProperty")||!Send(inv,method,b,now))return false;
 visit={};visit.target=target;visit.inventory=ObjectRef::Of(inv);visit.purpose=purpose;visit.phase=VisitPhase::Allow;visit.at=now;Mark(actor,12,now);return true;
}
bool VisitEnabled(const Settings& settings){switch(visit.purpose){case VisitPurpose::Saddle:return settings.dino.saddle.on;case VisitPurpose::CloneFill:return settings.dino.fillCloning.on;case VisitPurpose::IncubatorEggs:return settings.dino.transferEggs.on;case VisitPurpose::Forge:case VisitPurpose::Dedi:return settings.misc.autoForge.on;}return false;}
bool TickVisit(const GameContext& g,const Settings& settings,ULONGLONG now,bool stop){
 if(visit.phase==VisitPhase::None)return false;if(!Ready())return true;
 if(!visit.target.ref.Alive()||!visit.inventory.Alive()){visit={};return true;}
 if(stop||!VisitEnabled(settings)||!Mine(visit.target.ref.object,g)||Distance(visit.target.ref.object,g.pawn)>30000)visit.phase=VisitPhase::Close;
 if(visit.phase==VisitPhase::Close){if(visit.viewed){if(InventoryCall(g.controller,"ServerActorCloseRemoteInventory",visit.inventory.object,now))visit.viewed=false;}else visit={};return true;}
 if(visit.phase==VisitPhase::Allow){int at=pendingMethod.At("ReturnValue",1,"BoolProperty");if(at<0||!Read<unsigned char>(remote+at)){for(auto&p:allocations)if(p.first.actor==visit.target.ref.object)p.second=0;visit.phase=VisitPhase::Close;return true;}if(InventoryCall(g.controller,"ServerActorViewRemoteInventory",visit.inventory.object,now)){visit.viewed=true;visit.phase=VisitPhase::View;}return true;}
 if(visit.phase==VisitPhase::View){if(RequestItems(g.controller,visit.inventory.object,now)){visit.phase=VisitPhase::Wait;visit.at=now;}return true;}
 std::vector<Item> mine,stock;Address player=Object(g.pawn,"MyInventoryComponent");
 if(visit.phase==VisitPhase::Wait&&now-visit.at<600)return true;
 if(!Items(player,mine)||!Items(visit.inventory.object,stock)){if(now-visit.at>5000)visit.phase=VisitPhase::Close;return true;}
 if(visit.purpose==VisitPurpose::Saddle){std::vector<Item> eq;if(Items(visit.inventory.object,eq,"EquippedItems"))stock.insert(stock.end(),eq.begin(),eq.end());}
 if(visit.phase==VisitPhase::Transfer){
  int sourceNow=visit.taking?StationCount(visit,stock,visit.itemClass):Count(mine,visit.itemClass),sourceBefore=visit.taking?visit.stationBefore:visit.playerBefore;
  int destNow=visit.taking?Count(mine,visit.itemClass):StationCount(visit,stock,visit.itemClass),destBefore=visit.taking?visit.playerBefore:visit.stationBefore;
  if(sourceNow<sourceBefore&&destNow>destBefore){int moved=(std::min)(visit.quantity,(std::min)(sourceBefore-sourceNow,destNow-destBefore));if(visit.purpose==VisitPurpose::Forge&&!visit.taking){int material=Material(visit.itemClass);auto& remaining=allocations[{visit.target.ref.object,material}];remaining=(std::max)(0,remaining-moved);}visit.phase=visit.purpose==VisitPurpose::Saddle?VisitPhase::Equip:VisitPhase::Close;visit.at=now;forgeStatus="Inventory transfer confirmed.";}
  else if(now-visit.at>5000){forgeStatus="Transfer not confirmed; visit stopped.";visit.phase=VisitPhase::Close;}return true;
 }
 if(visit.phase==VisitPhase::Equip){
  if(HasSaddle(visit.target.ref.object,visit.inventory.object)){visit.phase=VisitPhase::Close;dinoStatus="Saddle equipped.";return true;}
  if(now-visit.at>2000){visit.phase=VisitPhase::Close;return true;}
  for(auto&i:stock)if(SaddleFits(i,visit.target.ref.object)){auto f=Resolve(g.controller,"ServerEquipToRemoteInventory");std::array<unsigned char,kParams>b{};if(f.Put(b,"InventoryComp",visit.inventory.object,"ObjectProperty")&&f.Put(b,"ItemId",i.id,"StructProperty")&&Send(g.controller,f,b,now)){visit.phase=VisitPhase::Close;dinoStatus="Saddle equip requested.";}return true;}return true;
 }
 visit.phase=VisitPhase::Work;
 if(visit.purpose==VisitPurpose::Saddle){if(HasSaddle(visit.target.ref.object,visit.inventory.object)){visit.phase=VisitPhase::Close;return true;}for(auto&i:stock)if(SaddleFits(i,visit.target.ref.object)){visit.phase=VisitPhase::Equip;visit.at=now;return true;}for(auto&i:mine)if(SaddleFits(i,visit.target.ref.object)){Transfer(g,i,1,false,mine,stock,now);return true;}}
 if(visit.purpose==VisitPurpose::CloneFill)for(auto&i:mine)if(IsA(i.cls,"PrimalItemResource_ElementShard_C")){Transfer(g,i,i.count,false,mine,stock,now);return true;}
 if(visit.purpose==VisitPurpose::IncubatorEggs)for(auto&i:mine)if(NameOf(i.cls).find("Fertilized")!=std::string::npos){Transfer(g,i,i.count,false,mine,stock,now);return true;}
 if(visit.purpose==VisitPurpose::Dedi){Address cls=DedicatedType(visit.target.ref.object);for(auto&i:mine)if(i.cls==cls&&Material(i.cls)>=3){Transfer(g,i,i.count,false,mine,stock,now);return true;}}
 if(visit.purpose==VisitPurpose::Forge){
  for(auto&i:mine){int material=Material(i.cls);if(material<0||material>2||(material==0&&!settings.misc.forgeGas)||(material>0&&!settings.misc.forgeMetal))continue;auto found=allocations.find({visit.target.ref.object,material});if(found!=allocations.end()&&found->second>0){Transfer(g,i,found->second,false,mine,stock,now);return true;}}
  if(settings.misc.forgePull||settings.misc.forgeDedi)for(auto&i:stock)if(Material(i.cls)>=3&&PlayerRoom(g,player,mine,i.cls)){Transfer(g,i,i.count,true,mine,stock,now);return true;}
  bool active=true;if(settings.misc.forgeTurnOn&&Flag(visit.target.ref.object,"bIsActive",active)&&!active&&Due(visit.target.ref.object,13,now,5000)){
   if(MultiUse(g,visit.target.ref.object,600,now)){Mark(visit.target.ref.object,13,now);visit.phase=VisitPhase::Close;forgeStatus="Forge activation requested.";}return true;
  }
 }
 visit.phase=VisitPhase::Close;return true;
}
bool ChooseVisit(const GameContext& g,const Settings& s,const std::vector<Item>& mine,ULONGLONG now){
 if(s.misc.autoForge.on&&s.misc.forgeDedi){float best=1e12f;const Actor* target=nullptr;for(auto&a:actors)if(a.ref.Alive()&&(a.kind&Dedi)&&Mine(a.ref.object,g)){float distance=Distance(a.ref.object,g.pawn);if(distance>std::clamp(s.misc.forgeRange,1,100)*100.f||distance>=best||!Due(a.ref.object,12,now))continue;Address cls=DedicatedType(a.ref.object);for(auto&i:mine)if(Material(i.cls)>=3&&i.cls==cls){best=distance;target=&a;break;}}if(target&&StartVisit(g,*target,VisitPurpose::Dedi,now))return true;}
 static std::size_t cursor=0;if(actors.empty())return false;
 for(std::size_t n=0;n<actors.size();++n){auto&a=actors[cursor++%actors.size()];if(!a.ref.Alive()||!Mine(a.ref.object,g)||!Due(a.ref.object,12,now))continue;float dist=Distance(a.ref.object,g.pawn);
  if(s.dino.saddle.on&&(a.kind&Dino)&&!On(a.ref.object,"bIsBaby")&&dist<=std::clamp(s.dino.saddleRange,1,60)*100.f){Address inv=Object(a.ref.object,"MyInventoryComponent");if(!HasSaddle(a.ref.object,inv))for(auto&i:mine)if(SaddleFits(i,a.ref.object)){if(StartVisit(g,a,VisitPurpose::Saddle,now))return true;break;}}
  if(s.dino.fillCloning.on&&(a.kind&Cloner)&&dist<=1500)for(auto&i:mine)if(IsA(i.cls,"PrimalItemResource_ElementShard_C")){if(StartVisit(g,a,VisitPurpose::CloneFill,now))return true;break;}
  if(s.dino.transferEggs.on&&(a.kind&Incubator)&&dist<=1500)for(auto&i:mine)if(NameOf(i.cls).find("Fertilized")!=std::string::npos){if(StartVisit(g,a,VisitPurpose::IncubatorEggs,now))return true;break;}
  if(s.misc.autoForge.on&&(a.kind&Forge)&&dist<=std::clamp(s.misc.forgeRange,1,100)*100.f&&(s.misc.forgeGas||s.misc.forgeMetal||s.misc.forgePull||s.misc.forgeDedi||s.misc.forgeTurnOn))if(StartVisit(g,a,VisitPurpose::Forge,now))return true;
 }return false;
}

ObjectRef pickupState;int pickupHoldAt=0;float pickupOriginal=0;
void RestorePickup(){if(pickupState.Alive()&&pickupHoldAt&&Read<float>(pickupState.object+pickupHoldAt)==0)Write(pickupState.object+pickupHoldAt,pickupOriginal);pickupState={};pickupHoldAt=0;}
void QuickHold(const GameContext& g,bool enabled){
 if(!enabled){RestorePickup();return;}Address state=Object(g.world,"GameState");if(!state)return;
 if(pickupState.object!=state){RestorePickup();Address f=MainReflection().FindField(ClassOf(state),"StructurePickupHoldDuration");if(!f||NameOf(ClassOf(f))!="FloatProperty")return;int at=Read<int>(f+offsets::reflection::kPropertyOffset);float original=Read<float>(state+at);if(at<0x20||at>0x10000||!std::isfinite(original)||original<0||original>3600)return;pickupState=ObjectRef::Of(state);pickupHoldAt=at;pickupOriginal=original;}
 if(pickupState.Alive())Write(pickupState.object+pickupHoldAt,0.f);
}
Address openedUI=0,takenUI=0;ULONGLONG openedAt=0;
bool TakeAll(const GameContext& g,Address ui,const MiscSettings& s,ULONGLONG now){
 if(!ui){openedUI=takenUI=0;return false;}if(ui!=openedUI){openedUI=ui;takenUI=0;openedAt=now;}
 bool key=s.takeAllActionKey&&wintek::ui::ActionPressed(s.takeAllActionKey);
 if(!s.takeAll.on||(!key&&(s.takeAllActionKey||takenUI==ui))||now-openedAt<600)return false;
 int at=PropertyOffset(ClassOf(g.controller),"RemoteViewingInventories");if(!at)return false;auto a=Read<TArray>(g.controller+at);if(!a.data||a.count<1||a.count>64||a.max<a.count)return false;
 Address inv=Read<Address>(a.data+(a.count-1)*sizeof(Address));if(!inv||!ObjectRef::Of(inv).Alive()||inv==Object(g.pawn,"MyInventoryComponent")||!IsA(ClassOf(inv),"PrimalInventoryComponent")||On(inv,"bReceivingInventoryItems"))return false;
 auto f=Resolve(g.controller,"ServerTransferAllFromRemoteInventory");std::array<unsigned char,kParams>b{};unsigned char yes=1;
 if(!f.Put(b,"InventoryComp",inv,"ObjectProperty"))return false;f.Put(b,"bNoFolderView",yes,"BoolProperty");
 if(Send(g.controller,f,b,now)){takenUI=ui;return true;}return false;
}
ULONGLONG levelSavedAt=0;
} // namespace

bool AutomationInventoryBusy(){return visit.phase!=VisitPhase::None;}
const char* DinoAutomationStatus(){return dinoStatus.c_str();}
const char* AutoForgeStatus(){return forgeStatus.c_str();}
void TickAutomation(const GameContext& game,const Settings& settings,bool restoring){
 auto now=GetTickCount64();if(currentWorld&&currentWorld!=game.world){if(!Ready())return;ResetAutomation();}currentWorld=game.world;
 ConfirmLevels(now);
 bool valid=game.world&&game.pawn&&game.controller;
 if(restoring||!settings.dino.level.on)levelQuery={};
 bool dino=valid&&!restoring&&WantsDinos(settings.dino),forge=valid&&!restoring&&settings.misc.autoForge.on;
 bool pickup=valid&&!restoring&&settings.misc.quickPickup.on,take=valid&&!restoring&&settings.misc.takeAll.on;
 QuickHold(game,pickup);
 Address ui=game.hud?Read<Address>(game.hud+offsets::hud::kOpenInventory):0;
 bool wanted=dino||forge||take||(pickup&&settings.misc.pickupActionKey)||AutomationInventoryBusy()||!Ready();
 RequestDebugger(DebuggerClient::Automation,wanted);
 if(!Ready())return;
 FinishHatch();
 if(levelsDirty&&now-levelSavedAt>=2000){SaveLevels();levelSavedAt=now;}
 if(AutomationInventoryBusy()){TickVisit(game,settings,now,restoring||!valid||ui||ResourcePullBusy());return;}
 if(!wanted||restoring||!valid){dinoStatus="off";forgeStatus="off";cuddleAfterFood={};levelQuery={};return;}
 if(!DebuggerAttached()){const char* error=DebuggerError();if(forge)forgeStatus=error?error:"Waiting for game-call connection.";if(dino)dinoStatus=error?error:"Waiting for game-call connection.";return;}
 if(ui){TakeAll(game,ui,settings.misc,now);return;}openedUI=takenUI=0;
 if(ResourcePullBusy()||AutoChemBenchBusy())return;
 if(pickup&&settings.misc.pickupActionKey&&FindGameWindow(g_process.pid).IsActive(GetForegroundWindow())&&wintek::ui::ActionPressed(settings.misc.pickupActionKey)){
  int at=PropertyOffset(ClassOf(game.hud),"LastTargetedActor");Address target=at?Weak(game.hud+at):0;
  if(target&&IsA(ClassOf(target),"PrimalStructure")&&Distance(target,game.pawn)<=400&&MultiUse(game,target,203,now))return;
 }
 if(!dino&&!forge)return;
 if(!scanAt||now-scanAt>=1000){Scan(game);scanAt=now;}
 std::vector<Item> mine;if(!Items(Object(game.pawn,"MyInventoryComponent"),mine))return;
 if(forge)PlanForge(game,settings.misc,mine,now);
 static bool stationTurn=false;
 if(stationTurn&&ChooseVisit(game,settings,mine,now)){stationTurn=false;return;}
 if(dino&&DinoActions(game,settings.dino,mine,now)){stationTurn=true;return;}
 if(ChooseVisit(game,settings,mine,now)){stationTurn=false;return;}
 if(dino&&dinoStatus=="off")dinoStatus="Watching nearby dinos and breeding stations.";
 if(forge&&forgeStatus=="off")forgeStatus="Watching reachable owned forges.";
}
void ResetAutomation(){
 RestorePickup();SaveLevels();
 if(remotePid==g_process.pid){if(!Ready())return;if(remote&&g_process.handle)VirtualFreeEx(g_process.handle,reinterpret_cast<void*>(remote),0,MEM_RELEASE);if(hatchRemote&&g_process.handle)VirtualFreeEx(g_process.handle,reinterpret_cast<void*>(hatchRemote),0,MEM_RELEASE);}
 RequestDebugger(DebuggerClient::Automation,false);actors.clear();kinds.clear();due.clear();methods.clear();allocations.clear();hatchActions.clear();visit={};hatch={};levelQuery={};cuddleAfterFood={};pickupState={};pickupHoldAt=0;
 remote=hatchRemote=currentWorld=openedUI=takenUI=0;remotePid=0;ticket=0;cloneName=0;nameCursor=1;for(auto& pair:levels)pair.second.pending=-1;scanAt=lastRpc=lastUse=plannedAt=0;dinoStatus=forgeStatus="off";
}
void FlushAutomation(unsigned long timeout){auto until=GetTickCount64()+timeout;while((!Ready()||AutomationInventoryBusy()||PendingLevels())&&GetTickCount64()<until){TickAutomation(ReadContext(),g_settings,true);TickDebugger();Sleep(1);}RestorePickup();SaveLevels();}
} // namespace wintek




