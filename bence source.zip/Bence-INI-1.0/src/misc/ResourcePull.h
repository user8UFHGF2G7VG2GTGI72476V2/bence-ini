#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"
namespace wintek {
void TickResourcePull(const GameContext&,const MiscSettings&,bool restoring);
bool ResourcePullBusy();
const wchar_t* ResourcePullStatus();
void ResetResourcePull();
void FlushResourcePull(unsigned long timeoutMs);
void DestroyResourcePullPanel();
}
