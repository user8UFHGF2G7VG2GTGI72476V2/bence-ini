#pragma once
namespace wintek {
inline bool MayEnableMating(bool own, bool alive, bool adult, bool neutered, bool enabled,
                           bool readable, bool learned, float distanceSquared, float rangeSquared) {
  return own && alive && adult && !neutered && !enabled && readable && learned &&
         distanceSquared >= 0 && distanceSquared <= rangeSquared;
}
}
