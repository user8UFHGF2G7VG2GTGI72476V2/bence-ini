#include "client/Features.h"
#include "client/Renderer.h"
#include "client/Window.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include "hud/Overlay.h"
#include "misc/ResourcePull.h"
#include "tabs/config/Config.h"
#include "core/Settings.h"
#include "ui/Fonts.h"
#include "ui/Hotkeys.h"
#include "ui/Logo.h"
#include "ui/Menu.h"
#include "ui/Theme.h"
#include "ui/Widgets.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <algorithm>
#include <cfloat>
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"

using namespace wintek;

namespace {

constexpr DWORD kAttachPollMs = 500;


void SetUpImGui(HWND window) {
  IMGUI_CHECKVERSION();
  ImGui::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  io.IniFilename = nullptr;
  ImGui::StyleColorsDark();
  ui::ApplyTheme();
  ui::LoadMenuFonts(io);  // fonts are compiled into the exe (client/Resources.rc.in), see ui/Fonts.cpp
  ui::LoadLogo(g_renderer.device());
  ImGui_ImplWin32_Init(window);
  ImGui_ImplDX11_Init(g_renderer.device(), g_renderer.context());
}

// Returns false once the window has been closed.
bool PumpMessages() {
  MSG msg;
  while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
    TranslateMessage(&msg);
    DispatchMessageW(&msg);
    if (msg.message == WM_QUIT) return false;
  }
  return true;
}

void RenderFrame() {
  ui::UseMenuFont(g_settings.menuFont);
  ImGui_ImplDX11_NewFrame();
  ImGui_ImplWin32_NewFrame();
  const float scale=std::clamp(g_settings.interfaceScale,75,150)/100.f;
  ImGuiIO& io=ImGui::GetIO();io.DisplaySize.x/=scale;io.DisplaySize.y/=scale;
  static ImU32 lastEvent=0;
  for(auto& e:ImGui::GetCurrentContext()->InputEventsQueue)if(e.Type==ImGuiInputEventType_MousePos&&e.EventId>lastEvent){lastEvent=e.EventId;if(e.MousePos.PosX>-FLT_MAX/2)e.MousePos.PosX/=scale;if(e.MousePos.PosY>-FLT_MAX/2)e.MousePos.PosY/=scale;}
  ImGui::NewFrame();
  ui::NewFrame();
  ui::DrawMenu();
  ImGui::Render();
  g_renderer.BeginFrame();
  ImDrawData* data=ImGui::GetDrawData();
  // The bundled DX11 backend predates framebuffer scaling support.
  data->DisplaySize.x*=scale;data->DisplaySize.y*=scale;data->ScaleClipRects(ImVec2(scale,scale));
  for(int l=0;l<data->CmdListsCount;++l)for(auto& v:data->CmdLists[l]->VtxBuffer){v.pos.x*=scale;v.pos.y*=scale;}
  ImGui_ImplDX11_RenderDrawData(data);
  g_renderer.EndFrame();
}

}  // namespace

int APIENTRY wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int) {
  const HWND window = CreateAppWindow();
  if (!window || !g_renderer.Create(window)) return 1;
  ShowWindow(window, SW_SHOW);
  AnimateWindow(window, 180, AW_BLEND);
  SetForegroundWindow(window);

  SetUpImGui(window);
  LoadConfig();
  CreateOverlay(window);

  DWORD lastPoll = 0;
  while (PumpMessages()) {
    if (GetTickCount() - lastPoll > kAttachPollMs) {
      lastPoll = GetTickCount();
      g_process.Poll();
    }
    ui::PollHotkeys();
    TickFeatures();
    TickDebugger();
    TickOverlay();
    if (IsAppWindowVisible()) {
      RenderFrame();
    } else {
      Sleep(5);  // menu hidden: keep the features and hotkeys running without drawing
    }
  }

  DestroyOverlay();
  RestoreFeatures();
  DestroyResourcePullPanel();
  StopDebugger();
  ui::ReleaseLogo();
  ImGui_ImplDX11_Shutdown();
  ImGui_ImplWin32_Shutdown();
  ImGui::DestroyContext();
  g_renderer.Destroy();
  return 0;
}
