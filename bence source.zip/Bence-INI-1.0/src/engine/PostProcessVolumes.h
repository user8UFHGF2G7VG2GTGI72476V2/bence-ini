#pragma once
#include "engine/Engine.h"
#include <vector>

namespace wintek {

// A post-process volume in the current world, with the settings it had when first seen so every feature that
// changes it can put it back exactly.
struct PostProcessVolume {
  ObjectRef ref;
  std::uint8_t overrides[3] = {};  // bOverride_* bits for the fields below
  float saturation = 0.0f;
  float contrast = 0.0f;
  float tint[4] = {};
  std::uint8_t flags = 0;  // offsets::volume::kEnabled / kUnbound / kWater

  // What WinTek has done to it, so each change is undone once.
  bool graded = false;   // Vibrance / Color Filter
  bool drained = false;  // No Water switched it off

  Address address() const { return ref.object; }
};

// Keeps the list for the current world. `wanted` says whether any feature needs it this tick; the levels are
// rescanned every couple of seconds while it is.
void TrackVolumes(Address world, bool wanted);
std::vector<PostProcessVolume>& Volumes();
void ResetVolumes();

}  // namespace wintek
