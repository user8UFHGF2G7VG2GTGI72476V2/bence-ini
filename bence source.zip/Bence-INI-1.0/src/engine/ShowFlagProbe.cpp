#include "engine/ShowFlagProbe.h"
#include "engine/Console.h"
#include <windows.h>
#include <string>
#include <vector>

namespace wintek {

namespace {

constexpr std::size_t kViewBytes = offsets::viewport::kViewBytes;
constexpr std::size_t kFlagsAt = sizeof(std::int32_t);  // the flags follow ViewModeIndex
constexpr DWORD kTimeoutMs = 15000;
constexpr int kMaxTries = 3;

struct Probe {
  std::string name;
  int bit = -1;
  int tries = 0;
};

struct {
  std::vector<Probe> probes;
  int active = -1;  // index into probes while one is running
  Address viewport = 0;
  std::uint8_t before[kViewBytes] = {};
  std::uint64_t command = 0;
  DWORD startedAt = 0;
} g_probe;

Probe& Find(const char* name) {
  for (Probe& p : g_probe.probes)
    if (p.name == name) return p;
  g_probe.probes.push_back({ name });
  return g_probe.probes.back();
}

Address FlagsOf(Address viewport) { return viewport + offsets::viewport::kViewModeIndex; }

void Finish(Probe& p, int bit) {
  p.bit = bit;
  g_probe.active = -1;
}

}  // namespace

int ShowFlagBit(const char* name) {
  for (const Probe& p : g_probe.probes)
    if (p.name == name) return p.bit;
  return -1;
}

void RequestShowFlag(const char* name) { Find(name); }

void TickShowFlagProbe(Address viewport) {
  if (g_probe.active >= 0) {
    Probe& p = g_probe.probes[g_probe.active];
    if (!viewport || viewport != g_probe.viewport || GetTickCount() - g_probe.startedAt > kTimeoutMs) {
      if (viewport == g_probe.viewport) g_memory.WriteRaw(FlagsOf(viewport), g_probe.before, kViewBytes);
      Finish(p, ++p.tries >= kMaxTries ? -2 : -1);
      return;
    }
    if (!ConsoleCommandDone(g_probe.command)) return;
    std::uint8_t after[kViewBytes];
    if (!g_memory.ReadRaw(FlagsOf(viewport), after, kViewBytes)) return;
    // Exactly one flag bit should have flipped.
    int changed = 0, bit = -1;
    for (std::size_t i = kFlagsAt; i < kViewBytes; ++i)
      for (int b = 0; b < 8; ++b)
        if ((after[i] ^ g_probe.before[i]) & (1u << b)) {
          ++changed;
          bit = static_cast<int>((i - kFlagsAt) * 8 + b);
        }
    g_memory.WriteRaw(FlagsOf(viewport), g_probe.before, kViewBytes);  // put the game's flags back
    if (changed == 1) Finish(p, bit);
    else Finish(p, changed == 0 || ++p.tries >= kMaxTries ? -2 : -1);  // nothing flipped: "show" isn't available
    return;
  }
  if (!viewport) return;
  for (std::size_t i = 0; i < g_probe.probes.size(); ++i) {
    Probe& p = g_probe.probes[i];
    if (p.bit != -1) continue;
    if (!g_memory.ReadRaw(FlagsOf(viewport), g_probe.before, kViewBytes)) return;
    g_probe.viewport = viewport;
    g_probe.active = static_cast<int>(i);
    g_probe.startedAt = GetTickCount();
    g_probe.command = QueueConsoleCommand(L"show " + std::wstring(p.name.begin(), p.name.end()), false);
    return;
  }
}

void ResetShowFlagProbe() { g_probe = {}; }

}  // namespace wintek
