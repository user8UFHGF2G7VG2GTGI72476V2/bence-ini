#include "engine/Signatures.h"
#include "core/Memory.h"
#include <windows.h>
#include <algorithm>
#include <cstdlib>

namespace wintek {

namespace {

using Pattern = std::vector<int>;  // -1 = wildcard

Pattern Parse(const char* text) {
  Pattern out;
  while (*text) {
    if (*text == ' ') {
      ++text;
    } else if (*text == '?') {
      out.push_back(-1);
      while (*text == '?') ++text;
    } else {
      char* end = nullptr;
      out.push_back(static_cast<int>(std::strtol(text, &end, 16)));
      text = end;
    }
  }
  return out;
}

std::size_t Match(const std::vector<std::uint8_t>& bytes, const Pattern& pattern) {
  for (std::size_t i = 0; i + pattern.size() <= bytes.size(); ++i) {
    std::size_t k = 0;
    while (k < pattern.size() && (pattern[k] < 0 || bytes[i + k] == static_cast<std::uint8_t>(pattern[k]))) ++k;
    if (k == pattern.size()) return i;
  }
  return SIZE_MAX;
}

}  // namespace

std::vector<std::uintptr_t> FindPatterns(std::uintptr_t imageBase, std::initializer_list<const char*> patterns) {
  std::vector<Pattern> parsed;
  for (const char* p : patterns) parsed.push_back(Parse(p));
  std::vector<std::uintptr_t> found(parsed.size(), 0);

  const auto dos = g_memory.Read<IMAGE_DOS_HEADER>(imageBase);
  if (dos.e_magic != IMAGE_DOS_SIGNATURE) return found;
  const auto nt = g_memory.Read<IMAGE_NT_HEADERS64>(imageBase + dos.e_lfanew);
  const std::uintptr_t sections =
      imageBase + dos.e_lfanew + offsetof(IMAGE_NT_HEADERS64, OptionalHeader) + nt.FileHeader.SizeOfOptionalHeader;

  // Read 1 MB at a time, overlapping so a pattern spanning two chunks is still seen.
  constexpr std::size_t kChunk = 1 << 20, kOverlap = 128;
  std::vector<std::uint8_t> bytes;
  for (int s = 0; s < nt.FileHeader.NumberOfSections; ++s) {
    const auto section = g_memory.Read<IMAGE_SECTION_HEADER>(sections + s * sizeof(IMAGE_SECTION_HEADER));
    if (!(section.Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
    const std::size_t size = section.Misc.VirtualSize;
    for (std::size_t offset = 0; offset < size; offset += kChunk) {
      bytes.resize((std::min)(kChunk + kOverlap, size - offset));
      const std::uintptr_t start = imageBase + section.VirtualAddress + offset;
      if (!g_memory.ReadRaw(start, bytes.data(), bytes.size())) continue;
      for (std::size_t p = 0; p < parsed.size(); ++p) {
        if (found[p]) continue;
        const std::size_t at = Match(bytes, parsed[p]);
        if (at != SIZE_MAX) found[p] = start + at;
      }
    }
  }
  return found;
}

std::uintptr_t FindPattern(std::uintptr_t start, std::size_t size, const char* pattern) {
  std::vector<std::uint8_t> bytes(size);
  if (!g_memory.ReadRaw(start, bytes.data(), size)) return 0;
  const std::size_t at = Match(bytes, Parse(pattern));
  return at == SIZE_MAX ? 0 : start + at;
}

std::uintptr_t ResolveRipRelative(std::uintptr_t instruction) {
  return instruction + 7 + g_memory.Read<std::int32_t>(instruction + 3);
}

}  // namespace wintek
