#pragma once
#include <cstddef>
#include <cstdint>

// Offsets into ARK's (UE 4.5-era) engine structures for the Microsoft Store build of ShooterGame.exe.
// Anything reflection can find by name is looked up at runtime instead (see Engine.h).
namespace wintek::offsets {

using Offset = std::uintptr_t;

// GObjects (FUObjectArray) and the GNames chunk table.
constexpr Offset kObjectCount = 0x14;
constexpr Offset kObjectItemSize = 0x10;
constexpr int kObjectsPerChunk = 65536;
constexpr int kNamesPerChunk = 16384;
constexpr int kMaxNameChunks = 128;
constexpr Offset kNameText = 0x10;

namespace object {
constexpr Offset kFlags = 0x08;
constexpr Offset kIndex = 0x0C;
constexpr Offset kClass = 0x10;
constexpr Offset kName = 0x18;
constexpr Offset kOuter = 0x20;
}  // namespace object

namespace reflection {
constexpr Offset kSuperStruct = 0x30;     // UStruct
constexpr Offset kChildren = 0x38;        // UStruct
constexpr Offset kNext = 0x28;            // UField
constexpr Offset kPropertyOffset = 0x4C;  // UProperty
constexpr Offset kBoolByteOffset = 0x71;  // UBoolProperty
constexpr Offset kBoolFieldMask = 0x72;   // UBoolProperty
}  // namespace reflection

namespace world {
constexpr Offset kLevels = 0x268;
constexpr Offset kGameInstance = 0x290;
constexpr Offset kLocalPlayers = 0x38;  // UGameInstance
constexpr Offset kLevelActors = 0x88;   // ULevel
}  // namespace world

namespace player {
constexpr Offset kController = 0x30;      // ULocalPlayer
constexpr Offset kViewportClient = 0x68;  // ULocalPlayer
constexpr Offset kPawn = 0x4E8;           // APlayerController::AcknowledgedPawn
constexpr Offset kHud = 0x500;            // APlayerController::MyHUD
constexpr Offset kCamera = 0x508;         // APlayerController::PlayerCameraManager
}  // namespace player

namespace viewport {
constexpr Offset kEngine = 0x20;         // UGameViewportClient::Outer
constexpr Offset kViewModeIndex = 0xB0;  // followed by EngineShowFlags
constexpr std::size_t kViewBytes = 0x18;
}  // namespace viewport

namespace camera {
constexpr Offset kLockedFov = 0x49C;
constexpr Offset kLockFlags = 0x1480;          // bit 0: bLockedFOV
constexpr Offset kIgnoreHealthShading = 0x1851;  // bCustomDepthStencilIgnoreHealth, rebuilt every frame
}  // namespace camera

namespace hud {
constexpr Offset kHidden = 0xA88;
constexpr Offset kUserHidden = 0xAB0;
constexpr Offset kOpenInventory = 0xAB8;
}  // namespace hud

namespace volume {  // APostProcessVolume
constexpr Offset kOverrideFlags = 0x4C0;
constexpr Offset kFilmSaturation = 0x518;
constexpr Offset kFilmContrast = 0x54C;
constexpr Offset kSceneColorTint = 0x56C;
constexpr Offset kBlendables = 0x7F0;
constexpr Offset kFlags = 0x828;
constexpr std::uint8_t kEnabled = 0x01, kUnbound = 0x02, kWater = 0x04;
}  // namespace volume

namespace primitive {
constexpr Offset kVisibility = 0x110;   // bVisible (0x40) / bHiddenInGame (0x80)
constexpr Offset kSceneProxy = 0x5D0;
constexpr Offset kProxyFlags = 0x40;    // FPrimitiveSceneProxy
constexpr std::uint8_t kDrawInGame = 0x02;
}  // namespace primitive

namespace material {
constexpr Offset kParent = 0x68;  // UMaterialInstance
}  // namespace material

}  // namespace wintek::offsets
