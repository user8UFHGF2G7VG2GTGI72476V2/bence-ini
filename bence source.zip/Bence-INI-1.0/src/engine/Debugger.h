#pragma once
#include <cstdint>

// Some features need to act once per frame on ARK's game thread, which memory writes alone can't do.
// For those, WinTek attaches to ARK as a debugger and sets a hardware breakpoint where
// ULocalPlayer::GetProjectionData has finished the frame's projection data. Each time the game thread stops
// there, WinTek can
//  - run frame callbacks (read and write memory while the game thread waits), and
//  - have the game thread call ARK's own UObject::ProcessEvent, the same entry point Knucklebutt uses to
//    call game functions.
// No code is written into ARK: only thread registers, the stack, and data memory change.
//
// While attached, killing WinTek (rather than closing it) leaves the breakpoint set and crashes ARK on the next
// frame. A crash inside WinTek clears the breakpoints first.
namespace wintek {

enum class DebuggerClient { StretchedRes, StalkerIni, Console, FpsCounter, TurretFiller, PlayerList, StructureSnap, BlackStructures, AutoMating, AutoChemBench, Trajectory, TargetOutlines, ResourcePull, Automation, AimTarget, Count };

using FrameCallback = void (*)(std::uintptr_t projectionData);

// The debugger stays attached while any client wants it.
void RequestDebugger(DebuggerClient client, bool wanted);
void SetFrameCallback(DebuggerClient client, FrameCallback callback);

void TickDebugger();  // main thread: attaches and detaches as clients come and go
void StopDebugger();  // finishes any call in flight, then detaches
bool DebuggerAttached();
const char* DebuggerError();  // nullptr while fine

// Queues ProcessEvent(object, function, params) for an upcoming frame; `params` must point into ARK's memory.
// Calls run in order. A call is finished once CompletedCalls() reaches the returned ticket. Detaching drops
// queued calls and counts them as finished, so callers check the call's result rather than assume it ran.
std::uint64_t QueueProcessEvent(std::uintptr_t object, std::uintptr_t function, std::uintptr_t params);
std::uint64_t CompletedCalls();

// Up to three more hardware breakpoints (slots 0-2 = DR1-DR3), each at the start of one game function (0 = none).
// Each time a game thread enters one, its callback gets that thread's rcx, rdx and r8 (the function's first three
// arguments plus r9) on the debugger thread while the game thread waits; then the function runs normally.
// The breakpoints are only set while the debugger is attached for some client. Slot 0: Player List.
using HookCallback = void (*)(std::uintptr_t rcx, std::uintptr_t rdx, std::uintptr_t r8, std::uintptr_t r9);
constexpr int kHookSlots = 3;
void SetHookBreakpoint(int slot, std::uintptr_t address, HookCallback callback);

}  // namespace wintek
