#include "engine/Debugger.h"
#include "engine/QueuedObject.h"
#include "core/Memory.h"
#include "core/Process.h"
#include "engine/Signatures.h"
#include <windows.h>
#include <tlhelp32.h>
#include <atomic>
#include <cstring>
#include <cstdio>
#include <deque>
#include <mutex>
#include <thread>
#include <unordered_map>

namespace wintek {

namespace {

using Address = std::uintptr_t;

// ULocalPlayer::GetProjectionData (the function Knucklebutt hooks for Stretched Resolution), and inside it the
// point every successful path reaches with the projection data complete: lea rcx,[rbp+80h]; call ...; mov al,1.
constexpr const char* kSigProjection = "48 8B C4 55 53 56 57 41 56 41 57 48 8D A8 38 FB FF FF 48 81 EC 98 05 00 00";
constexpr const char* kSigProjectionDone = "48 8D 8D 80 00 00 00 E8 ? ? ? ? B0 01";
constexpr std::size_t kProjectionFunctionSize = 0x1000;
constexpr const char* kSigProcessEvent =
    "40 55 53 56 57 41 54 41 56 41 57 48 81 EC ? ? ? ? 48 8D 6C 24 ? 48 C7 45 ? ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C5 "
    "48 89 85 ? ? ? ? 49 8B F0 48 8B FA 4C 8B F1 8B 41 08 C1 E8 0E A8 01 0F 85 ? ? ? ?";

constexpr DWORD64 kDr7Slot0 = 0xF0003;    // L0/G0 enable + RW0/LEN0 (00/00 = break on execute)
// Hook slot n uses DR(n+1): its L/G enable bits and its RW/LEN nibble.
constexpr DWORD64 Dr7HookMask(int n) { return (DWORD64{ 0x3 } << (2 * (n + 1))) | (DWORD64{ 0xF } << (16 + 4 * (n + 1))); }
constexpr DWORD64 Dr7HookEnable(int n) { return DWORD64{ 0x1 } << (2 * (n + 1)); }
constexpr DWORD kResumeFlag = 0x10000;
constexpr DWORD kCallStackGap = 0x400;  // stack left untouched below the paused frame before a call's frame
constexpr DWORD kStopTimeoutMs = 3000;

struct PendingCall {
  Address object, function, params;
  QueuedObject receiver,method;
};

// A ProcessEvent call the game thread is running for us. Its return address is the breakpoint itself, so the
// return shows up as another hit there, with the stack pointer just past that return address.
struct ActiveCall {
  DWORD threadId = 0;
  Address returnRsp = 0;
  CONTEXT resumeContext{};
};

std::atomic<unsigned> g_clients{ 0 };
std::atomic<bool> g_running{ false }, g_attached{ false };
std::atomic<const char*> g_error{ nullptr };
std::thread g_thread;
DWORD g_pid = 0;
Address g_imageBase = 0, g_breakpoint = 0, g_processEvent = 0;
DWORD g_resolvedAt = 0;          // last search for the game functions
constexpr DWORD kRetryMs = 5000;  // a failed search is tried again this often (ARK may still have been loading)
FrameCallback g_callbacks[static_cast<int>(DebuggerClient::Count)] = {};

// The hook breakpoints (DR1-DR3), see SetHookBreakpoint. g_rearm asks the debug loop to re-apply all breakpoints.
std::atomic<Address> g_hookAddress[kHookSlots] = {};
std::atomic<HookCallback> g_hookCallback[kHookSlots] = {};
std::atomic<bool> g_rearm{ false };

std::mutex g_callMutex;
std::deque<PendingCall> g_calls;
std::atomic<std::uint64_t> g_issued{ 0 }, g_completed{ 0 };
ActiveCall g_active;  // debugger thread only

bool ResolveAddresses(Address imageBase) {
  const auto found = FindPatterns(imageBase, { kSigProjection, kSigProcessEvent });
  g_breakpoint = found[0] ? FindPattern(found[0], kProjectionFunctionSize, kSigProjectionDone) : 0;
  g_processEvent = found[1];
  return g_breakpoint && g_processEvent;
}

// Sets both breakpoints (DR0: the frame breakpoint, DR1: the hook, if any) on one thread, or clears them.
void ArmThread(HANDLE thread, bool on) {
  CONTEXT c{};
  c.ContextFlags = CONTEXT_DEBUG_REGISTERS;
  if (!GetThreadContext(thread, &c)) return;
  c.Dr7 &= ~kDr7Slot0;
  c.Dr0 = on ? g_breakpoint : 0;
  if (on && g_breakpoint) c.Dr7 |= 1;
  DWORD64* hookRegs[kHookSlots] = { &c.Dr1, &c.Dr2, &c.Dr3 };
  for (int n = 0; n < kHookSlots; ++n) {
    const Address hook = on ? g_hookAddress[n].load() : 0;
    c.Dr7 &= ~Dr7HookMask(n);
    *hookRegs[n] = hook;
    if (hook) c.Dr7 |= Dr7HookEnable(n);
  }
  SetThreadContext(thread, &c);
}

// Sets or clears the breakpoint on every thread of the process. Opens its own thread handles, so it also works
// from the crash handler after the debug loop is gone.
void ArmAllThreads(DWORD pid, bool on) {
  HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
  if (snap == INVALID_HANDLE_VALUE) return;
  THREADENTRY32 entry{ sizeof(entry) };
  for (BOOL ok = Thread32First(snap, &entry); ok; ok = Thread32Next(snap, &entry)) {
    if (entry.th32OwnerProcessID != pid) continue;
    HANDLE thread = OpenThread(THREAD_GET_CONTEXT | THREAD_SET_CONTEXT | THREAD_SUSPEND_RESUME, FALSE, entry.th32ThreadID);
    if (!thread) continue;
    SuspendThread(thread);
    ArmThread(thread, on);
    ResumeThread(thread);
    CloseHandle(thread);
  }
  CloseHandle(snap);
}

void DropQueuedCalls() {
  std::lock_guard<std::mutex> lock(g_callMutex);
  g_calls.clear();
  g_completed = g_issued.load();
}

// Points the paused thread at ProcessEvent for the next queued call. Returns false if there's nothing to run.
bool StartCall(HANDLE thread, const CONTEXT& paused) {
  PendingCall call;
  {
    std::lock_guard<std::mutex> lock(g_callMutex);
    if (g_calls.empty()) return false;
    call = g_calls.front();
    g_calls.pop_front();
  }
  if(!call.receiver.Alive()||!call.method.Alive()){++g_completed;return false;}
  // 16-byte aligned before the call, as the x64 ABI expects; the return address is the slot just below.
  const Address rsp = ((paused.Rsp - kCallStackGap) & ~Address{ 0xF }) - sizeof(Address);
  if (!g_memory.Write(rsp, g_breakpoint)) {
    ++g_completed;
    return false;
  }
  CONTEXT c = paused;
  c.Rcx = call.object;
  c.Rdx = call.function;
  c.R8 = call.params;
  c.Rsp = rsp;
  c.Rip = g_processEvent;
  c.EFlags &= ~kResumeFlag;
  g_active.resumeContext = paused;
  g_active.threadId = GetThreadId(thread);
  g_active.returnRsp = rsp + sizeof(Address);
  SetThreadContext(thread, &c);
  return true;
}

// Returns true if this single-step came from a hook breakpoint (DR1-DR3), current or just cleared, and handled it.
// Checked by DR6's B1-B3 bits rather than by address, so a hit that races a SetHookBreakpoint(.., 0, ..) is still
// ours and never gets passed on to the game.
bool OnHook(HANDLE thread) {
  CONTEXT c{};
  c.ContextFlags = CONTEXT_FULL | CONTEXT_DEBUG_REGISTERS;
  if (!GetThreadContext(thread, &c) || !(c.Dr6 & 0xE)) return false;
  for (int n = 0; n < kHookSlots; ++n) {
    if (!(c.Dr6 & (DWORD64{ 2 } << n))) continue;
    const Address hook = g_hookAddress[n].load();
    if (hook && c.Rip == hook)
      if (const HookCallback callback = g_hookCallback[n].load()) callback(c.Rcx, c.Rdx, c.R8, c.R9);
  }
  c.Dr6 = 0;
  c.EFlags |= kResumeFlag;  // run the first instruction instead of breaking on it again
  SetThreadContext(thread, &c);
  return true;
}

void OnBreakpoint(HANDLE thread) {
  CONTEXT c{};
  c.ContextFlags = CONTEXT_FULL;
  if (!GetThreadContext(thread, &c)) return;
  if (g_active.threadId == GetThreadId(thread) && c.Rsp == g_active.returnRsp) {  // a call just returned
    c = g_active.resumeContext;
    g_active.threadId = 0;
    ++g_completed;
  }
  if (!g_active.threadId && g_running && StartCall(thread, c)) return;  // the frame resumes after the call
  if (!g_active.threadId) {
    for (FrameCallback callback : g_callbacks)
      if (callback) callback(c.Rbx);  // rbx holds the FSceneViewProjectionData being filled
  }
  c.EFlags |= kResumeFlag;  // run the instruction instead of breaking on it again
  SetThreadContext(thread, &c);
}

// Diagnostic text only: unhandled game exceptions still go to ARK's own handler.
void WriteCrashLog(const char* source,const EXCEPTION_RECORD& record){
 wchar_t path[32768]{};DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",path,32000);if(!n||n>=32000)return;
 if(wcscat_s(path,L"\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\AC\\Bence INI\\crash.log"))return;
 HANDLE file=CreateFileW(path,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(file==INVALID_HANDLE_VALUE)return;
 SYSTEMTIME time{};GetLocalTime(&time);char line[512]{};int length=std::snprintf(line,sizeof(line),"%04u-%02u-%02u %02u:%02u:%02u %s code=0x%08lX address=%p gamePid=%lu\r\n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,source,record.ExceptionCode,record.ExceptionAddress,g_pid);DWORD written=0;if(length>0&&length<sizeof(line))WriteFile(file,line,static_cast<DWORD>(length),&written,nullptr);CloseHandle(file);
}

// Returns false once the process has exited.
bool HandleEvent(const DEBUG_EVENT& e, std::unordered_map<DWORD, HANDLE>& threads, bool& sawAttachBreak) {
  DWORD status = DBG_CONTINUE;
  bool alive = true;
  switch (e.dwDebugEventCode) {
    case CREATE_PROCESS_DEBUG_EVENT:
      if (e.u.CreateProcessInfo.hFile) CloseHandle(e.u.CreateProcessInfo.hFile);
      threads[e.dwThreadId] = e.u.CreateProcessInfo.hThread;
      if (g_running) ArmThread(e.u.CreateProcessInfo.hThread, true);
      break;
    case CREATE_THREAD_DEBUG_EVENT:
      threads[e.dwThreadId] = e.u.CreateThread.hThread;
      if (g_running) ArmThread(e.u.CreateThread.hThread, true);
      break;
    case EXIT_THREAD_DEBUG_EVENT:
      threads.erase(e.dwThreadId);
      if (g_active.threadId == e.dwThreadId) {
        g_active.threadId = 0;
        ++g_completed;
      }
      break;
    case LOAD_DLL_DEBUG_EVENT:
      if (e.u.LoadDll.hFile) CloseHandle(e.u.LoadDll.hFile);
      break;
    case EXIT_PROCESS_DEBUG_EVENT:
      alive = false;
      break;
    case EXCEPTION_DEBUG_EVENT: {
      const EXCEPTION_RECORD& record = e.u.Exception.ExceptionRecord;
      const auto thread = threads.find(e.dwThreadId);
      if (record.ExceptionCode == EXCEPTION_SINGLE_STEP && reinterpret_cast<Address>(record.ExceptionAddress) == g_breakpoint &&
          thread != threads.end()) {
        OnBreakpoint(thread->second);
      } else if (record.ExceptionCode == EXCEPTION_SINGLE_STEP && thread != threads.end() && OnHook(thread->second)) {
        // handled: the hook breakpoint
      } else if (record.ExceptionCode == EXCEPTION_BREAKPOINT && !sawAttachBreak) {
        sawAttachBreak = true;  // raised by Windows in the thread it creates for the attach
      } else {
        if(!e.u.Exception.dwFirstChance)WriteCrashLog("ARK",record);
        status = DBG_EXCEPTION_NOT_HANDLED;  // the game's own exceptions go to the game's own handlers
      }
      break;
    }
    default:
      break;
  }
  ContinueDebugEvent(e.dwProcessId, e.dwThreadId, status);
  return alive;
}

void DebugLoop(DWORD pid) {
  SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
  if (!DebugActiveProcess(pid)) {
    g_error = "Couldn't attach to ARK";
    g_resolvedAt = GetTickCount();
    g_running = false;
    return;
  }
  DebugSetProcessKillOnExit(FALSE);  // WinTek exiting must never take ARK with it
  g_attached = true;

  std::unordered_map<DWORD, HANDLE> threads;
  bool sawAttachBreak = false, alive = true;
  DWORD stopRequestedAt = 0;
  DEBUG_EVENT e;
  // After a stop request, keep handling events until a call in flight has returned and its thread is restored.
  while (alive && (g_running || g_active.threadId)) {
    if (!g_running && !stopRequestedAt) stopRequestedAt = GetTickCount();
    if (stopRequestedAt && GetTickCount() - stopRequestedAt > kStopTimeoutMs) break;
    if (g_running && g_rearm.exchange(false)) ArmAllThreads(pid, true);
    if (WaitForDebugEvent(&e, 50)) alive = HandleEvent(e, threads, sawAttachBreak);
  }
  if (alive) {
    ArmAllThreads(pid, false);
    while (alive && WaitForDebugEvent(&e, 0)) alive = HandleEvent(e, threads, sawAttachBreak);
    DebugActiveProcessStop(pid);
  }
  g_active.threadId = 0;
  DropQueuedCalls();
  g_attached = false;
  g_running = false;
}

LPTOP_LEVEL_EXCEPTION_FILTER g_previousFilter = nullptr;

LONG WINAPI OnCrash(EXCEPTION_POINTERS* info) {
  if(info&&info->ExceptionRecord)WriteCrashLog("Bence",*info->ExceptionRecord);
  if (g_pid && g_breakpoint) ArmAllThreads(g_pid, false);
  return g_previousFilter ? g_previousFilter(info) : EXCEPTION_CONTINUE_SEARCH;
}

unsigned Bit(DebuggerClient client) { return 1u << static_cast<int>(client); }

}  // namespace

void RequestDebugger(DebuggerClient client, bool wanted) {
  if (wanted) g_clients |= Bit(client);
  else g_clients &= ~Bit(client);
}

void SetFrameCallback(DebuggerClient client, FrameCallback callback) { g_callbacks[static_cast<int>(client)] = callback; }

void StopDebugger() {
  g_running = false;
  if (g_thread.joinable()) g_thread.join();
  g_pid = 0;
}

void TickDebugger() {
  const DWORD pid = g_process.pid;
  const bool wanted = g_clients && g_process.IsAttached();
  if (g_thread.joinable() && (!wanted || pid != g_pid || !g_running)) StopDebugger();
  if (!wanted) {
    g_error = nullptr;
    DropQueuedCalls();
    return;
  }
  if (g_thread.joinable()) return;

  // Find the game functions once per game process. A failed search isn't final: it runs again every few seconds,
  // since a search made while ARK was still starting up can miss code that isn't loaded yet.
  const bool found = g_imageBase == g_process.base && g_breakpoint && g_processEvent;
  if (!found && (g_imageBase != g_process.base || GetTickCount() - g_resolvedAt >= kRetryMs)) {
    g_imageBase = g_process.base;
    g_resolvedAt = GetTickCount();
    ResolveAddresses(g_imageBase);
  }
  if (!g_breakpoint || !g_processEvent) {
    g_error = !g_breakpoint && !g_processEvent ? "Game functions not found (both) - retrying"
              : !g_breakpoint                  ? "Game function not found (projection) - retrying"
                                               : "Game function not found (ProcessEvent) - retrying";
    return;
  }
  if (g_error && std::strcmp(g_error, "Couldn't attach to ARK") == 0) {
    if (GetTickCount() - g_resolvedAt < kRetryMs) return;  // try attaching again after a pause
    g_resolvedAt = GetTickCount();
  }
  g_error = nullptr;
  static bool crashHandlerInstalled = false;
  if (!crashHandlerInstalled) {
    crashHandlerInstalled = true;
    g_previousFilter = SetUnhandledExceptionFilter(OnCrash);
  }
  g_pid = pid;
  g_running = true;
  g_thread = std::thread(DebugLoop, pid);
}

bool DebuggerAttached() { return g_attached; }
const char* DebuggerError() { return g_error; }

std::uint64_t QueueProcessEvent(std::uintptr_t object, std::uintptr_t function, std::uintptr_t params) {
  std::lock_guard<std::mutex> lock(g_callMutex);
  g_calls.push_back({ object, function, params, QueuedObject::Capture(object), QueuedObject::Capture(function) });
  return ++g_issued;
}

std::uint64_t CompletedCalls() { return g_completed; }

void SetHookBreakpoint(int slot, std::uintptr_t address, HookCallback callback) {
  if (slot < 0 || slot >= kHookSlots) return;
  if (g_hookAddress[slot] == address && g_hookCallback[slot] == callback) return;
  if (address) {
    g_hookCallback[slot] = callback;
    g_hookAddress[slot] = address;
  } else {
    g_hookAddress[slot] = 0;  // cleared first, so a late hit is ignored rather than calling a stale callback
    g_hookCallback[slot] = nullptr;
  }
  g_rearm = true;
}

}  // namespace wintek
