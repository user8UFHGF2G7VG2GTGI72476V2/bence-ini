#include "engine/Engine.h"
#include "core/Process.h"
#include "engine/Signatures.h"
#include <cctype>

namespace wintek {

namespace {

constexpr const char* kSigObjects = "4C 8B 15 ? ? ? ? 33 F6 48 89 5C 24 ? 48 89 7C 24 ?";
constexpr const char* kSigNames = "48 8B 05 ? ? ? ? 48 85 C0 75 77 48 8B 0D ? ? ? ? 48 89 5C 24 ?";
constexpr const char* kSigWorld = "48 8B 3D ? ? ? ? 40 38 35 ? ? ? ? 48 0F 45 F8 EB 03 48 8B FE 48 85 FF";

constexpr int kMaxClassDepth = 48;
constexpr int kMaxFieldsPerClass = 8192;

struct {
  Address objects = 0;
  Address names = 0;
  Address world = 0;
} g_globals;

// GObjects' chunk pointers and size, cached once per tick by RefreshObjectTable.
std::vector<Address> g_objectChunks;
std::int32_t g_objectCount = 0;

Reflection g_reflection;

}  // namespace

void SetBits(Address address, std::uint8_t mask, bool on) {
  const auto before = Read<std::uint8_t>(address);
  const auto after = static_cast<std::uint8_t>(on ? (before | mask) : (before & ~mask));
  if (after != before) Write(address, after);
}

bool InitEngine() {
  const auto found = FindPatterns(g_process.base, { kSigObjects, kSigNames, kSigWorld });
  for (Address site : found)
    if (!site) return false;
  g_globals.objects = ResolveRipRelative(found[0]);
  g_globals.names = ResolveRipRelative(found[1]);
  g_globals.world = ResolveRipRelative(found[2]);
  return true;
}

void ResetEngine() {
  g_globals = {};
  g_objectChunks.clear();
  g_objectCount = 0;
  g_reflection = {};
  ++g_scanGeneration;
}

Address GObjects() { return g_globals.objects; }
Address GNames() { return g_globals.names; }

void RefreshObjectTable() {
  using namespace offsets;
  g_objectCount = Read<std::int32_t>(g_globals.objects + kObjectCount);
  g_objectChunks.resize(g_objectCount > 0 ? (g_objectCount + kObjectsPerChunk - 1) / kObjectsPerChunk : 0);
  if (g_objectChunks.empty() ||
      !g_memory.ReadRaw(Read<Address>(g_globals.objects), g_objectChunks.data(), g_objectChunks.size() * sizeof(Address))) {
    g_objectChunks.clear();
    g_objectCount = 0;
  }
}

const std::string& Reflection::Name(std::int32_t id) {
  using namespace offsets;
  static const std::string kEmpty;
  if (auto it = names_.find(id); it != names_.end()) return it->second;
  if (id <= 0 || id >= kNamesPerChunk * kMaxNameChunks) return kEmpty;
  const Address table = Read<Address>(g_globals.names);
  const Address chunk = table ? Read<Address>(table + (id / kNamesPerChunk) * sizeof(Address)) : 0;
  const Address entry = chunk ? Read<Address>(chunk + (id % kNamesPerChunk) * sizeof(Address)) : 0;
  if (!entry || (Read<std::int32_t>(entry) & 1)) return kEmpty;  // bit 0: wide string, never used for these names
  char text[128] = {};
  // An entry near the end of a page may not have 127 readable bytes after it; fall back to a short read.
  if (!g_memory.ReadRaw(entry + kNameText, text, sizeof(text) - 1) && !g_memory.ReadRaw(entry + kNameText, text, 32)) return kEmpty;
  text[sizeof(text) - 1] = 0;
  return names_.emplace(id, text).first->second;
}

Address Reflection::FindField(Address cls, const char* name) {
  using namespace offsets::reflection;
  for (int depth = 0; cls && depth < kMaxClassDepth; cls = Read<Address>(cls + kSuperStruct), ++depth) {
    int n = 0;
    for (Address field = Read<Address>(cls + kChildren); field && n < kMaxFieldsPerClass; field = Read<Address>(field + kNext), ++n)
      if (NameOf(field) == name) return field;
  }
  return 0;
}

std::int32_t Reflection::PropertyOffset(Address cls, const char* name) {
  const Address field = FindField(cls, name);
  const std::int32_t offset = field ? Read<std::int32_t>(field + offsets::reflection::kPropertyOffset) : 0;
  return offset >= 0x20 && offset < 0x8000 ? offset : 0;
}

bool Reflection::IsA(Address cls, const char* className) {
  for (int depth = 0; cls && depth < kMaxClassDepth; cls = Read<Address>(cls + offsets::reflection::kSuperStruct), ++depth)
    if (NameOf(cls) == className) return true;
  return false;
}

Reflection& MainReflection() { return g_reflection; }

bool BoolProperty::Get(Address object) {
  using namespace offsets::reflection;
  if (!object) return false;
  const Address cls = ClassOf(object);
  auto it = byClass_.find(cls);
  if (it == byClass_.end()) {
    // A bool property is a bit: byte offset within the property plus a single-bit mask.
    const Address field = MainReflection().FindField(cls, name_);
    std::int32_t offset = 0;
    std::uint8_t mask = 0;
    if (field) {
      mask = Read<std::uint8_t>(field + kBoolFieldMask);
      if (mask && !(mask & (mask - 1))) offset = Read<std::int32_t>(field + kPropertyOffset) + Read<std::uint8_t>(field + kBoolByteOffset);
    }
    it = byClass_.emplace(cls, std::make_pair(offset, mask)).first;
  }
  const auto [offset, mask] = it->second;
  return offset && (Read<std::uint8_t>(object + offset) & mask);
}

bool ObjectRef::Alive() const {
  using namespace offsets;
  if (!object || index < 0 || index >= g_objectCount) return false;
  const Address chunk = g_objectChunks[index / kObjectsPerChunk];
  return chunk && Read<Address>(chunk + (index % kObjectsPerChunk) * kObjectItemSize) == object;
}

GameContext ReadContext() {
  using namespace offsets;
  GameContext c;
  c.world = Read<Address>(g_globals.world);
  const Address gameInstance = c.world ? Read<Address>(c.world + world::kGameInstance) : 0;
  const Address localPlayers = gameInstance ? Read<Address>(gameInstance + world::kLocalPlayers) : 0;
  const Address localPlayer = localPlayers ? Read<Address>(localPlayers) : 0;
  if (!localPlayer) return c;
  c.controller = Read<Address>(localPlayer + player::kController);
  c.viewport = Read<Address>(localPlayer + player::kViewportClient);
  c.engine = c.viewport ? Read<Address>(c.viewport + viewport::kEngine) : 0;
  if (c.controller) {
    c.camera = Read<Address>(c.controller + player::kCamera);
    c.hud = Read<Address>(c.controller + player::kHud);
    c.pawn = Read<Address>(c.controller + player::kPawn);
  }
  return c;
}

// The proxy is read here while the render thread owns it, so one freed between our read and write could take
// a stray bit. In practice proxies live as long as their component is registered.
void SetDrawInGame(Address component, bool draw) {
  using namespace offsets::primitive;
  if (const Address proxy = Read<Address>(component + kSceneProxy)) SetBits(proxy + kProxyFlags, kDrawInGame, draw);
}

bool IsVisibleInGame(Address component) {
  return (Read<std::uint8_t>(component + offsets::primitive::kVisibility) & 0xC0) == 0x40;
}

Address MeshAssetOf(Reflection& reflection, std::unordered_map<Address, std::int32_t>& offsetCache, Address component) {
  const Address cls = ClassOf(component);
  auto it = offsetCache.find(cls);
  if (it == offsetCache.end()) {
    std::int32_t offset = reflection.PropertyOffset(cls, "StaticMesh");
    if (!offset) offset = reflection.PropertyOffset(cls, "SkeletalMesh");
    it = offsetCache.emplace(cls, offset).first;
  }
  return it->second ? Read<Address>(component + it->second) : 0;
}

Address NativeOf(Address function) {
  if (!function || !g_process.base) return 0;
  const Address base = g_process.base;
  const std::int32_t peAt = Read<std::int32_t>(base + 0x3C);
  const std::uint32_t size = peAt > 0 && peAt < 0x1000 ? Read<std::uint32_t>(base + peAt + 0x50) : 0;
  if (!size) return 0;
  for (Address at = 0x80; at < 0x110; at += sizeof(Address)) {
    const Address value = Read<Address>(function + at);
    if (value >= base + 0x1000 && value < base + size) return value;
  }
  return 0;
}

Address FrameLocals(Address frame, Address function) {
  Address slots[10] = {};
  if (!function || !g_memory.ReadRaw(frame, slots, sizeof(slots))) return 0;
  for (int i = 0; i + 3 < 10; ++i)
    if (slots[i] == function) return slots[i + 3];
  return 0;
}

std::string ToLower(std::string text) {
  for (char& ch : text) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  return text;
}

}  // namespace wintek
