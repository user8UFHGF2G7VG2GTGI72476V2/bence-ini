#include "engine/PostProcessVolumes.h"
#include <windows.h>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>

namespace wintek {

namespace {

constexpr DWORD kRescanMs = 2000;
constexpr std::int32_t kMaxLevels = 4096;
constexpr std::int32_t kMaxActors = 200000;

struct {
  std::vector<PostProcessVolume> volumes;
  std::unordered_set<Address> seen;
  std::unordered_map<Address, bool> isVolumeClass;
  Address world = 0;
  DWORD scannedAt = 0;
} g_state;

bool IsVolumeClass(Address cls) {
  auto it = g_state.isVolumeClass.find(cls);
  if (it == g_state.isVolumeClass.end()) it = g_state.isVolumeClass.emplace(cls, IsA(cls, "PostProcessVolume")).first;
  return it->second;
}

PostProcessVolume Snapshot(Address actor) {
  using namespace offsets::volume;
  PostProcessVolume v;
  v.ref = ObjectRef::Of(actor);
  g_memory.ReadRaw(actor + kOverrideFlags, v.overrides, sizeof(v.overrides));
  v.saturation = Read<float>(actor + kFilmSaturation);
  v.contrast = Read<float>(actor + kFilmContrast);
  g_memory.ReadRaw(actor + kSceneColorTint, v.tint, sizeof(v.tint));
  v.flags = Read<std::uint8_t>(actor + kFlags);
  return v;
}

void Scan(Address world) {
  using namespace offsets::world;
  auto& volumes = g_state.volumes;
  volumes.erase(std::remove_if(volumes.begin(), volumes.end(), [](const PostProcessVolume& v) { return !v.ref.Alive(); }), volumes.end());

  const auto levels = Read<TArray>(world + kLevels);
  if (!levels.data || levels.count <= 0 || levels.count > kMaxLevels) return;
  std::vector<Address> levelList(levels.count);
  if (!g_memory.ReadRaw(levels.data, levelList.data(), levelList.size() * sizeof(Address))) return;

  std::vector<Address> actors;
  for (Address level : levelList) {
    const auto list = level ? Read<TArray>(level + kLevelActors) : TArray{};
    if (!list.data || list.count <= 0 || list.count > kMaxActors) continue;
    actors.resize(list.count);
    if (!g_memory.ReadRaw(list.data, actors.data(), actors.size() * sizeof(Address))) continue;
    for (Address actor : actors) {
      if (!actor || !g_state.seen.insert(actor).second || !IsVolumeClass(ClassOf(actor))) continue;
      volumes.push_back(Snapshot(actor));
    }
  }
}

}  // namespace

void TrackVolumes(Address world, bool wanted) {
  // The world reads as 0 during loading screens; the list, and what was changed, is kept until a new world loads.
  if (world && world != g_state.world) {
    ResetVolumes();
    g_state.world = world;
  }
  if (!world || !wanted) return;
  const DWORD now = GetTickCount();
  if (g_state.scannedAt && now - g_state.scannedAt < kRescanMs) return;
  g_state.scannedAt = now;
  Scan(world);
}

std::vector<PostProcessVolume>& Volumes() { return g_state.volumes; }

void ResetVolumes() { g_state = {}; }

}  // namespace wintek
