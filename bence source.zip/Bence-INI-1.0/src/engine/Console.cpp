#include "engine/Console.h"
#include "core/Diagnostics.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <deque>

namespace wintek {

namespace {

constexpr std::size_t kParamBytes = 0x1000;
constexpr Address kStringAt = 0x100;  // the command text, after the parameter block
constexpr std::size_t kMaxChars = (kParamBytes - kStringAt) / sizeof(wchar_t) - 1;

struct FString {
  Address data;
  std::int32_t count, max;
};

struct Pending {
  std::wstring command;
  std::uint64_t id;
};

struct {
  std::deque<Pending> pending;
  std::uint64_t issuedId = 0, doneId = 0;
  Address params = 0;  // memory we allocate in ARK for the parameters (data only, never executed)
  Address controllerClass = 0;
  Address function = 0;  // PlayerController.ConsoleCommand
  std::int32_t commandAt = 0, writeLogAt = -1, returnAt = -1;
  bool running = false;
  std::uint64_t ticket = 0;
  const char* error = nullptr;
} g_console;

// A property's offset inside a function's parameter block (0 is a valid offset here, unlike for objects).
std::int32_t ParamOffset(Address function, const char* name) {
  const Address field = MainReflection().FindField(function, name);
  if (!field) return -1;
  const std::int32_t offset = Read<std::int32_t>(field + offsets::reflection::kPropertyOffset);
  return offset >= 0 && offset < 0x100 ? offset : -1;
}

bool Resolve(Address controller) {
  const Address cls = ClassOf(controller);
  if (cls == g_console.controllerClass && g_console.function) return true;
  g_console.controllerClass = cls;
  // PlayerController.ConsoleCommand is the engine's; ARK's controller also has a client function servers use
  // to run console commands on players, which does the same thing locally.
  static const char* const kCandidates[] = { "ConsoleCommand", "ClientRunLocalConsoleCommand", "ClientExecuteConsoleCommand" };
  const char* used = nullptr;
  for (const char* name : kCandidates) {
    g_console.function = MainReflection().FindField(cls, name);
    if (g_console.function) {
      used = name;
      break;
    }
  }
  g_diag.consoleFunction = used ? used : "not found";
  if (!g_console.function) {
    g_console.error = "Console settings aren't available on this version of ARK.";
    return false;
  }
  g_console.commandAt = ParamOffset(g_console.function, "Command");
  if (g_console.commandAt < 0) g_console.commandAt = ParamOffset(g_console.function, "Cmd");
  g_console.writeLogAt = ParamOffset(g_console.function, "bWriteToLog");
  g_console.returnAt = ParamOffset(g_console.function, "ReturnValue");
  if (g_console.commandAt < 0) {
    g_console.function = 0;
    g_console.error = "Console settings aren't available on this version of ARK.";
    return false;
  }
  g_console.error = nullptr;
  return true;
}

}  // namespace

std::uint64_t QueueConsoleCommand(const std::wstring& command, bool replaceSame) {
  if (replaceSame) {
    const std::wstring key = command.substr(0, command.find(L' '));
    // Never drop the front one while it's running.
    for (auto it = g_console.pending.begin() + (g_console.running ? 1 : 0); it != g_console.pending.end();) {
      if (it->command.substr(0, it->command.find(L' ')) == key) it = g_console.pending.erase(it);
      else ++it;
    }
  }
  const std::uint64_t id = ++g_console.issuedId;
  g_console.pending.push_back({ command.substr(0, kMaxChars), id });
  return id;
}

bool ConsoleCommandDone(std::uint64_t id) {
  if (id <= g_console.doneId) return true;
  for (const Pending& p : g_console.pending)
    if (p.id == id) return false;
  return true;  // dropped
}

void TickConsole(const GameContext& game) {
  if (g_console.running && CompletedCalls() >= g_console.ticket) {
    g_console.running = false;
    const Pending& done = g_console.pending.front();
    g_diag.consoleLast = std::string(done.command.begin(), done.command.end()) + " (sent)";
    g_console.doneId = done.id;
    g_console.pending.pop_front();
  }
  const bool busy = g_console.running || !g_console.pending.empty();
  RequestDebugger(DebuggerClient::Console, busy);
  if (busy && !g_console.running) {
    const std::wstring& next = g_console.pending.front().command;
    g_diag.consoleLast = std::string(next.begin(), next.end()) +
                         (!game.controller ? " (waiting for game)" : !DebuggerAttached() ? " (waiting for debugger)" : "");
    if (const char* error = DebuggerError()) g_diag.consoleLast += std::string(" - ") + error;
  }
  if (g_console.running || g_console.pending.empty() || !game.controller || !DebuggerAttached()) return;
  if (!Resolve(game.controller)) {
    if (!g_console.pending.empty()) g_console.doneId = g_console.pending.back().id;
    g_console.pending.clear();
    return;
  }
  if (!g_console.params) {
    g_console.params = reinterpret_cast<Address>(VirtualAllocEx(g_process.handle, nullptr, kParamBytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    if (!g_console.params) return;
  }

  const std::wstring& command = g_console.pending.front().command;
  std::uint8_t block[kStringAt] = {};
  const auto length = static_cast<std::int32_t>(command.size() + 1);
  const FString text{ g_console.params + kStringAt, length, length };
  std::memcpy(block + g_console.commandAt, &text, sizeof(text));
  if (g_console.writeLogAt >= 0) block[g_console.writeLogAt] = 0;
  // ReturnValue stays an empty FString; the game fills it in.
  g_memory.WriteRaw(g_console.params, block, sizeof(block));
  g_memory.WriteRaw(g_console.params + kStringAt, command.c_str(), length * sizeof(wchar_t));
  g_console.ticket = QueueProcessEvent(game.controller, g_console.function, g_console.params);
  g_console.running = true;
}

void FlushConsole(unsigned timeoutMs) {
  const ULONGLONG until = GetTickCount64() + timeoutMs;
  while (!ConsoleIdle() && GetTickCount64() < until && g_process.IsAttached()) {
    RefreshObjectTable();
    TickConsole(ReadContext());
    TickDebugger();
    Sleep(10);
  }
  RequestDebugger(DebuggerClient::Console, false);
}

bool ConsoleIdle() { return !g_console.running && g_console.pending.empty(); }
const char* ConsoleError() { return g_console.error; }

void ResetConsole() {
  g_console.doneId = g_console.issuedId;
  g_console.pending.clear();
  g_console.params = 0;  // belonged to the previous game process
  g_console.controllerClass = 0;
  g_console.function = 0;
  g_console.running = false;
  RequestDebugger(DebuggerClient::Console, false);
}

}  // namespace wintek
