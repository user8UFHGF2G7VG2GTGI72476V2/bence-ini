#pragma once
#include "engine/Engine.h"

// Finds where a named show flag (like "Fog") lives in the viewport's EngineShowFlags. The flags have no names
// in memory, so the game is asked to flip one with the "show <Name>" console command, the bit that changed is
// noted, and the original flags are put straight back. Each flag is looked up once per game session.
namespace wintek {

// The flag's bit index, or -1 while it's still being looked up (or not asked for yet), or -2 if it can't be found.
int ShowFlagBit(const char* name);
// Asks for the flag to be looked up. Call every tick while a feature wants it.
void RequestShowFlag(const char* name);
// Main thread, at the start of every feature tick, before anything writes the view flags.
void TickShowFlagProbe(Address viewport);
void ResetShowFlagProbe();

}  // namespace wintek
