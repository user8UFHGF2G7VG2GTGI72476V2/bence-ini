#pragma once
#include "engine/Engine.h"
namespace wintek {
// Raw reads only: usable on the debugger thread while the game is paused.
struct QueuedObject {
 Address object=0;int index=-1,serial=0;
 static Address Slot(int index){
  Address objects=GObjects();if(!objects||index<0)return 0;
  int count=Read<int>(objects+offsets::kObjectCount);if(index>=count||count>12000000)return 0;
  Address chunks=Read<Address>(objects),chunk=chunks?Read<Address>(chunks+(index/offsets::kObjectsPerChunk)*8):0;
  return chunk?chunk+(index%offsets::kObjectsPerChunk)*offsets::kObjectItemSize:0;
 }
 static QueuedObject Capture(Address object){
  if(!object)return {};int index=Read<int>(object+offsets::object::kIndex);Address slot=Slot(index);
  if(!slot||Read<Address>(slot)!=object)return {};int serial=Read<int>(slot+8);
  return serial>0?QueuedObject{object,index,serial}:QueuedObject{};
 }
 bool Alive()const{
  if(!object||serial<=0)return false;Address slot=Slot(index);
  return slot&&Read<Address>(slot)==object&&Read<int>(slot+8)==serial&&
    Read<int>(object+offsets::object::kIndex)==index&&
    !(Read<unsigned>(object+offsets::object::kFlags)&(0x100|0x4000|0x8000|0x10000));
 }
};
}
