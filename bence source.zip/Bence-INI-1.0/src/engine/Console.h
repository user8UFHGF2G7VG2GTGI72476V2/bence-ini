#pragma once
#include "engine/Engine.h"
#include <string>

// Runs console commands (like "r.ScreenPercentage 50") in ARK by having the game thread call the local
// PlayerController's ConsoleCommand function through the debugger (see engine/Debugger.h). The debugger is
// only attached while a command is waiting or running, then let go again.
namespace wintek {

// Returns an id for ConsoleCommandDone. With `replaceSame`, a waiting command for the same setting (same first
// word) is dropped, since only the latest value matters.
std::uint64_t QueueConsoleCommand(const std::wstring& command, bool replaceSame = true);
bool ConsoleCommandDone(std::uint64_t id);  // ran, or was dropped
void TickConsole(const GameContext& game);  // main thread, every feature tick
// Keeps ticking until every queued command has run or `timeoutMs` passes. Used when closing.
void FlushConsole(unsigned timeoutMs);
bool ConsoleIdle();
const char* ConsoleError();  // nullptr while fine
void ResetConsole();

}  // namespace wintek
