#pragma once
#include "core/Memory.h"
#include "engine/Offsets.h"
#include <atomic>
#include <cstdint>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

// Access to ARK's engine from outside the process: the global object and name tables, reflection lookups,
// and the local player's objects. Everything here is read through ReadProcessMemory.
namespace wintek {

using Address = std::uintptr_t;

template <typename T>
T Read(Address address) { return g_memory.Read<T>(address); }

template <typename T>
void Write(Address address, const T& value) { g_memory.Write(address, value); }

// Sets or clears `mask` in the byte at `address`, writing only if it changes.
void SetBits(Address address, std::uint8_t mask, bool on);

struct TArray {
  Address data;
  std::int32_t count, max;
};

// Finds GObjects, GNames and GWorld in the attached game. Returns false if the signatures don't match.
bool InitEngine();
// Forgets everything resolved for the previous game process.
void ResetEngine();
Address GObjects();
Address GNames();
// Re-reads GObjects' size and chunk table, which ObjectRef::Alive uses. Call once per tick on the main thread.
void RefreshObjectTable();

// Background scans (No Water, No XYZ) tag their results with this and drop them if it changed meanwhile,
// so a scan started before a world change or re-attach never applies to the new one.
inline std::atomic<std::uint32_t> g_scanGeneration{ 0 };

// Name and reflection lookups with a cache. Not thread-safe: each worker thread uses its own instance.
class Reflection {
public:
  const std::string& Name(std::int32_t id);
  const std::string& NameOf(Address object) { return Name(Read<std::int32_t>(object + offsets::object::kName)); }
  Address FindField(Address cls, const char* name);
  std::int32_t PropertyOffset(Address cls, const char* name);  // 0 if missing
  bool IsA(Address cls, const char* className);

private:
  std::unordered_map<std::int32_t, std::string> names_;
};

// The main thread's instance, used through the helpers below.
Reflection& MainReflection();
inline const std::string& NameOf(Address object) { return MainReflection().NameOf(object); }
inline std::int32_t PropertyOffset(Address cls, const char* name) { return MainReflection().PropertyOffset(cls, name); }
inline bool IsA(Address cls, const char* className) { return MainReflection().IsA(cls, className); }
inline Address ClassOf(Address object) { return Read<Address>(object + offsets::object::kClass); }

// Reads a bool property by name, caching the lookup per class. False if the class doesn't have it.
class BoolProperty {
public:
  explicit BoolProperty(const char* name) : name_(name) {}
  bool Get(Address object);

private:
  const char* name_;
  std::unordered_map<Address, std::pair<std::int32_t, std::uint8_t>> byClass_;
};

// An object plus its GObjects index, so it can be checked for still being alive later.
struct ObjectRef {
  Address object = 0;
  std::int32_t index = 0;

  static ObjectRef Of(Address object) { return { object, Read<std::int32_t>(object + offsets::object::kIndex) }; }
  bool Alive() const;  // main thread only, see RefreshObjectTable
  bool operator==(const ObjectRef& other) const { return object == other.object; }
};

// Calls fn(object, index) for every object in GObjects, reading a whole chunk per call so a full walk
// (about a million objects) stays well under a second. fn returns false to stop early.
template <typename Fn>
void ForEachObject(Fn&& fn) {
  using namespace offsets;
  const Address objects = GObjects();
  const std::int32_t count = Read<std::int32_t>(objects + kObjectCount);
  const Address chunks = Read<Address>(objects);
  std::vector<std::uint8_t> items(kObjectsPerChunk * kObjectItemSize);
  for (std::int32_t c = 0; c * kObjectsPerChunk < count; ++c) {
    const Address chunk = Read<Address>(chunks + c * sizeof(Address));
    if (!chunk || !g_memory.ReadRaw(chunk, items.data(), items.size())) continue;
    for (int i = 0; i < kObjectsPerChunk; ++i) {
      Address object;
      std::memcpy(&object, &items[i * kObjectItemSize], sizeof(object));
      if (object && !fn(object, c * kObjectsPerChunk + i)) return;
    }
  }
}

// The local player's objects for this tick. Any of them can be 0 (main menu, loading, dead).
struct GameContext {
  Address world = 0;
  Address controller = 0;
  Address viewport = 0;
  Address engine = 0;
  Address camera = 0;
  Address hud = 0;
  Address pawn = 0;
};
GameContext ReadContext();

// Hides or shows a primitive component by flipping its render proxy's DrawInGame bit, which the renderer checks
// every frame. The proxy is rebuilt with the component's render state, so callers re-apply this every tick.
void SetDrawInGame(Address component, bool draw);
// Whether the game itself wants the component drawn (bVisible set, bHiddenInGame clear).
bool IsVisibleInGame(Address component);

// The StaticMesh / SkeletalMesh asset a mesh component draws, with the property offset cached per class.
Address MeshAssetOf(Reflection& reflection, std::unordered_map<Address, std::int32_t>& offsetCache, Address component);

std::string ToLower(std::string text);

// A UFunction's native handler (UFunction::Func), the only pointer into ShooterGame.exe's code in a UFunction past
// its UStruct part. 0 if not found. Hardware breakpoints go here to see (or skip) calls that arrive through
// ProcessEvent, like replies and messages from the server.
Address NativeOf(Address function);
// Inside such a handler's first instruction, rdx is the FFrame: Node (the UFunction), Object, Code, then Locals, the
// parameter block. Returns Locals if `frame` is a call of `function`, else 0.
Address FrameLocals(Address frame, Address function);

}  // namespace wintek
