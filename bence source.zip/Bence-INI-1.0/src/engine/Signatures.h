#pragma once
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <vector>

namespace wintek {

// Byte patterns in IDA style, e.g. "48 8B 05 ? ? ? ? 48 85 C0".

// Scans the executable sections of the module at `imageBase` once for all `patterns`.
// Returns the first match of each, or 0 where a pattern wasn't found.
std::vector<std::uintptr_t> FindPatterns(std::uintptr_t imageBase, std::initializer_list<const char*> patterns);

// First match of `pattern` in [start, start + size).
std::uintptr_t FindPattern(std::uintptr_t start, std::size_t size, const char* pattern);

// Target of a `mov reg, [rip + disp32]` (7 bytes, displacement at +3).
std::uintptr_t ResolveRipRelative(std::uintptr_t instruction);

}  // namespace wintek
