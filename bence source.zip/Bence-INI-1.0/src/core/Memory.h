#pragma once
#include <windows.h>
#include <cstdint>

namespace wintek {

// ReadProcessMemory / WriteProcessMemory on the attached game. Apart from the debugger (engine/Debugger.h),
// this is the only way WinTek touches ARK.
class Memory {
public:
  void Attach(HANDLE process) { handle_ = process; }
  void Detach() { handle_ = nullptr; }
  bool IsValid() const { return handle_ != nullptr && handle_ != INVALID_HANDLE_VALUE; }

  bool ReadRaw(std::uintptr_t address, void* out, SIZE_T size) const {
    if (!IsValid() || !address || !out || !size) return false;
    SIZE_T done = 0;
    return ReadProcessMemory(handle_, reinterpret_cast<LPCVOID>(address), out, size, &done) && done == size;
  }

  bool WriteRaw(std::uintptr_t address, const void* in, SIZE_T size) const {
    if (!IsValid() || !address || !in || !size) return false;
    SIZE_T done = 0;
    return WriteProcessMemory(handle_, reinterpret_cast<LPVOID>(address), in, size, &done) && done == size;
  }

  template <typename T>
  T Read(std::uintptr_t address) const {
    T value{};
    ReadRaw(address, &value, sizeof(T));
    return value;
  }

  template <typename T>
  bool Write(std::uintptr_t address, const T& value) const {
    return WriteRaw(address, &value, sizeof(T));
  }

private:
  HANDLE handle_ = nullptr;
};

inline Memory g_memory;

}  // namespace wintek
