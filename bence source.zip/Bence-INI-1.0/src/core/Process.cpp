#include "core/Process.h"
#include "core/Memory.h"
#include <tlhelp32.h>

namespace wintek {

namespace {

DWORD FindProcess(const wchar_t* exeName) {
  HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (snap == INVALID_HANDLE_VALUE) return 0;
  DWORD found = 0;
  PROCESSENTRY32W entry{ sizeof(entry) };
  for (BOOL ok = Process32FirstW(snap, &entry); ok && !found; ok = Process32NextW(snap, &entry)) {
    if (_wcsicmp(entry.szExeFile, exeName) == 0) found = entry.th32ProcessID;
  }
  CloseHandle(snap);
  return found;
}

std::uintptr_t FindModule(DWORD pid, const wchar_t* moduleName) {
  HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
  if (snap == INVALID_HANDLE_VALUE) return 0;
  std::uintptr_t found = 0;
  MODULEENTRY32W entry{ sizeof(entry) };
  for (BOOL ok = Module32FirstW(snap, &entry); ok && !found; ok = Module32NextW(snap, &entry)) {
    if (_wcsicmp(entry.szModule, moduleName) == 0) found = reinterpret_cast<std::uintptr_t>(entry.modBaseAddr);
  }
  CloseHandle(snap);
  return found;
}

}  // namespace

void Process::Poll() {
  if (IsAttached() && IsAlive()) return;
  Detach();
  Attach();
}

bool Process::IsAttached() const { return pid != 0 && g_memory.IsValid(); }

bool Process::Attach() {
  const DWORD id = FindProcess(kExeName);
  if (!id) return false;
  constexpr DWORD kAccess = PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_QUERY_INFORMATION | SYNCHRONIZE;
  HANDLE h = OpenProcess(kAccess, FALSE, id);
  if (!h) return false;
  const std::uintptr_t moduleBase = FindModule(id, kExeName);
  if (!moduleBase) {
    CloseHandle(h);
    return false;
  }
  pid = id;
  handle = h;
  base = moduleBase;
  g_memory.Attach(h);
  return true;
}

void Process::Detach() {
  if (handle) CloseHandle(handle);
  handle = nullptr;
  pid = 0;
  base = 0;
  g_memory.Detach();
}

bool Process::IsAlive() const {
  return handle && WaitForSingleObject(handle, 0) == WAIT_TIMEOUT;
}

}  // namespace wintek
