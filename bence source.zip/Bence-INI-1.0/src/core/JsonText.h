#pragma once
#include <string>
#include <cstddef>
namespace wintek {
inline std::string JsonQuote(const char* input){std::string out="\"";for(const unsigned char* p=reinterpret_cast<const unsigned char*>(input);*p;++p){switch(*p){case '"':out+="\\\"";break;case '\\':out+="\\\\";break;case '\n':out+="\\n";break;case '\r':out+="\\r";break;case '\t':out+="\\t";break;default:if(*p<32){const char* h="0123456789abcdef";out+="\\u00";out+=h[*p>>4];out+=h[*p&15];}else out+=static_cast<char>(*p);}}out+='"';return out;}
inline bool JsonReadText(const char* p,std::string& out,std::size_t maxBytes){
 if(!p||*p++!='"')return false;std::string result;
 auto hex=[](char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;};
 auto unit=[&](unsigned& n){n=0;for(int i=0;i<4;++i){if(!*p)return false;int v=hex(*p++);if(v<0)return false;n=(n<<4)|v;}return true;};
 while(*p&&*p!='"'){
  unsigned char c=static_cast<unsigned char>(*p++);if(c<32)return false;
  if(c!='\\')result+=static_cast<char>(c);else{switch(*p++){case '"':result+='"';break;case '\\':result+='\\';break;case '/':result+='/';break;case 'n':result+='\n';break;case 'r':result+='\r';break;case 't':result+='\t';break;case 'b':result+='\b';break;case 'f':result+='\f';break;case 'u':{
   unsigned n=0;if(!unit(n))return false;if(n>=0xd800&&n<=0xdbff){if(p[0]!='\\'||p[1]!='u')return false;p+=2;unsigned low=0;if(!unit(low)||low<0xdc00||low>0xdfff)return false;n=0x10000+((n-0xd800)<<10)+(low-0xdc00);}else if(n>=0xdc00&&n<=0xdfff)return false;if(!n)return false;
   if(n<0x80)result+=static_cast<char>(n);else if(n<0x800){result+=static_cast<char>(0xc0|(n>>6));result+=static_cast<char>(0x80|(n&63));}else if(n<0x10000){result+=static_cast<char>(0xe0|(n>>12));result+=static_cast<char>(0x80|((n>>6)&63));result+=static_cast<char>(0x80|(n&63));}else{result+=static_cast<char>(0xf0|(n>>18));result+=static_cast<char>(0x80|((n>>12)&63));result+=static_cast<char>(0x80|((n>>6)&63));result+=static_cast<char>(0x80|(n&63));}break;}
   default:return false;
  }}if(result.size()>maxBytes)return false;
 }if(*p!='"')return false;out=std::move(result);return true;
}
inline bool ValidConfigName(const std::string& s){if(s.empty()||s.size()>48||s.front()==' '||s.back()==' ')return false;for(unsigned char c:s)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c==' '||c=='_'||c=='-'))return false;std::string upper=s;for(char& c:upper)if(c>='a'&&c<='z')c-=32;if(upper=="CON"||upper=="PRN"||upper=="AUX"||upper=="NUL"||upper=="CONIN"||upper=="CONOUT")return false;if(upper.size()==4&&(upper.substr(0,3)=="COM"||upper.substr(0,3)=="LPT")&&upper[3]>='1'&&upper[3]<='9')return false;return true;}
}
