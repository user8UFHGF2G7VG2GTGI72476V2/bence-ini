#pragma once
#include "imgui.h"

namespace wintek {

// A feature that can be switched on from the menu or with a global hotkey (an ImGuiKey, 0 = unbound).
struct KeyedToggle {
  bool on = false;
  int key = 0;
};

struct IniSettings {
  KeyedToggle normal, hard, potato;  // view-mode presets, one at a time
  KeyedToggle stalker;
  float stalkerDistance = 240.0f;  // metres
  KeyedToggle fullbright;
  float fullbrightLevel = 2.5f;
  KeyedToggle noXyz, noRockTrees, noLandscape, noWater, noHands, noHud, noFoliage, removeParticle;
  KeyedToggle lowMemory;
  int lowMemoryScale = 50;  // render resolution in percent while Low Memory is on
  KeyedToggle blackSky;
  KeyedToggle blackStructures;
};

// The HUD tab: things drawn on a see-through overlay on top of the game window.
struct HudSettings {
  int hudFont = 0;                    // see kHudFonts in hud/HudStyle.h (0 = Verdana, the original look)
  KeyedToggle watermark{ true, 0 };  // "Bence INI" in a top corner of the game
  int watermarkCorner = 1;            // 0 top left, 1 top right
  int watermarkColor = 0;             // see kWatermarkColors in hud/HudStyle.h
  int watermarkSize = 20;             // text height in pixels
  KeyedToggle crosshair;
  int crossShape = 2;  // see kCrossShapes in tabs/hud/HudTab.cpp
  int crossColor = 1;
  int crossSize = 8;
  int crossThickness = 2;
  int crossOpacity=100;
  int crossGap = 3;
  bool crossOutline = true;

  KeyedToggle info;
  int infoCorner = 0;  // top left, top right, bottom left, bottom right
  bool infoFps = true, infoClock = true, infoTimer = true, infoCoords = true;
  bool infoPing=false, infoServerFps=false, infoPlayers=false, infoTurrets=false, infoFriendlyTurrets=false, infoSlots=false, infoServerName=false, infoRainbow=false;
  int infoScale=100;

  KeyedToggle armor;  // Armor HUD: equipped armor with durability, down the right side
  int armorSize = 100;         // icon scale, percent
  int armorTextSize = 100;     // text scale, percent
  int armorYOffset = 360;      // how far above the bottom the column starts, in pixels at 1440p
  bool armorShowDurability = true;
  bool armorPercent = false;   // show durability as a percentage instead of the number
  bool armorCount = true;      // "x2" for spare copies you carry

  KeyedToggle penisEsp;
  int penisEspRange = 300, penisEspSize = 28;
  KeyedToggle tekIndicator;
  bool tekAnyWeapon=false;int tekRange=50,tekScale=100;float tekX=50,tekY=43;
  KeyedToggle trajectory, playerOutlines, turretOutlines;
  int trajectorySeconds = 3, outlineRange = 150;
  bool outlineEnemiesOnly = false;
  KeyedToggle corruptedEsp;
  int corruptedEspRange = 300;  // metres, 20..700

  KeyedToggle spyglass;  // Awesome Spyglass: wild dinos, your tribe's tames and structures
  float spyX = 50.0f, spyY = 64.0f;  // percent of the game window
  int spyRange = 300;                 // metres, 20..700
  bool spyTamedPoints=true, spyColors=true, spyBackground=true;
  int spyLockKey=0, spyScale=100;
  bool spyWildPoints = true;          // wild dinos: the level-up points each stat rolled

  KeyedToggle hp;
  float hpX = 2.0f, hpY = 92.0f;  // percent of the game window
  KeyedToggle mountHp;
  float mountX = 2.0f, mountY = 81.0f;

  KeyedToggle playerList;      // Player List (Admin): connected players' IDs, gamertags and names
  int playerSide = 1;          // 0 left, 1 right
  float playerY = 18.0f;       // top of the panel, percent of the game window
  int playerTextSize = 15;     // pixels
  int playerMaxRows = 30;
  int playerRefresh = 5;       // seconds between requests to the server
};

struct OtherSettings {
  KeyedToggle stretchedRes;
  float stretchHorizontal = 1.333f;
  float stretchVertical = 1.0f;
  int stretchWidth = 1440;
  int stretchHeight = 1080;

  bool vibrance = false;
  int vibranceLevel = 50;

  bool fov = false;
  int fovLevel = 90;

  bool colorFilter = false;
  float filterSaturation = 100.0f;
  float filterContrast = 100.0f;
  float filterBrightness = 100.0f;
  float filterGamma = 1.0f;
  float filterTemperature = 0.0f;
  float filterTint = 0.0f;  // -100 magenta .. +100 green
  float filterSharpen=0.0f;
  int filterPreset = 0;     // see kFilterPresets in tabs/other/ColorFilter.h
};

// The Visual tab.
struct VisualSettings {
  KeyedToggle noFog, noClouds, noShadows, noBloom, noLensFlare, noMotionBlur;
  KeyedToggle viewDistance;
  float viewDistanceScale = 2.0f;  // r.ViewDistanceScale
  KeyedToggle fpsLimit;
  int maxFps = 60;                 // t.MaxFPS
  int textureQuality = 0;          // 0 = leave ARK's setting, 1..4 = Low..Epic
};

// The Misc tab.
struct MiscSettings {
  KeyedToggle autoForge, quickPickup, takeAll;
  bool forgeGas=false, forgeMetal=false, forgePull=false, forgeDedi=false, forgeTurnOn=false;
  int forgeRange=15, pickupActionKey=0, takeAllActionKey=0;
  KeyedToggle structureSnap;  // Turret Snap; keeps the existing saved setting
  KeyedToggle structureSnapOther;
  int vaultSnapGap = 2;  // centimetres between measured bounds
  int structureSnapSpacing = 100;
  int structureSnapAngle = 90;
  bool snapVaults = true, snapOtherStructures = true;
  int snapSpacing = 100;  // centimetres, anchor-local XY grid
  int snapAngle = 90;
  KeyedToggle turretFiller;     // top up your turrets from your inventory as you walk past
  int heavyStacks = 20;         // stacks of advanced rifle bullets (100 each) per heavy turret
  int tekStacks = 1;            // stacks of element shards (1000 each) per Tek turret
  bool showTurretFill = true;   // markers on your turrets within range
  int turretRange = 150;        // metres, 20..700
  KeyedToggle resourcePull;
  int pullRange = 15, pullCrafts = 1;
  KeyedToggle autoChemBench;
  int chemRecipe = 1, chemRange = 10, chemQueue = 10;
  bool chemSupply = true, chemCollect = true, chemFuel = true;
  int chemGasoline = 5;
  KeyedToggle autoMating;
  int matingRange = 10;
  KeyedToggle betterInput;      // Drop / Transfer / Use fire every frame while held in the inventory
};

struct DinoSettings {
  KeyedToggle saddle, imprint, name, claim, neuter, level, clone, fillCloning, pickupEggs, transferEggs, hatchEggs;
  int saddleRange=30, nameRange=10, neuterRange=10, cloneRange=100;
  bool renameNamed=false;
  char nameText[64]={};
  int levelPoints[8]={};
};

struct Settings {
  IniSettings ini;
  OtherSettings other;
  HudSettings hud;
  VisualSettings visual;
  MiscSettings misc;
  DinoSettings dino;
  int menuKey = ImGuiKey_Insert;  // hides / shows the menu; an ImGuiKey, changeable on the Config tab
  int interfaceScale=100;
  bool menuBackgroundEffect=false;
  int menuFont = 0;               // the menu's font, picked on the Config tab (ui/Fonts.h)
  bool customAccent = false;      // use accentHue instead of the theme's own accent colour
  int accentHue = 187;            // 0..360
  // Menu Colors on the Config tab: 0xRRGGBB per colour (see ui/MenuColors.h), -1 = the theme's own.
  int colors[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
};

inline Settings g_settings;

}  // namespace wintek
