#pragma once
#include <string>

// What the newer features found in the game, shown on the Config tab under Diagnostics so a screenshot is
// enough to tell why one of them isn't working.
namespace wintek {

struct Diagnostics {
  bool engineReady = false;      // signatures matched in ShooterGame.exe
  bool gameWindow = false;
  int gameWidth = 0, gameHeight = 0;
  bool gameActive = false;
  bool overlayShown = false;

  bool pawn = false;
  std::string healthSource = "-";  // where HP came from
  bool mount = false;
  bool location = false;
  std::string map = "-";
  int armorItems = 0;
  std::string spyglass = "-";
  std::string corruptedEsp = "off";
  std::string corruptedClasses = "-";
  std::string turrets = "-";      // Turret Filler
  std::string betterInput = "-";  // Better Input
  std::string fps = "-";

  std::string consoleFunction = "-";  // the game function Low Memory uses
  std::string consoleLast = "-";      // last command and whether it ran
  std::string fogFlag = "-";
  int cloudMeshes = 0;
  int skyMeshes = 0;
  std::string skySample = "-";
  std::string blackStructures = "off";
};

inline Diagnostics g_diag;

}  // namespace wintek
