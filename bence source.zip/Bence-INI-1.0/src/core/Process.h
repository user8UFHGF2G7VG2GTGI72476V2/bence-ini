#pragma once
#include <windows.h>
#include <cstdint>

namespace wintek {

// The game process. Opened for memory access only; WinTek attaches to it automatically and re-attaches
// when the game is restarted.
class Process {
public:
  static constexpr const wchar_t* kExeName = L"ShooterGame.exe";

  DWORD pid = 0;
  HANDLE handle = nullptr;
  std::uintptr_t base = 0;

  // Keeps the attachment current; call a couple of times a second.
  void Poll();
  bool IsAttached() const;
  void Detach();

private:
  bool Attach();
  bool IsAlive() const;
};

inline Process g_process;

}  // namespace wintek
