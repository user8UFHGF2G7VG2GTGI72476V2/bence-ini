#include "core/GameWindow.h"

namespace wintek {

namespace {

struct Search {
  DWORD pid;
  GameWindow best;
  LONG area;
  HWND currentRoot;
};

void Consider(Search& s, HWND window, HWND root) {
  DWORD pid = 0;
  GetWindowThreadProcessId(window, &pid);
  RECT r;
  if (pid != s.pid || !IsWindowVisible(window) || !GetClientRect(window, &r)) return;
  const LONG area = r.right * r.bottom;
  if (area > s.area) {
    s.area = area;
    s.best = { window, root };
  }
}

BOOL CALLBACK OnChild(HWND window, LPARAM param) {
  auto& s = *reinterpret_cast<Search*>(param);
  Consider(s, window, s.currentRoot);
  return TRUE;
}

BOOL CALLBACK OnTopLevel(HWND window, LPARAM param) {
  auto& s = *reinterpret_cast<Search*>(param);
  Consider(s, window, window);
  wchar_t cls[64] = {};
  GetClassNameW(window, cls, 63);
  if (lstrcmpW(cls, L"ApplicationFrameWindow") == 0) {  // UWP frame: the game window is a child
    s.currentRoot = window;
    EnumChildWindows(window, OnChild, param);
  }
  return TRUE;
}

}  // namespace

GameWindow FindGameWindow(DWORD pid) {
  Search s{ pid, {}, 0, nullptr };
  if (pid) EnumWindows(OnTopLevel, reinterpret_cast<LPARAM>(&s));
  return s.best;
}

}  // namespace wintek
