#pragma once
#include <windows.h>

// Finds ARK's window. The Microsoft Store version is a UWP app: its game window (a CoreWindow owned by
// ShooterGame.exe) sits inside an ApplicationFrameWindow owned by ApplicationFrameHost.exe, and that frame is
// what Windows reports as the active window. Both are tracked.
namespace wintek {

struct GameWindow {
  HWND content = nullptr;  // the window the game draws into
  HWND root = nullptr;     // its top-level window (the frame, for UWP)

  bool IsActive(HWND foreground) const {
    return foreground && (foreground == content || foreground == root || GetAncestor(foreground, GA_ROOT) == root);
  }
};

GameWindow FindGameWindow(DWORD pid);

}  // namespace wintek
