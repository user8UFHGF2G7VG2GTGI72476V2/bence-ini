#pragma once
namespace wintek::ui {void DrawDinoTab();float DinoTabHeight();}
