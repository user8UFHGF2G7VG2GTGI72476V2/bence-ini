#include "tabs/dino/DinoTab.h"
#include "core/Settings.h"
#include "misc/Automation.h"
#include "misc/AutoMating.h"
#include "ui/Widgets.h"
#include "ui/Layout.h"
namespace wintek::ui {
void DrawDinoTab(){
 auto& d=g_settings.dino;
 ToggleBind("Auto Saddle",&d.saddle.on,&d.saddle.key);if(d.saddle.on)SliderInt("Saddle Range",&d.saddleRange,1,60,"%d m");
 ToggleBind("Auto Imprint",&d.imprint.on,&d.imprint.key);
 ToggleBind("Auto Name",&d.name.on,&d.name.key);if(d.name.on){ImGui::SetNextItemWidth(-1);ImGui::InputText("##dino-name",d.nameText,sizeof(d.nameText));SliderInt("Name Range",&d.nameRange,1,60,"%d m");Toggle("Rename Named Dinos",&d.renameNamed);}
 ToggleBind("Auto Claim",&d.claim.on,&d.claim.key);
 ToggleBind("Auto Neuter",&d.neuter.on,&d.neuter.key);if(d.neuter.on)SliderInt("Neuter Range",&d.neuterRange,1,60,"%d m");
 ToggleBind("Auto Level",&d.level.on,&d.level.key);if(d.level.on){const char* labels[]={"Health Points","Stamina Points","Oxygen Points","Food Points","Weight Points","Melee Points","Speed Points","Crafting Points"};for(int i=0;i<8;++i)SliderInt(labels[i],&d.levelPoints[i],0,255);}
 ToggleBind("Auto Clone",&d.clone.on,&d.clone.key);if(d.clone.on)SliderInt("Clone Range",&d.cloneRange,1,300,"%d m");
 ToggleBind("Auto Fill Cloning Chamber",&d.fillCloning.on,&d.fillCloning.key);
 ToggleBind("Auto Pickup Eggs",&d.pickupEggs.on,&d.pickupEggs.key);
 ToggleBind("Auto Transfer Eggs",&d.transferEggs.on,&d.transferEggs.key);
 ToggleBind("Auto Hatch Eggs",&d.hatchEggs.on,&d.hatchEggs.key);
 Separator();
 ToggleBind("Auto Enable Mating",&g_settings.misc.autoMating.on,&g_settings.misc.autoMating.key);
 if(g_settings.misc.autoMating.on){SliderInt("Mating Range",&g_settings.misc.matingRange,1,15,"%d m");HintText(AutoMatingStatus());}
 HintText(DinoAutomationStatus());
}
float DinoTabHeight(){auto& d=g_settings.dino;return 12*kToggleRowStep+2*24.f+(d.saddle.on?kSliderRowStep:0)+(d.name.on?2*kToggleRowStep+kSliderRowStep:0)+(d.neuter.on?kSliderRowStep:0)+(d.level.on?8*kSliderRowStep:0)+(d.clone.on?kSliderRowStep:0)+(g_settings.misc.autoMating.on?kSliderRowStep+24.f:0);}
}
