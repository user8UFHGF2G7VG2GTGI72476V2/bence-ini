#include "tabs/misc/MiscTab.h"
#include "core/Settings.h"
#include "hud/Spyglass.h"
#include "misc/AutoMating.h"
#include "misc/AutoChemBench.h"
#include "misc/ResourcePull.h"
#include "misc/Automation.h"
#include "ui/Layout.h"
#include "ui/Widgets.h"

namespace wintek::ui {

namespace {

constexpr float kHintRowStep = 24.0f;
}  // namespace

void DrawMiscTab() {
  MiscSettings& m = g_settings.misc;
  ToggleBind("Turret Snap", &m.structureSnap.on, &m.structureSnap.key);
  if (m.structureSnap.on) {
    SliderInt("Turret Spacing", &m.snapSpacing, 10, 600, "%d cm");
    SliderInt("Turret Angle", &m.snapAngle, 5, 90, "%d degrees");
    HintText(StructureSnapStatus());
  }
  ToggleBind("Turret Filler", &m.turretFiller.on, &m.turretFiller.key);
  HintText("Fills your turrets from your inventory when you walk up to them.");
  SliderInt("Heavy Turret Stacks", &m.heavyStacks, 1, 58);
  SliderInt("Tek Turret Stacks", &m.tekStacks, 1, 5);
  Toggle("Show Turret Fill", &m.showTurretFill);
  SliderInt("Turret Range", &m.turretRange, 20, 700, "%d m");
  SliderInt("Pull Search Range", &m.pullRange, 1, 100, "%d m");
  ToggleBind("Auto Forge", &m.autoForge.on, &m.autoForge.key);
  if(m.autoForge.on){
    Toggle("Deposit Gas", &m.forgeGas);
    Toggle("Deposit Metal", &m.forgeMetal);
    Toggle("Pull Metal", &m.forgePull);
    Toggle("Pull Metal To Dedi", &m.forgeDedi);
    Toggle("Turn On Forges", &m.forgeTurnOn);
    SliderInt("Forge Range", &m.forgeRange, 1, 100, "%d m");
    HintText(AutoForgeStatus());
  }
  ToggleBind("Quick Pickup", &m.quickPickup.on, &m.quickPickup.key);
  if(m.quickPickup.on)KeyBind("Pickup Action Key", &m.pickupActionKey);
  ToggleBind("Take All", &m.takeAll.on, &m.takeAll.key);
  if(m.takeAll.on)KeyBind("Take All Action Key", &m.takeAllActionKey);

  ToggleBind("Auto Chem Bench", &m.autoChemBench.on, &m.autoChemBench.key);
  if (m.autoChemBench.on) {
    Choice("Chem Recipe", &m.chemRecipe, kChemRecipeNames, kChemRecipeCount);
    SliderInt("Chem Bench Range", &m.chemRange, 1, 15, "%d m");
    SliderInt("Craft Queue Target", &m.chemQueue, 1, 100);
    Toggle("Supply Ingredients", &m.chemSupply);
    Toggle("Collect Crafted Output", &m.chemCollect);
    Toggle("Supply Gasoline", &m.chemFuel);
    if (m.chemFuel) SliderInt("Gasoline Target", &m.chemGasoline, 1, 100);
    HintText("Uses your inventory. Keep benches powered and switched on.");
    HintText(AutoChemBenchStatus());
  }
  ToggleBind("Better Input", &m.betterInput.on, &m.betterInput.key);
  HintText("Hold Drop / Transfer / Use in your inventory to fire every frame.");
}

float MiscTabHeight() {
  const auto& m=g_settings.misc;
  return kSliderRowStep + 4*kToggleRowStep + (m.autoForge.on?5*kToggleRowStep+kSliderRowStep+kHintRowStep:0) + (m.quickPickup.on?kToggleRowStep:0) + (m.takeAll.on?kToggleRowStep:0) + kToggleRowStep + (m.autoChemBench.on ? 4*kSliderRowStep + 3*kToggleRowStep + 2*kHintRowStep + (m.chemFuel ? kSliderRowStep : 0.0f) : 0.0f) + kToggleRowStep + (m.structureSnap.on ? 2.0f*kSliderRowStep+kHintRowStep : 0.0f) + 2.0f * (kToggleRowStep + kHintRowStep) + 3.0f * kSliderRowStep + kToggleRowStep;
}

}  // namespace wintek::ui
