#pragma once

namespace wintek::ui {

void DrawMiscTab();
float MiscTabHeight();  // height of the tab's content, for sizing the window

}  // namespace wintek::ui
