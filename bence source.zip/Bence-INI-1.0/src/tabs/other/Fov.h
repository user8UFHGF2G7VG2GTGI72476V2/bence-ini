#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// FOV: locks the camera's field of view (PlayerCameraManager::LockedFOV + bLockedFOV), as Knucklebutt's
// FovChanger does. While you look through a real scope the lock is released so the scope zooms normally;
// aiming anything without one (Tek Gauntlet, pistols) keeps the custom FOV.
namespace wintek {

void TickFov(const OtherSettings& settings, Address camera, Address pawn);
void ResetFov();

}  // namespace wintek
