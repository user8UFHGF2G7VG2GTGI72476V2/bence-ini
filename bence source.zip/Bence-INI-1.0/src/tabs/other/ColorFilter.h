#pragma once
#include "core/Settings.h"

// Color Filter: saturation, contrast, brightness and temperature through the post-process volumes' film
// settings (gamma is handled with Fullbright, in tabs/ini/Fullbright.cpp). Knucklebutt draws a shader over
// the frame for this; changing the game's own grading is the closest external equivalent.
//
// Vibrance writes the same settings, so both are applied here: only volumes that affect the whole map (or
// already override saturation) are changed, and each volume's original values are put back when both are off.
namespace wintek {

void TickColorGrading(const OtherSettings& settings);

// Ready-made looks for the Color Filter. Picking one sets the sliders; "Custom" leaves them alone.
inline constexpr const char* kFilterPresets[] = { "Custom", "Default", "Grayscale", "Sepia", "Night Vision", "Vivid", "Cold", "Warm" };
inline constexpr int kFilterPresetCount = 8;

inline void ApplyFilterPreset(OtherSettings& s, int preset) {
  struct Look { float saturation, contrast, brightness, gamma, temperature, tint; };
  static constexpr Look kLooks[] = {
    { 0, 0, 0, 0, 0, 0 },              // Custom (unused)
    { 100, 100, 100, 1.0f, 0, 0 },     // Default
    { 0, 110, 100, 1.0f, 0, 0 },       // Grayscale
    { 15, 105, 105, 1.0f, 80, 15 },    // Sepia
    { 0, 120, 135, 1.3f, 0, 100 },     // Night Vision
    { 160, 115, 100, 1.0f, 0, 0 },     // Vivid
    { 90, 105, 100, 1.0f, -60, 0 },    // Cold
    { 110, 100, 105, 1.0f, 50, 0 },    // Warm
  };
  if (preset <= 0 || preset >= kFilterPresetCount) return;
  const Look& l = kLooks[preset];
  s.filterSaturation = l.saturation;
  s.filterContrast = l.contrast;
  s.filterBrightness = l.brightness;
  s.filterGamma = l.gamma;
  s.filterTemperature = l.temperature;
  s.filterTint = l.tint;
}

}  // namespace wintek
