#include "tabs/other/Fov.h"

namespace wintek {

namespace {

constexpr std::uint8_t kLockedBit = 0x01;

struct {
  ObjectRef camera;  // the camera we locked, empty if none
  float originalFov = 0.0f;
} g_fov;

// AShooterCharacter::bIsTargeting with a CurrentWeapon that draws a scope overlay (Fabricated Sniper, scoped
// Longneck, ...).
bool LookingThroughScope(Address pawn) {
  static BoolProperty targeting("bIsTargeting"), scopeOverlay("bUseScopeOverlay");
  static std::unordered_map<Address, std::int32_t> weaponOffset;
  if (!targeting.Get(pawn)) return false;
  const Address cls = ClassOf(pawn);
  auto it = weaponOffset.find(cls);
  if (it == weaponOffset.end()) it = weaponOffset.emplace(cls, PropertyOffset(cls, "CurrentWeapon")).first;
  return it->second && scopeOverlay.Get(Read<Address>(pawn + it->second));
}

}  // namespace

void TickFov(const OtherSettings& settings, Address camera, Address pawn) {
  using namespace offsets::camera;
  // `camera` reads as 0 during loading screens; only a different camera means ours is gone.
  const Address held = g_fov.camera.object;
  if (held && (!settings.fov || (camera && camera != held))) {
    if (g_fov.camera.Alive()) {
      Write(held + kLockedFov, g_fov.originalFov);
      SetBits(held + kLockFlags, kLockedBit, false);
    }
    g_fov.camera = {};
  }
  if (!settings.fov || !camera) return;
  if (!g_fov.camera.object) {
    g_fov.originalFov = Read<float>(camera + kLockedFov);
    g_fov.camera = ObjectRef::Of(camera);
  }

  if (LookingThroughScope(pawn)) {
    SetBits(camera + kLockFlags, kLockedBit, false);
    return;
  }
  Write(camera + kLockedFov, static_cast<float>(settings.fovLevel));
  SetBits(camera + kLockFlags, kLockedBit, true);
}

void ResetFov() { g_fov = {}; }

}  // namespace wintek
