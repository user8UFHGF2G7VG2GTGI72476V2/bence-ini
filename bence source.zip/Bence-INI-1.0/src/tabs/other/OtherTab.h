#pragma once

namespace wintek::ui {

void DrawOtherTab(float width);
float OtherTabHeight();  // height of the tab's content, for sizing the window

}  // namespace wintek::ui
