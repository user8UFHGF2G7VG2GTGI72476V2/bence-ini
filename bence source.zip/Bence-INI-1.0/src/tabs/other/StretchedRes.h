#pragma once
#include "core/Settings.h"

// Stretched Resolution: stretches the 3D world while the HUD stays sharp, like Knucklebutt's
// GetProjectionData hook. Once per frame, through the debugger (engine/Debugger.h), the X and Y columns of
// the projection matrix are scaled by Horizontal and Vertical.
namespace wintek {

void TickStretchedRes(const OtherSettings& settings);

// "Apply" in the menu: the Horizontal stretch that makes the screen look like `width` x `height`.
void ApplyStretchResolution(OtherSettings& settings);
// "Reset" in the menu: back to the game window's own size and no stretch.
void ResetStretch(OtherSettings& settings);

}  // namespace wintek
