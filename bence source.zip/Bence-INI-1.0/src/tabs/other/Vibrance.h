#pragma once
#include "core/Settings.h"

// Vibrance: scales the film saturation of the world's post-process volumes. 50% leaves colours as they are,
// 100% doubles saturation. Applied together with Color Filter (see ColorFilter.cpp), since both write the
// same volume settings.
namespace wintek {

inline float VibranceSaturation(const OtherSettings& s) { return s.vibrance ? s.vibranceLevel / 50.0f : 1.0f; }

}  // namespace wintek
