#include "tabs/other/ColorFilter.h"
#include "engine/Console.h"
#include <algorithm>
#include "engine/PostProcessVolumes.h"
#include "tabs/other/Vibrance.h"

namespace wintek {

namespace {

// bOverride_* bits within the volume's override flags.
constexpr std::uint8_t kOverrideSaturation = 0x02, kOverrideContrast = 0x20;  // byte 0
constexpr std::uint8_t kOverrideTint = 0x01;                                    // byte 2
constexpr float kDefaultContrast = 0.03f;

void Grade(const OtherSettings& s, PostProcessVolume& v) {
  using namespace offsets::volume;
  const bool affectsMap = (v.flags & kEnabled) && ((v.flags & kUnbound) || (v.overrides[0] & kOverrideSaturation));
  const bool wanted = affectsMap && (s.vibrance || s.colorFilter);
  if ((!wanted && !v.graded) || !v.ref.Alive()) return;

  const Address volume = v.address();
  std::uint8_t overrides[3];
  if (!g_memory.ReadRaw(volume + kOverrideFlags, overrides, sizeof(overrides))) return;

  // Start from the volume's original values, then apply what's on.
  float saturation = v.saturation, contrast = v.contrast;
  float tint[4] = { v.tint[0], v.tint[1], v.tint[2], v.tint[3] };
  auto byte0 = static_cast<std::uint8_t>((overrides[0] & ~(kOverrideSaturation | kOverrideContrast)) |
                                         (v.overrides[0] & (kOverrideSaturation | kOverrideContrast)));
  auto byte2 = static_cast<std::uint8_t>((overrides[2] & ~kOverrideTint) | (v.overrides[2] & kOverrideTint));

  const bool filter = wanted && s.colorFilter;
  if (wanted) {
    const float base = (v.overrides[0] & kOverrideSaturation) ? v.saturation : 1.0f;
    saturation = base * VibranceSaturation(s) * (filter ? s.filterSaturation / 100.0f : 1.0f);
    byte0 |= kOverrideSaturation;
  }
  if (filter) {
    contrast = ((v.overrides[0] & kOverrideContrast) ? v.contrast : kDefaultContrast) * (s.filterContrast / 100.0f);
    if (!(v.overrides[2] & kOverrideTint)) tint[0] = tint[1] = tint[2] = tint[3] = 1.0f;
    const float brightness = s.filterBrightness / 100.0f, warmth = s.filterTemperature / 100.0f, green = s.filterTint / 100.0f;
    tint[0] *= brightness * (1.0f + 0.3f * warmth) * (1.0f - 0.25f * green);
    tint[1] *= brightness * (1.0f + 0.35f * green);
    tint[2] *= brightness * (1.0f - 0.3f * warmth) * (1.0f - 0.25f * green);
    byte0 |= kOverrideContrast;
    byte2 |= kOverrideTint;
  }

  Write(volume + kFilmSaturation, saturation);
  Write(volume + kFilmContrast, contrast);
  g_memory.WriteRaw(volume + kSceneColorTint, tint, sizeof(tint));
  if (byte0 != overrides[0]) Write(volume + kOverrideFlags, byte0);
  if (byte2 != overrides[2]) Write(volume + kOverrideFlags + 2, byte2);
  v.graded = wanted;
}

}  // namespace

void TickColorGrading(const OtherSettings& settings) {
  static float last=0;float sharpen=settings.colorFilter?std::clamp(settings.filterSharpen,0.0f,5.0f):0.0f;
  if(sharpen!=last){QueueConsoleCommand(L"r.Tonemapper.Sharpen "+std::to_wstring(sharpen));last=sharpen;}
  for (PostProcessVolume& v : Volumes()) Grade(settings, v);
}

}  // namespace wintek
