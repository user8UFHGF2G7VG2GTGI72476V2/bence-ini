#include "tabs/other/OtherTab.h"
#include "core/Settings.h"
#include "engine/Debugger.h"
#include "tabs/other/ColorFilter.h"
#include "tabs/other/StretchedRes.h"
#include "ui/Layout.h"
#include "ui/Theme.h"
#include "ui/Widgets.h"

namespace wintek::ui {

namespace {

constexpr int kToggleCount = 4;
constexpr float kHintRowStep = 24.0f;

// Knucklebutt's layout: Horizontal and Vertical, then width x height with Apply and Reset on one row.
void StretchedResSection(OtherSettings& s, float width) {
  ToggleBind("Stretched Resolution", &s.stretchedRes.on, &s.stretchedRes.key);
  if (!s.stretchedRes.on) return;
  if (const char* error = DebuggerError()) HintText(error);
  SliderFloat("Horizontal", &s.stretchHorizontal, 0.5f, 4.0f, "%.3f");
  SliderFloat("Vertical", &s.stretchVertical, 0.5f, 4.0f, "%.3f");

  const float cell = (width - kItemSpacing * 3.0f) * 0.25f;
  NumberBox("##stretch_width", &s.stretchWidth, cell);
  ImGui::SameLine(0.0f, kItemSpacing);
  NumberBox("##stretch_height", &s.stretchHeight, cell);
  ImGui::SameLine(0.0f, kItemSpacing);
  if (Button("Apply", ImVec2(cell, g_theme.controlHeight))) ApplyStretchResolution(s);
  ImGui::SameLine(0.0f, kItemSpacing);
  if (Button("Reset", ImVec2(cell, g_theme.controlHeight))) ResetStretch(s);
}

}  // namespace

void DrawOtherTab(float width) {
  OtherSettings& s = g_settings.other;
  StretchedResSection(s, width);

  Toggle("Vibrance", &s.vibrance);
  if (s.vibrance) SliderInt("Amount", &s.vibranceLevel, 0, 100, "%d%%");

  Toggle("FOV", &s.fov);
  if (s.fov) SliderInt("Degrees", &s.fovLevel, 70, 150, "%d");

  Toggle("Color Filter", &s.colorFilter);
  if (s.colorFilter) {
    if (Choice("Preset", &s.filterPreset, kFilterPresets, kFilterPresetCount)) ApplyFilterPreset(s, s.filterPreset);
    SliderFloat("Saturation", &s.filterSaturation, 0.0f, 200.0f, "%.0f%%");
    SliderFloat("Contrast", &s.filterContrast, 50.0f, 150.0f, "%.0f%%");
    SliderFloat("Brightness", &s.filterBrightness, 50.0f, 150.0f, "%.0f%%");
    SliderFloat("Gamma", &s.filterGamma, 0.5f, 2.0f, "%.2f");
    SliderFloat("Temperature", &s.filterTemperature, -100.0f, 100.0f, "%.0f");
    SliderFloat("Tint (green)", &s.filterTint, -100.0f, 100.0f, "%.0f");
    SliderFloat("Sharpen",&s.filterSharpen,0.0f,5.0f,"%.2f");
    if(Button("Reset Filter",ImVec2(width,g_theme.controlHeight))){ApplyFilterPreset(s,1);s.filterPreset=1;s.filterSharpen=0;}
  }
}

float OtherTabHeight() {
  const OtherSettings& s = g_settings.other;
  float height = kToggleCount * kToggleRowStep;
  if (s.stretchedRes.on) height += 2.0f * kSliderRowStep + g_theme.controlHeight + kItemSpacing + (DebuggerError() ? kHintRowStep : 0.0f);
  if (s.vibrance) height += kSliderRowStep;
  if (s.fov) height += kSliderRowStep;
  if (s.colorFilter) height += kToggleRowStep + 7.0f * kSliderRowStep + kToggleRowStep;
  return height;
}

}  // namespace wintek::ui
