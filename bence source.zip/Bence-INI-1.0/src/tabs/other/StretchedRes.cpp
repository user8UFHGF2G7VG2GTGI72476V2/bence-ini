#include "tabs/other/StretchedRes.h"
#include "core/GameWindow.h"
#include "core/Memory.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <windows.h>
#include <algorithm>
#include <atomic>
#include <cmath>

namespace wintek {

namespace {

constexpr std::uintptr_t kProjectionMatrix = 0x40;  // FSceneViewProjectionData::ProjectionMatrix
constexpr float kMinScale = 0.25f, kMaxScale = 8.0f;

std::atomic<bool> g_enabled{ false };
std::atomic<float> g_horizontal{ 1.0f }, g_vertical{ 1.0f };

float ClampScale(float value) { return std::isfinite(value) ? std::clamp(value, kMinScale, kMaxScale) : 1.0f; }

// Runs on the debugger thread while the game thread is paused with the frame's projection data complete.
void ScaleProjection(std::uintptr_t projectionData) {
  if (!g_enabled) return;
  float matrix[4][4];
  if (!g_memory.ReadRaw(projectionData + kProjectionMatrix, matrix, sizeof(matrix))) return;
  const float h = g_horizontal, v = g_vertical;
  for (auto& row : matrix) {
    row[0] *= h;
    row[1] *= v;
  }
  g_memory.WriteRaw(projectionData + kProjectionMatrix, matrix, sizeof(matrix));
}

// The game window's client size, or 1920x1080 if it can't be found.
void GameScreenSize(int& width, int& height) {
  const GameWindow game = FindGameWindow(g_process.pid);
  RECT rect{};
  if (game.content) GetClientRect(game.content, &rect);
  width = rect.right > 0 ? rect.right : 1920;
  height = rect.bottom > 0 ? rect.bottom : 1080;
}

}  // namespace

void TickStretchedRes(const OtherSettings& settings) {
  static bool callbackSet = false;
  if (!callbackSet) {
    callbackSet = true;
    SetFrameCallback(DebuggerClient::StretchedRes, ScaleProjection);
  }
  g_horizontal = ClampScale(settings.stretchHorizontal);
  g_vertical = ClampScale(settings.stretchVertical);
  g_enabled = settings.stretchedRes.on;
  RequestDebugger(DebuggerClient::StretchedRes, settings.stretchedRes.on);
}

void ApplyStretchResolution(OtherSettings& settings) {
  if (settings.stretchWidth <= 0 || settings.stretchHeight <= 0) return;
  int screenWidth, screenHeight;
  GameScreenSize(screenWidth, screenHeight);
  const float screenAspect = static_cast<float>(screenWidth) / screenHeight;
  const float targetAspect = static_cast<float>(settings.stretchWidth) / settings.stretchHeight;
  settings.stretchHorizontal = ClampScale(screenAspect / targetAspect);
  settings.stretchVertical = 1.0f;
}

void ResetStretch(OtherSettings& settings) {
  GameScreenSize(settings.stretchWidth, settings.stretchHeight);
  settings.stretchHorizontal = settings.stretchVertical = 1.0f;
}

}  // namespace wintek
