#include "tabs/structure/StructureSnapTab.h"
#include "core/Settings.h"
#include "hud/Spyglass.h"
#include "ui/Layout.h"
#include "ui/Widgets.h"

namespace wintek::ui {
void DrawStructureSnapTab() {
  auto& s=g_settings.misc;
  ToggleBind("Structure Snap",&s.structureSnapOther.on,&s.structureSnapOther.key);
  HintText("Automatically align vaults and other structures to nearby tribe structures.");
  if (s.structureSnapOther.on) {
    Toggle("Vaults",&s.snapVaults);
    Toggle("Other Free-Placement Structures",&s.snapOtherStructures);
    if (s.snapVaults) SliderInt("Vault Gap",&s.vaultSnapGap,0,50,"%d cm");
    SliderInt("Structure Spacing",&s.structureSnapSpacing,10,600,"%d cm");
    SliderInt("Structure Angle",&s.structureSnapAngle,5,90,"%d degrees");
  }
}

float StructureSnapTabHeight() {
  return kToggleRowStep+24.0f+(g_settings.misc.structureSnapOther.on ? 2.0f*kToggleRowStep+2.0f*kSliderRowStep+(g_settings.misc.snapVaults ? kSliderRowStep : 0.0f) : 0.0f);
}
}
