#pragma once
namespace wintek::ui {
void DrawStructureSnapTab();
float StructureSnapTabHeight();
}
