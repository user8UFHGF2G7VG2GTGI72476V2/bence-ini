#pragma once

namespace wintek::ui {

void DrawHudTab();
float HudTabHeight();  // height of the tab's content, for sizing the window

}  // namespace wintek::ui
