#include "tabs/hud/HudTab.h"
#include "core/Settings.h"
#include "hud/HudStyle.h"
#include "hud/PlayerList.h"
#include "hud/Targeting.h"
#include "ui/Layout.h"
#include "ui/Widgets.h"

namespace wintek::ui {

namespace {

constexpr int kMainToggles = 14;
constexpr float kHintRowStep = 24.0f;

}  // namespace

void DrawHudTab() {
  HudSettings& h = g_settings.hud;
  HintText("Overlays need ARK in windowed or borderless mode.");
  Choice("HUD Font", &h.hudFont, kHudFontNames, kHudFontCount);

  ToggleBind("Watermark", &h.watermark.on, &h.watermark.key);
  if (h.watermark.on) {
    Choice("Watermark Position", &h.watermarkCorner, kWatermarkCorners, kWatermarkCornerCount);
    Choice("Watermark Color", &h.watermarkColor, kWatermarkColors, kWatermarkColorCount);
    SliderInt("Watermark Size", &h.watermarkSize, 12, 48);
  }
  ToggleBind("Crosshair", &h.crosshair.on, &h.crosshair.key);
  if (h.crosshair.on) {
    Choice("Shape", &h.crossShape, kCrossShapes, kCrossShapeCount);
    Choice("Color", &h.crossColor, kCrossColors, kCrossColorCount);
    SliderInt("Size", &h.crossSize, 2, 24);
    SliderInt("Thickness", &h.crossThickness, 1, 6);
    SliderInt("Gap", &h.crossGap, 0, 12);
    Toggle("Outline", &h.crossOutline);
    SliderInt("Opacity",&h.crossOpacity,0,100,"%d%%");
  }

  ToggleBind("Info Display", &h.info.on, &h.info.key);
  if (h.info.on) {
    // With the watermark on, the info lines sit under it instead, so they follow its position.
    if (h.watermark.on) HintText("Shown under the watermark, in its style.");
    else Choice("Position", &h.infoCorner, kCorners, kCornerCount);
    Toggle("FPS", &h.infoFps);
    Toggle("Clock", &h.infoClock);
    Toggle("Session Timer", &h.infoTimer);
    Toggle("Coordinates", &h.infoCoords);
    Toggle("Ping",&h.infoPing);
    Toggle("Server FPS",&h.infoServerFps);
    Toggle("Connected Players",&h.infoPlayers);
    Toggle("Nearby Enemy Turrets",&h.infoTurrets);
    Toggle("Nearby Friendly Turrets",&h.infoFriendlyTurrets);
    Toggle("Inventory Slots",&h.infoSlots);
    Toggle("Server Name",&h.infoServerName);
    Toggle("Rainbow Info Text",&h.infoRainbow);
    SliderInt("Info Text Scale",&h.infoScale,50,200,"%d%%");
  }

  ToggleBind("Armor HUD", &h.armor.on, &h.armor.key);
  if (h.armor.on) {
    SliderInt("Armor HUD Size", &h.armorSize, 50, 200, "%d%%");
    SliderInt("Armor Text Size", &h.armorTextSize, 50, 300, "%d%%");
    SliderInt("Armor Height", &h.armorYOffset, 0, 1440);
    Toggle("Show Durability", &h.armorShowDurability);
    Toggle("Show As Percent", &h.armorPercent);
    Toggle("Show Spare Count", &h.armorCount);
  }
  ToggleBind("Penis ESP", &h.penisEsp.on, &h.penisEsp.key);
  if (h.penisEsp.on) {
    SliderInt("Marker Size", &h.penisEspSize, 12, 64, "%d px");
  }
  ToggleBind("Arrow / Grapple Trajectory", &h.trajectory.on, &h.trajectory.key);
  if(h.trajectory.on) {
    SliderInt("Prediction Time", &h.trajectorySeconds, 1, 5, "%d seconds");
    HintText(TrajectoryStatus());
  }
  ToggleBind("Player Outlines", &h.playerOutlines.on, &h.playerOutlines.key);
  ToggleBind("Turret Outlines", &h.turretOutlines.on, &h.turretOutlines.key);
  if(h.playerOutlines.on || h.turretOutlines.on) {
    SliderInt("Outline Range", &h.outlineRange, 20, 240, "%d m");
    Toggle("Enemy Outlines Only", &h.outlineEnemiesOnly);
    HintText(OutlineStatus());
  }
  ToggleBind("Corrupted Dino ESP", &h.corruptedEsp.on, &h.corruptedEsp.key);
  if (h.corruptedEsp.on) SliderInt("Corrupted ESP Range", &h.corruptedEspRange, 20, 700, "%d m");
  ToggleBind("Tek Rifle Indicator",&h.tekIndicator.on,&h.tekIndicator.key);
  if(h.tekIndicator.on){Toggle("Any Weapon",&h.tekAnyWeapon);SliderInt("Tek Range",&h.tekRange,1,300,"%d m");SliderInt("Tek Indicator Scale",&h.tekScale,50,200,"%d%%");SliderFloat("Tek Position X",&h.tekX,0,100,"%.0f%%");SliderFloat("Tek Position Y",&h.tekY,0,100,"%.0f%%");}
  ToggleBind("AWESOME SPYGLASS", &h.spyglass.on, &h.spyglass.key);
  if (h.spyglass.on) {
    SliderInt("Spyglass Range", &h.spyRange, 20, 700, "%d m");
    Toggle("Wild Dino Stat Points", &h.spyWildPoints);
    Toggle("Tamed Dino Stat Points",&h.spyTamedPoints);
    Toggle("Dino Color IDs",&h.spyColors);
    Toggle("Spyglass Background",&h.spyBackground);
    KeyBind("Lock Target Key",&h.spyLockKey);
    SliderInt("Spyglass Scale",&h.spyScale,50,200,"%d%%");
    SliderFloat("Spyglass Position X", &h.spyX, 0.0f, 100.0f, "%.0f%%");
    SliderFloat("Spyglass Position Y", &h.spyY, 0.0f, 100.0f, "%.0f%%");
  }
  ToggleBind("HP Overlay", &h.hp.on, &h.hp.key);
  if (h.hp.on) {
    SliderFloat("HP Position X", &h.hpX, 0.0f, 100.0f, "%.0f%%");
    SliderFloat("HP Position Y", &h.hpY, 0.0f, 100.0f, "%.0f%%");
  }

  ToggleBind("Mount HP Overlay", &h.mountHp.on, &h.mountHp.key);
  if (h.mountHp.on) {
    SliderFloat("Mount Position X", &h.mountX, 0.0f, 100.0f, "%.0f%%");
    SliderFloat("Mount Position Y", &h.mountY, 0.0f, 100.0f, "%.0f%%");
  }

  ToggleBind("Player List (Admin)", &h.playerList.on, &h.playerList.key);
  if (h.playerList.on) {
    HintText(PlayerListStatusText());
    Choice("Player List Side", &h.playerSide, kSides, kSideCount);
    SliderFloat("Player List Height", &h.playerY, 0.0f, 100.0f, "%.0f%%");
    SliderInt("Player List Text Size", &h.playerTextSize, 10, 30);
    SliderInt("Player List Rows", &h.playerMaxRows, 5, 70);
    SliderInt("Refresh Every", &h.playerRefresh, 3, 60, "%d s");
  }
}

float HudTabHeight() {
  const HudSettings& h = g_settings.hud;
  float height = kHintRowStep + kToggleRowStep + kMainToggles * kToggleRowStep;  // + the HUD Font picker
  if (h.crosshair.on) height += 3.0f * kToggleRowStep + 4.0f * kSliderRowStep;
  if (h.watermark.on) height += 2.0f * kToggleRowStep + kSliderRowStep;
  if (h.info.on) height += kSliderRowStep + 12.0f * kToggleRowStep + (h.watermark.on ? kHintRowStep : kToggleRowStep);
  if (h.armor.on) height += 3.0f * kSliderRowStep + 3.0f * kToggleRowStep;
  if(h.tekIndicator.on)height+=kToggleRowStep+4*kSliderRowStep;
  if (h.spyglass.on) height += 4.0f * kSliderRowStep + 5*kToggleRowStep;
  if (h.penisEsp.on) height += kSliderRowStep;
  if (h.corruptedEsp.on) height += kSliderRowStep;
  if(h.trajectory.on)height += kSliderRowStep+kHintRowStep;
  if(h.playerOutlines.on || h.turretOutlines.on)height += kSliderRowStep+kToggleRowStep+kHintRowStep;
  if (h.hp.on) height += 2.0f * kSliderRowStep;
  if (h.mountHp.on) height += 2.0f * kSliderRowStep;
  if (h.playerList.on) height += kHintRowStep + kToggleRowStep + 4.0f * kSliderRowStep;
  return height;
}

}  // namespace wintek::ui
