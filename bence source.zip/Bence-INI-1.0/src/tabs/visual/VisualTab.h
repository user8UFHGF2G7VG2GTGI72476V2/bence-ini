#pragma once

namespace wintek::ui {

void DrawVisualTab();
float VisualTabHeight();  // height of the tab's content, for sizing the window

}  // namespace wintek::ui
