#include "tabs/visual/VisualTab.h"
#include "core/Settings.h"
#include "ui/Layout.h"
#include "ui/Widgets.h"

namespace wintek::ui {

namespace {

constexpr float kHintRowStep = 24.0f;
constexpr const char* kTextureQualities[] = { "ARK default", "Low", "Medium", "High", "Epic" };

void FeatureToggle(const char* label, KeyedToggle& toggle) { ToggleBind(label, &toggle.on, &toggle.key); }

}  // namespace

void DrawVisualTab() {
  VisualSettings& v = g_settings.visual;
  FeatureToggle("No Fog", v.noFog);
  FeatureToggle("No Clouds", v.noClouds);
  FeatureToggle("No Shadows", v.noShadows);
  FeatureToggle("No Bloom", v.noBloom);
  FeatureToggle("No Lens Flare", v.noLensFlare);
  FeatureToggle("No Motion Blur", v.noMotionBlur);

  FeatureToggle("View Distance", v.viewDistance);
  if (v.viewDistance.on) SliderFloat("Distance Scale", &v.viewDistanceScale, 0.1f, 5.0f, "%.1fx");
  FeatureToggle("FPS Limit", v.fpsLimit);
  if (v.fpsLimit.on) SliderInt("Max FPS", &v.maxFps, 20, 360);
  Choice("Texture Quality", &v.textureQuality, kTextureQualities, 5);
  HintText("Back to ARK default needs an ARK restart.");
}

float VisualTabHeight() {
  const VisualSettings& v = g_settings.visual;
  float height = 9.0f * kToggleRowStep + kHintRowStep;
  if (v.viewDistance.on) height += kSliderRowStep;
  if (v.fpsLimit.on) height += kSliderRowStep;
  return height;
}

}  // namespace wintek::ui
