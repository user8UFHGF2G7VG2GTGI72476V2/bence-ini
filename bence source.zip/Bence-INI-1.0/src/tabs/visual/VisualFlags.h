#pragma once
#include "engine/ShowFlagProbe.h"
#include "tabs/ini/ViewMode.h"

// The Visual tab's render toggles, applied through the same view-flag block as the INI presets.
// Fog's flag position isn't fixed, so it's looked up at runtime (see engine/ShowFlagProbe.h).
namespace wintek {

inline bool AnyVisualFlag(const VisualSettings& v) {
  return v.noFog.on || v.noShadows.on || v.noBloom.on || v.noLensFlare.on || v.noMotionBlur.on;
}

inline void ApplyVisualFlags(const VisualSettings& v, ViewEdit& view) {
  if (v.noShadows.on) view.Hide(ShowFlag::DynamicShadows);
  if (v.noBloom.on) view.Hide(ShowFlag::Bloom);
  if (v.noLensFlare.on) view.Hide(ShowFlag::LensFlares);
  if (v.noMotionBlur.on) view.Hide(ShowFlag::MotionBlur);
  if (v.noFog.on) {
    view.HideBit(ShowFlagBit("Fog"));
    view.HideBit(ShowFlagBit("AtmosphericFog"));
  }
}

}  // namespace wintek
