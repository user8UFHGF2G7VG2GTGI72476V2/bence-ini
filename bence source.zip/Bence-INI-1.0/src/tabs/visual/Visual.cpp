#include "tabs/visual/Visual.h"
#include "core/Diagnostics.h"
#include "engine/Console.h"
#include "engine/ShowFlagProbe.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

namespace wintek {

namespace {

constexpr float kDefaultViewDistance = 1.0f;
constexpr int kUnlimitedFps = 0;

struct {
  float viewDistance = kDefaultViewDistance;  // what we last set
  int maxFps = kUnlimitedFps;
  int textureQuality = 0;                     // 0: never touched
} g_visual;

std::wstring Number(float value) {
  wchar_t text[32];
  std::swprintf(text, 32, L"%.2f", value);
  return text;
}

std::string FlagStatus(const char* name) {
  const int bit = ShowFlagBit(name);
  return bit >= 0 ? "bit " + std::to_string(bit) : bit == -2 ? "not available" : "looking...";
}

}  // namespace

void TickVisual(const VisualSettings& s, bool restoring) {
  if (s.noFog.on && !restoring) {
    RequestShowFlag("Fog");
    RequestShowFlag("AtmosphericFog");
    g_diag.fogFlag = FlagStatus("Fog") + " / atmos " + FlagStatus("AtmosphericFog");
  }

  const float distance = s.viewDistance.on && !restoring ? std::clamp(s.viewDistanceScale, 0.1f, 5.0f) : kDefaultViewDistance;
  if (std::fabs(distance - g_visual.viewDistance) > 0.004f) {
    QueueConsoleCommand(L"r.ViewDistanceScale " + Number(distance));
    g_visual.viewDistance = distance;
  }

  const int fps = s.fpsLimit.on && !restoring ? std::clamp(s.maxFps, 20, 360) : kUnlimitedFps;
  if (fps != g_visual.maxFps) {
    QueueConsoleCommand(L"t.MaxFPS " + std::to_wstring(fps));
    g_visual.maxFps = fps;
  }

  // Texture quality has no known "original" to go back to, so choosing "ARK default" just stops changing it.
  const int quality = std::clamp(s.textureQuality, 0, 4);
  if (!restoring && quality != 0 && quality != g_visual.textureQuality) {
    QueueConsoleCommand(L"sg.TextureQuality " + std::to_wstring(quality - 1));
    g_visual.textureQuality = quality;
  }
  if (quality == 0) g_visual.textureQuality = 0;
}

void ResetVisual() { g_visual = {}; }

}  // namespace wintek
