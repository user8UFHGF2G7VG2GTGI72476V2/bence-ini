#pragma once
#include "core/Settings.h"

// The Visual tab's console settings: view distance, FPS limit and texture quality. Each is only sent when it
// changes; turning View Distance or FPS Limit off puts the engine default back (1.0 and unlimited).
namespace wintek {

void TickVisual(const VisualSettings& settings, bool restoring);
void ResetVisual();

}  // namespace wintek
