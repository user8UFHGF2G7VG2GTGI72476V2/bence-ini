#include "tabs/config/ConfigTab.h"
#include "tabs/config/Config.h"
#include "core/Diagnostics.h"
#include "core/Process.h"
#include "core/Settings.h"
#include <string>
#include <vector>
#include "tabs/config/Themes.h"
#include "ui/Fonts.h"
#include "ui/MenuColors.h"
#include "ui/Layout.h"
#include "ui/Pixel.h"
#include "ui/Theme.h"
#include "ui/Widgets.h"
#include "imgui_internal.h"
#include <windows.h>
#include <algorithm>

namespace wintek::ui {

namespace {

constexpr DWORD kConfirmMs = 1500;

constexpr int kColorColumns = 2;
constexpr float kColorRow = 24.0f;

int ToRgbInt(const ImVec4& c) {
  auto ch = [](float v) { return static_cast<int>(ImClamp(v, 0.0f, 1.0f) * 255.0f + 0.5f); };
  return (ch(c.x) << 16) | (ch(c.y) << 8) | ch(c.z);
}

// Menu Colors: a box showing each colour with a "..." button beside it that opens a colour picker.
void MenuColorGrid(float width) {
  static bool changed = false;
  const float cell = std::floor((width - kItemSpacing * (kColorColumns - 1)) / kColorColumns);
  ImGuiWindow* window = ImGui::GetCurrentWindow();
  for (int i = 0; i < kMenuColorCount; ++i) {
    if (i % kColorColumns != 0) ImGui::SameLine(0.0f, kItemSpacing);
    ImGui::PushID(i);
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::ItemSize(ImVec2(cell, kColorRow));
    const bool custom = g_settings.colors[i] >= 0;
    const ImVec4 color = MenuColor(i);

    // the colour box (clicking it also opens the picker)
    const ImRect swatch(ImVec2(p.x, p.y + 3.0f), ImVec2(p.x + 34.0f, p.y + kColorRow - 3.0f));
    const ImGuiID swatchId = window->GetID("swatch");
    // the "..." button at the right end of the cell
    const ImRect dots(ImVec2(p.x + cell - 30.0f, p.y + 2.0f), ImVec2(p.x + cell, p.y + kColorRow - 2.0f));
    const ImGuiID dotsId = window->GetID("dots");
    bool swatchHovered = false, dotsHovered = false, held = false;
    ImGui::ItemAdd(swatch, swatchId);
    const bool openA = ImGui::ButtonBehavior(swatch, swatchId, &swatchHovered, &held, ImGuiButtonFlags_None);
    ImGui::ItemAdd(dots, dotsId);
    const bool openB = ImGui::ButtonBehavior(dots, dotsId, &dotsHovered, &held, ImGuiButtonFlags_None);
    if (openA || openB) ImGui::OpenPopup("picker");
    const bool open = ImGui::IsPopupOpen("picker");

    ImDrawList* dl = window->DrawList;
    dl->AddRectFilled(swatch.Min, swatch.Max, Color(color));
    dl->AddRect(swatch.Min, swatch.Max, Color(swatchHovered || open ? g_theme.accent : g_theme.border));
    const char* name = kMenuColorNames[i];
    const float textY = std::floor(p.y + (kColorRow - ImGui::CalcTextSize(name).y) * 0.5f);
    dl->AddText(ImVec2(swatch.Max.x + 8.0f, textY), Color(custom ? g_theme.text : g_theme.textDim), name);
    if (custom) dl->AddCircleFilled(ImVec2(dots.Min.x - 9.0f, p.y + kColorRow * 0.5f), 2.5f, Color(g_theme.accent));  // changed from the theme
    dl->AddRectFilled(dots.Min, dots.Max, Color(dotsHovered || open ? g_theme.panelHeader : g_theme.bgSoft));
    dl->AddRect(dots.Min, dots.Max, Color(dotsHovered || open ? g_theme.accent : g_theme.border));
    for (int d = -1; d <= 1; ++d)
      dl->AddRectFilled(ImVec2(std::floor((dots.Min.x + dots.Max.x) * 0.5f) + d * 5.0f - 1.0f, std::floor((dots.Min.y + dots.Max.y) * 0.5f) - 1.0f),
                        ImVec2(std::floor((dots.Min.x + dots.Max.x) * 0.5f) + d * 5.0f + 1.0f, std::floor((dots.Min.y + dots.Max.y) * 0.5f) + 1.0f),
                        Color(dotsHovered || open ? g_theme.text : g_theme.textDim));

    // The picker, kept inside the menu window.
    constexpr float kPickerW = 214.0f, kPickerH = 262.0f;
    const ImVec2 display = ImGui::GetIO().DisplaySize;
    ImVec2 at(dots.Max.x - kPickerW, dots.Max.y + 4.0f);
    if (at.y + kPickerH > display.y) at.y = (std::max)(4.0f, dots.Min.y - 4.0f - kPickerH);
    at.x = ImClamp(at.x, 4.0f, display.x - kPickerW - 4.0f);
    ImGui::SetNextWindowPos(at);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8.0f, 8.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4.0f, 3.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(6.0f, 6.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemInnerSpacing, ImVec2(4.0f, 4.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, g_theme.bgSoft);
    ImGui::PushStyleColor(ImGuiCol_Border, g_theme.accent);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, g_theme.panelHeader);
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, g_theme.panelHeader);
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, g_theme.panelHeader);
    ImGui::PushStyleColor(ImGuiCol_Text, g_theme.text);
    if (ImGui::BeginPopup("picker", ImGuiWindowFlags_NoMove)) {
      ImGui::TextUnformatted(name);
      float rgb[3] = { color.x, color.y, color.z };
      ImGui::SetNextItemWidth(kPickerW - 16.0f);
      if (ImGui::ColorPicker3("##pick", rgb, ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_DisplayHex |
                                                 ImGuiColorEditFlags_NoLabel)) {
        g_settings.colors[i] = ToRgbInt(ImVec4(rgb[0], rgb[1], rgb[2], 1.0f));
        changed = true;
      }
      if (Button("Use theme colour", ImVec2(kPickerW - 16.0f, 22.0f))) {
        g_settings.colors[i] = -1;
        changed = true;
      }
      ImGui::EndPopup();
    }
    ImGui::PopStyleColor(6);
    ImGui::PopStyleVar(4);
    ImGui::PopID();
  }
  if (changed && !ImGui::IsMouseDown(ImGuiMouseButton_Left)) {  // saved once you let go
    changed = false;
    SaveConfig();
  }
}

void ProfileControls(float width) {
  static char name[64]{};
  static std::string status;
  auto profiles=ConfigProfiles();
  std::vector<const char*> labels;for(auto& p:profiles)labels.push_back(p.c_str());
  static int selected=0;
  if(!labels.empty()) {selected=std::clamp(selected,0,static_cast<int>(labels.size())-1);if(Choice("Saved Configs",&selected,labels.data(),static_cast<int>(labels.size())))strcpy_s(name,profiles[selected].c_str());}
  ImGui::SetNextItemWidth(width);ImGui::InputText("##profile_name",name,sizeof(name));
  const ImVec2 size((width-3*kItemSpacing)/4,g_theme.controlHeight);
  if(Button("Create",size))status=SaveConfigProfile(name,true)?"Created config.":"Use a new name: letters, numbers, spaces, _ or -.";
  ImGui::SameLine(0,kItemSpacing);if(Button("Save Profile",size))status=SaveConfigProfile(name)?"Saved config.":"Could not save config.";
  ImGui::SameLine(0,kItemSpacing);if(Button("Load",size))status=LoadConfigProfile(name)?"Loaded config.":"Config not found.";
  ImGui::SameLine(0,kItemSpacing);if(Button("Delete",size))status=DeleteConfigProfile(name)?"Deleted config.":"Config not found.";
  if(!status.empty())HintText(status.c_str());
}
void SaveResetButtons(float width) {
  static DWORD savedAt = 0, resetAt = 0;
  const DWORD now = GetTickCount();
  const ImVec2 size((width - kItemSpacing) * 0.5f, g_theme.controlHeight);
  if (Button(savedAt && now - savedAt < kConfirmMs ? "Saved" : "Save", size) && SaveConfig()) savedAt = now;
  ImGui::SameLine(0.0f, kItemSpacing);
  if (Button(resetAt && now - resetAt < kConfirmMs ? "Reset done" : "Reset", size)) {
    ResetConfig();
    resetAt = now;
  }
}

}  // namespace

void DrawConfigTab(float width) {
  HintText("Press the menu key to hide or show this menu.");
  if (KeyBind("Menu key", &g_settings.menuKey, false)) SaveConfig();  // saved straight away so it sticks
  Separator();
  if (Toggle("Custom Accent Color", &g_settings.customAccent)) SaveConfig();
  static bool hueChanged = false;
  if (g_settings.customAccent && SliderInt("Accent Hue", &g_settings.accentHue, 0, 360, "%d")) hueChanged = true;
  if (hueChanged && !ImGui::IsMouseDown(ImGuiMouseButton_Left)) {  // saved once the slider is let go
    hueChanged = false;
    SaveConfig();
  }
  if (Choice("Menu Font", &g_settings.menuFont, kMenuFontNames, kMenuFontCount)) SaveConfig();
  SliderInt("Interface Size",&g_settings.interfaceScale,75,150,"%d%%");
  Toggle("Menu Background Effect",&g_settings.menuBackgroundEffect);
  Separator();
  HintText("Menu colors. Click ... to change one.");
  MenuColorGrid(width);
  if (Button("Reset Colors", ImVec2(width, g_theme.controlHeight))) {
    for (int& color : g_settings.colors) color = -1;
    SaveConfig();
  }
  Separator();
  HintText("Type a config name, or select a saved config.");
  ProfileControls(width);
  SaveResetButtons(width);
  if(Button("Eject / Close",ImVec2(width,g_theme.controlHeight)))PostQuitMessage(0);
}

float ConfigTabHeight() {
  constexpr float kHint = 24.0f, kSeparator = 18.0f;
  return kSliderRowStep+kToggleRowStep+5*kHint+3*kToggleRowStep+kHint + kToggleRowStep + kSeparator + kToggleRowStep +
         (g_settings.customAccent ? kSliderRowStep : 0.0f) + kToggleRowStep + kSeparator + kHint +
         ((kMenuColorCount + kColorColumns - 1) / kColorColumns) * (kColorRow + kItemSpacing) + g_theme.controlHeight + kItemSpacing + kSeparator + g_theme.controlHeight + kItemSpacing;
}

}  // namespace wintek::ui
