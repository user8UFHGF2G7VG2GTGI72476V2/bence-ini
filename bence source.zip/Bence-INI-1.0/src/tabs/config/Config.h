#pragma once
#include <string>
#include <vector>

// Settings and theme, saved to config.json in a Bence INI folder inside ARK's own app-data folder:
// %LOCALAPPDATA%\Packages\StudioWildcard.4558480580BB9_1w2mm55455e38\AC\Bence INI
namespace wintek {

void LoadConfig();   // creates the folder; loads config.json if it exists
bool SaveConfig();
void ResetConfig();  // back to defaults, and saved
std::vector<std::string> ConfigProfiles();
bool SaveConfigProfile(const std::string& name,bool createOnly=false);
bool LoadConfigProfile(const std::string& name);
bool DeleteConfigProfile(const std::string& name);

}  // namespace wintek
