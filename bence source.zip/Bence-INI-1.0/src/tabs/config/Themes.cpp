#include "tabs/config/Themes.h"
#include "ui/Theme.h"
#include <cmath>
#include <cstring>

namespace wintek::ui {

namespace {

const ThemePreset kThemes[] = {
  { "Cyan", ImVec4(0.0314f, 0.0784f, 0.0941f, 1.0f), ImVec4(0.0392f, 0.1020f, 0.1216f, 1.0f), ImVec4(0.0510f, 0.1216f, 0.1451f, 1.0f), ImVec4(0.0627f, 0.1490f, 0.1765f, 1.0f), ImVec4(0.1059f, 0.2549f, 0.2902f, 1.0f), ImVec4(0.9020f, 0.9765f, 0.9882f, 1.0f), ImVec4(0.5333f, 0.7059f, 0.7373f, 1.0f), ImVec4(0.0f, 0.85f, 0.95f, 1.0f) },
  { "Crimson", ImVec4(0.078f, 0.055f, 0.059f, 1.0f), ImVec4(0.102f, 0.071f, 0.078f, 1.0f), ImVec4(0.118f, 0.082f, 0.094f, 1.0f), ImVec4(0.137f, 0.098f, 0.114f, 1.0f), ImVec4(0.216f, 0.137f, 0.157f, 1.0f), ImVec4(0.961f, 0.922f, 0.922f, 1.0f), ImVec4(0.667f, 0.549f, 0.569f, 1.0f), ImVec4(0.95f, 0.30f, 0.30f, 1.0f) },
  { "Forest", ImVec4(0.051f, 0.075f, 0.059f, 1.0f), ImVec4(0.067f, 0.098f, 0.075f, 1.0f), ImVec4(0.078f, 0.114f, 0.090f, 1.0f), ImVec4(0.094f, 0.133f, 0.106f, 1.0f), ImVec4(0.137f, 0.216f, 0.157f, 1.0f), ImVec4(0.922f, 0.949f, 0.925f, 1.0f), ImVec4(0.549f, 0.647f, 0.569f, 1.0f), ImVec4(0.35f, 0.80f, 0.45f, 1.0f) },
  { "Violet", ImVec4(0.067f, 0.055f, 0.086f, 1.0f), ImVec4(0.086f, 0.071f, 0.114f, 1.0f), ImVec4(0.102f, 0.082f, 0.133f, 1.0f), ImVec4(0.118f, 0.098f, 0.157f, 1.0f), ImVec4(0.196f, 0.157f, 0.255f, 1.0f), ImVec4(0.941f, 0.925f, 0.973f, 1.0f), ImVec4(0.627f, 0.588f, 0.706f, 1.0f), ImVec4(0.55f, 0.40f, 1.0f, 1.0f) },
  { "Sunset", ImVec4(0.086f, 0.059f, 0.047f, 1.0f), ImVec4(0.110f, 0.075f, 0.059f, 1.0f), ImVec4(0.129f, 0.090f, 0.071f, 1.0f), ImVec4(0.149f, 0.106f, 0.082f, 1.0f), ImVec4(0.235f, 0.165f, 0.125f, 1.0f), ImVec4(0.973f, 0.933f, 0.910f, 1.0f), ImVec4(0.706f, 0.588f, 0.529f, 1.0f), ImVec4(1.0f, 0.60f, 0.20f, 1.0f) },
  { "Ocean", ImVec4(0.047f, 0.071f, 0.086f, 1.0f), ImVec4(0.059f, 0.094f, 0.114f, 1.0f), ImVec4(0.071f, 0.110f, 0.133f, 1.0f), ImVec4(0.086f, 0.129f, 0.157f, 1.0f), ImVec4(0.125f, 0.204f, 0.255f, 1.0f), ImVec4(0.910f, 0.949f, 0.973f, 1.0f), ImVec4(0.549f, 0.647f, 0.706f, 1.0f), ImVec4(0.30f, 0.90f, 0.80f, 1.0f) },
  { "Mono", ImVec4(0.059f, 0.059f, 0.063f, 1.0f), ImVec4(0.078f, 0.078f, 0.086f, 1.0f), ImVec4(0.094f, 0.094f, 0.102f, 1.0f), ImVec4(0.114f, 0.114f, 0.125f, 1.0f), ImVec4(0.176f, 0.176f, 0.196f, 1.0f), ImVec4(0.941f, 0.941f, 0.949f, 1.0f), ImVec4(0.588f, 0.588f, 0.608f, 1.0f), ImVec4(0.85f, 0.85f, 0.90f, 1.0f) },
  { "Sakura", ImVec4(0.078f, 0.055f, 0.067f, 1.0f), ImVec4(0.102f, 0.071f, 0.086f, 1.0f), ImVec4(0.122f, 0.086f, 0.106f, 1.0f), ImVec4(0.149f, 0.106f, 0.129f, 1.0f), ImVec4(0.231f, 0.157f, 0.196f, 1.0f), ImVec4(0.973f, 0.929f, 0.949f, 1.0f), ImVec4(0.690f, 0.569f, 0.627f, 1.0f), ImVec4(1.0f, 0.47f, 0.72f, 1.0f) },
  { "Gold", ImVec4(0.071f, 0.063f, 0.047f, 1.0f), ImVec4(0.094f, 0.082f, 0.059f, 1.0f), ImVec4(0.114f, 0.102f, 0.071f, 1.0f), ImVec4(0.137f, 0.122f, 0.086f, 1.0f), ImVec4(0.224f, 0.196f, 0.133f, 1.0f), ImVec4(0.973f, 0.957f, 0.910f, 1.0f), ImVec4(0.690f, 0.651f, 0.553f, 1.0f), ImVec4(1.0f, 0.78f, 0.22f, 1.0f) },
  { "Toxic", ImVec4(0.043f, 0.059f, 0.039f, 1.0f), ImVec4(0.059f, 0.078f, 0.051f, 1.0f), ImVec4(0.071f, 0.094f, 0.063f, 1.0f), ImVec4(0.086f, 0.114f, 0.075f, 1.0f), ImVec4(0.141f, 0.196f, 0.118f, 1.0f), ImVec4(0.933f, 0.973f, 0.910f, 1.0f), ImVec4(0.588f, 0.667f, 0.549f, 1.0f), ImVec4(0.62f, 1.0f, 0.20f, 1.0f) },
  { "Cyber", ImVec4(0.043f, 0.039f, 0.067f, 1.0f), ImVec4(0.059f, 0.051f, 0.090f, 1.0f), ImVec4(0.075f, 0.063f, 0.110f, 1.0f), ImVec4(0.094f, 0.078f, 0.137f, 1.0f), ImVec4(0.169f, 0.129f, 0.235f, 1.0f), ImVec4(0.941f, 0.922f, 0.980f, 1.0f), ImVec4(0.612f, 0.573f, 0.722f, 1.0f), ImVec4(1.0f, 0.25f, 0.85f, 1.0f) },
  { "Arctic", ImVec4(0.922f, 0.933f, 0.949f, 1.0f), ImVec4(0.882f, 0.898f, 0.922f, 1.0f), ImVec4(0.980f, 0.984f, 0.992f, 1.0f), ImVec4(0.933f, 0.945f, 0.961f, 1.0f), ImVec4(0.804f, 0.831f, 0.863f, 1.0f), ImVec4(0.118f, 0.133f, 0.157f, 1.0f), ImVec4(0.431f, 0.471f, 0.518f, 1.0f), ImVec4(0.20f, 0.50f, 0.95f, 1.0f) },
};

int g_current = 0;  // index into kThemes

}  // namespace

const ThemePreset* ThemePresets(int& count) {
  count = static_cast<int>(IM_ARRAYSIZE(kThemes));
  return kThemes;
}

void ApplyThemePreset(const ThemePreset& preset) {
  for (int i = 0; i < static_cast<int>(IM_ARRAYSIZE(kThemes)); ++i)
    if (&kThemes[i] == &preset) g_current = i;
  g_theme.bg = preset.bg;
  g_theme.bgSoft = preset.bgSoft;
  g_theme.panel = preset.panel;
  g_theme.panelHeader = preset.panelHeader;
  g_theme.border = preset.border;
  g_theme.text = preset.text;
  g_theme.textDim = preset.textDim;
  g_theme.accent = preset.accent;
}

bool IsCurrentTheme(const ThemePreset& preset) { return &preset == &kThemes[g_current]; }

const ThemePreset& CurrentThemePreset() { return kThemes[g_current]; }

const char* CurrentThemeName() { return kThemes[g_current].name; }

void SetTheme(const char* name) {
  for (const ThemePreset& preset : kThemes)
    if (std::strcmp(preset.name, name) == 0) ApplyThemePreset(preset);
  // (unknown names, e.g. from an older config, leave the theme as it is)
}

}  // namespace wintek::ui
