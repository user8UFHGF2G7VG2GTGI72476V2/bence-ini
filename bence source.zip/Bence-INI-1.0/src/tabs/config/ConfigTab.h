#pragma once

namespace wintek::ui {

void DrawConfigTab(float width);
float ConfigTabHeight();  // height of the tab's content, for sizing the window

}  // namespace wintek::ui
