#include "tabs/config/Config.h"
#include "core/Settings.h"
#include "core/JsonText.h"
#include "tabs/config/Themes.h"
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <limits>

namespace wintek {

namespace {

constexpr const wchar_t* kGameDataFolder = L"\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\AC";
constexpr const char* kDefaultTheme = "Cyan";

enum class Type { Bool, Int, Float, Text64 };

struct Field {
  const char* key;
  Type type;
  void* value;
};

// config.json is one flat object. Keys are kept stable so older config files still load.
std::vector<Field> Fields() {
  IniSettings& ini = g_settings.ini;
  OtherSettings& other = g_settings.other;
  std::vector<Field> fields;
  auto add = [&](const char* key, bool& v) { fields.push_back({ key, Type::Bool, &v }); };
  auto addInt = [&](const char* key, int& v) { fields.push_back({ key, Type::Int, &v }); };
  auto addFloat = [&](const char* key, float& v) { fields.push_back({ key, Type::Float, &v }); };
  auto addToggle = [&](const char* key, const char* hotkey, KeyedToggle& t) {
    add(key, t.on);
    addInt(hotkey, t.key);
  };

  addToggle("normalIni", "keyNormalIni", ini.normal);
  addToggle("hardIni", "keyHardIni", ini.hard);
  addToggle("potatoIni", "keyPotatoIni", ini.potato);
  addToggle("stalkerIni", "keyStalkerIni", ini.stalker);
  addFloat("stalkerDist", ini.stalkerDistance);
  addToggle("fullbright", "keyFullbright", ini.fullbright);
  addFloat("fullbrightLevel", ini.fullbrightLevel);
  addToggle("noXyz", "keyNoXyz", ini.noXyz);
  addToggle("noRockTrees", "keyNoRockTrees", ini.noRockTrees);
  addToggle("noLandscape", "keyNoLandscape", ini.noLandscape);
  addToggle("noWater", "keyNoWater", ini.noWater);
  addToggle("noHands", "keyNoHands", ini.noHands);
  addToggle("noHud", "keyNoHud", ini.noHud);
  addToggle("noFoliage", "keyNoFoliage", ini.noFoliage);
  addToggle("removeParticle", "keyRemoveParticle", ini.removeParticle);
  addToggle("lowMemory", "keyLowMemory", ini.lowMemory);
  addInt("lowMemoryScale", ini.lowMemoryScale);
  addToggle("blackSky", "keyBlackSky", ini.blackSky);
  addToggle("blackStructures", "keyBlackStructures", ini.blackStructures);


  VisualSettings& visual = g_settings.visual;
  addToggle("noFog", "keyNoFog", visual.noFog);
  addToggle("noClouds", "keyNoClouds", visual.noClouds);
  addToggle("noShadows", "keyNoShadows", visual.noShadows);
  addToggle("noBloom", "keyNoBloom", visual.noBloom);
  addToggle("noLensFlare", "keyNoLensFlare", visual.noLensFlare);
  addToggle("noMotionBlur", "keyNoMotionBlur", visual.noMotionBlur);
  addToggle("viewDistance", "keyViewDistance", visual.viewDistance);
  addFloat("viewDistanceScale", visual.viewDistanceScale);
  addToggle("fpsLimit", "keyFpsLimit", visual.fpsLimit);
  addInt("maxFps", visual.maxFps);
  addInt("textureQuality", visual.textureQuality);

  MiscSettings& misc = g_settings.misc;
  addToggle("autoForge","keyAutoForge",misc.autoForge);
  add("forgeGas",misc.forgeGas);add("forgeMetal",misc.forgeMetal);add("forgePull",misc.forgePull);add("forgeDedi",misc.forgeDedi);add("forgeTurnOn",misc.forgeTurnOn);addInt("forgeRange",misc.forgeRange);
  addToggle("quickPickup","keyQuickPickup",misc.quickPickup);addInt("pickupActionKey",misc.pickupActionKey);
  addToggle("takeAll","keyTakeAll",misc.takeAll);addInt("takeAllActionKey",misc.takeAllActionKey);

  auto& d=g_settings.dino;
  addToggle("dinoAutoSaddle","keyDinoAutoSaddle",d.saddle);addInt("dinoSaddleRange",d.saddleRange);
  addToggle("dinoAutoImprint","keyDinoAutoImprint",d.imprint);
  addToggle("dinoAutoName","keyDinoAutoName",d.name);addInt("dinoNameRange",d.nameRange);add("dinoRenameNamed",d.renameNamed);fields.push_back({"dinoNameText",Type::Text64,d.nameText});
  addToggle("dinoAutoClaim","keyDinoAutoClaim",d.claim);
  addToggle("dinoAutoNeuter","keyDinoAutoNeuter",d.neuter);addInt("dinoNeuterRange",d.neuterRange);
  addToggle("dinoAutoLevel","keyDinoAutoLevel",d.level);
  constexpr const char* levelKeys[]={"dinoLevelHealth","dinoLevelStamina","dinoLevelOxygen","dinoLevelFood","dinoLevelWeight","dinoLevelMelee","dinoLevelSpeed","dinoLevelCrafting"};for(int i=0;i<8;++i)addInt(levelKeys[i],d.levelPoints[i]);
  addToggle("dinoAutoClone","keyDinoAutoClone",d.clone);addInt("dinoCloneRange",d.cloneRange);
  addToggle("dinoFillCloning","keyDinoFillCloning",d.fillCloning);addToggle("dinoPickupEggs","keyDinoPickupEggs",d.pickupEggs);addToggle("dinoTransferEggs","keyDinoTransferEggs",d.transferEggs);addToggle("dinoHatchEggs","keyDinoHatchEggs",d.hatchEggs);
  addToggle("turretFiller", "keyTurretFiller", misc.turretFiller);
  addInt("heavyStacks", misc.heavyStacks);
  addInt("tekStacks", misc.tekStacks);
  add("showTurretFill", misc.showTurretFill);
  addInt("turretRange", misc.turretRange);
  addToggle("resourcePull", "keyResourcePull", misc.resourcePull);
  addInt("pullRange", misc.pullRange);
  addInt("pullCrafts", misc.pullCrafts);
  addToggle("autoChemBench", "keyAutoChemBench", misc.autoChemBench);
  addInt("chemRecipe", misc.chemRecipe);
  addInt("chemRange", misc.chemRange);
  addInt("chemQueue", misc.chemQueue);
  add("chemSupply", misc.chemSupply);
  add("chemCollect", misc.chemCollect);
  add("chemFuel", misc.chemFuel);
  addInt("chemGasoline", misc.chemGasoline);
  addToggle("autoMating", "keyAutoMating", misc.autoMating);
  addInt("matingRange", misc.matingRange);
  addToggle("betterInput", "keyBetterInput", misc.betterInput);

  HudSettings& hud = g_settings.hud;
  addToggle("watermark", "keyWatermark", hud.watermark);
  addInt("watermarkCorner", hud.watermarkCorner);
  addInt("watermarkColor", hud.watermarkColor);
  addInt("watermarkSize", hud.watermarkSize);
  addToggle("crosshair", "keyCrosshair", hud.crosshair);
  addInt("crossShape", hud.crossShape);
  addInt("crossColor", hud.crossColor);
  addInt("crossSize", hud.crossSize);
  addInt("crossThickness", hud.crossThickness);
  addInt("crossGap", hud.crossGap);
  addInt("crossOpacity",hud.crossOpacity);
  add("crossOutline", hud.crossOutline);
  addToggle("trajectory", "keyTrajectory", hud.trajectory);
  addToggle("playerOutlines", "keyPlayerOutlines", hud.playerOutlines);
  addToggle("turretOutlines", "keyTurretOutlines", hud.turretOutlines);
  addInt("trajectorySeconds", hud.trajectorySeconds);
  addInt("outlineRange", hud.outlineRange);
  add("outlineEnemiesOnly", hud.outlineEnemiesOnly);
  addToggle("infoDisplay", "keyInfoDisplay", hud.info);
  addInt("infoCorner", hud.infoCorner);
  add("infoFps", hud.infoFps);
  add("infoClock", hud.infoClock);
  add("infoTimer", hud.infoTimer);
  add("infoCoords", hud.infoCoords);
  addToggle("armorHud", "keyArmorHud", hud.armor);
  addInt("armorSize", hud.armorSize);
  addInt("armorTextSize", hud.armorTextSize);
  addInt("armorYOffset", hud.armorYOffset);
  add("armorShowDurability", hud.armorShowDurability);
  add("armorPercent", hud.armorPercent);
  add("armorCount", hud.armorCount);
  addToggle("awesomeSpyglass", "keyAwesomeSpyglass", hud.spyglass);
  addFloat("spyX", hud.spyX);
  addFloat("spyY", hud.spyY);
  addToggle("structureSnap", "keyStructureSnap", g_settings.misc.structureSnap);
  addInt("snapSpacing", g_settings.misc.snapSpacing);
  addInt("snapAngle", g_settings.misc.snapAngle);
  addToggle("structureSnapOther", "keyStructureSnapOther", g_settings.misc.structureSnapOther);
  addInt("vaultSnapGap", g_settings.misc.vaultSnapGap);
  addInt("structureSnapSpacing", g_settings.misc.structureSnapSpacing);
  addInt("structureSnapAngle", g_settings.misc.structureSnapAngle);
  add("snapVaults", g_settings.misc.snapVaults);
  add("snapOtherStructures", g_settings.misc.snapOtherStructures);
  addInt("spyRange", hud.spyRange);
  addToggle("corruptedDinoEsp", "keyCorruptedDinoEsp", hud.corruptedEsp);
  addInt("corruptedEspRange", hud.corruptedEspRange);
  addToggle("penisEsp", "keyPenisEsp", hud.penisEsp);
  addInt("penisEspRange", hud.penisEspRange);
  addInt("penisEspSize", hud.penisEspSize);
  addToggle("tekIndicator","keyTekIndicator",hud.tekIndicator);add("tekAnyWeapon",hud.tekAnyWeapon);addInt("tekRange",hud.tekRange);addInt("tekScale",hud.tekScale);addFloat("tekX",hud.tekX);addFloat("tekY",hud.tekY);
  add("spyWildPoints", hud.spyWildPoints);
  add("spyTamedPoints",hud.spyTamedPoints);add("spyColors",hud.spyColors);add("spyBackground",hud.spyBackground);addInt("spyLockKey",hud.spyLockKey);addInt("spyScale",hud.spyScale);
  add("infoPing",hud.infoPing);
  add("infoServerFps",hud.infoServerFps);
  add("infoPlayers",hud.infoPlayers);
  add("infoTurrets",hud.infoTurrets);
  add("infoFriendlyTurrets",hud.infoFriendlyTurrets);
  add("infoSlots",hud.infoSlots);
  add("infoServerName",hud.infoServerName);
  add("infoRainbow",hud.infoRainbow);
  addInt("infoScale",hud.infoScale);
  addInt("hudFont", hud.hudFont);
  addToggle("hpOverlay", "keyHpOverlay", hud.hp);
  addFloat("hpX", hud.hpX);
  addFloat("hpY", hud.hpY);
  addToggle("mountHpOverlay", "keyMountHpOverlay", hud.mountHp);
  addFloat("mountX", hud.mountX);
  addFloat("mountY", hud.mountY);
  addToggle("playerList", "keyPlayerList", hud.playerList);
  addInt("playerSide", hud.playerSide);
  addFloat("playerY", hud.playerY);
  addInt("playerTextSize", hud.playerTextSize);
  addInt("playerMaxRows", hud.playerMaxRows);
  addInt("playerRefresh", hud.playerRefresh);

  addToggle("stretchRes", "keyStretchRes", other.stretchedRes);
  addFloat("stretchH", other.stretchHorizontal);
  addFloat("stretchV", other.stretchVertical);
  addInt("stretchW", other.stretchWidth);
  addInt("stretchHt", other.stretchHeight);
  add("vibrance", other.vibrance);
  addInt("vibranceLevel", other.vibranceLevel);
  add("fov", other.fov);
  addInt("fovLevel", other.fovLevel);
  add("colorFilter", other.colorFilter);
  addFloat("filterSaturation", other.filterSaturation);
  addFloat("filterContrast", other.filterContrast);
  addFloat("filterBrightness", other.filterBrightness);
  addFloat("filterGamma", other.filterGamma);
  addFloat("filterTemperature", other.filterTemperature);
  addFloat("filterTint",other.filterTint);
  addFloat("filterSharpen",other.filterSharpen);
  addInt("filterPreset",other.filterPreset);
  addInt("keyMenu", g_settings.menuKey);
  addInt("menuFont", g_settings.menuFont);
  addInt("interfaceScale",g_settings.interfaceScale);add("menuBackgroundEffect",g_settings.menuBackgroundEffect);
  add("customAccent", g_settings.customAccent);
  addInt("accentHue", g_settings.accentHue);
  static const char* const kColorKeys[10] = { "colorBackground", "colorSidebar", "colorPanel", "colorControls", "colorBorder",
                                              "colorText", "colorDimText", "colorAccent", "colorTopLine", "colorTitles" };
  for (int i = 0; i < 10; ++i) addInt(kColorKeys[i], g_settings.colors[i]);
  return fields;
}

std::wstring Folder() {
  const wchar_t* localAppData = _wgetenv(L"LOCALAPPDATA");
  return std::wstring(localAppData ? localAppData : L"") + kGameDataFolder + L"\\Bence INI";
}

std::wstring FilePath() { return Folder() + L"\\config.json"; }

// The text after "key": in a flat JSON object, or nullptr if the key isn't there.
const char* FindValue(const std::string& json, const char* key) {
  const std::string quoted = std::string("\"") + key + "\"";
  std::size_t at = json.find(quoted);
  if (at == std::string::npos) return nullptr;
  at = json.find(':', at + quoted.size());
  if (at == std::string::npos) return nullptr;
  const char* value = json.c_str() + at + 1;
  while (*value == ' ' || *value == '\t') ++value;
  return value;
}

std::string ReadFile(const std::wstring& path) {
  std::string text;
  FILE* file = _wfopen(path.c_str(), L"rb");
  if (!file) return text;
  char buffer[4096];
  for (std::size_t n; (n = std::fread(buffer, 1, sizeof(buffer), file)) > 0;) text.append(buffer, n);
  std::fclose(file);
  return text;
}

void ApplyJson(const std::string& json) {
  if (json.empty()) return;
  if (const char* v = FindValue(json, "theme"); v && *v == '"') {
    if (const char* end = std::strchr(v + 1, '"')) ui::SetTheme(std::string(v + 1, end).c_str());
  }
  for (const Field& field : Fields()) {
    const char* v = FindValue(json, field.key);
    if (!v) continue;
    switch (field.type) {
      case Type::Bool: *static_cast<bool*>(field.value) = std::strncmp(v, "true", 4) == 0; break;
      case Type::Int: {char* end=nullptr;auto n=std::strtoll(v,&end,10);if(end!=v&&n>=std::numeric_limits<int>::min()&&n<=std::numeric_limits<int>::max())*static_cast<int*>(field.value)=static_cast<int>(n);break;}
      case Type::Float: {char* end=nullptr;float n=std::strtof(v,&end);if(end!=v&&std::isfinite(n))*static_cast<float*>(field.value)=n;break;}
      case Type::Text64: {std::string text;if(JsonReadText(v,text,63)){std::memset(field.value,0,64);std::memcpy(field.value,text.data(),text.size());}break;}
    }
  }
  if (g_settings.menuKey <= 0) g_settings.menuKey = ImGuiKey_Insert;  // never leave the menu without a key
}
bool WriteConfigFile(const std::wstring& path) {
  FILE* file = _wfopen(path.c_str(), L"wb");
  if (!file) return false;
  std::fprintf(file, "{\n  \"theme\": \"%s\"", ui::CurrentThemeName());
  for (const Field& field : Fields()) {
    std::fprintf(file, ",\n  \"%s\": ", field.key);
    switch (field.type) {
      case Type::Bool: std::fputs(*static_cast<bool*>(field.value) ? "true" : "false", file); break;
      case Type::Int: std::fprintf(file, "%d", *static_cast<int*>(field.value)); break;
      case Type::Float: std::fprintf(file, "%g", *static_cast<float*>(field.value)); break;
      case Type::Text64: std::fputs(JsonQuote(static_cast<const char*>(field.value)).c_str(),file); break;
    }
  }
  std::fputs("\n}\n", file);
  return std::fclose(file) == 0;
}
std::wstring ProfileFolder(){return Folder()+L"\\profiles";}
std::wstring ProfilePath(const std::string& name){return ProfileFolder()+L"\\"+std::wstring(name.begin(),name.end())+L".json";}
} // namespace

void LoadConfig(){const auto folder=Folder();CreateDirectoryW(folder.substr(0,folder.rfind(L'\\')).c_str(),nullptr);CreateDirectoryW(folder.c_str(),nullptr);ApplyJson(ReadFile(FilePath()));}
bool SaveConfig(){return WriteConfigFile(FilePath());}
std::vector<std::string> ConfigProfiles(){
 std::vector<std::string> result;WIN32_FIND_DATAW data{};HANDLE h=FindFirstFileW((ProfileFolder()+L"\\*.json").c_str(),&data);if(h==INVALID_HANDLE_VALUE)return result;
 do{if(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)continue;std::wstring name=data.cFileName;if(name.size()<6)continue;name.resize(name.size()-5);std::string value;bool ascii=true;for(wchar_t c:name){if(c>127){ascii=false;break;}value+=static_cast<char>(c);}if(ascii&&ValidConfigName(value))result.push_back(value);}while(FindNextFileW(h,&data));FindClose(h);std::sort(result.begin(),result.end());return result;
}
bool SaveConfigProfile(const std::string& name,bool createOnly){
 if(!ValidConfigName(name))return false;CreateDirectoryW(ProfileFolder().c_str(),nullptr);auto path=ProfilePath(name);if(createOnly&&GetFileAttributesW(path.c_str())!=INVALID_FILE_ATTRIBUTES)return false;
 auto temporary=path+L".tmp";if(!WriteConfigFile(temporary))return false;return MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_WRITE_THROUGH|(createOnly?0:MOVEFILE_REPLACE_EXISTING))!=0;
}
bool LoadConfigProfile(const std::string& name){if(!ValidConfigName(name))return false;auto json=ReadFile(ProfilePath(name));if(json.empty()||json.front()!='{'||json.find('}')==std::string::npos)return false;g_settings=Settings{};ApplyJson(json);return SaveConfig();}
bool DeleteConfigProfile(const std::string& name){return ValidConfigName(name)&&DeleteFileW(ProfilePath(name).c_str())!=0;}

void ResetConfig() {
  g_settings = Settings{};
  ui::SetTheme(kDefaultTheme);
  SaveConfig();
}

}  // namespace wintek
