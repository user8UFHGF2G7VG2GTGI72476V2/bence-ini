#pragma once
#include "imgui.h"

// The menu's colour themes, chosen on the Config tab and saved in config.json.
namespace wintek::ui {

struct ThemePreset {
  const char* name;
  ImVec4 bg;
  ImVec4 bgSoft;
  ImVec4 panel;
  ImVec4 panelHeader;
  ImVec4 border;
  ImVec4 text;
  ImVec4 textDim;
  ImVec4 accent;
};

const ThemePreset* ThemePresets(int& count);
void ApplyThemePreset(const ThemePreset& preset);
bool IsCurrentTheme(const ThemePreset& preset);

const ThemePreset& CurrentThemePreset();
const char* CurrentThemeName();
void SetTheme(const char* name);  // unknown names are ignored

}  // namespace wintek::ui
