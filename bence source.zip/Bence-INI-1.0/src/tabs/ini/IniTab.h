#pragma once

namespace wintek::ui {

void DrawIniTab();
float IniTabHeight();  // height of the tab's content, for sizing the window

}  // namespace wintek::ui
