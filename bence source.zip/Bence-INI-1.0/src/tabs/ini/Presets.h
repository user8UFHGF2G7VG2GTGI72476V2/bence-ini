#pragma once
#include "tabs/ini/ViewMode.h"

// Normal, Hard and Potato INI: whole-view presets. Only one is on at a time (the menu and hotkeys enforce it).
namespace wintek {

inline bool AnyPreset(const IniSettings& s) { return s.normal.on || s.hard.on || s.potato.on; }

inline void ApplyPresets(const IniSettings& s, ViewEdit& view) {
  if (s.normal.on) view.SetMode(ViewModeIndex::Lit);
  if (s.hard.on) view.SetMode(ViewModeIndex::Wireframe);
  if (s.potato.on) {
    view.SetMode(ViewModeIndex::BrushWireframe);
    for (ShowFlag flag : { ShowFlag::DynamicShadows, ShowFlag::AmbientOcclusion, ShowFlag::MotionBlur, ShowFlag::LensFlares,
                           ShowFlag::DepthOfField, ShowFlag::Bloom, ShowFlag::LightShafts, ShowFlag::ScreenSpaceReflections,
                           ShowFlag::GroundClutter, ShowFlag::Particles })
      view.Hide(flag);
  }
}

// Switching one preset on switches the others off.
inline void SelectPreset(IniSettings& s, KeyedToggle& chosen) {
  for (KeyedToggle* preset : { &s.normal, &s.hard, &s.potato })
    if (preset != &chosen) preset->on = false;
}

}  // namespace wintek
