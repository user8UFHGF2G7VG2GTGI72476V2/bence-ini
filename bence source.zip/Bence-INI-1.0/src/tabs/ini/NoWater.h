#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// No Water: hides water surfaces and switches off underwater post-process volumes.
//
// Surfaces are found the way Knucklebutt finds them: mesh and particle components on placed level actors (not
// structures, players or dinos) whose mesh, material or particle template has a water name, with meshes also
// needing a translucent base material. Walking every object is slow over ReadProcessMemory, so it runs on a
// worker thread every 20 seconds while the feature is on.
namespace wintek {

void TickNoWater(const IniSettings& settings, Address world, bool restoring);
void ResetNoWater();

}  // namespace wintek
