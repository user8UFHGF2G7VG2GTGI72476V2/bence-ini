#pragma once
#include "tabs/ini/ViewMode.h"

// Remove Particle: hides particle effects (smoke, fire, weather).
namespace wintek {

inline void ApplyRemoveParticle(const IniSettings& s, ViewEdit& view) {
  if (s.removeParticle.on) view.Hide(ShowFlag::Particles);
}

}  // namespace wintek
