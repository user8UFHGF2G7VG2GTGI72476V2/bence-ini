#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// Fullbright: raises UEngine::DisplayGamma (ARK's default is 2.2). Color Filter's gamma slider scales the same
// value, so both are handled here; Fullbright wins when both are on.
namespace wintek {

void TickDisplayGamma(const Settings& settings, Address engine);
void ResetDisplayGamma();

}  // namespace wintek
