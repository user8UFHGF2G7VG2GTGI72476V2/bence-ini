#include "tabs/ini/NoWater.h"
#include "engine/PostProcessVolumes.h"
#include <windows.h>
#include <algorithm>
#include <mutex>
#include <thread>

namespace wintek {

namespace {

constexpr DWORD kRescanMs = 20000;
// RF_PendingKill and the BeginDestroyed / FinishDestroyed / Unreachable family: objects on their way out.
constexpr std::uint32_t kDeadFlags = 0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000;

struct {
  std::vector<ObjectRef> surfaces;
  std::unordered_map<Address, bool> waterVolumes;  // volume -> is underwater, by flag or name
  bool hidden = false;
  Address world = 0;
  DWORD scannedAt = 0;

  std::mutex mutex;  // guards the two fields below, written by the scan thread
  std::vector<ObjectRef> found;
  bool foundReady = false;
  std::atomic<bool> scanning{ false };
} g_water;

bool IsWaterName(const std::string& name) {
  const std::string s = ToLower(name);
  if (s.find("water") != std::string::npos || s.find("wtrf") != std::string::npos || s.find("ocean") != std::string::npos ||
      s.find("river") != std::string::npos)
    return true;
  for (std::size_t p = s.find("lake"); p != std::string::npos; p = s.find("lake", p + 1))
    if (p == 0 || s[p - 1] != 'f') return true;  // "flake" isn't water
  return false;
}

void ScanSurfaces(std::uint32_t generation) {
  using namespace offsets;
  Reflection reflection;
  enum Kind { kOther, kMesh, kParticles };
  std::unordered_map<Address, Kind> kinds;
  std::unordered_map<Address, bool> ownerAllowed;
  std::unordered_map<Address, std::int32_t> assetOffset, overrideOffset, templateOffset, materialsOffset;
  std::int32_t blendModeOffset = -1;

  auto cachedOffset = [&](std::unordered_map<Address, std::int32_t>& cache, Address cls, const char* name) {
    auto it = cache.find(cls);
    if (it == cache.end()) it = cache.emplace(cls, reflection.PropertyOffset(cls, name)).first;
    return it->second;
  };
  // Follows material instances up to their base material; translucent, additive and modulated count.
  auto isTranslucent = [&](Address material) {
    for (int depth = 0; material && depth < 6; ++depth) {
      const Address cls = ClassOf(material);
      if (reflection.NameOf(cls).find("MaterialInstance") != std::string::npos) {
        material = Read<Address>(material + material::kParent);
        continue;
      }
      if (blendModeOffset < 0) blendModeOffset = reflection.PropertyOffset(cls, "BlendMode");
      const auto mode = blendModeOffset > 0 ? Read<std::uint8_t>(material + blendModeOffset) : 0;
      return mode >= 2 && mode <= 4;
    }
    return false;
  };

  std::vector<ObjectRef> hits;
  ForEachObject([&](Address object, std::int32_t index) {
    if (g_scanGeneration != generation) return false;
    std::uint8_t header[0x28];
    if (!g_memory.ReadRaw(object, header, sizeof(header))) return true;
    std::uint32_t flags;
    Address cls, owner;
    std::memcpy(&flags, header + object::kFlags, sizeof(flags));
    std::memcpy(&cls, header + object::kClass, sizeof(cls));
    std::memcpy(&owner, header + object::kOuter, sizeof(owner));
    if (!cls || !owner || (flags & kDeadFlags)) return true;

    auto kind = kinds.find(cls);
    if (kind == kinds.end())
      kind = kinds.emplace(cls, reflection.IsA(cls, "MeshComponent") ? kMesh : reflection.IsA(cls, "ParticleSystemComponent") ? kParticles : kOther).first;
    if (kind->second == kOther) return true;

    const Address level = Read<Address>(owner + object::kOuter);
    if (!level || reflection.NameOf(ClassOf(level)) != "Level") return true;
    const Address ownerClass = ClassOf(owner);
    auto allowed = ownerAllowed.find(ownerClass);
    if (allowed == ownerAllowed.end()) {
      const bool excluded = reflection.IsA(ownerClass, "PrimalStructure") || reflection.IsA(ownerClass, "ShooterCharacter") ||
                            reflection.IsA(ownerClass, "PrimalDinoCharacter");
      allowed = ownerAllowed.emplace(ownerClass, !excluded).first;
    }
    if (!allowed->second) return true;

    bool water = false;
    if (kind->second == kParticles) {
      const std::int32_t offset = cachedOffset(templateOffset, cls, "Template");
      const Address effect = offset ? Read<Address>(object + offset) : 0;
      water = effect && IsWaterName(reflection.NameOf(effect));
    } else {
      const Address asset = MeshAssetOf(reflection, assetOffset, object);
      const bool waterMesh = asset && IsWaterName(reflection.NameOf(asset));
      const std::int32_t overridesAt = cachedOffset(overrideOffset, cls, "OverrideMaterials");
      const std::int32_t materialsAt = asset ? cachedOffset(materialsOffset, ClassOf(asset), "Materials") : 0;
      const auto overrides = overridesAt ? Read<TArray>(object + overridesAt) : TArray{};
      const auto materials = materialsAt ? Read<TArray>(asset + materialsAt) : TArray{};
      const std::int32_t overrideCount = overrides.data ? overrides.count : 0;
      const std::int32_t materialCount = materials.data ? materials.count : 0;
      for (std::int32_t m = 0; m < (std::max)(overrideCount, materialCount) && m < 16 && !water; ++m) {
        Address material = m < overrideCount ? Read<Address>(overrides.data + m * sizeof(Address)) : 0;
        if (!material && m < materialCount) material = Read<Address>(materials.data + m * sizeof(Address));
        water = material && (waterMesh || IsWaterName(reflection.NameOf(material))) && isTranslucent(material);
      }
    }
    if (water) hits.push_back({ object, index });
    return true;
  });

  {
    std::lock_guard<std::mutex> lock(g_water.mutex);
    if (g_scanGeneration == generation) {
      g_water.found = std::move(hits);
      g_water.foundReady = true;
    }
  }
  g_water.scanning = false;
}

void TickSurfaces(bool wanted, Address world, bool restoring) {
  if (world && world != g_water.world) {  // 0 during loading screens: keep the list until a new world loads
    g_water.surfaces.clear();
    g_water.waterVolumes.clear();
    g_water.world = world;
    g_water.scannedAt = 0;
    g_water.hidden = false;
    ++g_scanGeneration;
  }
  const DWORD now = GetTickCount();
  if (wanted && world && !restoring && !g_water.scanning && (!g_water.scannedAt || now - g_water.scannedAt >= kRescanMs)) {
    g_water.scannedAt = now;
    g_water.scanning = true;
    std::thread(ScanSurfaces, g_scanGeneration.load()).detach();
  }
  {
    std::lock_guard<std::mutex> lock(g_water.mutex);
    if (g_water.foundReady) {
      g_water.foundReady = false;
      for (const ObjectRef& surface : g_water.found)
        if (std::find(g_water.surfaces.begin(), g_water.surfaces.end(), surface) == g_water.surfaces.end())
          g_water.surfaces.push_back(surface);
    }
  }
  if (wanted) {
    for (const ObjectRef& surface : g_water.surfaces)
      if (surface.Alive()) SetDrawInGame(surface.object, false);
    g_water.hidden = true;
  } else if (g_water.hidden) {
    for (const ObjectRef& surface : g_water.surfaces)
      if (surface.Alive()) SetDrawInGame(surface.object, IsVisibleInGame(surface.object));
    g_water.hidden = false;
  }
}

bool IsWaterVolume(const PostProcessVolume& v) {
  auto it = g_water.waterVolumes.find(v.address());
  if (it == g_water.waterVolumes.end())
    it = g_water.waterVolumes.emplace(v.address(), (v.flags & offsets::volume::kWater) || IsWaterName(NameOf(v.address()))).first;
  return it->second;
}

// Underwater volumes are switched off by clearing their enabled flag, and switched back on only if they were on.
void TickVolumes(bool wanted) {
  using namespace offsets::volume;
  for (PostProcessVolume& v : Volumes()) {
    const bool drain = wanted && IsWaterVolume(v);
    if ((!drain && !v.drained) || !v.ref.Alive()) continue;
    const Address flags = v.address() + kFlags;
    if (drain == v.drained) {
      if (drain) SetBits(flags, kEnabled, false);  // the game may re-enable it
      continue;
    }
    if (drain) {
      v.drained = (Read<std::uint8_t>(flags) & kEnabled) != 0;
      SetBits(flags, kEnabled, false);
    } else {
      SetBits(flags, kEnabled, true);
      v.drained = false;
    }
  }
}

}  // namespace

void TickNoWater(const IniSettings& settings, Address world, bool restoring) {
  TickSurfaces(settings.noWater.on, world, restoring);
  TickVolumes(settings.noWater.on);
}

void ResetNoWater() {
  std::lock_guard<std::mutex> lock(g_water.mutex);
  g_water.surfaces.clear();
  g_water.waterVolumes.clear();
  g_water.found.clear();
  g_water.foundReady = false;
  g_water.hidden = false;
  g_water.world = 0;
  g_water.scannedAt = 0;
}

}  // namespace wintek
