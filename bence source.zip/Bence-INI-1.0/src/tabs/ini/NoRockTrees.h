#pragma once
#include "tabs/ini/ViewMode.h"

// No Rock/Trees: rocks, trees and bushes are instanced static meshes, so hiding that show flag removes them.
namespace wintek {

inline void ApplyNoRockTrees(const IniSettings& s, ViewEdit& view) {
  if (s.noRockTrees.on) view.Hide(ShowFlag::InstancedStaticMeshes);
}

}  // namespace wintek
