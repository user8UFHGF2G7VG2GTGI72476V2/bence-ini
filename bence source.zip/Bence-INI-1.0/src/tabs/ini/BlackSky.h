#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// Black Sky: hides the sky dome and cloud meshes so the sky renders black. Found by a background scan like
// No Water's, then hidden through their render proxies every tick.
namespace wintek {

// Also does No Clouds (Visual tab), which hides only the cloud meshes the same scan finds.
void TickBlackSky(const IniSettings& ini, const VisualSettings& visual, Address world, bool restoring);
void ResetBlackSky();

}  // namespace wintek
