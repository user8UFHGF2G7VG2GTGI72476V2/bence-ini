#include "tabs/ini/ViewMode.h"
#include "tabs/ini/NoFoliage.h"
#include "tabs/ini/NoLandscape.h"
#include "tabs/ini/NoRockTrees.h"
#include "tabs/ini/Presets.h"
#include "tabs/ini/RemoveParticle.h"
#include "tabs/visual/VisualFlags.h"

namespace wintek {

namespace {

constexpr std::size_t kViewBytes = offsets::viewport::kViewBytes;

struct {
  ObjectRef viewport;  // the viewport we changed; empty while no snapshot is held
  std::uint8_t snapshot[kViewBytes] = {};
} g_view;

Address ViewOf(Address viewport) { return viewport + offsets::viewport::kViewModeIndex; }

bool AnyViewFeature(const Settings& settings) {
  const IniSettings& s = settings.ini;
  return AnyPreset(s) || s.noRockTrees.on || s.noLandscape.on || s.noFoliage.on || s.removeParticle.on || AnyVisualFlag(settings.visual);
}

}  // namespace

// `viewport` reads as 0 during loading screens. The snapshot is kept through that, so it's never retaken from
// values we already changed.
void TickViewMode(const Settings& all, Address viewport) {
  const IniSettings& settings = all.ini;
  const bool wanted = AnyViewFeature(all);
  const Address held = g_view.viewport.object;
  if (held && (!wanted || (viewport && viewport != held))) {
    if (g_view.viewport.Alive()) g_memory.WriteRaw(ViewOf(held), g_view.snapshot, kViewBytes);
    g_view.viewport = {};
  }
  if (!wanted || !viewport) return;
  const Address view = ViewOf(viewport);
  if (!g_view.viewport.object) {
    if (!g_memory.ReadRaw(view, g_view.snapshot, kViewBytes)) return;
    g_view.viewport = ObjectRef::Of(viewport);
  }

  ViewEdit edit(g_view.snapshot);
  ApplyPresets(settings, edit);
  ApplyNoRockTrees(settings, edit);
  ApplyRemoveParticle(settings, edit);
  ApplyNoLandscape(settings, edit);
  ApplyNoFoliage(settings, edit);
  ApplyVisualFlags(all.visual, edit);

  std::uint8_t current[kViewBytes];
  if (g_memory.ReadRaw(view, current, kViewBytes) && std::memcmp(current, edit.bytes(), kViewBytes) != 0)
    g_memory.WriteRaw(view, edit.bytes(), kViewBytes);
}

void ResetViewMode() { g_view = {}; }

}  // namespace wintek
