#include "tabs/ini/NoXyz.h"
#include "engine/Engine.h"
#include <windows.h>
#include <algorithm>
#include <mutex>
#include <thread>

namespace wintek {

namespace {

constexpr DWORD kRescanMs = 30000;  // new effects load in as you travel
constexpr std::uint8_t kDomainSurface = 0, kDomainPostProcess = 3;

struct {
  std::vector<ObjectRef> materials;
  bool switched = false;
  DWORD scannedAt = 0;
  std::atomic<std::int32_t> domainOffset{ 0 };  // UMaterial::MaterialDomain, found by the first scan

  std::mutex mutex;  // guards the two fields below, written by the scan thread
  std::vector<ObjectRef> found;
  bool foundReady = false;
  std::atomic<bool> scanning{ false };
} g_xyz;

void ScanMaterials(std::uint32_t generation) {
  Reflection reflection;
  std::unordered_map<Address, bool> isMaterial;
  std::int32_t domain = g_xyz.domainOffset;
  std::vector<ObjectRef> hits;
  ForEachObject([&](Address object, std::int32_t index) {
    if (g_scanGeneration != generation) return false;
    const Address cls = ClassOf(object);
    if (!cls) return true;
    auto it = isMaterial.find(cls);
    if (it == isMaterial.end()) it = isMaterial.emplace(cls, reflection.NameOf(cls) == "Material").first;
    if (!it->second) return true;
    if (!domain) domain = reflection.PropertyOffset(cls, "MaterialDomain");
    if (!domain || Read<std::uint8_t>(object + domain) != kDomainPostProcess) return true;
    const std::string& name = reflection.NameOf(object);
    if (name != "ARK_PostProcess" && name != "ESPMaterialOutline") hits.push_back({ object, index });
    return true;
  });

  {
    std::lock_guard<std::mutex> lock(g_xyz.mutex);
    if (g_scanGeneration == generation) {
      g_xyz.domainOffset = domain;
      g_xyz.found = std::move(hits);
      g_xyz.foundReady = true;
    }
  }
  g_xyz.scanning = false;
}

}  // namespace

void TickNoXyz(const IniSettings& settings, bool restoring) {
  const bool wanted = settings.noXyz.on;
  const DWORD now = GetTickCount();
  if (wanted && !restoring && !g_xyz.scanning && (!g_xyz.scannedAt || now - g_xyz.scannedAt >= kRescanMs)) {
    g_xyz.scannedAt = now;
    g_xyz.scanning = true;
    std::thread(ScanMaterials, g_scanGeneration.load()).detach();
  }
  {
    std::lock_guard<std::mutex> lock(g_xyz.mutex);
    if (g_xyz.foundReady) {
      g_xyz.foundReady = false;
      for (const ObjectRef& material : g_xyz.found)
        if (std::find(g_xyz.materials.begin(), g_xyz.materials.end(), material) == g_xyz.materials.end())
          g_xyz.materials.push_back(material);
    }
  }

  const std::int32_t domain = g_xyz.domainOffset;
  if (!domain) return;
  if (wanted) {
    for (const ObjectRef& m : g_xyz.materials)
      if (m.Alive() && Read<std::uint8_t>(m.object + domain) == kDomainPostProcess) Write(m.object + domain, kDomainSurface);
    g_xyz.switched = true;
  } else if (g_xyz.switched) {
    for (const ObjectRef& m : g_xyz.materials)
      if (m.Alive() && Read<std::uint8_t>(m.object + domain) == kDomainSurface) Write(m.object + domain, kDomainPostProcess);
    g_xyz.switched = false;
  }
}

void ResetNoXyz() {
  std::lock_guard<std::mutex> lock(g_xyz.mutex);
  g_xyz.materials.clear();
  g_xyz.found.clear();
  g_xyz.foundReady = false;
  g_xyz.switched = false;
  g_xyz.scannedAt = 0;
  g_xyz.domainOffset = 0;
}

}  // namespace wintek
