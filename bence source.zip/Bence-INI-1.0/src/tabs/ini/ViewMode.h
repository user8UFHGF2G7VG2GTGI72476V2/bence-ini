#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"
#include <cstring>

// The viewport's ViewModeIndex and EngineShowFlags, which several INI features change. They're kept as one
// block: the game's own values are snapshotted when the first of those features turns on, every tick the
// snapshot plus the features' changes is written back, and the snapshot is restored when the last turns off.
namespace wintek {

// Bit positions in UGameViewportClient::EngineShowFlags.
enum class ShowFlag : int {
  Bloom = 0,
  LensFlares = 7,
  AmbientOcclusion = 11,
  DepthOfField = 20,
  MotionBlur = 23,
  ScreenSpaceReflections = 40,
  InstancedStaticMeshes = 49,
  DynamicShadows = 50,
  Particles = 51,
  Landscape = 88,
  LightShafts = 98,
  GroundClutter = 127,
};

enum class ViewModeIndex : std::int32_t { BrushWireframe = 0, Wireframe = 1, Lit = 3 };

class ViewEdit {
public:
  explicit ViewEdit(const std::uint8_t* snapshot) { std::memcpy(bytes_, snapshot, sizeof(bytes_)); }

  void SetMode(ViewModeIndex mode) {
    const auto value = static_cast<std::int32_t>(mode);
    std::memcpy(bytes_, &value, sizeof(value));
  }
  void Hide(ShowFlag flag) { HideBit(static_cast<int>(flag)); }
  void HideBit(int bit) {
    if (bit < 0 || sizeof(std::int32_t) + bit / 8 >= sizeof(bytes_)) return;
    bytes_[sizeof(std::int32_t) + bit / 8] &= static_cast<std::uint8_t>(~(1u << (bit % 8)));
  }
  const std::uint8_t* bytes() const { return bytes_; }

private:
  std::uint8_t bytes_[offsets::viewport::kViewBytes];
};

void TickViewMode(const Settings& settings, Address viewport);
void ResetViewMode();

}  // namespace wintek
