#include "tabs/ini/BlackStructures.h"
#include "core/Diagnostics.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include <algorithm>
#include <array>
#include <mutex>
#include <thread>

namespace wintek {
namespace {
constexpr int kBatch=32,kBytes=128;
struct Name {int index=0,number=0;};
struct Resources {
  ObjectRef parent;
  Name color;
  Address library=0,create=0,setVector=0,getNum=0,getMaterial=0,setMaterial=0;
};
struct Mesh {
  ObjectRef ref;
  int slots=-1;
  std::vector<Address> original;
  std::vector<unsigned char> captured,applied;
};
enum class Kind {Create,Color,Count,Original,Apply,Restore};
struct Op {Kind kind;std::size_t mesh=0;int slot=0,result=-1;};
Resources g_resources,g_foundResources;
std::vector<Mesh> g_meshes;
std::vector<ObjectRef> g_found;
std::mutex g_mutex;
std::atomic<bool> g_scanning{false};
bool g_foundReady=false,g_colored=false;
ObjectRef g_mid;
Address g_params=0,g_world=0;
DWORD g_scannedAt=0;
std::uint64_t g_ticket=0;
std::vector<Op> g_ops;

int RawAt(Reflection& r,Address owner,const char* name) {
  const Address f=owner ? r.FindField(owner,name) : 0;
  if(!f)return -1;
  const int at=Read<int>(f+offsets::reflection::kPropertyOffset);
  return at>=0&&at<0x8000 ? at : -1;
}

Name DirectColorParameter(Reflection& r,Address material,const char* input) {
  const Address f=r.FindField(ClassOf(material),input);
  if(!f||r.NameOf(ClassOf(f))!="StructProperty")return {};
  const Address type=Read<Address>(f+0x70);
  const int at=RawAt(r,ClassOf(material),input);
  int expressionAt=RawAt(r,type,"Expression");
  // Older ARK metadata leaves the native ExpressionInput members unreflected.
  // Validate the input type and the pointed-to expression before using that layout.
  if(expressionAt<0&&type) {
    const std::string name=r.NameOf(type);
    const int size=Read<int>(f+0x34);
    if((name=="ColorMaterialInput"||name=="VectorMaterialInput"||name=="ExpressionInput")&&size>=8&&size<=128)expressionAt=0;
  }
  if(at<0||expressionAt<0||expressionAt>256)return {};
  const Address expression=Read<Address>(material+at+expressionAt);
  if(!expression||!r.IsA(ClassOf(expression),"MaterialExpressionVectorParameter"))return {};
  const int nameAt=r.PropertyOffset(ClassOf(expression),"ParameterName");
  return nameAt ? Read<Name>(expression+nameAt) : Name{};
}

bool MetalActor(Reflection& r,Address cls) {
  if(!r.IsA(cls,"PrimalStructure"))return false;
  for(int depth=0;cls&&depth<64;++depth) {
    const std::string n=ToLower(r.NameOf(cls));
    if(n.find("metal")!=std::string::npos||n.find("storagebox_huge")!=std::string::npos)return true;
    cls=Read<Address>(cls+offsets::reflection::kSuperStruct);
  }
  return false;
}

void Scan(std::uint32_t generation) {
  Reflection r;Resources resources;
  std::vector<ObjectRef> meshes;
  std::unordered_map<Address,int> kinds;
  std::unordered_map<Address,bool> metal;
  int score=-1;
  ForEachObject([&](Address object,std::int32_t index) {
    if(g_scanGeneration!=generation)return false;
    const Address cls=ClassOf(object);if(!cls)return true;
    auto k=kinds.find(cls);
    if(k==kinds.end()) {
      const std::string name=r.NameOf(cls);
      const int kind=name=="Function"?1:name=="Material"?2:name=="KismetMaterialLibrary"?3:r.IsA(cls,"MeshComponent")?4:0;
      k=kinds.emplace(cls,kind).first;
    }
    if(k->second==1) {
      const std::string name=r.NameOf(object),outer=r.NameOf(Read<Address>(object+offsets::object::kOuter));
      if(outer=="KismetMaterialLibrary"&&name=="CreateDynamicMaterialInstance")resources.create=object;
      if(outer=="MaterialInstanceDynamic"&&name=="SetVectorParameterValue")resources.setVector=object;
      if(outer=="PrimitiveComponent"||outer=="MeshComponent") {
        if(name=="GetNumMaterials")resources.getNum=object;
        if(name=="GetMaterial")resources.getMaterial=object;
        if(name=="SetMaterial")resources.setMaterial=object;
      }
      return true;
    }
    if(k->second==3&&r.NameOf(object)=="Default__KismetMaterialLibrary")resources.library=object;
    const auto flags=Read<std::uint32_t>(object+offsets::object::kFlags);
    if(flags&(0x30|0x100|0x4000|0x8000|0x10000))return true;
    if(k->second==2) {
      const int domain=r.PropertyOffset(cls,"MaterialDomain"),blend=r.PropertyOffset(cls,"BlendMode"),shading=r.PropertyOffset(cls,"ShadingModel");
      if(!domain||!blend||Read<unsigned char>(object+domain)!=0||Read<unsigned char>(object+blend)!=0)return true;
      Name color;
      int candidate=-1;
      if(shading&&Read<unsigned char>(object+shading)==0) {
        color=DirectColorParameter(r,object,"EmissiveColor");
        if(color.index>0)candidate=10;
      }
      const std::string name=ToLower(r.NameOf(object));
      if(name=="black"||name=="m_black"||name=="mat_black"||name=="blackmaterial") {candidate=5;color={};}
      if(candidate>score){score=candidate;resources.parent={object,index};resources.color=color;}
      return true;
    }
    if(k->second!=4)return true;
    const Address owner=Read<Address>(object+offsets::object::kOuter);
    if(!owner)return true;
    const Address level=Read<Address>(owner+offsets::object::kOuter);
    if(!level||r.NameOf(ClassOf(level))!="Level")return true;
    const Address ownerClass=ClassOf(owner);
    auto m=metal.find(ownerClass);
    if(m==metal.end())m=metal.emplace(ownerClass,MetalActor(r,ownerClass)).first;
    if(m->second)meshes.push_back({object,index});
    return true;
  });
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    if(g_scanGeneration==generation){g_found=std::move(meshes);g_foundResources=resources;g_foundReady=true;}
  }
  g_scanning=false;
}

int Param(Address fn,const char* name,const char* type,int bytes) {
  const Address f=fn ? MainReflection().FindField(fn,name) : 0;
  if(!f||NameOf(ClassOf(f))!=type)return -1;
  const int at=Read<int>(f+offsets::reflection::kPropertyOffset);
  return at>=0&&at+bytes<=kBytes ? at : -1;
}

bool Submit(Address object,Address fn,std::array<unsigned char,kBytes>& bytes,Op op) {
  if(!fn||!object||g_ops.size()>=kBatch)return false;
  const Address at=g_params+g_ops.size()*kBytes;
  if(!g_memory.WriteRaw(at,bytes.data(),bytes.size()))return false;
  g_ticket=QueueProcessEvent(object,fn,at);g_ops.push_back(op);return true;
}
template<class T> void Put(std::array<unsigned char,kBytes>& bytes,int at,const T& value){std::memcpy(bytes.data()+at,&value,sizeof(value));}

void Finish() {
  for(std::size_t n=0;n<g_ops.size();++n) {
    const auto& op=g_ops[n];const Address data=g_params+n*kBytes;
    if(op.kind==Kind::Create) {
      const Address value=Read<Address>(data+op.result);
      if(value&&IsA(ClassOf(value),"MaterialInstanceDynamic"))g_mid=ObjectRef::Of(value);
    } else if(op.kind==Kind::Color)g_colored=true;
    else if(op.mesh<g_meshes.size()) {
      auto& mesh=g_meshes[op.mesh];
      if(op.kind==Kind::Count) {
        const int count=Read<int>(data+op.result);mesh.slots=count>0&&count<=32?count:0;
        mesh.original.resize(mesh.slots);mesh.captured.resize(mesh.slots);mesh.applied.resize(mesh.slots);
      } else if(op.slot<mesh.slots) {
        if(op.kind==Kind::Original) {
          Address value=0;
          if(g_memory.ReadRaw(data+op.result,&value,sizeof(value))) {mesh.original[op.slot]=value;mesh.captured[op.slot]=1;}
        } else mesh.applied[op.slot]=op.kind==Kind::Apply;
      }
    }
  }
  g_ops.clear();g_ticket=0;
}
}

void TickBlackStructures(const GameContext& game,bool wanted) {
  bool changed=false;
  for(const auto& m:g_meshes)for(auto value:m.applied)changed=changed||value;
  RequestDebugger(DebuggerClient::BlackStructures,wanted||changed||!g_ops.empty());
  if(!g_ops.empty()) {if(CompletedCalls()<g_ticket)return;Finish();}
  if(!game.world){g_diag.blackStructures=wanted?"waiting for world":"off";return;}
  if(g_world!=game.world){g_world=game.world;g_meshes.clear();g_scannedAt=0;}
  const DWORD now=GetTickCount();
  if(wanted&&!g_scanning&&(!g_scannedAt||now-g_scannedAt>=5000)) {
    g_scannedAt=now;g_scanning=true;std::thread(Scan,g_scanGeneration.load()).detach();
  }
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    if(g_foundReady) {
      g_foundReady=false;
      if(!g_resources.parent.object||!g_resources.parent.Alive())g_resources=g_foundResources;
      for(const auto& ref:g_found) {
        const auto found=std::find_if(g_meshes.begin(),g_meshes.end(),[&](const Mesh& m){return m.ref==ref;});
        if(found==g_meshes.end()){Mesh mesh;mesh.ref=ref;g_meshes.push_back(std::move(mesh));}
      }
      g_found.clear();
    }
  }
  if(!wanted&&!changed){g_diag.blackStructures="off";return;}
  if(!DebuggerAttached()){g_diag.blackStructures=DebuggerError()?DebuggerError():"attaching material helper";return;}
  if(!g_params)g_params=reinterpret_cast<Address>(VirtualAllocEx(g_process.handle,nullptr,kBatch*kBytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
  if(!g_params){g_diag.blackStructures="material parameter allocation failed";return;}
  const auto& res=g_resources;
  if(!res.getNum||!res.getMaterial||!res.setMaterial){g_diag.blackStructures="finding material functions";return;}
  if(wanted) {
    if(!res.parent.Alive()){g_diag.blackStructures="no compatible black material loaded; retrying";return;}
    if(!g_mid.Alive()) {
      g_mid={};g_colored=false;
      if(res.color.index<=0){g_mid=res.parent;g_colored=true;}
      else {
        const int world=Param(res.create,"WorldContextObject","ObjectProperty",8),parent=Param(res.create,"Parent","ObjectProperty",8),result=Param(res.create,"ReturnValue","ObjectProperty",8);
        if(!res.library||!res.setVector||world<0||parent<0||result<0){g_diag.blackStructures="black material creation unavailable";return;}
        std::array<unsigned char,kBytes> bytes={};Put(bytes,world,game.pawn);Put(bytes,parent,res.parent.object);
        Submit(res.library,res.create,bytes,{Kind::Create,0,0,result});g_diag.blackStructures="creating black material";return;
      }
    }
    if(!g_colored) {
      const int name=Param(res.setVector,"ParameterName","NameProperty",8),value=Param(res.setVector,"Value","StructProperty",16);
      if(name<0||value<0){g_diag.blackStructures="black color parameters unavailable";return;}
      std::array<unsigned char,kBytes> bytes={};Put(bytes,name,res.color);const float black[4]={0,0,0,1};std::memcpy(bytes.data()+value,black,sizeof(black));
      Submit(g_mid.object,res.setVector,bytes,{Kind::Color});return;
    }
  }
  int applied=0;
  for(std::size_t i=0;i<g_meshes.size()&&g_ops.size()<kBatch;++i) {
    auto& m=g_meshes[i];if(!m.ref.Alive())continue;
    std::array<unsigned char,kBytes> bytes={};
    if(wanted&&m.slots<0) {
      const int result=Param(res.getNum,"ReturnValue","IntProperty",4);
      if(result>=0)Submit(m.ref.object,res.getNum,bytes,{Kind::Count,i,0,result});continue;
    }
    for(int slot=0;slot<m.slots&&g_ops.size()<kBatch;++slot) {
      if(m.applied[slot])++applied;
      if(wanted&&!m.captured[slot]) {
        const int index=Param(res.getMaterial,"ElementIndex","IntProperty",4),result=Param(res.getMaterial,"ReturnValue","ObjectProperty",8);
        if(index<0||result<0)continue;bytes={};Put(bytes,index,slot);Submit(m.ref.object,res.getMaterial,bytes,{Kind::Original,i,slot,result});
      } else if(m.captured[slot]&&((wanted&&!m.applied[slot])||(!wanted&&m.applied[slot]))) {
        const Address material=wanted?g_mid.object:m.original[slot];
        if(material&&!ObjectRef::Of(material).Alive())continue;
        const int index=Param(res.setMaterial,"ElementIndex","IntProperty",4),value=Param(res.setMaterial,"Material","ObjectProperty",8);
        if(index<0||value<0)continue;bytes={};Put(bytes,index,slot);Put(bytes,value,material);
        Submit(m.ref.object,res.setMaterial,bytes,{wanted?Kind::Apply:Kind::Restore,i,slot});
      }
    }
  }
  g_diag.blackStructures=(wanted?"black material slots: ":"restoring material slots: ")+std::to_string(applied);
}

void ResetBlackStructures() {
  std::lock_guard<std::mutex> lock(g_mutex);
  g_meshes.clear();g_found.clear();g_foundReady=false;g_resources={};g_foundResources={};
  g_mid={};g_colored=false;g_params=0;g_world=0;g_scannedAt=0;g_ticket=0;g_ops.clear();
}

void FlushBlackStructures(unsigned timeoutMs) {
  const ULONGLONG until=GetTickCount64()+timeoutMs;
  while(g_process.IsAttached()&&GetTickCount64()<until) {
    RefreshObjectTable();
    TickBlackStructures(ReadContext(),false);
    bool pending=!g_ops.empty();
    for(const auto& m:g_meshes)if(m.ref.Alive())for(auto value:m.applied)pending=pending||value;
    if(!pending)break;
    TickDebugger();Sleep(10);
  }
  RequestDebugger(DebuggerClient::BlackStructures,false);
}
}
