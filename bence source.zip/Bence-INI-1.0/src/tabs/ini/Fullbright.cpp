#include "tabs/ini/Fullbright.h"
#include <algorithm>

namespace wintek {

namespace {

struct {
  ObjectRef engine;         // the engine whose gamma we changed
  std::int32_t offset = 0;  // its DisplayGamma
  float original = 0.0f;
  bool changed = false;
} g_gamma;

}  // namespace

// `engine` reads as 0 during loading screens. The original gamma is kept through that and written back to the
// engine it came from, so it's never re-read from a value we already raised.
void TickDisplayGamma(const Settings& settings, Address engine) {
  const bool fullbright = settings.ini.fullbright.on;
  const bool filter = settings.other.colorFilter && settings.other.filterGamma != 1.0f;
  const bool wanted = fullbright || filter;
  if (g_gamma.changed && (!wanted || (engine && engine != g_gamma.engine.object))) {
    if (g_gamma.engine.Alive()) Write(g_gamma.engine.object + g_gamma.offset, g_gamma.original);
    g_gamma.changed = false;
  }
  if (!wanted || !engine) return;

  if (engine != g_gamma.engine.object) {
    g_gamma.engine = ObjectRef::Of(engine);
    g_gamma.offset = PropertyOffset(ClassOf(engine), "DisplayGamma");
  }
  if (!g_gamma.offset) return;
  const Address gamma = engine + g_gamma.offset;
  if (!g_gamma.changed) {
    g_gamma.original = Read<float>(gamma);
    g_gamma.changed = true;
  }
  const float level = fullbright ? std::clamp(settings.ini.fullbrightLevel, 1.0f, 10.0f)
                                 : g_gamma.original * settings.other.filterGamma;
  if (Read<float>(gamma) != level) Write(gamma, level);
}

void ResetDisplayGamma() { g_gamma = {}; }

}  // namespace wintek
