#pragma once
#include "tabs/ini/ViewMode.h"

// No Landscape: hides the terrain.
namespace wintek {

inline void ApplyNoLandscape(const IniSettings& s, ViewEdit& view) {
  if (s.noLandscape.on) view.Hide(ShowFlag::Landscape);
}

}  // namespace wintek
