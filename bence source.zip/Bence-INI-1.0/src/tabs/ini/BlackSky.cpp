#include "tabs/ini/BlackSky.h"
#include "core/Diagnostics.h"
#include <windows.h>
#include <algorithm>
#include <mutex>
#include <thread>

namespace wintek {

namespace {

constexpr DWORD kRescanMs = 20000;
constexpr std::uint32_t kDeadFlags = 0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000;  // same as No Water

struct SkyMesh {
  ObjectRef ref;
  bool cloud = false;   // a cloud mesh (No Clouds hides only these)
  bool hidden = false;  // we're hiding it
};

struct {
  std::vector<SkyMesh> meshes;
  Address world = 0;
  DWORD scannedAt = 0;

  std::mutex mutex;  // guards the two fields below, written by the scan thread
  std::vector<SkyMesh> found;
  std::string foundSample;
  bool foundReady = false;
  std::atomic<bool> scanning{ false };
} g_sky;

bool Contains(const std::string& text, const char* part) { return text.find(part) != std::string::npos; }

// Sky actors (SkySphere, SkyDome, ...) have every mesh hidden; elsewhere only sky / cloud / star meshes.
bool IsSkyActorName(const std::string& lower) { return Contains(lower, "sky") && !Contains(lower, "skylight"); }
bool IsSkyMeshName(const std::string& lower) {
  return Contains(lower, "skysphere") || Contains(lower, "sky_sphere") || Contains(lower, "skydome") || Contains(lower, "sky_dome") ||
         Contains(lower, "cloud") || Contains(lower, "starfield") || Contains(lower, "stars");
}

void Scan(std::uint32_t generation) {
  using namespace offsets;
  Reflection reflection;
  std::unordered_map<Address, bool> isMesh, skyActor, excludedOwner;
  std::unordered_map<Address, std::int32_t> assetOffset;
  std::vector<SkyMesh> hits;
  std::string sample;

  ForEachObject([&](Address object, std::int32_t index) {
    if (g_scanGeneration != generation) return false;
    std::uint8_t header[0x28];
    if (!g_memory.ReadRaw(object, header, sizeof(header))) return true;
    std::uint32_t flags;
    Address cls, owner;
    std::memcpy(&flags, header + object::kFlags, sizeof(flags));
    std::memcpy(&cls, header + object::kClass, sizeof(cls));
    std::memcpy(&owner, header + object::kOuter, sizeof(owner));
    if (!cls || !owner || (flags & kDeadFlags)) return true;

    auto mesh = isMesh.find(cls);
    if (mesh == isMesh.end()) mesh = isMesh.emplace(cls, reflection.IsA(cls, "MeshComponent")).first;
    if (!mesh->second) return true;

    const Address level = Read<Address>(owner + object::kOuter);
    if (!level || reflection.NameOf(ClassOf(level)) != "Level") return true;
    const Address ownerClass = ClassOf(owner);
    auto excluded = excludedOwner.find(ownerClass);
    if (excluded == excludedOwner.end()) {
      const bool no = reflection.IsA(ownerClass, "PrimalStructure") || reflection.IsA(ownerClass, "ShooterCharacter") ||
                      reflection.IsA(ownerClass, "PrimalDinoCharacter");
      excluded = excludedOwner.emplace(ownerClass, no).first;
    }
    if (excluded->second) return true;

    auto sky = skyActor.find(ownerClass);
    if (sky == skyActor.end()) sky = skyActor.emplace(ownerClass, IsSkyActorName(ToLower(reflection.NameOf(ownerClass)))).first;
    std::string name = reflection.NameOf(object);
    if (const Address asset = MeshAssetOf(reflection, assetOffset, object)) name += " " + reflection.NameOf(asset);
    name = ToLower(name);
    const bool cloud = Contains(name, "cloud");
    if (sky->second || cloud || IsSkyMeshName(name)) {
      hits.push_back({ { object, index }, cloud, false });
      if (hits.size() <= 3) sample += (sample.empty() ? "" : ", ") + reflection.NameOf(ownerClass);
    }
    return true;
  });

  {
    std::lock_guard<std::mutex> lock(g_sky.mutex);
    if (g_scanGeneration == generation) {
      g_sky.found = std::move(hits);
      g_sky.foundSample = sample;
      g_sky.foundReady = true;
    }
  }
  g_sky.scanning = false;
}

}  // namespace

void TickBlackSky(const IniSettings& ini, const VisualSettings& visual, Address world, bool restoring) {
  const bool blackSky = ini.blackSky.on && !restoring, noClouds = visual.noClouds.on && !restoring;
  const bool wanted = blackSky || noClouds;
  if (world && world != g_sky.world) {  // 0 during loading screens: keep the list until a new world loads
    g_sky.meshes.clear();
    g_sky.world = world;
    g_sky.scannedAt = 0;
  }
  const DWORD now = GetTickCount();
  if (wanted && world && !g_sky.scanning && (!g_sky.scannedAt || now - g_sky.scannedAt >= kRescanMs)) {
    g_sky.scannedAt = now;
    g_sky.scanning = true;
    std::thread(Scan, g_scanGeneration.load()).detach();
  }
  {
    std::lock_guard<std::mutex> lock(g_sky.mutex);
    if (g_sky.foundReady) {
      g_sky.foundReady = false;
      for (const SkyMesh& m : g_sky.found) {
        auto known = std::find_if(g_sky.meshes.begin(), g_sky.meshes.end(), [&](const SkyMesh& k) { return k.ref == m.ref; });
        if (known == g_sky.meshes.end()) g_sky.meshes.push_back(m);
      }
      g_diag.skySample = g_sky.foundSample.empty() ? "none" : g_sky.foundSample;
    }
  }

  auto& meshes = g_sky.meshes;
  meshes.erase(std::remove_if(meshes.begin(), meshes.end(), [](const SkyMesh& m) { return !m.ref.Alive(); }), meshes.end());
  int sky = 0, clouds = 0;
  for (SkyMesh& m : meshes) {
    const bool hide = blackSky || (noClouds && m.cloud);
    if (hide) SetDrawInGame(m.ref.object, false);  // proxies get rebuilt, so every tick
    else if (m.hidden) SetDrawInGame(m.ref.object, IsVisibleInGame(m.ref.object));
    m.hidden = hide;
    ++sky;
    if (m.cloud) ++clouds;
  }
  g_diag.skyMeshes = sky;
  g_diag.cloudMeshes = clouds;
}

void ResetBlackSky() {
  std::lock_guard<std::mutex> lock(g_sky.mutex);
  g_sky.meshes.clear();
  g_sky.found.clear();
  g_sky.foundReady = false;
  g_sky.world = 0;
  g_sky.scannedAt = 0;
}

}  // namespace wintek
