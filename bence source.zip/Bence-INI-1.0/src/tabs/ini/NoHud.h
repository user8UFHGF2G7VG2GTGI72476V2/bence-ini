#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// No HUD: hides the in-game HUD the way Knucklebutt does, by setting the HUD's user-hidden flag and clearing
// bHudHidden every 250 ms while no inventory is open (so menus and the inventory still work).
namespace wintek {

void TickNoHud(const IniSettings& settings, Address hud);
void ResetNoHud();

}  // namespace wintek
