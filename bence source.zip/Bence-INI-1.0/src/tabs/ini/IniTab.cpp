#include "tabs/ini/IniTab.h"
#include "core/Settings.h"
#include "engine/Console.h"
#include "tabs/ini/Presets.h"
#include "ui/Layout.h"
#include "ui/Widgets.h"

namespace wintek::ui {

namespace {

constexpr int kToggleCount = 16;
constexpr float kHintRowStep = 24.0f;

void PresetToggle(const char* label, IniSettings& ini, KeyedToggle& preset) {
  if (ToggleBind(label, &preset.on, &preset.key) && preset.on) SelectPreset(ini, preset);
}

void FeatureToggle(const char* label, KeyedToggle& toggle) { ToggleBind(label, &toggle.on, &toggle.key); }

}  // namespace

void DrawIniTab() {
  IniSettings& ini = g_settings.ini;
  PresetToggle("Normal INI", ini, ini.normal);
  PresetToggle("Hard INI", ini, ini.hard);
  PresetToggle("Potato INI", ini, ini.potato);
  FeatureToggle("Low Memory", ini.lowMemory);
  if (ini.lowMemory.on) {
    SliderInt("Render Scale", &ini.lowMemoryScale, 25, 100, "%d%%");
    if (const char* error = ConsoleError()) HintText(error);
  }
  FeatureToggle("Stalker INI", ini.stalker);
  if (ini.stalker.on) SliderFloat("Outline Distance (m)", &ini.stalkerDistance, 10.0f, 240.0f, "%.0f");
  FeatureToggle("Fullbright", ini.fullbright);
  if (ini.fullbright.on) SliderFloat("Level", &ini.fullbrightLevel, 1.0f, 10.0f, "%.1f");
  FeatureToggle("No XYZ", ini.noXyz);
  FeatureToggle("No Rock/Trees", ini.noRockTrees);
  FeatureToggle("No Landscape", ini.noLandscape);
  FeatureToggle("No Water", ini.noWater);
  FeatureToggle("Black Sky", ini.blackSky);
  FeatureToggle("Black Structure", ini.blackStructures);
  FeatureToggle("No Hands", ini.noHands);
  FeatureToggle("No HUD", ini.noHud);
  FeatureToggle("No Foliage", ini.noFoliage);
  FeatureToggle("Remove Particle", ini.removeParticle);
}

float IniTabHeight() {
  const IniSettings& ini = g_settings.ini;
  float height = kToggleCount * kToggleRowStep;
  if (ini.stalker.on) height += kSliderRowStep;
  if (ini.fullbright.on) height += kSliderRowStep;
  if (ini.lowMemory.on) height += kSliderRowStep + (ConsoleError() ? kHintRowStep : 0.0f);
  return height;
}

}  // namespace wintek::ui
