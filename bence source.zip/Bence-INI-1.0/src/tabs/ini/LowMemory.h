#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// Low Memory: renders the 3D world at a lower resolution (r.ScreenPercentage) for more FPS. The HUD stays
// at full resolution. Turning it off sets the render scale back to 100%.
namespace wintek {

void TickLowMemory(const IniSettings& settings, bool restoring);
void ResetLowMemory();

}  // namespace wintek
