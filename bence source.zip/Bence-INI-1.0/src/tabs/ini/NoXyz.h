#pragma once
#include "core/Settings.h"

// No XYZ: removes every post-process effect except ARK's own colour grading and the Stalker outline.
//
// Knucklebutt hooks UMaterial/UMaterialInstance::OverrideBlendableSettings and skips those materials. That
// function already ignores any material whose MaterialDomain isn't post-process, so instead of hooking we
// switch the domain of those materials to surface. Volumes are left untouched, so blueprints that manage their
// own blendables (Global_PostProcess re-creates its speed effect whenever it goes missing) don't react.
namespace wintek {

void TickNoXyz(const IniSettings& settings, bool restoring);
void ResetNoXyz();

}  // namespace wintek
