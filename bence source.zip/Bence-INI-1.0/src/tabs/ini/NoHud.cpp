#include "tabs/ini/NoHud.h"
#include <windows.h>

namespace wintek {

namespace {

constexpr DWORD kRefreshMs = 250;

struct {
  ObjectRef hud;  // the HUD we changed, empty if none
  std::uint8_t original = 0;
  DWORD refreshedAt = 0;
} g_hud;

}  // namespace

void TickNoHud(const IniSettings& settings, Address hud) {
  using namespace offsets::hud;
  const bool wanted = settings.noHud.on;
  // `hud` reads as 0 during loading screens; only a different HUD means ours is gone.
  const Address held = g_hud.hud.object;
  if (held && (!wanted || (hud && hud != held))) {
    if (g_hud.hud.Alive()) Write(held + kUserHidden, g_hud.original);
    g_hud.hud = {};
  }
  if (!wanted || !hud) return;
  if (!g_hud.hud.object) {
    // Only a 0/1 byte here is the in-game HUD's flag; the main menu's HUD class keeps other data at this offset.
    const auto value = Read<std::uint8_t>(hud + kUserHidden);
    if (value > 1) return;
    g_hud.original = value;
    g_hud.hud = ObjectRef::Of(hud);
  }
  if (!Read<std::uint8_t>(hud + kUserHidden)) Write<std::uint8_t>(hud + kUserHidden, 1);

  const DWORD now = GetTickCount();
  if (Read<Address>(hud + kOpenInventory) || now - g_hud.refreshedAt < kRefreshMs) return;
  g_hud.refreshedAt = now;
  Write<std::uint8_t>(hud + kHidden, 0);
}

void ResetNoHud() { g_hud = {}; }

}  // namespace wintek
