#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// Stalker INI: outlines creatures and players through terrain, the same way Knucklebutt does it. Through
// ProcessEvent it calls
//   KismetMaterialLibrary::CreateDynamicMaterialInstance(pawn, ESPMaterialOutline)
//   SetScalarParameterValue("ESPFillIntensity", 0) and ("ESPDepth", distance in cm)
//   SetVectorParameterValue("BackgroundColor", 0, 0, 0, 0)
// adds the material to a post-process volume's blendables, and sets the camera's "ignore health shading" flag
// every frame so outlines aren't tinted by health. The calls and the per-frame write go through the debugger
// (engine/Debugger.h); the blendables array is a plain memory write.
namespace wintek {

void TickStalkerIni(const IniSettings& settings, const GameContext& game, bool restoring);
void ResetStalkerIni();
bool StalkerOutlineReady();

}  // namespace wintek
