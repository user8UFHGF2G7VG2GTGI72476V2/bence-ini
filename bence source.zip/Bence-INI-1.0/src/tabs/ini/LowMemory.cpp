#include "tabs/ini/LowMemory.h"
#include "engine/Console.h"
#include <algorithm>
#include <string>

namespace wintek {

namespace {

constexpr int kFullScale = 100;
int g_applied = kFullScale;  // the render scale we last set; 100 means we haven't changed anything

}  // namespace

void TickLowMemory(const IniSettings& settings, bool restoring) {
  const int wanted = settings.lowMemory.on && !restoring ? std::clamp(settings.lowMemoryScale, 25, 100) : kFullScale;
  if (wanted == g_applied) return;
  QueueConsoleCommand(L"r.ScreenPercentage " + std::to_wstring(wanted));
  g_applied = wanted;
}

void ResetLowMemory() { g_applied = kFullScale; }  // a restarted game starts at its own default again

}  // namespace wintek
