#include "tabs/ini/NoHands.h"
#include <windows.h>
#include <algorithm>

namespace wintek {

namespace {

constexpr DWORD kRescanMs = 200;
constexpr int kMaxAttachDepth = 6;
constexpr std::size_t kMaxMeshes = 64;

struct {
  std::vector<ObjectRef> hidden;
  DWORD scannedAt = 0;
  std::unordered_map<Address, std::int32_t> mesh1pOffset, attachChildrenOffset, meshAssetOffset;
  std::unordered_map<Address, bool> isShield;
} g_hands;

bool OwnedBy(Address component, Address pawn) {
  int depth = 0;
  for (Address outer = Read<Address>(component + offsets::object::kOuter); outer && depth < 4;
       outer = Read<Address>(outer + offsets::object::kOuter), ++depth)
    if (outer == pawn) return true;
  return false;
}

// Mesh components at and under `component` in the attachment tree that belong to `pawn`.
void CollectMeshes(Address component, Address pawn, std::vector<Address>& out, int depth) {
  if (!component || depth > kMaxAttachDepth || out.size() > kMaxMeshes) return;
  const Address cls = ClassOf(component);
  if (IsA(cls, "MeshComponent")) out.push_back(component);

  auto it = g_hands.attachChildrenOffset.find(cls);
  if (it == g_hands.attachChildrenOffset.end()) it = g_hands.attachChildrenOffset.emplace(cls, PropertyOffset(cls, "AttachChildren")).first;
  if (!it->second) return;
  const auto children = Read<TArray>(component + it->second);
  if (!children.data || children.count <= 0 || children.count > 64) return;
  for (std::int32_t i = 0; i < children.count; ++i) {
    const Address child = Read<Address>(children.data + i * sizeof(Address));
    if (child && OwnedBy(child, pawn)) CollectMeshes(child, pawn, out, depth + 1);
  }
}

bool IsShield(Address component) {
  if (auto it = g_hands.isShield.find(component); it != g_hands.isShield.end()) return it->second;
  std::string name = NameOf(component);
  if (const Address asset = MeshAssetOf(MainReflection(), g_hands.meshAssetOffset, component)) name += NameOf(asset);
  return g_hands.isShield[component] = ToLower(name).find("shield") != std::string::npos;
}

void Rescan(Address pawn) {
  auto& hidden = g_hands.hidden;
  hidden.erase(std::remove_if(hidden.begin(), hidden.end(), [](const ObjectRef& r) { return !r.Alive(); }), hidden.end());

  const Address cls = ClassOf(pawn);
  auto it = g_hands.mesh1pOffset.find(cls);
  if (it == g_hands.mesh1pOffset.end()) it = g_hands.mesh1pOffset.emplace(cls, PropertyOffset(cls, "Mesh1P")).first;
  std::vector<Address> meshes;
  if (it->second) CollectMeshes(Read<Address>(pawn + it->second), pawn, meshes, 0);
  for (Address mesh : meshes) {
    const ObjectRef ref = ObjectRef::Of(mesh);
    if (!IsShield(mesh) && std::find(hidden.begin(), hidden.end(), ref) == hidden.end()) hidden.push_back(ref);
  }
}

}  // namespace

void TickNoHands(const IniSettings& settings, Address pawn) {
  if (!settings.noHands.on || !pawn) {
    for (const ObjectRef& mesh : g_hands.hidden)
      if (mesh.Alive()) SetDrawInGame(mesh.object, IsVisibleInGame(mesh.object));
    g_hands.hidden.clear();
    g_hands.scannedAt = 0;
    return;
  }
  // Re-collect a few times a second: switching items attaches new meshes under the arms.
  const DWORD now = GetTickCount();
  if (!g_hands.scannedAt || now - g_hands.scannedAt >= kRescanMs) {
    g_hands.scannedAt = now;
    Rescan(pawn);
  }
  for (const ObjectRef& mesh : g_hands.hidden)
    if (mesh.Alive()) SetDrawInGame(mesh.object, false);
}

void ResetNoHands() { g_hands = {}; }

}  // namespace wintek
