#pragma once
#include "core/Settings.h"
#include "engine/Engine.h"

// No Hands: hides the first-person arms (Mesh1P) and every mesh attached under them that the player owns,
// except shields, matching Knucklebutt's CollectBody.
namespace wintek {

void TickNoHands(const IniSettings& settings, Address pawn);
void ResetNoHands();

}  // namespace wintek
