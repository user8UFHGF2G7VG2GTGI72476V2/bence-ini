#pragma once
#include "engine/Engine.h"
namespace wintek {
void TickBlackStructures(const GameContext& game,bool wanted);
void ResetBlackStructures();
void FlushBlackStructures(unsigned timeoutMs);
}
