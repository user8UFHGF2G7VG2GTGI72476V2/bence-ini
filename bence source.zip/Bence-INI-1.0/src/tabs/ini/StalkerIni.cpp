#include "tabs/ini/StalkerIni.h"
#include "core/Process.h"
#include "engine/Debugger.h"
#include "engine/PostProcessVolumes.h"
#include <windows.h>
#include <algorithm>
#include <iterator>
#include <thread>

namespace wintek {

namespace {

constexpr float kMinDistance = 10.0f, kMaxDistance = 240.0f;  // metres
constexpr std::int32_t kMaxBlendables = 64;

// Everything the feature calls or uses, resolved once on a worker thread.
struct GameObjects {
  Address material = 0;   // Material ESPMaterialOutline
  Address makeMid = 0;    // Function KismetMaterialLibrary.CreateDynamicMaterialInstance
  Address kismet = 0;     // Default__KismetMaterialLibrary
  Address setScalar = 0;  // Function MaterialInstanceDynamic.SetScalarParameterValue
  Address setVector = 0;  // Function MaterialInstanceDynamic.SetVectorParameterValue
  std::int32_t fillName = 0, depthName = 0, backgroundName = 0;

  bool Complete() const {
    return material && makeMid && kismet && setScalar && setVector && fillName && depthName && backgroundName;
  }
};

enum class Search { NotStarted, Running, Done };

// ProcessEvent parameter blocks, laid out as the game functions expect.
struct NameParam { std::int32_t index, number; };
struct MakeMidParams { Address worldContext, parent, result; };
struct ScalarParams { NameParam name; float value; };
struct VectorParams { NameParam name; float rgba[4]; };

// Where each block lives in the memory we allocate in ARK (data only, never executed).
constexpr Address kMakeMidAt = 0x00, kFillAt = 0x20, kDepthAt = 0x30, kBackgroundAt = 0x40, kParamBytes = 0x100;

GameObjects g_objects;
std::atomic<Search> g_search{ Search::NotStarted };

struct {
  Address params = 0;
  ObjectRef mid;
  Address midClass = 0;
  bool creating = false;
  std::uint64_t createTicket = 0;
  ObjectRef volume;  // the volume holding our material, empty if none
  float appliedDistance = -1.0f;
} g_stalker;

std::atomic<Address> g_ignoreHealthFlag{ 0 };

// Finds the names first (one pass over GNames), then the objects by name index (one pass over GObjects).
void FindGameObjects(Address namesAddress) {
  using namespace offsets;
  enum { kOutline, kMakeMid, kKismet, kSetScalar, kSetVector, kFill, kDepth, kBackground, kMaterial, kKismetLibrary, kMidClass, kCount };
  static const char* const kNames[kCount] = { "ESPMaterialOutline", "CreateDynamicMaterialInstance", "Default__KismetMaterialLibrary",
                                              "SetScalarParameterValue", "SetVectorParameterValue", "ESPFillIntensity", "ESPDepth",
                                              "BackgroundColor", "Material", "KismetMaterialLibrary", "MaterialInstanceDynamic" };
  std::int32_t id[kCount];
  std::fill(std::begin(id), std::end(id), -1);

  const Address table = Read<Address>(namesAddress);
  std::vector<Address> entries(kNamesPerChunk);
  for (int c = 0; c < kMaxNameChunks && table; ++c) {
    const Address chunk = Read<Address>(table + c * sizeof(Address));
    if (!chunk) break;
    if (!g_memory.ReadRaw(chunk, entries.data(), entries.size() * sizeof(Address))) continue;
    for (int i = 0; i < kNamesPerChunk; ++i) {
      char entry[kNameText + 40] = {};
      if (!entries[i] || !g_memory.ReadRaw(entries[i], entry, sizeof(entry)) || (entry[0] & 1)) continue;
      for (int k = 0; k < kCount; ++k)
        if (id[k] < 0 && !std::strcmp(entry + kNameText, kNames[k])) id[k] = c * kNamesPerChunk + i;
    }
  }

  GameObjects found;
  found.fillName = (std::max)(id[kFill], 0);
  found.depthName = (std::max)(id[kDepth], 0);
  found.backgroundName = (std::max)(id[kBackground], 0);
  auto nameIndex = [](Address o) { return Read<std::int32_t>(o + object::kName); };
  ForEachObject([&](Address o, std::int32_t) {
    const std::int32_t name = nameIndex(o);
    const std::int32_t outer = nameIndex(Read<Address>(o + object::kOuter));
    if (name == id[kOutline] && nameIndex(ClassOf(o)) == id[kMaterial]) found.material = o;
    else if (name == id[kKismet]) found.kismet = o;
    else if (name == id[kMakeMid] && outer == id[kKismetLibrary]) found.makeMid = o;
    else if (name == id[kSetScalar] && outer == id[kMidClass]) found.setScalar = o;
    else if (name == id[kSetVector] && outer == id[kMidClass]) found.setVector = o;
    return true;
  });
  g_objects = found;
  g_search = Search::Done;
}

// The camera rebuilds this flag every frame, so it's written from the debugger's per-frame callback.
void WriteIgnoreHealthFlag(std::uintptr_t) {
  if (const Address flag = g_ignoreHealthFlag) Write<std::uint8_t>(flag, 1);
}

bool MidAlive() { return g_stalker.mid.Alive() && ClassOf(g_stalker.mid.object) == g_stalker.midClass; }

void QueueDistance(float metres) {
  Write(g_stalker.params + kDepthAt, ScalarParams{ { g_objects.depthName, 0 }, metres * 100.0f });
  QueueProcessEvent(g_stalker.mid.object, g_objects.setScalar, g_stalker.params + kDepthAt);
  g_stalker.appliedDistance = metres;
}

// Knucklebutt's EnsureMID. Creating the material takes a frame or two; returns true once it exists.
bool EnsureMaterial(Address pawn, float metres) {
  if (MidAlive()) return true;
  g_stalker.mid = {};
  g_stalker.volume = {};
  if (!g_stalker.params) {
    g_stalker.params = reinterpret_cast<Address>(VirtualAllocEx(g_process.handle, nullptr, kParamBytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    if (!g_stalker.params) return false;
  }

  if (g_stalker.creating) {
    if (CompletedCalls() < g_stalker.createTicket) return false;
    g_stalker.creating = false;
    const Address mid = Read<Address>(g_stalker.params + kMakeMidAt + offsetof(MakeMidParams, result));
    if (!mid) return false;
    g_stalker.mid = ObjectRef::Of(mid);
    g_stalker.midClass = ClassOf(mid);
    Write(g_stalker.params + kFillAt, ScalarParams{ { g_objects.fillName, 0 }, 0.0f });
    Write(g_stalker.params + kBackgroundAt, VectorParams{ { g_objects.backgroundName, 0 }, { 0.0f, 0.0f, 0.0f, 0.0f } });
    QueueProcessEvent(mid, g_objects.setScalar, g_stalker.params + kFillAt);
    QueueDistance(metres);
    QueueProcessEvent(mid, g_objects.setVector, g_stalker.params + kBackgroundAt);
    return true;
  }

  if (!pawn || !DebuggerAttached()) return false;
  Write(g_stalker.params + kMakeMidAt, MakeMidParams{ pawn, g_objects.material, 0 });
  g_stalker.createTicket = QueueProcessEvent(g_objects.kismet, g_objects.makeMid, g_stalker.params + kMakeMidAt);
  g_stalker.creating = true;
  return false;
}

// The volume's blendables, read in one go. Empty if the array looks wrong.
std::vector<Address> ReadBlendables(Address volume) {
  const auto array = Read<TArray>(volume + offsets::volume::kBlendables);
  std::vector<Address> items;
  if (!array.data || array.count <= 0 || array.count > kMaxBlendables) return items;
  items.resize(array.count);
  if (!g_memory.ReadRaw(array.data, items.data(), items.size() * sizeof(Address))) items.clear();
  return items;
}

bool VolumeHolds(Address volume, Address material) {
  const auto items = ReadBlendables(volume);
  return std::find(items.begin(), items.end(), material) != items.end();
}

// Knucklebutt's FindVolume + Push: an enabled volume, unbound preferred, with room in its blendables.
bool AddToVolume() {
  using namespace offsets::volume;
  if (g_stalker.volume.Alive() && VolumeHolds(g_stalker.volume.object, g_stalker.mid.object)) return true;
  g_stalker.volume = {};

  const PostProcessVolume* pick = nullptr;
  for (const PostProcessVolume& v : Volumes()) {
    if (!(v.flags & kEnabled) || !v.ref.Alive()) continue;
    const auto blendables = Read<TArray>(v.address() + kBlendables);
    if (!blendables.data || blendables.count < 0 || blendables.count >= blendables.max || blendables.max > kMaxBlendables) continue;
    if (!pick || ((v.flags & kUnbound) && !(pick->flags & kUnbound))) pick = &v;
  }
  if (!pick) return false;
  const auto blendables = Read<TArray>(pick->address() + kBlendables);
  Write(blendables.data + blendables.count * sizeof(Address), g_stalker.mid.object);
  Write(pick->address() + kBlendables + offsetof(TArray, count), blendables.count + 1);
  g_stalker.volume = pick->ref;
  return true;
}

void RemoveFromVolume() {
  using namespace offsets::volume;
  // A volume from a world that has since unloaded is freed memory: never write to it.
  const Address volume = g_stalker.volume.Alive() ? g_stalker.volume.object : 0;
  g_stalker.volume = {};
  if (!volume) return;
  // Like TArray::RemoveAt: shift the rest down, then shrink the count. Every copy goes, in case one was ever
  // added twice.
  std::vector<Address> items = ReadBlendables(volume);
  const auto end = std::remove(items.begin(), items.end(), g_stalker.mid.object);
  if (end == items.end()) return;
  items.erase(end, items.end());
  if (!items.empty()) g_memory.WriteRaw(Read<Address>(volume + kBlendables), items.data(), items.size() * sizeof(Address));
  Write(volume + kBlendables + offsetof(TArray, count), static_cast<std::int32_t>(items.size()));
}

bool Apply(Address pawn, float metres) {
  if (!EnsureMaterial(pawn, metres)) return false;
  if (g_stalker.appliedDistance != metres) QueueDistance(metres);
  return AddToVolume();
}

}  // namespace

void TickStalkerIni(const IniSettings& settings, const GameContext& game, bool restoring) {
  static bool callbackSet = false;
  if (!callbackSet) {
    callbackSet = true;
    SetFrameCallback(DebuggerClient::StalkerIni, WriteIgnoreHealthFlag);
  }

  const bool wanted = settings.stalker.on && !restoring;
  RequestDebugger(DebuggerClient::StalkerIni, wanted);
  if (wanted && g_search == Search::NotStarted) {
    g_search = Search::Running;
    std::thread(FindGameObjects, GNames()).detach();
  }

  const bool ready = g_search == Search::Done && g_objects.Complete();
  const float metres = std::clamp(settings.stalkerDistance, kMinDistance, kMaxDistance);
  const bool active = wanted && ready && Apply(game.pawn, metres);
  if (!active && g_stalker.volume.object) RemoveFromVolume();
  g_ignoreHealthFlag = active && game.camera ? game.camera + offsets::camera::kIgnoreHealthShading : 0;
}

bool StalkerOutlineReady() { return g_stalker.volume.Alive() && MidAlive(); }

void ResetStalkerIni() {
  g_objects = {};
  if (g_search == Search::Done) g_search = Search::NotStarted;
  g_stalker = {};  // the parameter memory belonged to the old process
  g_ignoreHealthFlag = 0;
}

}  // namespace wintek
