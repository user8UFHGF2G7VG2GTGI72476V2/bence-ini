#pragma once
#include "tabs/ini/ViewMode.h"

// No Foliage: hides grass and other ground clutter.
namespace wintek {

inline void ApplyNoFoliage(const IniSettings& s, ViewEdit& view) {
  if (s.noFoliage.on) view.Hide(ShowFlag::GroundClutter);
}

}  // namespace wintek
