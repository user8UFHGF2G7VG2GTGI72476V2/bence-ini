# Known issues

- Auto Forge and Take All were reported as nonfunctional in the external build. v28.33 corrects the Take All inventory-pointer reader and displays game-call connection errors for Auto Forge. Both still need live verification.
- Passing regression tests does not confirm game function layouts, server acceptance, or completed transfers.
- Auto Imprint handles pet and food care; walking care still requires walking.
- Resource Pull, structure snapping, and Black Structure need further in-game testing. See their individual notes for implementation limits.
- This source builds the external application. The separate injectable launcher was disabled after Windows terminated packaged ARK while loading its DLL (0xC000047E).
