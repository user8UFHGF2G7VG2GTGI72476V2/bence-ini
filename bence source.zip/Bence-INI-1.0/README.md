# Bence INI

External Windows x64 client for the Microsoft Store / Xbox-app version of ARK.

## Build

Requires CMake 3.20+, Git, and Visual Studio 2022 or newer with Desktop development with C++ installed. CMake downloads Dear ImGui during configuration.

Run `build.bat`, or use:

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

Output: `build/Release/Bence INI.exe`.

## Project layout

- `src/core`, `src/engine`: process access, reflection and game-call queue.
- `src/client`, `src/ui`, `src/tabs`: application loop, menu and settings.
- `src/hud`, `src/misc`: overlays and automation.
- `assets`: embedded fonts and images.
- `tests`: isolated regression tests.

## Settings

Startup settings and named profiles are stored in:

`%LOCALAPPDATA%/Packages/StudioWildcard.4558480580BB9_1w2mm55455e38/AC/Bence INI`

See [FEATURES.md](FEATURES.md) for controls and [KNOWN-ISSUES.md](KNOWN-ISSUES.md) for current limitations.

## Tests

Configure with `-DBENCE_BUILD_TESTS=ON` to build the regression tests. Run `AutomationTests` and `ConfigProfilesTests` with separate temporary data directories. `MenuSmokeTests` takes no arguments. These tests use local fixtures; they do not test transfers in ARK.
