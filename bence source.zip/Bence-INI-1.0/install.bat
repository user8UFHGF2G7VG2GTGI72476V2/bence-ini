@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Bence INI - install and build
echo ============================================
echo   Bence INI - install tools and build
echo ============================================
echo.

rem ---- winget is needed to download the tools ----
where winget >nul 2>&1
if errorlevel 1 goto nowinget

rem ---- Visual Studio C++ build tools ----
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSPATH="
call :findvs
if defined VSPATH goto havevs
echo [1/3] Visual Studio C++ build tools not found. Downloading them (about 2-4 GB, this takes a while)...
echo       Click Yes if Windows asks for permission.
winget install -e --id Microsoft.VisualStudio.2022.BuildTools --accept-package-agreements --accept-source-agreements --override "--wait --passive --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
call :findvs
if not defined VSPATH goto vsfail
:havevs
echo [1/3] Visual Studio C++ tools: OK  (%VSPATH%)

rem ---- CMake: use Visual Studio's own copy if it has one, otherwise install it ----
set "VSCMAKE=%VSPATH%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin"
if exist "%VSCMAKE%\cmake.exe" set "PATH=%VSCMAKE%;%PATH%"
if exist "%ProgramFiles%\CMake\bin\cmake.exe" set "PATH=%ProgramFiles%\CMake\bin;%PATH%"
where cmake >nul 2>&1
if not errorlevel 1 goto havecmake
echo [2/3] CMake not found. Downloading it...
winget install -e --id Kitware.CMake --accept-package-agreements --accept-source-agreements --silent
set "PATH=%ProgramFiles%\CMake\bin;%PATH%"
where cmake >nul 2>&1
if errorlevel 1 goto cmakefail
:havecmake
echo [2/3] CMake: OK

rem ---- Git (the build uses it to download Dear ImGui) ----
set "VSGIT=%VSPATH%\Common7\IDE\CommonExtensions\Microsoft\TeamFoundation\Team Explorer\Git\cmd"
if exist "%VSGIT%\git.exe" set "PATH=%VSGIT%;%PATH%"
if exist "%ProgramFiles%\Git\cmd\git.exe" set "PATH=%ProgramFiles%\Git\cmd;%PATH%"
where git >nul 2>&1
if not errorlevel 1 goto havegit
echo [3/3] Git not found. Downloading it...
winget install -e --id Git.Git --accept-package-agreements --accept-source-agreements --silent
set "PATH=%ProgramFiles%\Git\cmd;%PATH%"
where git >nul 2>&1
if errorlevel 1 goto gitfail
:havegit
echo [3/3] Git: OK
echo.
echo Everything is installed. Building Bence INI now...
echo.
call build.bat
exit /b %errorlevel%

:findvs
set "VSPATH="
if not exist "%VSWHERE%" exit /b 0
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"
exit /b 0

:nowinget
echo winget isn't available on this PC, so the tools can't be downloaded automatically.
echo Install "App Installer" from the Microsoft Store, then run install.bat again.
goto fail
:vsfail
echo The Visual Studio C++ build tools didn't finish installing.
echo If the installer is still running, wait for it to finish, then run install.bat again.
goto fail
:cmakefail
echo CMake didn't install. Close this window, open a new one and run install.bat again.
goto fail
:gitfail
echo Git didn't install. Close this window, open a new one and run install.bat again.
goto fail
:fail
echo.
echo INSTALL FAILED - screenshot this window and send it.
pause
exit /b 1
