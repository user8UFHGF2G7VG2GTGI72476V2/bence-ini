# Corrupted Dino ESP

Open the HUD tab and enable **Corrupted Dino ESP**. Set its range from 20 to 700 metres (default 300 m), and optionally assign a hotkey. Settings and the hotkey are saved with the existing configuration system.

Purple markers show a creature's class-derived name and distance, including through terrain. These are position markers, not Stalker INI silhouette outlines. Use ARK in windowed or borderless mode, as with the other overlays.

The feature shares the Spyglass background actor scan but works with Spyglass switched off. New actors are discovered on the existing approximately 2.5-second scan interval; positions update on feature ticks. It only considers PrimalDinoCharacter actors whose class or ancestor class contains `corrupt` (case insensitive), and skips dead actors. Display names do not control matching. Only client-loaded actors can appear, regardless of the selected range.

Validation: release compilation is checked separately. In-game classification and positioning still require testing against the target ARK build. A modded corrupted creature whose class ancestry lacks the corruption token will not appear.

Suggested in-game checks: enable this option with Spyglass and Stalker INI off; approach both a normal and corrupted dino; confirm that only the corrupted dino receives a purple marker; change range, turn the camera, toggle via hotkey, and save/reload configuration. Check that disabling the option removes its markers.

Revision v28.3: adds a bottom-left ESP status line and Config diagnostics with scan/filter counts and sample dino classes. Removes the HUD-pointer requirement when inventory state is unavailable. Adds an approximate pawn/controller camera fallback if the preferred camera cache lookup fails; marker placement may be inaccurate in third person or with a changed FOV. Release build passed; the reported in-game failure has not yet been reproduced or confirmed fixed. If markers remain absent, report the full status line and Config > Diagnostics > Dino classes while standing near a corrupted dino.

Revision v28.4: removes the bottom-of-screen scanning/status text. Keeps v28.3 ESP detection and camera behavior, which the user confirmed works. Diagnostics remain available in Config. Release build passed.
